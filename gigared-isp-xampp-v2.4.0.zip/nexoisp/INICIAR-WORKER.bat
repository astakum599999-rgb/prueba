@echo off
setlocal
title GIGARED ISP - Procesador de operaciones
cd /d "%~dp0"
set "NEXOISP_PHP=%~dp0..\..\php\php.exe"
if not exist "%NEXOISP_PHP%" (
  echo No se encontro PHP de XAMPP en la ruta habitual.
  echo Copia la carpeta nexoisp dentro de C:\xampp\htdocs\
  echo Si usas otra instalacion, ejecuta su php.exe con bin\worker.php.
  pause
  exit /b 1
)
if not exist "%~dp0storage\config.php" (
  echo Primero completa la instalacion en http://localhost/nexoisp/
  pause
  exit /b 1
)
echo GIGARED ISP: procesando consultas y tareas permitidas por el modo de red.
echo Apache y MySQL deben estar encendidos en XAMPP.
echo Manten esta ventana abierta. Para detener el proceso, pulsa Ctrl+C.
echo.
"%NEXOISP_PHP%" "%~dp0bin\worker.php"
set "NEXOISP_RESULT=%ERRORLEVEL%"
echo.
echo El procesador se ha detenido. Codigo de salida: %NEXOISP_RESULT%
pause
exit /b %NEXOISP_RESULT%
