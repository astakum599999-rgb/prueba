<?php
declare(strict_types=1);
namespace Nexo;

require_once __DIR__ . '/secret-import.php';

/** A device address must be a literal unicast host, never a pool, hostname or URL. */
function clientIpAddress(mixed $value): ?string
{
    if (!is_string($value) || $value === '' || strlen($value) > 45 || filter_var($value, FILTER_VALIDATE_IP) === false) return null;
    $packed = @inet_pton($value);
    if (!is_string($packed)) return null;
    if (strlen($packed) === 4) {
        $first = ord($packed[0]);
        if ($first === 0 || $first === 127 || $first >= 224) return null;
    } else {
        if ($packed === str_repeat("\0",16) || $packed === str_repeat("\0",15) . "\1" || ord($packed[0]) === 255) return null;
        // Mapped IPv4 hosts retain the same validity rules as their IPv4 form.
        if (substr($packed,0,12) === str_repeat("\0",10) . "\xff\xff" && clientIpAddress(inet_ntop(substr($packed,12))) === null) return null;
    }
    $address = inet_ntop($packed);
    return is_string($address) ? strtolower($address) : null;
}

function clientIpEntry(array $row, string $source): ?array
{
    $address = clientIpAddress($row['address'] ?? null);
    if ($address === null) return null;
    $entry = ['address'=>$address,'source'=>$source,'routerId'=>$row['routerId'],'routerName'=>$row['routerName'],
        'username'=>is_string($row['username'] ?? null) ? secretImportDisplayText($row['username']) : null,
        'observedAt'=>$row['observedAt'] ?? null,'present'=>true];
    if (isset($row['serviceId'])) $entry['serviceId'] = $row['serviceId'];
    if (isset($row['secretId'])) $entry['secretId'] = $row['secretId'];
    return $entry;
}

function clientIpAddressesWarm(array $clientIds): void
{
    $ids = array_values(array_unique(array_filter($clientIds,'is_string')));
    $missing = array_values(array_filter($ids, static fn(string $id): bool => !array_key_exists($id,$GLOBALS['nexo_client_ips'] ?? [])));
    if (!$missing) return;
    foreach ($missing as $id) $GLOBALS['nexo_client_ips'][$id] = [];
    foreach (array_chunk($missing,500) as $batch) {
        $slots = implode(',',array_fill(0,count($batch),'?'));
        $services = fetchAll("SELECT s.clientId,s.id AS serviceId,s.ipAddress AS address,s.username,s.routerId,r.name AS routerName,s.updatedAt AS observedAt FROM `Service` s JOIN `Router` r ON r.id=s.routerId WHERE s.clientId IN ($slots) AND s.desiredState<>'RETIRED' AND (s.appliedState IS NULL OR s.appliedState<>'RETIRED') ORDER BY s.id",$batch);
        $secrets = fetchAll("SELECT s.clientId,s.id AS secretId,s.remoteAddress AS address,s.username,s.routerId,r.name AS routerName,s.lastSeenAt AS observedAt FROM `RouterSecretImport` s JOIN `Router` r ON r.id=s.routerId WHERE s.clientId IN ($slots) AND s.present=1 ORDER BY s.id",$batch);
        foreach ([['SERVICE',$services],['PPP_SECRET',$secrets]] as [$source,$rows]) {
            foreach ($rows as $row) {
                $entry = clientIpEntry($row,$source);
                if ($entry === null) continue;
                $key = $entry['routerId'] . ':' . $entry['address'];
                // A managed service is the first source when both observe one host.
                $GLOBALS['nexo_client_ips'][$row['clientId']][$key] ??= $entry;
            }
        }
        foreach ($batch as $id) $GLOBALS['nexo_client_ips'][$id] = array_values($GLOBALS['nexo_client_ips'][$id]);
    }
}

function clientIpAddresses(string $clientId): array
{
    clientIpAddressesWarm([$clientId]);
    return $GLOBALS['nexo_client_ips'][$clientId] ?? [];
}

/** Active PPP sessions are queried only by an explicit staff action, never by list rendering. */
function clientIpActive(string $clientId, array $actor): array
{
    if (!in_array($actor['role'],['ADMIN','TECHNICIAN'],true)) throw new HttpError(403,'No dispone de permisos para consultar sesiones PPP.','FORBIDDEN');
    if (!fetchOne('SELECT id FROM `Client` WHERE id=?',[$clientId])) throw new HttpError(404,'Cliente no encontrado.','NOT_FOUND');
    $accounts = fetchAll("SELECT s.routerId,s.username,s.id AS secretId FROM `RouterSecretImport` s WHERE s.clientId=? AND s.present=1 AND s.pppService IN ('pppoe','any')",[$clientId]);
    $accounts = array_merge($accounts,fetchAll("SELECT s.routerId,s.username,s.id AS serviceId FROM `Service` s WHERE s.clientId=? AND s.type='PPPOE' AND s.desiredState<>'RETIRED' AND (s.appliedState IS NULL OR s.appliedState<>'RETIRED')",[$clientId]));
    $grouped = [];
    foreach ($accounts as $account) {
        if (!is_string($account['username']) || $account['username'] === '') continue;
        $key = 'u:' . bin2hex($account['username']);
        $grouped[$account['routerId']][$key] = $account;
    }
    if (count($accounts) > 100) throw new HttpError(422,'Consulta un cliente con hasta 100 cuentas PPP asociadas.','QUERY_LIMIT');
    $results = []; $errors = []; $succeeded = 0;
    foreach ($grouped as $routerId=>$routerAccounts) {
        $lockKey = 'router:' . $routerId;
        if (!lock($lockKey,5)) { $errors[] = ['routerId'=>$routerId,'message'=>'El router está ocupado. Repite la consulta.']; continue; }
        $transport = null;
        try {
            $router = fetchOne('SELECT * FROM `Router` WHERE id=?',[$routerId]);
            if (!$router) { $errors[] = ['routerId'=>$routerId,'message'=>'El router asociado ya no está disponible.']; continue; }
            $transport = secretImportTransport($router);
            foreach ($routerAccounts as $account) {
                if ($router['transport'] === 'REST' && preg_match('//u',$account['username']) !== 1) {
                    $errors[] = ['routerId'=>$routerId,'message'=>'Esta cuenta usa una codificación heredada que REST no puede consultar fielmente.']; continue;
                }
                $rows = $transport->print('/ppp/active',['name'=>$account['username']],['.proplist'=>'.id,name,address,service']);
                $succeeded++;
                foreach ($rows as $row) {
                    if (!is_array($row) || ($row['name'] ?? null) !== $account['username']) continue;
                    $entry = clientIpEntry(['address'=>$row['address'] ?? null,'routerId'=>$routerId,'routerName'=>$router['name'],'username'=>$account['username'],
                        'observedAt'=>now(),...array_intersect_key($account,array_flip(['serviceId','secretId']))],'PPP_ACTIVE');
                    if ($entry !== null) $results[$routerId . ':' . $entry['address']] = $entry;
                }
            }
        } catch (\Throwable) {
            $errors[] = ['routerId'=>$routerId,'message'=>'No se pudieron leer las sesiones PPP. Revisa conexión y permisos de lectura del router.'];
        } finally {
            $transport?->close(); unlock($lockKey);
        }
    }
    if (!$succeeded && $errors) throw new HttpError(502,'No se pudieron consultar las IP activas. Revisa conexión y permisos de lectura.','ROUTER_UNAVAILABLE');
    $message = $results ? 'IP observada en las sesiones PPP activas durante esta consulta.' : ($accounts ? 'No se encontró una IP válida en las sesiones activas de este cliente.' : 'Este cliente no tiene una cuenta PPP asociada para consultar su sesión.');
    if ($errors) $message .= ' Algunas cuentas no pudieron consultarse.';
    return ['results'=>array_values($results),'message'=>$message,'errors'=>$errors];
}

function clientIpAccessDispatch(string $method, string $route): bool
{
    if ($method === 'GET' && preg_match('#^/clients/([a-f0-9]{24})/ip-addresses/active$#D',$route,$match)) {
        $actor = permit('ADMIN','TECHNICIAN');
        rateLimit('client-ip-active:' . $actor['id'],30,60);
        json(clientIpActive($match[1],$actor));
    }
    return false;
}
