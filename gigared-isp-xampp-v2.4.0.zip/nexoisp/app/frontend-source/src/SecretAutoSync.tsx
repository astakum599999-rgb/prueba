import { useEffect, useRef, useState } from 'react';
import { RefreshCw } from 'lucide-react';
import { api } from './api';
import { date, errorMessage } from './ui';

interface AutoRouter {
  routerId: string;
  routerName: string;
  enabled: boolean;
  status: string;
  lastSuccessAt: string | null;
  nextRunAt: string | null;
  lastError: string | null;
}
interface AutoState {
  intervalSeconds: number;
  serverTime: string;
  routers: AutoRouter[];
  processed?: number;
  changed?: boolean;
}
const panelVisible = () => document.visibilityState !== 'hidden';

export function useSecretAutoSync({ enabled, userId, canRun, paused, refreshed }: {
  enabled: boolean; userId?: string; canRun: boolean; paused: boolean; refreshed: () => void;
}) {
  const [state, setState] = useState<AutoState | null>(null);
  const [error, setError] = useState('');
  const observed = useRef<string | null>(null);
  useEffect(() => { observed.current = null; setState(null); setError(''); }, [userId, enabled]);
  useEffect(() => {
    if (!enabled || !userId || paused) return;
    let stopped = false;
    let timer: number | undefined;
    let pending: AbortController | undefined;
    let deadline: number | undefined;
    const tick = async () => {
      window.clearTimeout(timer);
      if (stopped || pending || !panelVisible()) return;
      pending = new AbortController();
      deadline = window.setTimeout(() => pending?.abort(), 90000);
      let delay = 15000;
      try {
        const result = await api<AutoState>('/routers/secrets/auto-sync', {
          method: canRun ? 'POST' : 'GET', ...(canRun ? { body: '{}' } : {}),
          cache: 'no-store', signal: pending.signal,
        });
        if (stopped) return;
        setState(result); setError('');
        const stamp = JSON.stringify(result.routers.map(router => [router.routerId, router.lastSuccessAt]).sort());
        if (result.changed || (observed.current !== null && observed.current !== stamp)) refreshed();
        observed.current = stamp;
        // Drain other due routers without waiting a whole polling interval.
        if (canRun && (result.processed || 0) > 0) delay = 1000;
      } catch (err) {
        if (!stopped) setError(errorMessage(err));
      } finally {
        window.clearTimeout(deadline); pending = undefined;
        if (!stopped && panelVisible()) timer = window.setTimeout(() => void tick(), delay);
      }
    };
    const visible = () => { if (panelVisible()) void tick(); else window.clearTimeout(timer); };
    document.addEventListener('visibilitychange', visible);
    timer = window.setTimeout(() => void tick(), 350);
    return () => { stopped = true; window.clearTimeout(timer); window.clearTimeout(deadline); pending?.abort(); document.removeEventListener('visibilitychange', visible); };
  }, [enabled, userId, canRun, paused, refreshed]);
  return { state, error };
}

export function SecretAutoSyncStatus({ state, error, paused }: { state: AutoState | null; error: string; paused: boolean }) {
  const routers = state?.routers || [];
  const delayed = routers.filter(router => router.lastError).length;
  return <section className="secret-auto-status" aria-label="Estado de actualización de secrets">
    <div className="inline-gap"><RefreshCw size={15} /><strong>Secrets · actualización automática</strong><span className="subtle">Lectura cada {state?.intervalSeconds || 30} s</span></div>
    {delayed > 0 && <p className="secret-auto-warning">{delayed} {delayed === 1 ? 'router tiene' : 'routers tienen'} una lectura pendiente de reintento. Consulta el detalle.</p>}
    {error ? <p className="secret-auto-warning" role="status">No se pudo actualizar: {error}. Se conservan los últimos datos.</p> : paused ? <p className="subtle">El panel pausa sus consultas mientras editas. Los datos del formulario se conservan.</p> : !state ? <p className="subtle">Consultando el estado de actualización…</p> : !routers.length ? <p className="subtle">Importa los secrets de un router una vez para activar su lectura automática.</p> : <details><summary>Última lectura de {routers.length} {routers.length === 1 ? 'router' : 'routers'}</summary><ul>{routers.map(router => <li key={router.routerId}><strong>{router.routerName}</strong><span>{router.lastSuccessAt ? `Última lectura correcta: ${date(router.lastSuccessAt, true)}` : 'Primera lectura automática pendiente'}</span>{router.lastError && <span className="secret-auto-warning">{router.lastError}</span>}</li>)}</ul></details>}
    <p className="subtle secret-auto-help">Se actualiza con el panel abierto. Ejecuta INICIAR-WORKER.bat para continuar con el navegador cerrado. El intervalo aumenta temporalmente si el router no responde.</p>
  </section>;
}
