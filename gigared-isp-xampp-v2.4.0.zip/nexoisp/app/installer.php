<?php
declare(strict_types=1);

namespace Nexo;

use PDO;
use PDOException;
use Throwable;

const XAMPP_SCHEMA_VERSION = '001_initial';

function installerEscape(mixed $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function installerBasePath(): string
{
    $script = str_replace('\\', '/', (string) ($_SERVER['SCRIPT_NAME'] ?? '/install.php'));
    $base = rtrim(str_replace('\\', '/', dirname($script)), '/.');
    return preg_match('#^(?:/[A-Za-z0-9._~%\-]+)*$#D', $base) ? $base : '';
}

function installerIsHttps(): bool
{
    return (!empty($_SERVER['HTTPS']) && strtolower((string) $_SERVER['HTTPS']) !== 'off') || (int) ($_SERVER['SERVER_PORT'] ?? 0) === 443;
}

function installerDetectedOrigin(): string
{
    $host = (string) ($_SERVER['HTTP_HOST'] ?? 'localhost');
    if (!preg_match('/^[A-Za-z0-9.\-:\[\]]{1,260}$/D', $host)) {
        $host = 'localhost';
    }
    return (installerIsHttps() ? 'https://' : 'http://') . $host;
}

function installerOrigin(string $value): string
{
    $value = rtrim(trim($value), '/');
    $parts = parse_url($value);
    if ($parts === false || !isset($parts['scheme'], $parts['host']) || !in_array($parts['scheme'], ['http','https'], true) ||
        isset($parts['user'], $parts['pass']) || isset($parts['user']) || isset($parts['query']) || isset($parts['fragment']) || !empty($parts['path']) ||
        !preg_match('/^[A-Za-z0-9.\-:\[\]]+$/D', $parts['host']) || (isset($parts['port']) && ($parts['port'] < 1 || $parts['port'] > 65535))) {
        throw new HttpError(422, 'El origen web debe tener formato http://host:puerto o https://host, sin ruta ni credenciales.');
    }
    $scheme = strtolower($parts['scheme']);
    $port = $parts['port'] ?? null;
    if (($scheme === 'http' && $port === 80) || ($scheme === 'https' && $port === 443)) {
        $port = null;
    }
    return $scheme . '://' . strtolower($parts['host']) . ($port !== null ? ':' . $port : '');
}

function installerRequirements(): array
{
    return [
        ['name' => 'PHP 8.2 o posterior', 'ok' => PHP_VERSION_ID >= 80200],
        ['name' => 'PDO MySQL', 'ok' => extension_loaded('pdo_mysql')],
        ['name' => 'OpenSSL para cifrado y conexiones TLS', 'ok' => extension_loaded('openssl')],
        ['name' => 'Carpeta storage con permiso de escritura', 'ok' => is_dir(APP_ROOT . '/storage') && is_writable(APP_ROOT . '/storage')],
        ['name' => 'Apache mod_rewrite', 'ok' => !function_exists('apache_get_modules') || in_array('mod_rewrite', apache_get_modules(), true)],
    ];
}

function installerSettings(array $input): array
{
    $settings = [
        'db_host' => trim((string) ($input['db_host'] ?? '127.0.0.1')),
        'db_port' => filter_var($input['db_port'] ?? 3306, FILTER_VALIDATE_INT),
        'db_name' => trim((string) ($input['db_name'] ?? 'nexoisp')),
        'db_user' => trim((string) ($input['db_user'] ?? 'root')),
        'db_password' => (string) ($input['db_password'] ?? ''),
        'admin_email' => strtolower(trim((string) ($input['admin_email'] ?? ''))),
        'admin_password' => (string) ($input['admin_password'] ?? ''),
        'web_origin' => installerOrigin((string) ($input['web_origin'] ?? installerDetectedOrigin())),
        'router_ca_file' => trim((string) ($input['router_ca_file'] ?? '')),
        'allow_simulated_routers' => ($input['allow_simulated_routers'] ?? '') === '1',
        'payment_webhook_secret' => (string) ($input['payment_webhook_secret'] ?? ''),
    ];
    if (!preg_match('/^[A-Za-z0-9.\-:]{1,253}$/D', $settings['db_host']) || !$settings['db_port'] || $settings['db_port'] < 1 || $settings['db_port'] > 65535) {
        throw new HttpError(422, 'Revisa el host y el puerto de MySQL.');
    }
    if (!preg_match('/^[A-Za-z0-9_]{1,64}$/D', $settings['db_name']) || $settings['db_user'] === '' || strlen($settings['db_user']) > 128 || strlen($settings['db_password']) > 4096) {
        throw new HttpError(422, 'El nombre de base de datos sólo admite letras, números y guiones bajos; revisa también el usuario.');
    }
    if (!filter_var($settings['admin_email'], FILTER_VALIDATE_EMAIL) || strlen($settings['admin_email']) > 254) {
        throw new HttpError(422, 'Escribe un email válido para el administrador.');
    }
    $passwordBytes = strlen($settings['admin_password']);
    $argon = defined('PASSWORD_ARGON2ID') && in_array('argon2id', password_algos(), true);
    if ($passwordBytes < 12 || $passwordBytes > 128 || (!$argon && $passwordBytes > 72)) {
        throw new HttpError(422, $argon ? 'La contraseña debe tener entre 12 y 128 bytes.' : 'La contraseña debe tener entre 12 y 72 bytes en esta instalación de PHP.');
    }
    if (isset($input['admin_password_confirm']) && !hash_equals($settings['admin_password'], (string) $input['admin_password_confirm'])) {
        throw new HttpError(422, 'La confirmación de contraseña no coincide.');
    }
    if ($settings['payment_webhook_secret'] !== '' && (strlen($settings['payment_webhook_secret']) < 32 || strlen($settings['payment_webhook_secret']) > 512)) {
        throw new HttpError(422, 'El secreto del webhook debe tener entre 32 y 512 bytes o quedar vacío para generarlo automáticamente.');
    }
    if ($settings['router_ca_file'] !== '' && (!is_file($settings['router_ca_file']) || !is_readable($settings['router_ca_file']))) {
        throw new HttpError(422, 'El archivo de CA indicado no existe o PHP no puede leerlo.');
    }
    return $settings;
}

function installerConnect(array $settings): PDO
{
    try {
        $connection = new PDO(
            'mysql:host=' . $settings['db_host'] . ';port=' . $settings['db_port'] . ';charset=utf8mb4',
            $settings['db_user'], $settings['db_password'],
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false, PDO::ATTR_TIMEOUT => 10, PDO::MYSQL_ATTR_MULTI_STATEMENTS => false]
        );
        $connection->exec("SET time_zone = '+00:00'");
        $connection->exec("SET SESSION sql_mode = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION'");
    } catch (PDOException) {
        throw new HttpError(422, 'No se pudo conectar con MySQL. Inícialo en XAMPP y revisa host, puerto, usuario y contraseña.');
    }
    $version = (string) $connection->query('SELECT VERSION()')->fetchColumn();
    if (stripos($version, 'mariadb') !== false) {
        if (!preg_match('/(\d+\.\d+\.\d+)-MariaDB/i', $version, $match) || version_compare($match[1], '10.4.0', '<')) {
            throw new HttpError(422, 'Se requiere MariaDB 10.4 o posterior.');
        }
    } elseif (!preg_match('/^(\d+\.\d+\.\d+)/', $version, $match) || version_compare($match[1], '8.0.0', '<')) {
        throw new HttpError(422, 'Se requiere MariaDB 10.4 o MySQL 8.0 o posterior.');
    }
    $name = $settings['db_name'];
    try {
        $connection->exec("CREATE DATABASE IF NOT EXISTS `{$name}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    } catch (PDOException) {
        // An existing database can be used by an account without CREATE DATABASE.
    }
    try {
        $connection->exec("USE `{$name}`");
    } catch (PDOException) {
        throw new HttpError(422, 'La base de datos no existe o el usuario no tiene acceso. Créala desde phpMyAdmin o concede el permiso correspondiente.');
    }
    return $connection;
}

function installerApplySchema(PDO $connection): void
{
    $schema = file_get_contents(APP_ROOT . '/database/schema.sql');
    if ($schema === false || trim($schema) === '') {
        throw new HttpError(500, 'No se encontró el esquema SQL de la distribución.');
    }
    $connection->exec('CREATE TABLE IF NOT EXISTS `_nexoisp_migrations` (`name` VARCHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL PRIMARY KEY, `checksum` CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL, `appliedAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3)) ENGINE=InnoDB');
    $history = $connection->query('SELECT `name`,`checksum` FROM `_nexoisp_migrations` ORDER BY `name`')->fetchAll();
    $checksum = hash('sha256', $schema);
    if ($history !== []) {
        if ($history[0]['name'] !== XAMPP_SCHEMA_VERSION || !hash_equals($history[0]['checksum'], $checksum)) {
            throw new HttpError(409, 'El historial SQL no coincide con esta distribución. Conserva el esquema aplicado y usa la versión correspondiente.');
        }
        require_once __DIR__ . '/migrations.php';
        migrationStatus($connection);
        return;
    }
    // MariaDB commits DDL implicitly. Every statement is repeatable so a failed
    // initial installation can resume without erasing tables or user records.
    $statements = preg_split('/;\s*(?:\R|$)/', $schema);
    foreach ($statements ?: [] as $statement) {
        if (trim($statement) !== '') {
            $connection->exec($statement);
        }
    }
    $record = $connection->prepare('INSERT INTO `_nexoisp_migrations` (`name`,`checksum`) VALUES (?,?)');
    $record->execute([XAMPP_SCHEMA_VERSION, $checksum]);
}

function installerPersist(array $settings, PDO $connection): bool
{
    $passwordHash = hashPassword($settings['admin_password']);
    $encryptedRecords = (int) $connection->query('SELECT COUNT(*) FROM `Router`')->fetchColumn() +
        (int) $connection->query('SELECT COUNT(*) FROM `Service` WHERE `passwordEncrypted` IS NOT NULL')->fetchColumn();
    if ($encryptedRecords > 0) {
        throw new HttpError(409, 'Esta base contiene credenciales cifradas. Restaura su archivo storage/config.php original; no generes otra clave de cifrado.');
    }
    $createdAdmin = false;
    $connection->beginTransaction();
    try {
        if ((int) $connection->query('SELECT COUNT(*) FROM `User`')->fetchColumn() === 0) {
            $user = $connection->prepare('INSERT INTO `User` (`id`,`name`,`email`,`passwordHash`,`role`,`active`) VALUES (?,?,?,?,?,1)');
            $user->execute([id(), 'Administrador', $settings['admin_email'], $passwordHash, 'ADMIN']);
            $createdAdmin = true;
        } elseif ((int) $connection->query("SELECT COUNT(*) FROM `User` WHERE `role` = 'ADMIN' AND `active` = 1")->fetchColumn() === 0) {
            throw new HttpError(409, 'La base ya contiene usuarios sin un administrador activo. Recupera esa cuenta antes de continuar.');
        }
        $connection->commit();
    } catch (Throwable $error) {
        if ($connection->inTransaction()) {
            $connection->rollBack();
        }
        throw $error;
    }
    $saved = [
        'db_host' => $settings['db_host'], 'db_port' => (int) $settings['db_port'], 'db_name' => $settings['db_name'],
        'db_user' => $settings['db_user'], 'db_password' => $settings['db_password'],
        'encryption_key' => base64_encode(random_bytes(32)),
        'web_origin' => $settings['web_origin'], 'base_path' => installerBasePath(),
        'cookie_secure' => str_starts_with($settings['web_origin'], 'https://'),
        'session_hours' => 12, 'allow_simulated_routers' => $settings['allow_simulated_routers'],
        'router_ca_file' => $settings['router_ca_file'],
        'worker_secret' => base64urlEncode(random_bytes(32)),
        'payment_webhook_secret' => $settings['payment_webhook_secret'] !== '' ? $settings['payment_webhook_secret'] : bin2hex(random_bytes(32)),
        'installed_at' => now(), 'schema_version' => XAMPP_SCHEMA_VERSION,
    ];
    $file = tempnam(APP_ROOT . '/storage', '.config-');
    if ($file === false) {
        throw new HttpError(500, 'PHP no puede crear la configuración dentro de storage. Revisa los permisos de Windows.');
    }
    try {
        $content = "<?php\ndeclare(strict_types=1);\n\nreturn " . var_export($saved, true) . ";\n";
        if (file_put_contents($file, $content, LOCK_EX) !== strlen($content)) {
            throw new HttpError(500, 'No se pudo guardar la configuración local. Revisa espacio y permisos.');
        }
        @chmod($file, 0600);
        if (is_file(APP_ROOT . '/storage/config.php') || !rename($file, APP_ROOT . '/storage/config.php')) {
            throw new HttpError(409, 'La configuración ya existe o no se pudo finalizar su escritura.');
        }
        @chmod(APP_ROOT . '/storage/config.php', 0600);
    } finally {
        if (is_file($file)) {
            @unlink($file);
        }
    }
    return $createdAdmin;
}

function installerPerform(array $settings): bool
{
    $fileLock = @fopen(APP_ROOT . '/storage/install.lock', 'c');
    if ($fileLock === false || !flock($fileLock, LOCK_EX | LOCK_NB)) {
        if (is_resource($fileLock)) {
            fclose($fileLock);
        }
        throw new HttpError(409, 'Otra instalación está en curso o storage no permite escritura.');
    }
    @chmod(APP_ROOT . '/storage/install.lock', 0600);
    $connection = null;
    $locked = false;
    $name = 'nexo-install-' . substr(hash('sha256', $settings['db_name']), 0, 48);
    try {
        if (is_file(APP_ROOT . '/storage/config.php')) {
            throw new HttpError(423, 'La instalación ya está bloqueada.');
        }
        $connection = installerConnect($settings);
        $statement = $connection->prepare('SELECT GET_LOCK(?,10)');
        $statement->execute([$name]);
        $locked = (int) $statement->fetchColumn() === 1;
        if (!$locked) {
            throw new HttpError(409, 'La base de datos está siendo preparada por otra instalación.');
        }
        installerApplySchema($connection);
        require_once __DIR__ . '/migrations.php';
        migrationApply($connection);
        return installerPersist($settings, $connection);
    } finally {
        if ($connection instanceof PDO && $locked) {
            try {
                $statement = $connection->prepare('SELECT RELEASE_LOCK(?)');
                $statement->execute([$name]);
            } catch (PDOException) {
                // Connection closure releases the lock even after a database failure.
            }
        }
        flock($fileLock, LOCK_UN);
        fclose($fileLock);
    }
}

function runInstaller(): never
{
    ini_set('display_errors', '0');
    date_default_timezone_set('UTC');
    header('Content-Type: text/html; charset=utf-8');
    header('Cache-Control: no-store');
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: DENY');
    header("Content-Security-Policy: default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; frame-ancestors 'none'; base-uri 'none'");
    $basePath = installerBasePath();
    $locked = is_file(APP_ROOT . '/storage/config.php');
    $requirements = installerRequirements();
    $requirementsOk = !in_array(false, array_column($requirements, 'ok'), true);
    $error = null;
    $success = false;
    $createdAdmin = false;
    $values = ['db_host' => '127.0.0.1','db_port' => '3306','db_name' => 'nexoisp','db_user' => 'root','admin_email' => '', 'web_origin' => installerDetectedOrigin(), 'router_ca_file' => ''];
    if ($locked) {
        http_response_code(423);
    } else {
        ini_set('session.use_strict_mode', '1');
        ini_set('session.use_only_cookies', '1');
        session_name('nexoisp_installer');
        session_set_cookie_params(['httponly' => true,'secure' => installerIsHttps(),'samesite' => 'Strict','path' => $basePath !== '' ? $basePath : '/']);
        session_start();
        if (!isset($_SESSION['installer_csrf'])) {
            $_SESSION['installer_csrf'] = bin2hex(random_bytes(32));
        }
        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
            foreach (array_keys($values) as $field) {
                if (isset($_POST[$field]) && is_string($_POST[$field])) {
                    $values[$field] = substr($_POST[$field], 0, 300);
                }
            }
            try {
                if ((int) ($_SERVER['CONTENT_LENGTH'] ?? 0) > 65536) {
                    throw new HttpError(413, 'La solicitud de instalación es demasiado grande.');
                }
                if (!isset($_POST['csrf']) || !is_string($_POST['csrf']) || !hash_equals($_SESSION['installer_csrf'], $_POST['csrf'])) {
                    throw new HttpError(403, 'La sesión de instalación expiró. Recarga la página y vuelve a intentarlo.');
                }
                if (!$requirementsOk) {
                    throw new HttpError(422, 'Completa los requisitos de PHP, Apache y permisos antes de instalar.');
                }
                $settings = installerSettings($_POST);
                $createdAdmin = installerPerform($settings);
                $success = true;
                $_SESSION = [];
                session_destroy();
            } catch (HttpError $failure) {
                http_response_code($failure->status);
                $error = $failure->getMessage();
            } catch (Throwable) {
                http_response_code(500);
                $error = 'No se pudo completar la instalación. Revisa que MySQL use MariaDB 10.4+, que la cuenta tenga permisos de creación de tablas y que storage sea escribible.';
            }
        }
    }
    ?>
<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Instalación de GIGARED ISP</title>
<style>
*{box-sizing:border-box}body{margin:0;background:#0b1120;color:#dbe5f2;font:15px/1.55 system-ui,-apple-system,Segoe UI,sans-serif}main{max-width:1000px;margin:48px auto;padding:0 24px}.brand{color:#8ce5cf;letter-spacing:.18em;font-size:13px;font-weight:750}.hero{display:flex;align-items:flex-end;justify-content:space-between;gap:24px;margin-bottom:28px}h1{font-size:36px;line-height:1.15;letter-spacing:-.04em;margin:12px 0}h2{font-size:18px;margin:0 0 5px}p{color:#9fafc6;margin:0 0 18px}.badge{border:1px solid #2c4056;background:#122236;border-radius:99px;padding:7px 12px;white-space:nowrap;font-size:12px;color:#b3cfe3}.panel{background:#121d2d;border:1px solid #26364c;border-radius:18px;padding:26px;margin:20px 0;box-shadow:0 16px 40px #0002}.checks{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:9px;margin-top:18px}.check{font-size:13px;color:#b8c5d7}.check b{color:#69dfbb;margin-right:8px}.check.bad b{color:#ff9eaa}.fields{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:18px;margin-top:20px}label{display:block;color:#d4dfeb;font-size:13px;font-weight:600}input{display:block;width:100%;padding:12px 13px;margin-top:7px;color:#f4f7fa;background:#0b1523;border:1px solid #344860;border-radius:9px;font:inherit}input:focus{outline:2px solid #4ad3ac;outline-offset:2px}small{display:block;font-size:12px;color:#91a3ba;font-weight:400;margin-top:6px}.full{grid-column:1/-1}.action{border:0;display:inline-block;text-decoration:none;background:#7be4c2;color:#092b26;padding:13px 24px;border-radius:10px;font-weight:750;font-size:15px;cursor:pointer}.action:disabled{background:#38485b;color:#9aa8ba;cursor:not-allowed}.footer{display:flex;align-items:center;justify-content:space-between;gap:20px;margin-top:25px}.notice{padding:17px 20px;border-radius:12px;border:1px solid #43546b;background:#17263a;margin:20px 0;color:#cbd6e4}.error{border-color:#8e4757;background:#341e2b;color:#ffd1d8}.success{border-color:#296d5d;background:#102f2c;color:#a9f1d8}details summary{cursor:pointer;color:#b8cfe5;font-weight:650}.checkbox{display:flex;align-items:center;gap:10px}.checkbox input{display:inline-block;width:18px;height:18px;margin:0}.fine{font-size:12px;color:#8ea1bb;margin-top:25px}.standalone{max-width:700px;margin:80px auto}code{font-size:12px;background:#0b1523;padding:3px 6px;border-radius:4px}@media(max-width:640px){main{margin:30px auto;padding:0 16px}.hero,.footer{display:block}h1{font-size:29px}.badge{display:inline-block}.fields,.checks{grid-template-columns:1fr}.panel{padding:21px}.footer p{margin-bottom:14px}}
</style>
</head>
<body><main>
<header class="hero"><div><div class="brand">GIGARED ISP · XAMPP</div><h1>Tu centro de operaciones ISP</h1><p>Prepara la base de datos y crea tu cuenta de administración.</p></div><span class="badge">PHP 8.2 + MariaDB · Sin Node.js</span></header>
<?php if ($locked): ?>
<section class="panel standalone"><h2>La instalación ya está bloqueada</h2><p>La configuración local existe. El instalador no sobrescribe usuarios, contraseñas ni la clave de cifrado.</p><a class="action" href="<?= installerEscape($basePath . '/') ?>">Abrir GIGARED ISP</a><p class="fine">Para recuperar una instalación, restaura juntos la base de datos y su archivo <code>storage/config.php</code> original.</p></section>
<?php elseif ($success): ?>
<section class="panel standalone"><div class="notice success">Instalación completada. La configuración quedó protegida y el instalador está bloqueado.</div><h2>Ya puedes entrar al panel</h2><p><?= $createdAdmin ? 'Usa el email y la contraseña que acabas de elegir.' : 'Se conservaron las cuentas existentes. Usa sus credenciales anteriores.' ?></p><a class="action" href="<?= installerEscape($basePath . '/') ?>">Iniciar sesión</a><p class="fine">Inicia también el worker incluido para Windows: las sincronizaciones, facturas y cortes automáticos se procesan en segundo plano. Conserva una copia segura de <code>storage/config.php</code> junto a tus backups.</p></section>
<?php else: ?>
<section class="panel"><h2>Antes de empezar</h2><p>Inicia Apache y MySQL desde el panel de XAMPP. El instalador crea únicamente las tablas y tu primera cuenta; no carga clientes de ejemplo.</p><div class="checks"><?php foreach ($requirements as $requirement): ?><div class="check <?= $requirement['ok'] ? '' : 'bad' ?>"><b><?= $requirement['ok'] ? '✓' : '×' ?></b><?= installerEscape($requirement['name']) ?></div><?php endforeach; ?></div></section>
<?php if ($error !== null): ?><div class="notice error" role="alert"><?= installerEscape($error) ?></div><?php endif; ?>
<form method="post" action="<?= installerEscape((string) ($_SERVER['SCRIPT_NAME'] ?? 'install.php')) ?>" autocomplete="off">
<input type="hidden" name="csrf" value="<?= installerEscape($_SESSION['installer_csrf'] ?? '') ?>">
<section class="panel"><h2>1. Conexión con MySQL</h2><p>Los valores iniciales corresponden a una instalación local estándar de XAMPP. Puedes usar otra cuenta o una base ya creada.</p><div class="fields">
<label>Host<input name="db_host" required maxlength="253" value="<?= installerEscape($values['db_host']) ?>"></label>
<label>Puerto<input name="db_port" type="number" required min="1" max="65535" value="<?= installerEscape($values['db_port']) ?>"></label>
<label>Base de datos<input name="db_name" required maxlength="64" pattern="[A-Za-z0-9_]+" value="<?= installerEscape($values['db_name']) ?>"></label>
<label>Usuario de MySQL<input name="db_user" required maxlength="128" value="<?= installerEscape($values['db_user']) ?>"></label>
<label class="full">Contraseña de MySQL<input name="db_password" type="password" autocomplete="new-password"><small>Déjala vacía sólo si tu MySQL local de XAMPP utiliza una cuenta sin contraseña. No se muestra ni se registra.</small></label>
</div></section>
<section class="panel"><h2>2. Tu administrador</h2><p>Elige una contraseña propia. No hay credenciales de acceso predeterminadas.</p><div class="fields">
<label class="full">Email<input name="admin_email" type="email" required maxlength="254" value="<?= installerEscape($values['admin_email']) ?>" autocomplete="username"></label>
<label>Contraseña<input name="admin_password" type="password" required minlength="12" maxlength="128" autocomplete="new-password"><small>Al menos 12 caracteres; en PHP sin Argon2id, el límite es de 72 bytes.</small></label>
<label>Confirmar contraseña<input name="admin_password_confirm" type="password" required minlength="12" maxlength="128" autocomplete="new-password"></label>
<label class="full">Origen web autorizado<input name="web_origin" required maxlength="300" value="<?= installerEscape($values['web_origin']) ?>"><small>Incluye protocolo, host y puerto; no añadas la carpeta. La aplicación está en <code><?= installerEscape($basePath !== '' ? $basePath : '/') ?></code>. Con HTTPS las cookies se marcan seguras.</small></label>
</div></section>
<section class="panel"><details><summary>Opciones avanzadas de red y pagos</summary><div class="fields">
<label class="full">CA privada de los routers, opcional<input name="router_ca_file" maxlength="500" value="<?= installerEscape($values['router_ca_file']) ?>"><small>Ruta absoluta a un archivo PEM confiable del equipo. Se conserva la verificación TLS; no se descargan certificados automáticamente.</small></label>
<label class="full">Secreto del webhook de pagos, opcional<input name="payment_webhook_secret" type="password" minlength="32" maxlength="512" autocomplete="new-password"><small>Al menos 32 bytes. Si lo dejas vacío se genera uno aleatorio y se guarda únicamente en la configuración protegida.</small></label>
<label class="full checkbox"><input type="checkbox" name="allow_simulated_routers" value="1" <?= isset($_POST['allow_simulated_routers']) ? 'checked' : '' ?>>Habilitar routers simulados para laboratorio</label>
</div></details></section>
<div class="footer"><p>Se conservarán los usuarios existentes si esta es una reanudación.<br><small>Los secretos se guardan en <code>storage/config.php</code>, protegido por Apache.</small></p><button class="action" type="submit" <?= $requirementsOk ? '' : 'disabled' ?>>Instalar GIGARED ISP</button></div>
</form>
<?php endif; ?>
<p class="fine">La instalación local no necesita Docker, Node.js, Redis ni Composer. Antes de publicar en Internet configura HTTPS, protege MySQL y limita el acceso a la red de administración.</p>
</main></body></html>
<?php
    exit;
}
