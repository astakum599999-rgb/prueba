<?php
declare(strict_types=1);
namespace Nexo;

use DateTimeImmutable;
use DateTimeZone;
use Throwable;

require_once __DIR__ . '/secret-import.php';
// The CLI worker needs the same pending-edit guards as authenticated web imports.
require_once __DIR__ . '/client-name-sync.php';

const SECRET_AUTO_SYNC_INTERVAL = 30;

function secretAutoSyncAfter(int $seconds): string
{
    return (new DateTimeImmutable('now', new DateTimeZone('UTC')))->modify('+' . max(0, $seconds) . ' seconds')->format('Y-m-d H:i:s.v');
}

/** A previous successful import is the opt-in; unimported routers are never read. */
function secretAutoSyncEnrollImported(): void
{
    db()->exec("INSERT IGNORE INTO `RouterSecretAutoSync` (routerId,nextRunAt,updatedAt)
        SELECT r.id,UTC_TIMESTAMP(3),UTC_TIMESTAMP(3) FROM `Router` r
        LEFT JOIN `RouterSecretAutoSync` currentSync ON currentSync.routerId=r.id
        WHERE currentSync.routerId IS NULL AND r.transport IN ('REST','SOCKET') AND
        (EXISTS (SELECT 1 FROM `RouterSecretImport` s WHERE s.routerId=r.id)
         OR EXISTS (SELECT 1 FROM `AuditLog` a WHERE a.entityType='Router' AND a.entityId=r.id AND a.action='router.secrets.import'))");
}

/** Called in the import's own transaction, including successful empty inventories. */
function secretAutoSyncRecordManual(string $routerId, array $summary): void
{
    $timestamp = now();
    db()->prepare("INSERT INTO `RouterSecretAutoSync` (routerId,status,lastSuccessAt,nextRunAt,lastSummary,updatedAt)
        VALUES (?,'SUCCESS',?,?,?,?) ON DUPLICATE KEY UPDATE status='SUCCESS',lastSuccessAt=VALUES(lastSuccessAt),nextRunAt=VALUES(nextRunAt),lastErrorCode=NULL,lastError=NULL,consecutiveFailures=0,lastSummary=VALUES(lastSummary),updatedAt=VALUES(updatedAt)")
        ->execute([$routerId, $timestamp, secretAutoSyncAfter(SECRET_AUTO_SYNC_INTERVAL), json_encode($summary, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE), $timestamp]);
}

/** Stable, credential-free projection. This function never contacts any router. */
function secretAutoSyncStatus(): array
{
    $rows = fetchAll("SELECT r.id AS routerId,r.name AS routerName,s.enabled,s.status,s.lastStartedAt,s.lastSuccessAt,s.nextRunAt,s.lastErrorCode,s.lastError,s.consecutiveFailures,s.lastSummary
        FROM `Router` r LEFT JOIN `RouterSecretAutoSync` s ON s.routerId=r.id
        WHERE r.transport IN ('REST','SOCKET') AND
        (s.routerId IS NOT NULL OR EXISTS (SELECT 1 FROM `RouterSecretImport` i WHERE i.routerId=r.id)
         OR EXISTS (SELECT 1 FROM `AuditLog` a WHERE a.entityType='Router' AND a.entityId=r.id AND a.action='router.secrets.import'))
        ORDER BY r.name,r.id LIMIT 1000");
    foreach ($rows as &$row) {
        $row['enabled'] = $row['enabled'] === null || (bool)$row['enabled'];
        $row['status'] ??= 'WAITING';
        $row['consecutiveFailures'] = (int)($row['consecutiveFailures'] ?? 0);
        $row['lastSummary'] = is_string($row['lastSummary']) ? json_decode($row['lastSummary'], true, 16, JSON_THROW_ON_ERROR) : null;
        // A terminated PHP process releases its advisory locks. Its reservation
        // expires after two minutes; do not claim a stale process is still live.
        if ($row['status'] === 'RUNNING' && $row['nextRunAt'] !== null && $row['nextRunAt'] <= now()) $row['status'] = 'WAITING';
    }
    unset($row);
    return ['intervalSeconds' => SECRET_AUTO_SYNC_INTERVAL, 'networkReadOnly' => true,
        'mode' => 'worker-or-open-panel', 'serverTime' => now(), 'routers' => $rows];
}

function secretAutoSyncChanged(array $summary): bool
{
    foreach (['created','updated','namesUpdated'] as $field) if (($summary[$field] ?? 0) > 0) return true;
    return (int)($summary['absencesChanged'] ?? $summary['missing'] ?? 0) > 0;
}

/**
 * Run at most one due router for browser requests. The advisory scheduler lock
 * spans claim, network read and completion; the shared router lock is acquired
 * inside secretImportRun with no waiting. No database transaction spans I/O.
 */
function secretAutoSyncTick(?string $actorId = null, int $maximum = 1): array
{
    $maximum = max(1, min(5, $maximum));
    secretAutoSyncEnrollImported();
    $result = ['processed' => 0, 'changed' => false, 'failed' => 0, 'deferred' => 0];
    $due = fetchAll("SELECT s.routerId FROM `RouterSecretAutoSync` s JOIN `Router` r ON r.id=s.routerId
        WHERE s.enabled=1 AND s.nextRunAt<=? AND r.transport IN ('REST','SOCKET') ORDER BY s.nextRunAt,s.routerId LIMIT " . $maximum, [now()]);
    foreach ($due as $candidate) {
        $key = 'secret-auto:' . $candidate['routerId'];
        if (!lock($key, 0)) continue;
        try {
            $state = fetchOne('SELECT * FROM `RouterSecretAutoSync` WHERE routerId=?', [$candidate['routerId']]);
            if ($state === null || !(bool)$state['enabled'] || $state['nextRunAt'] > now()) continue;
            // A manual import can complete after the SELECT while holding the
            // shared router lock. Recheck its new cooldown atomically at claim.
            $claimAt = now();
            $claim = db()->prepare("UPDATE `RouterSecretAutoSync` SET status='RUNNING',lastStartedAt=?,nextRunAt=?,updatedAt=? WHERE routerId=? AND enabled=1 AND nextRunAt<=?");
            $claim->execute([$claimAt, secretAutoSyncAfter(120), $claimAt, $candidate['routerId'], $claimAt]);
            if ($claim->rowCount() !== 1) continue;
            try {
                $summary = secretImportRun($candidate['routerId'], $actorId, null, 0, true);
                $result['processed']++;
                $result['changed'] = $result['changed'] || secretAutoSyncChanged($summary);
                db()->prepare("UPDATE `RouterSecretAutoSync` SET status='SUCCESS',lastSuccessAt=?,nextRunAt=?,lastErrorCode=NULL,lastError=NULL,consecutiveFailures=0,lastSummary=?,updatedAt=? WHERE routerId=?")
                    ->execute([now(), secretAutoSyncAfter(SECRET_AUTO_SYNC_INTERVAL), json_encode($summary, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE), now(), $candidate['routerId']]);
            } catch (Throwable $error) {
                $deferred = $error instanceof HttpError && in_array($error->errorCode, ['RESOURCE_BUSY','PPPOE_EDIT_PENDING','CLIENT_NAME_UNCERTAIN'], true);
                $failures = min(1000, (int)$state['consecutiveFailures'] + ($deferred ? 0 : 1));
                $code = $deferred ? $error->errorCode : ($error instanceof HttpError && $error->errorCode === 'INVALID_ROUTER_RESPONSE' ? 'INVALID_ROUTER_RESPONSE' : 'ROUTER_UNAVAILABLE');
                $message = $deferred ? 'Lectura aplazada: hay otra operación o un cambio PPP pendiente de verificar.' :
                    ($code === 'INVALID_ROUTER_RESPONSE' ? 'El router devolvió una lista PPP inválida. Se conservan los datos anteriores.' : 'No se pudo leer el router. Se conservan los datos anteriores; se reintentará automáticamente.');
                $delay = $deferred ? 5 : min(300, SECRET_AUTO_SYNC_INTERVAL * (2 ** min(4, max(0, $failures - 1))));
                db()->prepare('UPDATE `RouterSecretAutoSync` SET status=?,nextRunAt=?,lastErrorCode=?,lastError=?,consecutiveFailures=?,updatedAt=? WHERE routerId=?')
                    ->execute([$deferred ? 'DEFERRED' : 'ERROR', secretAutoSyncAfter($delay), $code, $message, $failures, now(), $candidate['routerId']]);
                $result[$deferred ? 'deferred' : 'failed']++;
            }
        } finally {
            unlock($key);
        }
    }
    return $result;
}

function secretAutoSyncDispatch(string $method, string $route): bool
{
    if ($route !== '/routers/secrets/auto-sync') return false;
    if ($method === 'GET') {
        requireAuth();
        json(secretAutoSyncStatus());
    }
    if ($method === 'POST') {
        $actor = permit('ADMIN', 'TECHNICIAN');
        if (body() !== []) throw new HttpError(422, 'La actualización automática no admite parámetros ni cambios de configuración.', 'VALIDATION_ERROR');
        rateLimit('secret-auto:' . $actor['id'], 120, 60);
        if (function_exists('set_time_limit')) set_time_limit(60);
        ignore_user_abort(true);
        $result = secretAutoSyncTick($actor['id']);
        json($result + secretAutoSyncStatus());
    }
    return false;
}
