-- Estado local de lecturas periódicas; no contiene credenciales ni modifica RouterOS.
CREATE TABLE IF NOT EXISTS `RouterSecretAutoSync` (
  `routerId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `enabled` TINYINT(1) NOT NULL DEFAULT 1,
  `status` VARCHAR(16) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'WAITING',
  `lastStartedAt` DATETIME(3) NULL,
  `lastSuccessAt` DATETIME(3) NULL,
  `nextRunAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `lastErrorCode` VARCHAR(64) CHARACTER SET ascii COLLATE ascii_bin NULL,
  `lastError` VARCHAR(500) NULL,
  `consecutiveFailures` INT UNSIGNED NOT NULL DEFAULT 0,
  `lastSummary` JSON NULL,
  `updatedAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`routerId`),
  KEY `secret_auto_due_idx` (`enabled`,`nextRunAt`),
  CONSTRAINT `secret_auto_router_fk` FOREIGN KEY (`routerId`) REFERENCES `Router` (`id`) ON DELETE CASCADE,
  CONSTRAINT `secret_auto_enabled_check` CHECK (`enabled` IN (0,1)),
  CONSTRAINT `secret_auto_status_check` CHECK (`status` IN ('WAITING','RUNNING','SUCCESS','ERROR','DEFERRED'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
