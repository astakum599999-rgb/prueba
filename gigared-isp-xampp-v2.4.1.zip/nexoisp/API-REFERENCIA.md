# API propia de GIGARED ISP para XAMPP v2.4.1

Base local: `http://localhost/nexoisp/api/v1`. Los cuerpos son JSON. Los importes se expresan como enteros en centavos y cada moneda usa tres letras mayúsculas. Las fechas de calendario usan `YYYY-MM-DD`; los instantes recibidos requieren zona horaria (`Z` o desplazamiento). La persistencia y los informes usan UTC.

El administrador crea claves personales desde **Claves de API**. Una integración envía `Authorization: Api-Key <TOKEN>`; hereda el rol de su propietario y puede revocarse. El inicio web utiliza cookies HttpOnly; las escrituras con sesión requieren que `Origin` coincida con el configurado durante la instalación. El portal de clientes tiene su propia sesión y sus rutas no aceptan una clave administrativa como identidad de cliente.

Los listados usan `page`, `pageSize` (máximo 100) y, donde corresponde, `search`. Responden `{results, count, page, pageSize}`. Los errores contienen `{error:{code,message}}`. Es un contrato propio; no ofrece compatibilidad completa con las rutas ni los JSON de WispHub.

## Modo de red solo lectura

`/auth/me` anuncia las capacidades `networkReadOnly: true`, `secretImport: true` y `profileImport: true`. El valor predeterminado también protege instalaciones anteriores sin esa opción en su configuración. No hay un control en el panel para activar escrituras.

Las acciones que crean, editan, retiran, sincronizan, suspenden o reactivan servicios de red, configuran firewall o reintentan trabajos mutantes se rechazan con **409 `NETWORK_READ_ONLY`** antes de aplicarse. El controlador y los transportes bloquean además los comandos de modificación. Los datos administrativos locales y las consultas siguen disponibles. Registrar o probar un router no aplica configuración al equipo.

El worker nuevo sólo reclama los tipos de trabajo permitidos de lectura. No procesa los trabajos antiguos que modificarían la red ni programa facturación automática/autocorte. Los endpoints manuales `/billing/run` y `/billing/autocut` también rechazan con 409. Los pagos, anulaciones y promesas conservan su efecto financiero local sin generar reconexiones ni modificar estados de servicios.

## IPs PPP activas y recuadro de acceso

La capacidad `clientIpLive` anuncia el módulo. `POST /clients/ip-addresses/active` acepta únicamente `{clientIds:[id,...]}` (máximo100) para ADMIN/TECHNICIAN, con origen válido en sesiones y límite120 solicitudes/minuto. No es una modificación RouterOS. Agrupa las cuentas de esos clientes, lee `/ppp/active` una vez por router con propiedades `.id,name,address,service` y comparte un caché15s entre pestañas. Procesa hasta5 routers vencidos por llamada.

Devuelve `{intervalSeconds:15,expiresAfterSeconds:30,serverTime,processed,results:[{clientId,addresses,status,stale,observedAt,message}],routers,errors}`. Los estados son `FRESH`, `NO_SESSION`, `NO_ACCOUNT`, `PENDING` y `STALE`. Las identidades se comparan por bytes exactos y las cuentas ambiguas no se asocian a otro cliente. No se solicitan contraseñas. Los fallos conservan la observación interna y devuelven IPs activas vacías/caducadas; el navegador también retira observaciones vencidas a los30s. Una cuenta sin sesión no recibe una IP inventada.

El listado normal de clientes sigue sirviendo IPs configuradas sin consultar RouterOS. El panel visible consulta el lote cada15s; no hay botón Consultar IP actual. El endpoint individual anterior `GET /clients/:id/ip-addresses/active` permanece para compatibilidad y conserva sus permisos y límite30/minuto; la interfaz nueva no lo llama por cada fila.

Pulsar una IP abre un iframe HTTP:80 en un recuadro. HTTP/HTTPS y puerto son configurables; Cargar acceso aplica la selección sin abrir otra pestaña. Es navegación directa desde el PC, sin proxy ni contraseñas en URLs. Las restricciones de marcos, cookies, certificados y contenido mixto del navegador o dispositivo siguen aplicándose. Consulta IP-CLIENTES.txt e IP-AUTOMATICA.txt.

## Actualización automática de secrets

La capacidad `secretAutoSync` identifica este módulo nativo. `GET /routers/secrets/auto-sync` requiere una sesión administrativa o clave de personal válida y devuelve `{intervalSeconds:30,mode:"worker-or-open-panel",networkReadOnly:true,serverTime,routers:[{routerId,routerName,enabled,status,lastStartedAt,lastSuccessAt,nextRunAt,lastErrorCode,lastError,consecutiveFailures,lastSummary}]}` sin consultar el router ni incluir credenciales.

`POST` a la misma ruta con `{}` requiere ADMIN o TECHNICIAN y el origen permitido para sesiones. Procesa como máximo un router vencido y agrega `{processed,changed,failed,deferred}` al estado. Una reserva persistida y los bloqueos del router impiden lecturas duplicadas entre pestañas y worker. El límite es120 solicitudes/minuto por actor; no permite modificar la frecuencia mediante parámetros. Los routers sin importación previa no se consultan.

El worker PHP hace la misma lectura incluso en modo de red solo lectura. El panel visible impulsa el proceso sin worker y refresca la tabla al detectar observaciones nuevas; pausa mientras se editan formularios. Para sincronización con el navegador cerrado utiliza `INICIAR-WORKER.bat`. El intervalo normal es30 segundos tras cada lectura; errores aumentan la espera hasta300 segundos. Los cambios manuales pendientes de reconciliar aplazan la importación. No se ejecutan comandos de configuración ni se piden contraseñas masivamente. Consulta `ACTUALIZACION-AUTOMATICA.txt`.

## Importar secrets a Clientes

**ADMIN o TECHNICIAN** puede ejecutar `POST /routers/:id/import-secrets` con cuerpo `{}`. Es una importación a la base local; todas las operaciones hacia MikroTik son lecturas.

La respuesta 200 contiene:

```json
{
  "router": { "id": "identificador del router", "name": "nombre del router" },
  "total": 12,
  "created": 9,
  "updated": 1,
  "unchanged": 2,
  "missing": 0,
  "namesUpdated": 1,
  "networkReadOnly": true
}
```

El ejemplo ilustra la forma del contrato, no datos incluidos en el ZIP. `total` cuenta las entradas de la lectura actual; `missing` cuenta las identidades anteriores ausentes de una lectura completa. No se eliminan sus clientes.

La consulta es `/ppp/secret/print` con lista explícita `.id,name,service,profile,remote-address,local-address,caller-id,disabled,comment`. Se incluyen los secrets locales de cualquier tipo PPP, incluso deshabilitados. No se solicita `password`; una respuesta que agregue propiedades no autorizadas tampoco las conserva. REST puede usar POST `/ppp/secret/print` para esa selección de propiedades: es una consulta, no una creación.

Se admiten hasta 20 000 entradas por router, sujetas a los límites de transporte. Una respuesta inválida, incompleta o superior al límite se rechaza sin guardar un inventario parcial. No se crean servicios gestionados, planes, facturas ni tareas de red. El nombre se toma del comentario no vacío del secret, normalizando espacios y limitándolo a 200 caracteres; el comentario completo permanece en la observación. Cada cliente conserva un código local `MT-` derivado de su identidad binaria original.

La identidad es router+usuario exacto, con distinción de mayúsculas y espacios. Repetir la misma lectura actualiza observaciones sin duplicar; el mismo usuario en routers diferentes representa clientes separados. No se fusionan clientes manuales por nombre. Al reimportar, el comentario no vacío es autoritativo para `Client.name`: reemplaza también nombres anteriores o editados localmente aunque no cambie el snapshot. Se conservan correo, teléfono, documento, dirección y los demás datos administrativos. Un comentario vacío conserva el nombre existente; para altas nuevas se usa el usuario como alternativa. `namesUpdated` cuenta renombres de clientes existentes y se incluyen en `updated`. Un nombre idéntico no actualiza `Client.updatedAt` por sí solo. Renombrar el usuario PPP representa una identidad nueva. El router con historial importado no puede reasignarse silenciosamente a otro equipo.

Los DTO de `/clients` y `/clients/:id` agregan `routerSecrets`, con `routerId`, `routerName`, `username`, `remoteId`, `pppService`, `profile`, `remoteAddress`, `localAddress`, `callerId`, `disabled`, `comment`, `present`, `firstSeenAt` y `lastSeenAt`, sin contraseña PPP. También existe `GET /clients/:id/router-secrets` para consultar esas observaciones, sujeto a autenticación. La búsqueda de clientes incluye usuario, perfil, dirección remota y nombre del router.

`disabled` expresa la habilitación del secret, no si tiene una sesión activa. La dirección puede estar vacía o contener un pool: no se convierte en una IP de sesión supuesta. La fuente no incluye RADIUS externo ni usuarios exclusivos de Hotspot. En el panel, **Clientes → Importar secrets de MikroTik** permite elegir uno o todos los routers registrados; consulta cada equipo secuencialmente e informa sus resultados por separado, sin reintentos automáticos.

## Importar perfiles PPP a Planes de Internet

**ADMIN o TECHNICIAN** puede ejecutar `POST /routers/:id/import-profiles` con cuerpo `{}`. Sólo consulta `/ppp/profile/print` con `.id,name,rate-limit,local-address,remote-address,comment`; no configura perfiles o servidores PPPoE.

La respuesta 200 incluye `{router,total,created,updated,unchanged,missing,plansCreated,plansUpdated,pending,networkReadOnly:true}`. Los primeros contadores describen observaciones; `plansCreated` y `plansUpdated` describen planes locales vinculados. `pending` cuenta perfiles que necesitan velocidad/nombre utilizable o tarifa explícita. Una lectura admite hasta 20 000 perfiles por router dentro de los límites del transporte y valida la lista completa antes de persistir.

`GET /router-profiles` lista las observaciones con paginación y búsqueda; admite filtro `routerId`. Sus DTO incluyen `id`, `routerId`, `routerName`, `profileName`, `rateLimit`, `downloadKbps`, `uploadKbps`, `rateStatus`, `status`, `reason`, `localAddress`, `remoteAddress`, `comment`, `planId`, `priceConfigured`, `present`, `firstSeenAt` y `lastSeenAt`. Las velocidades pueden ser `null` cuando no se conocen; `planId` puede ser `null` cuando no se puede generar un plan válido. Los planes vinculados exponen la observación como `Plan.profileImport`.

La identidad conserva router+nombre original binario exacto. Para la velocidad base sólo se interpreta el primer componente de `rate-limit`: Rx es **subida** del cliente y Tx es **bajada**. Una tasa sin barra es simétrica. K/M/G son unidades decimales y las tasas se convierten a kbps únicamente si el resultado entero y su rango son representables. Vacío, cero, ilimitado, tasa no interpretable o nombre que requiere revisión quedan señalados, sin inventar velocidades ni sustituir el perfil original.

Un perfil utilizable crea un plan local **inactivo**, con `priceConfigured:false` y presentación **Precio pendiente**. El valor provisional `Plan.priceCents=0` no es una tarifa comercial. Para configurarla se deben enviar explícitamente `priceCents` y `currency` en el `PATCH /plans/:id`; cero es admisible como precio gratuito sólo cuando se especifica deliberadamente junto con la moneda. Se rechaza activar o facturar un plan pendiente. Los códigos incluyen `PROFILE_PRICE_PENDING`, `PROFILE_RATE_PENDING` y `PROFILE_PLAN_CONFLICT` cuando se intenta sustituir su perfil de origen.

Los precios, moneda, nombre comercial y activación locales se conservan al reimportar; las velocidades base se actualizan desde el perfil. Si una observación desaparece o deja de ser utilizable, el plan vinculado se desactiva localmente. Las velocidades y `pppoeProfile` del plan importado no se sustituyen por valores manuales; para otra regla se crea un plan local independiente.

El `status` público distingue `PRICE_PENDING`, `RATE_PENDING`, `READY` y `ABSENT`. `READY` indica observación utilizable y tarifa configurada; no implica un plan activo, servicios facturables ni cambios en MikroTik. `rateStatus` detalla casos como `NO_RATE`, `UNLIMITED`, `UNSUPPORTED_RATE` y `NAME_REVIEW`. No se crean servicios, facturas ni tareas de red al importar perfiles.

## Recursos administrativos

| Ruta | Operaciones y propósito |
| --- | --- |
| `/auth/login`, `/auth/me`, `/auth/logout` | Entrar con correo y contraseña, consultar sesión y salir. |
| `/clients`, `/plans`, `/routers`, `/services` | Listar, crear y consultar recursos; `PATCH /:id` para edición permitida. Las operaciones de red mutantes están bloqueadas; se conserva el historial anterior. |
| `/routers/:id/test` | Encolar prueba de conexión. No devuelve contraseñas guardadas. |
| `/services/:id/diagnostics` | Diagnóstico desde el router mediante tarea. |
| `/services/:id/traffic` | Leer muestras reales guardadas y sus fechas. La ausencia de muestras no se rellena con tráfico simulado. |
| `/network/bulk-diagnostics` | `POST {ids:[serviceId,...]}`: diagnóstico por servicio, hasta 100 identificadores únicos. |
| `/tasks`, `/tasks/:id` | Consultar cola y resultados; las operaciones continúan en el worker. |
| `/invoices`, `/payments`, `/tickets` | Facturación, registro validado de pagos y soporte. El pago conserva su registro local sin reconexión en modo lectura. |
| `/users`, `/keys`, `/audit` | Personal y roles, claves revocables y auditoría, según permisos. |

Las pruebas de conexión y los diagnósticos permitidos son asíncronos y se consultan en **Operaciones de red**. Un trabajo aceptado no demuestra que terminó correctamente. La importación de secrets se realiza en la solicitud web y sólo guarda datos locales; no encola aprovisionamiento. Las acciones mutantes de versiones anteriores están bloqueadas en este modo.

## Ampliaciones de facturación

Administración y facturación pueden escribir estos recursos; los usuarios técnicos y de lectura conservan únicamente los permisos de consulta definidos por cada módulo.

| Ruta | Cuerpo de creación o comportamiento |
| --- | --- |
| `/service-charges` | `{serviceId,name,quantity,unitCents,recurrence}`; frecuencia `MONTHLY` o `ONE_TIME`. Los cargos únicos se consumen junto con su factura en una transacción. |
| `/service-discounts` | `{serviceId,name,kind,value,startOn,endOn}`. `FIXED` usa centavos; `PERCENT` usa puntos básicos (1000 = 10 %). Un descuento activo por servicio; no vuelve negativa la base del plan. |
| `/payment-promises` | `{invoiceId,amountCents,currency,promisedUntil}`. La fecha es inclusiva en UTC y el importe debe cubrir el saldo de esa factura. Las demás facturas vencidas siguen contando para el corte. |
| `/payment-promises/:id/cancel` | Cancelar un compromiso activo y conservar su historial; en lectura `autocutTaskId` es `null`, sin programar corte. |
| `/billing/prorate-preview` | `{serviceId,period,startOn,endOn}`; obtener líneas y total de la primera factura proporcional sin emitirla. |
| `/billing/prorate` | Mismo cuerpo; emitir únicamente si el servicio no tiene una factura anterior. Días inclusivos del mes real, cargos adicionales completos, descuento sobre la base proporcional. |

Las líneas de facturas emitidas son instantáneas: editar un plan, un cargo o un descuento no recalcula una factura existente. Las facturas antiguas reciben una línea `LEGACY` con su importe original al actualizar.

## Clientes, contratos y pagos informados

| Ruta del personal | Comportamiento |
| --- | --- |
| `/portal-accounts` | Administración/facturación crea `{clientId,username,password}`; contraseña propia de al menos 12 caracteres. `PATCH /:id` permite cambiar usuario, contraseña o activación. |
| `/contracts` | Crear `{serviceId,title,terms}`. Guardar condiciones y datos del servicio; las condiciones de un contrato aceptado no se editan. |
| `/payment-reports` | Consultar pagos pendientes de revisión. `POST /:id/approve` registra el pago una sola vez; `POST /:id/reject {reason}` conserva el motivo. |

Portal web: `http://localhost/nexoisp/portal/`. Sus rutas son `/portal/auth/login` con `{username,password}`, `/portal/auth/me`, `/portal/auth/logout`, `/portal/summary`, `/portal/invoices`, `/portal/payments`, `/portal/tickets`, `/portal/contracts` y `/portal/payment-reports`. Todas las consultas filtran por el cliente autenticado.

El cliente puede crear tickets, comentar los suyos, informar un pago con `{invoiceId,amountCents,currency,reference,note}` y aceptar un contrato mediante `POST /portal/contracts/:id/accept {name}`. Informar un pago no lo acredita: requiere aprobación del personal. La aceptación con nombre escrito registra una constancia, sin firma certificada.

Impresión: `/nexoisp/portal/documento.php?type=invoice|receipt|contract&id=...`, con la sesión correspondiente y control de propiedad. El navegador permite imprimir o guardar PDF. Las facturas y recibos son documentos administrativos, sin timbrado fiscal ni conexión bancaria.

## Caja, inventario, agenda e informes

| Ruta | Contrato principal |
| --- | --- |
| `/company-settings` | Perfil comercial del ISP; solo ADMIN lo modifica. |
| `/cash-accounts` | `{name,currency,openingCents}`; moneda y saldo inicial no se reescriben. |
| `/cash-movements` | `{accountId,type,amountCents,category,description,occurredAt?,paymentId?}`; `INCOME` o `EXPENSE`. Vincular un pago requiere importe y moneda exactos. |
| `/cash-movements/:id/reverse` | `POST {reason}`: contrapartida inmutable; no borra ni altera el movimiento inicial. |
| `/cash-transfers` | `{fromAccountId,toAccountId,amountCents,description,externalReference}`; dos asientos atómicos de igual moneda y referencia idempotente. |
| `/inventory-assets` | `{name,category,serialNumber?,macAddress?,brand?,model?,location?,costCents,currency}`; equipos individuales con historial de estados. |
| `/inventory-assets/:id/assign` | `{clientId,note?}`; acciones `/return`, `/repair`, `/retire` conservan movimientos y validan transiciones. |
| `/inventory-movements` | Historial de entrega, devolución y estados del equipo. |
| `/installations` | Cliente o prospecto, dirección, zona/GPS, técnico, fecha, plan/router previsto, estimado y notas. Estados `REQUESTED`, `SCHEDULED`, `IN_PROGRESS`, `COMPLETED`, `CANCELLED`. Una visita completada no provisiona automáticamente un servicio. |
| `/reports?from=...&to=...` | Facturación y cobros del intervalo, agrupados por moneda; cartera pendiente y vencida actual, cuentas y zonas. No reconstruye saldos históricos. |
| `/exports/clients.csv`, `/services.csv`, `/invoices.csv`, `/payments.csv`, `/tickets.csv`, `/cash.csv`, `/inventory.csv` | Prefijo común `/exports/` en cada nombre; columnas autorizadas, hasta 50 000 filas, sin contraseñas y con protección de fórmulas de hoja de cálculo. |

Los roles ADMIN/BILLING operan caja; VIEWER puede consultarla y TECHNICIAN no accede a sus recursos financieros. Inventario e instalaciones admiten trabajo de técnicos. El control se verifica en el servidor, independientemente de los botones visibles.

El código completo de cada contrato está en `app/api.php`, `secret-import.php`, `profile-import.php`, `portal.php`, `billing.php`, `finance.php` y `operations.php`. No se incluyen adaptadores ficticios para proveedores externos. El alcance comparado y las fuentes consultadas están en `MATRIZ-WISPHUB.md` y `REFERENCIAS-WISPHUB.md`.

## Corrección de texto PPP en 2.1.1

El importador conserva la identidad binaria exacta del usuario en la base local. Sus DTO y el nombre inicial del cliente usan presentación UTF-8; los bytes heredados de Socket se interpretan como Windows-1252 cuando no son UTF-8. Los controles quedan visibles, sin borrar ni fusionar identidades. El UTF-8 imprimible anterior conserva sus fingerprints. Una respuesta rechazada devuelve `INVALID_ROUTER_RESPONSE` con el campo y la posición de la fila, sin valores privados. No se modifican los SQL aplicados ni la política de red en lectura.

## Demostración aislada

`/nexoisp/demo/` sirve una página estática con datos ficticios y reloj virtual; también puede abrirse directamente `demo/index.html`. No utiliza esta API, credenciales, base real ni conexión a MikroTik. Permite explorar factura, suspensión, promesa y pago mediante estados simulados. No habilita acciones mutantes del panel; la suspensión real sigue bloqueada por `NETWORK_READ_ONLY`. El recorrido se documenta en `DEMOSTRACION.txt`.

## Moneda local en 2.2.1

`capabilities.defaultCurrency` refleja la moneda de Mi empresa; PEN es el valor predeterminado de esta entrega y se presenta como S/. La migración `008_currency_pen` actualiza sólo esa preferencia. Las monedas explícitas de registros anteriores permanecen intactas. Los importes siguen expresados en centavos y no se realiza conversión de divisas. Los planes importados pendientes de tarifa usan la preferencia vigente al completar su precio; los planes ya configurados conservan su moneda al editar.
