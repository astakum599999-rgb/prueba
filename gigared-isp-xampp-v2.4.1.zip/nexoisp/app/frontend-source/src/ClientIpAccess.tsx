import { useCallback, useState } from 'react';
import { createPortal } from 'react-dom';
import { RefreshCw } from 'lucide-react';
import type { ClientIpAddress } from './types';
import { date, Modal } from './ui';

/** Only literal IP hosts are accepted; pool names, credentials and URLs are not. */
export function clientIpHost(address: string): string | null {
  if (/^(?:0|[1-9]\d{0,2})(?:\.(?:0|[1-9]\d{0,2})){3}$/.test(address)) {
    const parts = address.split('.').map(Number);
    if (parts.some(part => part > 255) || parts[0] === 0 || parts[0] === 127 || parts[0]! >= 224) return null;
    return address;
  }
  if (!address.includes(':') || !/^[a-f\d:.]+$/i.test(address)) return null;
  try {
    const host = new URL(`http://[${address}]/`).hostname;
    if (host === '[::]' || host === '[::1]' || /^\[ff/i.test(host)) return null;
    const mapped = /^\[::ffff:([a-f\d]{1,4}):([a-f\d]{1,4})\]$/i.exec(host);
    if (mapped) {
      const high = Number.parseInt(mapped[1]!, 16), low = Number.parseInt(mapped[2]!, 16);
      if (clientIpHost([high >> 8, high & 255, low >> 8, low & 255].join('.')) === null) return null;
    }
    return host;
  } catch { return null; }
}

export function clientIpUrl(address: string, protocol: string, port: string): string | null {
  const host = clientIpHost(address);
  if (!host || !['http', 'https'].includes(protocol) || !/^\d{1,5}$/.test(port) || Number(port) < 1 || Number(port) > 65535) return null;
  try {
    const url = new URL(`${protocol}://${host}:${Number(port)}/`);
    return url.href;
  } catch { return null; }
}

function ClientIpDialog({ entry, clientName, close }: { entry: ClientIpAddress; clientName: string; close: () => void }) {
  const initialProtocol = 'http';
  const [protocol, setProtocol] = useState(initialProtocol), [port, setPort] = useState('80');
  const [loadedUrl, setLoadedUrl] = useState(() => clientIpUrl(entry.address, initialProtocol, '80'));
  const [reload, setReload] = useState(0);
  const draftUrl = clientIpUrl(entry.address, protocol, port);
  const sameOrigin = loadedUrl !== null && new URL(loadedUrl).origin === window.location.origin;
  const mixedContent = loadedUrl !== null && window.location.protocol === 'https:' && new URL(loadedUrl).protocol === 'http:';
  return <Modal title={`Acceso al router del cliente · ${entry.address}`} description={clientName} close={close} wide>
    <p className="field-hint">La interfaz del equipo se muestra en este recuadro. Inicia sesión con el usuario y la contraseña propios de ese equipo.</p>
    <div className="client-ip-origin"><strong className="mono">{entry.address}</strong><span>{entry.routerName || 'Router asignado'} · {entry.source === 'PPP_ACTIVE' ? 'IP observada en sesión PPP activa' : entry.source === 'SERVICE' ? 'IP asignada al servicio' : 'IP configurada en el secret PPP'}</span>{entry.observedAt && <span>Última observación: {date(entry.observedAt, true)}</span>}</div>
    <div className="client-ip-access-form">
      <label className="field"><span className="field-label">Protocolo web</span><select aria-label="Protocolo web" value={protocol} onChange={event => { setProtocol(event.target.value); setPort(event.target.value === 'https' ? '443' : '80'); }}><option value="http">HTTP</option><option value="https">HTTPS</option></select></label>
      <label className="field"><span className="field-label">Puerto web</span><input aria-label="Puerto web" type="number" inputMode="numeric" min={1} max={65535} step={1} required value={port} onChange={event => setPort(event.target.value)} /></label>
      <button className="button primary" type="button" disabled={draftUrl === null} onClick={() => { setLoadedUrl(draftUrl); setReload(value => value + 1); }}><RefreshCw size={16} />Cargar acceso</button>
    </div>
    {!draftUrl && <div className="alert error" role="alert">Elige HTTP o HTTPS y un puerto entre 1 y 65535.</div>}
    {loadedUrl && <div className="client-ip-url"><span className="mono">{loadedUrl}</span></div>}
    {sameOrigin ? <div className="alert warning" role="status">Esta dirección corresponde al mismo origen del panel. No se carga el sistema dentro de sí mismo. Revisa la IP y el puerto web del equipo.</div> : mixedContent ? <div className="alert warning" role="status">Este panel usa HTTPS y el navegador bloquea una interfaz HTTP dentro del recuadro. Elige HTTPS y el puerto web del equipo.</div> : loadedUrl && <iframe key={`${loadedUrl}:${reload}`} className="client-ip-frame" title={`Interfaz web del router del cliente ${entry.address}`} src={loadedUrl} referrerPolicy="no-referrer" sandbox="allow-forms allow-scripts allow-same-origin" />}
    <p className="field-hint client-ip-frame-note">Tu PC necesita conexión a la IP y acceso al puerto web. Si aparece ERR_BLOCKED_BY_RESPONSE o el recuadro queda bloqueado, el equipo puede impedir mostrarse dentro de otra página mediante X-Frame-Options o Content-Security-Policy. El panel no puede omitir esas restricciones, la autenticación ni los certificados del dispositivo.</p>
  </Modal>;
}

export interface ClientIpLiveState {
  loading?: boolean;
  error?: string;
  message?: string;
  observedAt?: string | null;
  stale?: boolean;
}

export function ClientIpAddresses({ addresses, clientName, activeAddresses, liveState }: { addresses: ClientIpAddress[] | undefined; clientName: string; clientId?: string; activeAddresses?: ClientIpAddress[]; liveState?: ClientIpLiveState }) {
  const [selected, setSelected] = useState<ClientIpAddress | null>(null);
  const close = useCallback(() => setSelected(null), []);
  const entries = [...(!liveState?.stale && Array.isArray(activeAddresses) ? activeAddresses : []), ...(Array.isArray(addresses) ? addresses : [])];
  const seen = new Set<string>();
  const valid = entries.filter(entry => {
    if (!entry || typeof entry.address !== 'string' || clientIpHost(entry.address) === null) return false;
    const key = `${entry.routerId}:${entry.address}`;
    if (seen.has(key)) return false;
    seen.add(key); return true;
  });
  return <>
    {valid.length ? <div className="client-ip-list">{valid.map(entry => <div className="client-ip-entry" key={`${entry.routerId}:${entry.address}`}><button className="text-link mono client-ip-button" type="button" aria-label={`Abrir router del cliente en ${entry.address} (${entry.routerName})`} onClick={() => setSelected(entry)}>{entry.address}</button><div className="table-secondary">{entry.routerName || 'Router asignado'} · {entry.source === 'PPP_ACTIVE' ? 'Sesión PPP observada' : entry.source === 'SERVICE' ? 'Servicio registrado' : 'Secret configurado'}</div></div>)}</div> : <span className="subtle">Sin IP registrada</span>}
    {liveState?.loading && <div className="table-secondary client-ip-live-status" role="status"><RefreshCw size={11} className="spinner" />Actualizando IP…</div>}
    {liveState?.stale && <div className="table-secondary client-ip-live-status" role="status">IP de sesión pendiente de actualizar.</div>}
    {liveState?.message && <div className="table-secondary client-ip-live-status">{liveState.message}</div>}
    {liveState?.observedAt && !liveState.stale && <div className="table-secondary client-ip-live-status">Lectura: {date(liveState.observedAt, true)}</div>}
    {liveState?.error && <div className="table-secondary client-ip-live-status error-text" role="status">{liveState.error}</div>}
    {selected && createPortal(<ClientIpDialog entry={selected} clientName={clientName} close={close} />, document.body)}
  </>;
}
