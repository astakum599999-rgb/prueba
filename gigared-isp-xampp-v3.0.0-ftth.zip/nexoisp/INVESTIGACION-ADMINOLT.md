# Investigación pública de AdminOLT e integración FTTH

Revisión: 30 de octubre de 2026 (America/Lima). Se consultaron las páginas públicas antes de modificar los módulos. Se implementan flujos propios dentro de GIGARED ISP; no se afirma identidad de código, interfaz privada, ni compatibilidad binaria con una API privada.

| Fuente oficial comprobada | Hallazgo utilizado |
| --- | --- |
| https://adminolt.com/documentacion/home-1/ | Organización por OLT, ONU autorizada/sin autorizar, sistema y mapa. |
| https://adminolt.com/explora-adminolt/ | Resumen de OLT, temperatura/uptime, ONUs online/offline/baja señal y mapa. |
| https://adminolt.com/documentacion/articulo/agregar-olt-2/ | Marca/modelo, tecnología PON y conexión; funciones varían por hardware/firmware. |
| https://adminolt.com/documentacion/articulo/autorizar-onu-9/ | Sin autorizar → selección de ONU → VLAN/perfiles/velocidad/ubicación → revisión. |
| https://adminolt.com/documentacion/articulo/lista-de-onus-autorizadas-35/ | Lista y acciones de detalle, edición y diagnóstico. |
| https://adminolt.com/documentacion/articulo/lista-de-onus-no-autorizadas-36/ | Inventario descubierto independiente de autorización. |
| https://adminolt.com/documentacion/articulo/ver-detalles-de-onu-25/ | Chasis/slot/PON, service-port, SN, VLAN, señal, modelo y plan. |
| https://adminolt.com/documentacion/articulo/crear-perfiles-de-linea-line-profiles-77/ | DBA, TCONT, GEM, VLAN, prioridad y mapping mode. |
| https://adminolt.com/documentacion/articulo/agregar-zonas-16/ | Organización geográfica de red. |
| https://adminolt.com/documentacion/articulo/agregar-naps-18/ | Nombre, zona, descripción, coordenadas y capacidad de splitter. |
| https://adminolt.com/documentacion/articulo/como-crear-scripts-y-consultas-para-tu-olt-generica-372/ | Consultas Telnet/SNMP y plantillas dependen de comandos/OIDs reales del fabricante. |
| https://adminolt.com/documentacion/articulo/integrar-adminolt-token-80/ | La integración publicada usa token de la cuenta y subdominio HTTPS. No publica allí el contrato completo de operaciones REST. |

La raíz pública https://adminolt.com/api/ respondió200 con un enlace zones; /api-docs/ respondió404. No se probaron tokens, cuentas ni subdominios de clientes. No se inventa una certificación de compatibilidad con endpoints privados. La API del módulo se documenta con sus propias rutas y autenticación Api-Key existentes.

Los artículos anuncian automatismos que cambian equipos. Esta instalación conserva su política de red en lectura: preparar un flujo o registrar inventario local no equivale a provisionar una ONU. La matriz de capacidades distingue datos locales, lectura real y operaciones no habilitadas.

## VSOL V1600GS-F

La ficha oficial y guías Single-PON identifican un puerto GPON y gestión Web/Telnet/CLI/SNMP. La versión de firmware sigue sin conocerse. No se verificaron comandos CLI ni OIDs vendor de ese firmware, por lo que no se heredan comandos de chasis ni se asegura aprovisionamiento/QoS. Referencias: https://www.vsolcn.com/product/1-pon-gpon-olt-v1600gsf-v1600gszf ; https://www.vsolcn.com/wp-content/uploads/2023/06/V1600GS-F-V1600GS-ZF-Datasheet-EN-.pdf ; artículos AdminOLT298/309/293 citados en FTTH.txt.
