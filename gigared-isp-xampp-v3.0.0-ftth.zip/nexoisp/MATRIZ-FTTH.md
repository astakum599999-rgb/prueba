# Alcance FTTH de GIGARED ISP 3.0.0

| Área | Implementación entregada | Límite comprobable |
| --- | --- | --- |
| OLT | Inventario, marca/modelo/firmware, acceso cifrado y consulta asincrónica SSH/Telnet/SNMP | Validado con protocolos de laboratorio; firmware físico aún no certificado. |
| PON/VLAN/perfiles | Esquema, CRUD, vínculos, TCONT/GEM/DBA/Traffic y ubicación | Los metadatos locales no crean perfiles ni VLAN en el equipo. |
| ONU | Inventario por OLT+SN, autorizadas/sin autorizar, estados/LOS y cliente | Observaciones diferenciadas de importaciones y preparaciones. |
| Descubrimiento | Bases Huawei/ZTE y consultas genéricas configurables | No se reutiliza CLI de chasis para VSOL V1600GS-F. |
| Potencia/tráfico | Valores observados, muestras fechadas y gráficos | Se muestran Sin lectura si no existen; los valores son los últimos observados, no una medición continua instantánea. |
| Autorización/WAN/WiFi | Asistente, validación, secretos cifrados y preparación revisable | La política de lectura bloquea aplicar o reiniciar; no hay escritor universal habilitado. |
| Red externa | Zonas, NAP/capacidad/puerto, splitters, hilos/enlaces y mapa SVG georreferenciado | Plano offline con coordenadas guardadas; no es Google Maps ni usa su API. |
| API | Rutas REST nativas y claves de API existentes | Equivalencia funcional documentada; no certificación de API privada AdminOLT. |
| VSOL V1600GS-F | Perfil Single-PON GPON, metadatos y MIB-II estándar si accesible | Falta validar firmware, comandos CLI/OIDs ópticos y capacidades de cambios reales. |

La entrega es una implementación propia en el proyecto existente. La investigación utilizada se enlaza en INVESTIGACION-ADMINOLT.md. Se conservaron SQL anteriores, configuración y datos; no se contactaron equipos del operador.
