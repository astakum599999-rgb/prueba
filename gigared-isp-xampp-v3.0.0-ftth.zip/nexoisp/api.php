<?php
declare(strict_types=1);
namespace Nexo;

ini_set('display_errors', '0');
ini_set('log_errors', '1');
date_default_timezone_set('UTC');
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header("Content-Security-Policy: default-src 'none'; frame-ancestors 'none'");

try {
    require_once __DIR__ . '/app/bootstrap.php';
    require_once __DIR__ . '/app/migrations.php';
    require_once __DIR__ . '/app/validation.php';
    require_once __DIR__ . '/app/auth.php';
    require_once __DIR__ . '/app/MikroTik.php';
    require_once __DIR__ . '/app/billing.php';
    require_once __DIR__ . '/app/worker.php';
    require_once __DIR__ . '/app/api.php';
    require_once __DIR__ . '/app/portal.php';
    require_once __DIR__ . '/app/finance.php';
    require_once __DIR__ . '/app/operations.php';
    require_once __DIR__ . '/app/secret-import.php';
    require_once __DIR__ . '/app/secret-auto-sync.php';
    require_once __DIR__ . '/app/profile-import.php';
    require_once __DIR__ . '/app/client-pppoe.php';
    require_once __DIR__ . '/app/client-name-sync.php';
    require_once __DIR__ . '/app/client-ip-live.php';
    require_once __DIR__ . '/app/FiberTransport.php';
    require_once __DIR__ . '/app/fiber.php';
    $requestId = bin2hex(random_bytes(12));
    header('X-Request-Id: ' . $requestId);
    config();
    $origin = headerValue('Origin');
    if ($origin !== null) {
        if (!trustedOrigin($origin)) throw new HttpError(403, 'Origen no autorizado', 'CSRF_REJECTED');
        header('Access-Control-Allow-Origin: ' . $origin);
        header('Access-Control-Allow-Credentials: true');
        header('Vary: Origin');
    }
    $method = strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET'));
    if ($method === 'OPTIONS') {
        header('Access-Control-Allow-Methods: GET, POST, PATCH, DELETE, OPTIONS');
        header('Access-Control-Allow-Headers: Authorization, Content-Type, X-Webhook-Timestamp, X-Webhook-Signature');
        header('Access-Control-Max-Age: 600');
        json(null, 204);
    }
    $route = $_GET['route'] ?? $_SERVER['PATH_INFO'] ?? null;
    if ($route === null) {
        $path = parse_url((string)($_SERVER['REQUEST_URI'] ?? '/'), PHP_URL_PATH);
        $route = is_string($path) ? $path : '/';
        $base = rtrim((string)config('base_path', ''), '/');
        if ($base !== '' && ($route === $base || str_starts_with($route, $base . '/'))) $route = substr($route, strlen($base));
        if ($route === '/api.php' || str_starts_with($route, '/api.php/')) $route = substr($route, strlen('/api.php'));
    }
    if (!is_string($route) || strlen($route) > 1000) throw new HttpError(400, 'Ruta inválida');
    $route = '/' . ltrim($route, '/');
    if ($route === '/api/v1' || str_starts_with($route, '/api/v1/')) $route = substr($route, strlen('/api/v1')) ?: '/';
    $route = $route !== '/' ? rtrim($route, '/') : $route;
    if ($method === 'GET' && $route === '/health/live') json(['status' => 'ok']);
    if ($method === 'GET' && $route === '/health/ready') {
        fetchOne('SELECT 1 AS ready');
        $installed = fetchOne("SELECT COUNT(*) AS n FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name IN ('User','Client','Service','Task','Invoice')");
        if ((int)$installed['n'] !== 5) throw new HttpError(503, 'La base de datos no está inicializada', 'DATABASE_UNAVAILABLE');
        json(['status' => 'ready', 'dependencies' => ['mysql' => 'up'], 'worker' => ['mode' => 'database-queue', 'browserFallback' => true]]);
    }
    if (!in_array($method, ['GET','POST','PATCH','DELETE','HEAD'], true)) throw new HttpError(405, 'Método no permitido', 'METHOD_NOT_ALLOWED');
    if (isset($_SERVER['CONTENT_LENGTH']) && (int)$_SERVER['CONTENT_LENGTH'] > 1048576) throw new HttpError(413, 'El cuerpo excede 1 MiB', 'BODY_TOO_LARGE');
    if (in_array($method, ['POST','PATCH','DELETE'], true)) {
        $stream = fopen('php://input', 'rb');
        if ($stream === false) throw new HttpError(400, 'No se pudo leer la solicitud', 'INVALID_JSON');
        $raw = stream_get_contents($stream, 1048577); fclose($stream);
        if (!is_string($raw)) throw new HttpError(400, 'No se pudo leer la solicitud', 'INVALID_JSON');
        if (strlen($raw) > 1048576) throw new HttpError(413, 'El cuerpo excede 1 MiB', 'BODY_TOO_LARGE');
        $GLOBALS['nexo_raw_body'] = $raw;
        if ($raw !== '' && preg_match('~^application/(?:[a-z0-9.+-]+\+)?json(?:\s*;|$)~i', (string)($_SERVER['CONTENT_TYPE'] ?? '')) !== 1) throw new HttpError(415, 'Utilice Content-Type: application/json', 'UNSUPPORTED_MEDIA_TYPE');
    }
    rateLimit('api', 600, 60);
    if (!in_array($route, ['/auth/login','/auth/me','/auth/logout'], true) && migrationNeedsUpgrade()) throw new HttpError(503, 'Un administrador debe completar la actualización del sistema', 'UPGRADE_REQUIRED');
    if (fiberDispatch($method, $route) || secretAutoSyncDispatch($method, $route) || clientIpLiveDispatch($method, $route) || clientIpAccessDispatch($method, $route) || clientNameSyncDispatch($method, $route) || clientPppoeDispatch($method, $route) || profileImportDispatch($method, $route) || secretImportDispatch($method, $route) || portalDispatch($method, $route) || financeDispatch($method, $route) || operationsDispatch($method, $route) || billingDispatch($method, $route) || apiDispatch($method, $route)) exit;
    throw new HttpError(404, 'Ruta no encontrada', 'NOT_FOUND');
} catch (HttpError $error) {
    if ($error->status === 429) header('Retry-After: 60');
    json(['error' => ['code' => $error->errorCode, 'message' => $error->getMessage()]], $error->status);
} catch (\PDOException $error) {
    $state = (string)$error->getCode();
    $driverCode = (int)($error->errorInfo[1] ?? 0);
    $conflict = str_starts_with($state, '23') || in_array($driverCode, [1062,1205,1213,1451,1452,4025], true);
    $unavailable = str_starts_with($state, '08') || in_array($driverCode, [1045,1049,1146,2002,2006,2013], true);
    $status = $conflict ? 409 : ($unavailable ? 503 : 500);
    error_log('GIGARED ISP database error [' . ($requestId ?? 'startup') . '] ' . preg_replace('/[^A-Z0-9]/', '', $state));
    json(['error' => ['code' => $conflict ? 'DATA_CONFLICT' : ($unavailable ? 'DATABASE_UNAVAILABLE' : 'INTERNAL_ERROR'), 'message' => $conflict ? 'La operación entra en conflicto con datos existentes' : ($unavailable ? 'La base de datos no está disponible o no está instalada' : 'Error interno del servidor')]], $status);
} catch (\Throwable $error) {
    error_log('GIGARED ISP internal error [' . ($requestId ?? 'startup') . '] ' . get_class($error));
    http_response_code(500);
    echo '{"error":{"code":"INTERNAL_ERROR","message":"Error interno del servidor"}}';
}
