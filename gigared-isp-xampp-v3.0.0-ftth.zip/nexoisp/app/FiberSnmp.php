<?php
declare(strict_types=1);
namespace Nexo;

/** Bounded SNMP v2c GET/GETNEXT client. No SET encoder or write primitive. */
final class FiberSnmp
{
    public function __construct(private string $host, private int $port, private string $community) {}
    private static function tlv(int $tag, string $value): string
    {
        $length = strlen($value);
        $encoded = $length < 128 ? chr($length) : ($length < 256 ? "\x81" . chr($length) : "\x82" . pack('n', $length));
        return chr($tag) . $encoded . $value;
    }
    private static function integer(int $value): string
    {
        $bytes = ltrim(pack('N', $value), "\0");
        if ($bytes === '') $bytes = "\0";
        if (ord($bytes[0]) & 128) $bytes = "\0" . $bytes;
        return self::tlv(2, $bytes);
    }
    private static function oid(string $value): string
    {
        if (!preg_match('/^[0-2](?:\.[0-9]{1,10}){1,63}$/D', $value)) throw new HttpError(422, 'OID SNMP inválido.', 'VALIDATION_ERROR');
        $parts = array_map('intval', explode('.', $value));
        if ($parts[0] < 2 && $parts[1] > 39) throw new HttpError(422, 'OID SNMP inválido.', 'VALIDATION_ERROR');
        $arcs = [40 * $parts[0] + $parts[1], ...array_slice($parts, 2)]; $bytes = '';
        foreach ($arcs as $part) {
            if ($part < 0 || $part > 4294967295) throw new HttpError(422, 'OID SNMP fuera de rango.', 'VALIDATION_ERROR');
            $encoded = chr($part & 127);
            while (($part >>= 7) > 0) $encoded = chr(128 | ($part & 127)) . $encoded;
            $bytes .= $encoded;
        }
        return self::tlv(6, $bytes);
    }
    private static function item(string $bytes, int &$offset): array
    {
        if ($offset + 2 > strlen($bytes)) throw new \RuntimeException('SNMP truncado');
        $tag = ord($bytes[$offset++]); $length = ord($bytes[$offset++]);
        if ($length & 128) {
            $count = $length & 127;
            if ($count < 1 || $count > 4 || $offset + $count > strlen($bytes)) throw new \RuntimeException('Longitud SNMP inválida');
            $length = 0;
            for ($n = 0; $n < $count; $n++) $length = ($length << 8) | ord($bytes[$offset++]);
        }
        if ($length > 65535 || $offset + $length > strlen($bytes)) throw new \RuntimeException('SNMP truncado');
        $value = substr($bytes, $offset, $length); $offset += $length;
        return [$tag, $value];
    }
    private static function number(string $bytes): int|string
    {
        if ($bytes === '' || strlen($bytes) > 9) throw new \RuntimeException('Número SNMP inválido');
        $result = '0';
        foreach (str_split($bytes) as $byte) {
            $carry = ord($byte); $next = '';
            for ($i = strlen($result)-1; $i >= 0; $i--) {
                $value = (int)$result[$i] * 256 + $carry;
                $next = (string)($value % 10) . $next; $carry = intdiv($value,10);
            }
            while ($carry > 0) { $next = (string)($carry % 10) . $next; $carry = intdiv($carry,10); }
            $result = ltrim($next, '0') ?: '0';
        }
        $max = (string)PHP_INT_MAX;
        return strlen($result) < strlen($max) || (strlen($result) === strlen($max) && strcmp($result,$max)<=0) ? (int)$result : $result;
    }
    private static function signed(string $bytes): int|string
    {
        if ($bytes === '' || strlen($bytes)>8) throw new \RuntimeException('Entero SNMP inválido');
        if (!(ord($bytes[0]) & 128)) return self::number($bytes);
        $value = -1;
        foreach (str_split($bytes) as $byte) $value = ($value << 8) | ord($byte);
        return $value;
    }
    private static function decodeOid(string $bytes): string
    {
        $arcs = []; $part = 0; $pending = false;
        foreach (str_split($bytes) as $byte) {
            $n = ord($byte); $part = ($part << 7) | ($n & 127); $pending = ($n & 128) !== 0;
            if ($part > 4294967295) throw new \RuntimeException('OID SNMP inválido');
            if (!$pending) { $arcs[] = $part; $part = 0; }
        }
        if (!$arcs || $pending) throw new \RuntimeException('OID SNMP incompleto');
        $first = array_shift($arcs); $a = min(2, intdiv($first, 40));
        return implode('.', [$a, $first - 40 * $a, ...$arcs]);
    }
    public function get(array $oids, bool $next = false): array
    {
        if (!$oids || count($oids) > 32 || $this->community === '' || strlen($this->community) > 512) throw new HttpError(422, 'Consulta SNMP inválida.', 'VALIDATION_ERROR');
        $id = random_int(1, 2147483647); $bindings = '';
        foreach ($oids as $oid) $bindings .= self::tlv(48, self::oid($oid) . "\x05\0");
        $packet = self::tlv(48, self::integer(1) . self::tlv(4, $this->community) . self::tlv($next ? 161 : 160, self::integer($id) . self::integer(0) . self::integer(0) . self::tlv(48, $bindings)));
        $host = str_contains($this->host, ':') ? '[' . $this->host . ']' : $this->host;
        $socket = @stream_socket_client('udp://' . $host . ':' . $this->port, $errno, $error, 3);
        if (!is_resource($socket)) throw new HttpError(502, 'No se pudo conectar con SNMP.', 'OLT_UNAVAILABLE');
        try {
            stream_set_timeout($socket, 3);
            if (fwrite($socket, $packet) !== strlen($packet)) throw new \RuntimeException('SNMP envío incompleto');
            $reply = fread($socket, 65535);
            if (!is_string($reply) || $reply === '') throw new \RuntimeException('SNMP sin respuesta');
            $offset = 0; [$tag, $body] = self::item($reply, $offset);
            if ($tag !== 48 || $offset !== strlen($reply)) throw new \RuntimeException('SNMP inválido');
            $offset = 0; [$t, $version] = self::item($body, $offset); [$ct, $community] = self::item($body, $offset); [$pt, $pdu] = self::item($body, $offset);
            if ($t !== 2 || self::number($version) !== 1 || $ct !== 4 || !hash_equals($this->community, $community) || $pt !== 162 || $offset !== strlen($body)) throw new \RuntimeException('Identidad SNMP inválida');
            $offset = 0; [$it, $rid] = self::item($pdu, $offset); [$et, $status] = self::item($pdu, $offset); self::item($pdu, $offset); [$lt, $list] = self::item($pdu, $offset);
            if ($it !== 2 || self::number($rid) !== $id || $et !== 2 || self::number($status) !== 0 || $lt !== 48 || $offset !== strlen($pdu)) throw new \RuntimeException('Respuesta SNMP rechazada');
            $result = []; $offset = 0;
            while ($offset < strlen($list)) {
                [$bt, $binding] = self::item($list, $offset); $position = 0;
                [$ot, $oid] = self::item($binding, $position); [$vt, $value] = self::item($binding, $position);
                if ($bt !== 48 || $ot !== 6 || $position !== strlen($binding) || count($result) >= 32) throw new \RuntimeException('Binding SNMP inválido');
                $oid = self::decodeOid($oid);
                $result[$oid] = match ($vt) { 2 => self::signed($value), 65,66,67,70 => self::number($value), 4 => $value, 6 => self::decodeOid($value), 5,128,129,130 => null, default => throw new \RuntimeException('Tipo SNMP no soportado') };
            }
            if (!$next && array_diff($oids, array_keys($result))) throw new \RuntimeException('Respuesta SNMP incompleta');
            return $result;
        } catch (\Throwable $error) {
            if ($error instanceof HttpError) throw $error;
            throw new HttpError(502, 'SNMP no respondió una consulta válida. Revisa comunidad, puerto y permisos de lectura.', 'OLT_SNMP_ERROR');
        } finally { fclose($socket); }
    }
    public function walk(string $prefix, int $limit = 256): array
    {
        self::oid($prefix); $cursor = $prefix; $result = []; $started = microtime(true);
        for ($n = 0; $n < min(512, max(1, $limit)); $n++) {
            if (microtime(true) - $started > 25) throw new HttpError(502, 'El recorrido SNMP agotó su tiempo; no se importan datos parciales.', 'OLT_RESPONSE_LIMIT');
            $next = $this->get([$cursor], true); $oid = array_key_first($next);
            if ($oid === null || $next[$oid] === null || !str_starts_with($oid, $prefix . '.')) return $result;
            if ($oid === $cursor || isset($result[$oid])) throw new HttpError(502, 'El recorrido SNMP repitió una entrada.', 'OLT_SNMP_ERROR');
            $result[$oid] = $next[$oid]; $cursor = $oid;
        }
        throw new HttpError(502, 'El recorrido SNMP superó el límite; no se importan datos parciales.', 'OLT_RESPONSE_LIMIT');
    }
}
