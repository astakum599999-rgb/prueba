<?php
declare(strict_types=1);
namespace Nexo;

require_once __DIR__ . '/fiber-autoload.php';
require_once __DIR__ . '/FiberSnmp.php';

/** Interactive read-only CLI transport for OLTs; never accepts configuration commands. */
final class FiberCli
{
    private mixed $socket = null;
    private ?\phpseclib3\Net\SSH2 $ssh = null;
    private string $pending = '';
    public function __construct(array $olt)
    {
        $username = (string)($olt['username'] ?? '');
        $password = empty($olt['passwordEncrypted']) ? '' : decryptSecret($olt['passwordEncrypted']);
        if (preg_match('/[\r\n\x00]/', $username . $password)) throw new HttpError(422, 'Credenciales CLI inválidas.', 'VALIDATION_ERROR');
        try {
            if ($olt['transport'] === 'SSH') {
                $pin = trim((string)($olt['ssh_fingerprint'] ?? ''));
                if (!preg_match('/^SHA256:[A-Za-z0-9+\/]{43}=?$/D', $pin)) throw new HttpError(422, 'Registra y verifica la huella SHA256 del servidor SSH antes de conectar.', 'SSH_HOST_KEY_REQUIRED');
                $this->ssh = new \phpseclib3\Net\SSH2($olt['host'], (int)$olt['port'], 8);
                $key = $this->ssh->getServerPublicHostKey();
                $parts = is_string($key) ? explode(' ', $key) : [];
                $binary = isset($parts[1]) ? base64_decode($parts[1], true) : false;
                $actual = $binary === false ? '' : 'SHA256:' . rtrim(base64_encode(hash('sha256', $binary, true)), '=');
                if (!hash_equals(rtrim($pin, '='), $actual)) throw new HttpError(502, 'La huella SSH no coincide con la registrada.', 'SSH_HOST_KEY_MISMATCH');
                if (!$this->ssh->login($username, $password)) throw new HttpError(502, 'No se pudo autenticar la conexión SSH.', 'OLT_AUTH_FAILED');
                $this->ssh->setTimeout(8); $this->prompt();
            } elseif ($olt['transport'] === 'TELNET') {
                $host = str_contains($olt['host'], ':') ? '[' . $olt['host'] . ']' : $olt['host'];
                $this->socket = @stream_socket_client('tcp://' . $host . ':' . (int)$olt['port'], $errno, $error, 5);
                if (!is_resource($this->socket)) throw new HttpError(502, 'No se pudo conectar con Telnet.', 'OLT_UNAVAILABLE');
                stream_set_timeout($this->socket, 1);
                $this->until('/(?:login|username|user name)\s*:\s*$/i'); $this->send($username . "\r\n");
                $this->until('/password\s*:\s*$/i'); $this->send($password . "\r\n"); $this->prompt();
            } else throw new HttpError(422, 'El transporte seleccionado no es CLI.', 'TRANSPORT_UNSUPPORTED');
        } catch (\Throwable $error) { $this->close(); if ($error instanceof HttpError) throw $error; throw new HttpError(502, 'No se pudo abrir una sesión CLI de lectura.', 'OLT_UNAVAILABLE'); }
    }
    private function send(string $text): void
    {
        if ($this->ssh !== null) { $this->ssh->write($text); return; }
        $offset = 0;
        while ($offset < strlen($text)) {
            $written = fwrite($this->socket, substr($text, $offset));
            if ($written === false || $written === 0) throw new HttpError(502, 'La sesión CLI se interrumpió.', 'OLT_UNAVAILABLE');
            $offset += $written;
        }
    }
    private function telnet(string $bytes): string
    {
        $bytes = $this->pending . $bytes; $this->pending = ''; $text = '';
        for ($i = 0, $length = strlen($bytes); $i < $length; $i++) {
            if (ord($bytes[$i]) !== 255) { $text .= $bytes[$i]; continue; }
            if ($i + 1 >= $length) { $this->pending = substr($bytes, $i); break; }
            $command = ord($bytes[++$i]);
            if ($command === 255) { $text .= "\xff"; continue; }
            if ($command === 250) {
                $end = strpos($bytes, "\xff\xf0", $i + 1);
                if ($end === false) { $this->pending = substr($bytes, $i - 1); break; }
                $i = $end + 1; continue;
            }
            if (in_array($command, [251,252,253,254], true)) {
                if ($i + 1 >= $length) { $this->pending = substr($bytes, $i - 1); break; }
                $option = $bytes[++$i];
                if ($command === 251 || $command === 253) $this->send("\xff" . chr($command === 251 ? 254 : 252) . $option);
            }
        }
        return $text;
    }
    private function until(string $pattern): string
    {
        if ($this->ssh !== null) {
            $text = $this->ssh->read($pattern, \phpseclib3\Net\SSH2::READ_REGEX);
            if (!is_string($text) || strlen($text) > 1048576 || !preg_match($pattern, $text)) throw new HttpError(502, 'La OLT no devolvió un prompt válido.', 'OLT_CLI_RESPONSE');
            return $text;
        }
        $text = ''; $started = microtime(true);
        while (microtime(true) - $started < 10) {
            $chunk = fread($this->socket, 8192);
            if ($chunk === false || ($chunk === '' && feof($this->socket))) break;
            if ($chunk === '') continue;
            $chunk = $this->telnet($chunk);
            $chunk = preg_replace('/\x1b\[[0-9;?]*[A-Za-z]/', '', $chunk) ?? '';
            if (preg_match('/(?:--+\s*More\s*--+|<--- More --->)/i', $chunk)) { $this->send(' '); $chunk = preg_replace('/(?:--+\s*More\s*--+|<--- More --->)/i', '', $chunk) ?? ''; }
            $text .= $chunk;
            if (strlen($text) > 1048576) throw new HttpError(502, 'La lectura CLI excedió su límite; no se importa parcialmente.', 'OLT_RESPONSE_LIMIT');
            if (preg_match($pattern, $text)) return $text;
        }
        throw new HttpError(502, 'La OLT no devolvió un prompt completo. Revisa acceso y permisos de lectura.', 'OLT_CLI_RESPONSE');
    }
    private function prompt(): string { return $this->until('/(?:^|[\r\n])[^\r\n]{0,120}[#>]\s*$/'); }
    public function read(string $command): string
    {
        fiberValidateReadCommand($command);
        $this->send($command . ($this->ssh === null ? "\r\n" : "\n"));
        $text = $this->prompt();
        if (preg_match('/(?:unknown command|unrecognized command|invalid input|permission denied|not permitted|command denied|%\s*error|failure:|error:)/i', $text)) throw new HttpError(502, 'La OLT rechazó la consulta de lectura. Revisa modelo, firmware y permisos.', 'OLT_COMMAND_REJECTED');
        return $text;
    }
    public function close(): void
    {
        if ($this->ssh !== null) { $this->ssh->disconnect(); $this->ssh = null; }
        if (is_resource($this->socket)) fclose($this->socket);
        $this->socket = null;
    }
    public function __destruct() { $this->close(); }
}

function fiberValidateReadCommand(string $command): void
{
    if (strlen($command) > 300 || !preg_match('/^(?:show|display) [A-Za-z0-9_.:\/ -]+$/D', $command)) throw new HttpError(422, 'Sólo se permiten consultas CLI show/display sin operadores, saltos ni configuración.', 'READ_ONLY_COMMAND');
    if (preg_match('/(?:password|secret|community|current-configuration|running-config|startup-config)/i', $command)) throw new HttpError(422, 'La consulta puede revelar credenciales y no está permitida.', 'READ_ONLY_COMMAND');
}
function fiberExpandReadCommand(string $template, array $values): string
{
    $command = preg_replace_callback('/\{\{?(frame|slot|port|onu_index)\}?\}/', static function (array $match) use ($values): string {
        $value = $values[$match[1]] ?? null;
        if (!is_numeric($value) || (int)$value != $value || (int)$value < 0 || (int)$value > 65535) throw new HttpError(422, 'Falta una posición física válida para la consulta.', 'QUERY_CONTEXT_REQUIRED');
        return (string)(int)$value;
    }, $template);
    fiberValidateReadCommand($command ?? ''); return $command;
}

/** The parser accepts observations, never CLI commands or credentials. */
function fiberParseObservations(string $text, string $pattern, string $kind, array $context = []): array
{
    if (strlen($text) > 1048576 || strlen($pattern) > 1500) throw new HttpError(422, 'La consulta supera los límites admitidos.', 'OLT_RESPONSE_LIMIT');
    $text = str_replace(["\r\n", "\r"], "\n", $text);
    $text = preg_replace('/\x1b\[[0-9;?]*[A-Za-z]/', '', $text) ?? '';
    $previous = ini_get('pcre.backtrack_limit'); ini_set('pcre.backtrack_limit', '100000');
    try { $count = @preg_match_all($pattern, $text, $matches, PREG_SET_ORDER | PREG_UNMATCHED_AS_NULL); }
    finally { if ($previous !== false) ini_set('pcre.backtrack_limit', $previous); }
    if ($count === false || $count > 20000) throw new HttpError(502, 'La expresión de lectura es inválida o excedió el límite.', 'OLT_PARSE_ERROR');
    $rows = [];
    foreach ($matches as $match) {
        $sn = strtoupper(trim((string)($match['sn'] ?? $context['sn'] ?? '')));
        if (!preg_match('/^[A-Z0-9]{6,64}$/D', $sn)) throw new HttpError(502, 'La lectura devolvió una identidad ONU inválida.', 'OLT_PARSE_ERROR');
        $row = ['sn' => $sn, 'authorization' => $kind === 'DISCOVER' ? 'UNAUTHORIZED' : 'AUTHORIZED', 'status' => 'UNKNOWN'];
        foreach (['frame','slot','port','onu_index'] as $field) {
            $value = $match[$field] ?? $context[$field] ?? ($field === 'port' ? ($context['pon_port'] ?? null) : null);
            if ($value === null && $field === 'onu_index') { $row[$field] = null; continue; }
            if ($value === null || !ctype_digit((string)$value) || (int)$value > ($field === 'onu_index' ? 4095 : 255)) throw new HttpError(502, 'La lectura no contiene una posición física ONU válida.', 'OLT_PARSE_ERROR');
            $row[$field] = (int)$value;
        }
        if (isset($match['onu_type'])) $row['onu_type'] = substr($match['onu_type'], 0, 100);
        if (isset($match['mac'])) $row['mac'] = strtoupper($match['mac']);
        if (isset($match['status'])) {
            $status = strtoupper($match['status']);
            $row['status'] = match ($status) { 'ONLINE','WORKING','UP' => 'ONLINE', 'OFFLINE','DOWN','DYING-GASP','DYINGGASP','POWER_OFF','POWEROFF' => 'OFFLINE', 'LOS','LOS-I','LOS-O' => 'LOS', default => 'UNKNOWN' };
        }
        foreach (['rx_power','tx_power','temperature','distance','download_bps','upload_bps'] as $field) if (isset($match[$field]) && $match[$field] !== '') {
            if (!is_numeric($match[$field]) || !is_finite((float)$match[$field])) throw new HttpError(502, 'Medición ONU inválida.', 'OLT_PARSE_ERROR');
            $row[$field] = (float)$match[$field];
        }
        foreach (['download_bytes','upload_bytes'] as $field) if (isset($match[$field])) {
            if (!ctype_digit($match[$field]) || strlen($match[$field]) > 24) throw new HttpError(502, 'Contador de tráfico inválido.', 'OLT_PARSE_ERROR');
            $row[$field] = $match[$field];
        }
        $rows[] = $row;
    }
    if ($count === 0 && trim($text) !== '' && !preg_match('/(?:no\s+(?:related\s+)?(?:ont|onu|information|entries)|total\s*[:=]?\s*0|no information)/i', $text)) throw new HttpError(502, 'La salida no coincide con el parser configurado; se conserva el inventario anterior.', 'OLT_PARSE_ERROR');
    return $rows;
}

/** Worker entry point. All transports are read-only; no configuration initialisation. */
function fiberRunReadJob(array $olt, string $kind, ?array $onu = null): array
{
    $started = microtime(true);
    $result = ['olt' => ['status' => 'ONLINE'], 'pons' => [], 'onus' => [], 'complete' => false];
    $queries = array_values(array_filter($olt['queries'] ?? [], static fn(array $query): bool => $query['kind'] === $kind && (bool)$query['enabled']));
    if (count($queries) > 20) throw new HttpError(422, 'Activa hasta veinte consultas por acción para mantener lecturas acotadas.', 'OLT_RESPONSE_LIMIT');
    if ($olt['transport'] === 'SNMP') {
        $community = empty($olt['snmpCommunityEncrypted']) ? '' : decryptSecret($olt['snmpCommunityEncrypted']);
        $snmp = new FiberSnmp($olt['host'], (int)$olt['port'], $community);
        $system = $snmp->get(['1.3.6.1.2.1.1.1.0','1.3.6.1.2.1.1.3.0','1.3.6.1.2.1.1.5.0']);
        if (isset($system['1.3.6.1.2.1.1.3.0'])) $result['olt']['uptime'] = (string)(int)floor($system['1.3.6.1.2.1.1.3.0'] / 100) . ' s';
        if ($kind !== 'TEST' && !$queries) throw new HttpError(422, 'Registra los OIDs y el parser de tu modelo para leer su inventario óptico. SNMP estándar sólo identifica el sistema.', 'OLT_QUERY_REQUIRED');
        foreach ($queries as $query) {
            if (microtime(true) - $started > 90) throw new HttpError(502, 'La lectura agotó su tiempo; se conserva el inventario anterior.', 'OLT_RESPONSE_LIMIT');
            if (empty($query['oid']) || empty($query['pattern'])) throw new HttpError(422, 'La consulta SNMP necesita OID y parser.', 'OLT_QUERY_REQUIRED');
            $values = $snmp->walk($query['oid']); $text = '';
            foreach ($values as $oid => $value) $text .= $oid . ' ' . (string)$value . "\n";
            $result['onus'] = [...$result['onus'], ...fiberParseObservations($text, $query['pattern'], $kind)];
        }
    } else {
        $cli = new FiberCli($olt);
        try {
            if ($kind === 'TEST') {
                if ($queries) foreach ($queries as $query) $cli->read(fiberExpandReadCommand((string)$query['command'], []));
                else $cli->read($olt['vendor'] === 'HUAWEI' ? 'display version' : 'show version');
                return $result;
            }
            if (!$queries && $kind === 'DISCOVER' && in_array($olt['vendor'], ['HUAWEI','ZTE'], true)) {
                $queries = $olt['vendor'] === 'ZTE' ? [['command' => 'show gpon onu uncfg', 'pattern' => '/gpon-onu_(?<frame>\d+)\/(?<slot>\d+)\/(?<port>\d+):(?<onu_index>\d+)\s+(?<sn>[A-Za-z0-9]{6,64})(?:\s+(?<onu_type>[^\s]+))?/i']] :
                    [['command' => 'display ont autofind all', 'pattern' => '/F\/S\/P\s*:\s*(?<frame>\d+)\s*\/\s*(?<slot>\d+)\s*\/\s*(?<port>\d+)(?:(?!F\/S\/P).)*?Ont\s+SN\s*:\s*(?<sn>[A-Za-z0-9]{6,64})/is']];
            }
            if (!$queries) throw new HttpError(422, 'Registra la consulta y parser de lectura para este modelo y acción. No se utilizan comandos de otro fabricante.', 'OLT_QUERY_REQUIRED');
            foreach ($queries as $query) {
                $contexts = preg_match('/\{\{?(?:frame|slot|port)\}?\}/', (string)$query['command']) ? ($onu !== null ? [$onu] : ($olt['pons'] ?? [])) : [[]];
                if (!$contexts) throw new HttpError(422, 'Registra primero los puertos PON para ejecutar esta consulta.', 'QUERY_CONTEXT_REQUIRED');
                foreach ($contexts as $context) {
                    if (microtime(true) - $started > 90) throw new HttpError(502, 'La lectura agotó su tiempo; se conserva el inventario anterior.', 'OLT_RESPONSE_LIMIT');
                    if (isset($context['pon_port'])) $context['port'] = $context['pon_port'];
                    $text = $cli->read(fiberExpandReadCommand($query['command'], $context));
                    if (empty($query['pattern'])) throw new HttpError(422, 'Configura el parser de observaciones de esta consulta.', 'OLT_QUERY_REQUIRED');
                    $rows = fiberParseObservations($text, $query['pattern'], $kind, $context);
                    $result['onus'] = [...$result['onus'], ...$rows];
                }
            }
        } finally { $cli->close(); }
    }
    if (count($result['onus']) > 20000) throw new HttpError(502, 'El inventario excede el límite; no se aplica parcialmente.', 'OLT_RESPONSE_LIMIT');
    return $result;
}
