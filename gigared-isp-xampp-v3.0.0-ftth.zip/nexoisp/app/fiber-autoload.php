<?php
declare(strict_types=1);
// Pure PHP dependencies are bundled for Windows/XAMPP; no Composer runtime.
spl_autoload_register(static function (string $class): void {
    foreach (['phpseclib3\\' => __DIR__ . '/vendor/phpseclib/phpseclib/phpseclib/', 'ParagonIE\\ConstantTime\\' => __DIR__ . '/vendor/paragonie/constant_time_encoding/src/'] as $prefix => $directory) {
        if (!str_starts_with($class, $prefix)) continue;
        $relative = substr($class, strlen($prefix));
        if (!preg_match('/^[A-Za-z0-9_\\\\]+$/D', $relative)) return;
        $path = $directory . str_replace('\\', '/', $relative) . '.php';
        if (is_file($path)) require_once $path;
        return;
    }
});
