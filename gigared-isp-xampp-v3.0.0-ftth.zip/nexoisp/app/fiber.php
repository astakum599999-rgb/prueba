<?php
declare(strict_types=1);
namespace Nexo;

use DateTimeImmutable;
use DateTimeZone;
use PDO;
use Throwable;

require_once __DIR__ . '/operations.php';

/** FTTH metadata is local. Observed device fields are changed only by imports. */
function fiberTables(): array
{
    return ['olts'=>'FiberOlt','onus'=>'FiberOnu','pons'=>'FiberPonPort','vlans'=>'FiberVlan','profiles'=>'FiberProfile','zones'=>'FiberZone','naps'=>'FiberNap','splitters'=>'FiberSplitter','links'=>'FiberLink','queries'=>'FiberQuery','jobs'=>'FiberJob','drafts'=>'FiberDraft','samples'=>'FiberSample'];
}

function fiberTable(string $resource): string
{
    return fiberTables()[$resource] ?? throw new HttpError(404, 'Recurso FTTH no encontrado.', 'NOT_FOUND');
}

function fiberRecord(string $resource, string $identifier, bool $forUpdate = false): array
{
    if (preg_match('/^[a-f0-9]{24}$/D', $identifier) !== 1) throw new HttpError(422, 'Identificador FTTH inválido.', 'VALIDATION_ERROR');
    return fetchOne('SELECT * FROM `' . fiberTable($resource) . '` WHERE id=?' . ($forUpdate ? ' FOR UPDATE' : ''), [$identifier]) ?? throw new HttpError(404, 'Registro FTTH no encontrado.', 'NOT_FOUND');
}

function fiberFields(string $resource): array
{
    return match ($resource) {
        'olts'=>['id','name','vendor','model','software_version','host','transport','port','username','passwordEncrypted','snmpCommunityEncrypted','ssh_fingerprint','enabled','poll_enabled','poll_interval','next_poll_at','zone_id','latitude','longitude','status','temperature','cpu_percent','uptime','last_seen_at','last_error','created_at','updated_at'],
        'pons'=>['id','olt_id','frame','slot','port','name','technology','capacity','status','rx_power','tx_power','source','present','last_seen_at','created_at','updated_at'],
        'vlans'=>['id','olt_id','vlan','name','description','created_at','updated_at'],
        'profiles'=>['id','olt_id','name','kind','profile_index','tcont','gem_port','download_kbps','upload_kbps','fixed_kbps','assured_kbps','maximum_kbps','priority','description','created_at','updated_at'],
        'zones'=>['id','name','description','latitude','longitude','created_at','updated_at'],
        'naps'=>['id','zone_id','name','capacity','description','latitude','longitude','created_at','updated_at'],
        'splitters'=>['id','nap_id','parent_id','name','ports','loss_db','latitude','longitude','created_at','updated_at'],
        'links'=>['id','name','from_type','from_id','from_port','to_type','to_id','to_port','fiber','length_meters','color','description','created_at','updated_at'],
        'onus'=>['id','olt_id','pon_id','frame','slot','pon_port','onu_index','sn','mac','onu_type','name','status','authorization','mode','wan_mode','vlan','profile_id','rx_power','tx_power','temperature','distance','client_id','zone_id','nap_id','nap_port','latitude','longitude','notes','source','present','last_seen_at','created_at','updated_at'],
        'queries'=>['id','olt_id','kind','name','command','pattern','oid','enabled','created_at','updated_at'],
        'jobs'=>['id','olt_id','onu_id','kind','status','active_key','attempts','next_run_at','locked_at','locked_by','result','error','actor_id','created_at','updated_at','completed_at'],
        'drafts'=>['id','onu_id','action','status','configurationEncrypted','summary','actor_id','created_at','updated_at'],
        'samples'=>['id','onu_id','sampled_at','source','rx_power','tx_power','temperature','distance','download_bps','upload_bps','download_bytes','upload_bytes'],
        default=>throw new \LogicException('Entidad FTTH desconocida'),
    };
}

function fiberStore(string $resource, array $data, ?string $identifier = null): array
{
    if (array_diff(array_keys($data), fiberFields($resource))) throw new \LogicException('Campo FTTH interno no permitido');
    $fields = fiberFields($resource);
    if ($identifier === null) {
        $data['id'] ??= id();
        if (in_array('created_at', $fields, true)) $data['created_at'] ??= now();
        if (in_array('updated_at', $fields, true)) $data['updated_at'] ??= now();
        db()->prepare('INSERT INTO `' . fiberTable($resource) . '` (`' . implode('`,`', array_keys($data)) . '`) VALUES (' . implode(',', array_fill(0, count($data), '?')) . ')')->execute(array_values($data));
        return fiberRecord($resource, $data['id']);
    }
    if (array_intersect(array_keys($data), ['id','created_at'])) throw new \LogicException('Identidad FTTH inmutable');
    if (in_array('updated_at', $fields, true)) $data['updated_at'] = now();
    if ($data) db()->prepare('UPDATE `' . fiberTable($resource) . '` SET ' . implode(',', array_map(static fn($key)=>'`'.$key.'`=?', array_keys($data))) . ' WHERE id=?')->execute([...array_values($data), $identifier]);
    return fiberRecord($resource, $identifier);
}

function fiberDto(string $resource, array $row): array
{
    $result = array_intersect_key($row, array_flip(fiberFields($resource)));
    if ($resource === 'olts') {
        $result['has_password'] = !empty($row['passwordEncrypted']);
        $result['has_snmp_community'] = !empty($row['snmpCommunityEncrypted']);
        $result['network_read_only'] = networkReadOnly();
        if ($row['vendor'] === 'VSOL' && preg_match('/^V1600GS[-_ ]?F$/iD', trim((string)$row['model']))) {
            $result['model_capabilities'] = ['family'=>'VSOL_SINGLE_PON','pon_technology'=>'GPON','physical_pon_ports'=>1,'documented_transports'=>['TELNET','SNMP'],'ssh_verified'=>false,'vendor_queries_required'=>true,'speed_profiles_informational'=>true,'hardware_verified'=>false];
        }
    }
    foreach (['passwordEncrypted','snmpCommunityEncrypted','configurationEncrypted','active_key','locked_by'] as $private) unset($result[$private]);
    foreach ($result as $key=>&$value) {
        if ($value === null) continue;
        if (str_ends_with($key, '_at') && is_string($value)) $value = (new DateTimeImmutable($value, new DateTimeZone('UTC')))->format('Y-m-d\TH:i:s.v\Z');
        elseif (in_array($key, ['enabled','poll_enabled','present'], true)) $value = (bool)$value;
        elseif (in_array($key, ['summary','result'], true) && is_string($value)) $value = json_decode($value, true, 64, JSON_THROW_ON_ERROR);
        elseif (in_array($key, ['rx_power','tx_power','latitude','longitude','temperature','cpu_percent','distance','loss_db','download_bps','upload_bps'], true)) $value = (float)$value;
        elseif (in_array($key, ['port','frame','slot','pon_port','onu_index','vlan','capacity','ports','profile_index','tcont','gem_port','priority','poll_interval','nap_port','fiber','length_meters','attempts','download_kbps','upload_kbps','fixed_kbps','assured_kbps','maximum_kbps'], true)) $value = (int)$value;
    }
    unset($value);
    if ($resource === 'onus') {
        $result['fresh'] = $row['source'] === 'DEVICE' && $row['last_seen_at'] !== null && strtotime($row['last_seen_at'] . ' UTC') >= time()-120;
        $result['low_signal'] = $row['rx_power'] !== null && (float)$row['rx_power'] < -27;
    }
    if ($resource === 'drafts') $result['network_read_only'] = networkReadOnly();
    return $result;
}

function fiberRules(string $resource): array
{
    $name = ['type'=>'string','required'=>true,'min'=>1,'max'=>200];
    $text = ['type'=>'string','max'=>10000,'nullable'=>true];
    $id = ['type'=>'id','nullable'=>true,'pattern'=>'/^[a-f0-9]{24}$/D'];
    $requiredId = ['type'=>'id','required'=>true,'pattern'=>'/^[a-f0-9]{24}$/D'];
    $location = ['latitude'=>['type'=>'number','min'=>-90,'max'=>90,'nullable'=>true], 'longitude'=>['type'=>'number','min'=>-180,'max'=>180,'nullable'=>true]];
    return match ($resource) {
        'olts'=>['name'=>$name,'vendor'=>['type'=>'enum','required'=>true,'values'=>['HUAWEI','ZTE','FIBERHOME','VSOL','GENERIC']], 'software_version'=>['type'=>'string','max'=>100,'nullable'=>true], 'model'=>['type'=>'string','max'=>100,'nullable'=>true],
            'host'=>['type'=>'string','required'=>true,'min'=>1,'max'=>253], 'transport'=>['type'=>'enum','required'=>true,'values'=>['SSH','TELNET','SNMP']],
            'port'=>['type'=>'integer','min'=>1,'max'=>65535], 'username'=>['type'=>'string','max'=>200,'nullable'=>true],
            'password'=>['type'=>'string','min'=>1,'max'=>1024], 'snmp_community'=>['type'=>'string','min'=>1,'max'=>200],
            'ssh_fingerprint'=>['type'=>'string','max'=>200,'nullable'=>true,'pattern'=>'/^SHA256:[A-Za-z0-9+\/]{43}=?$/D'],
            'enabled'=>['type'=>'boolean','default'=>true], 'poll_enabled'=>['type'=>'boolean','default'=>false], 'poll_interval'=>['type'=>'integer','min'=>15,'max'=>3600,'default'=>60], 'zone_id'=>$id]+$location,
        'pons'=>['olt_id'=>$requiredId,'frame'=>['type'=>'integer','min'=>0,'max'=>255,'default'=>0],'slot'=>['type'=>'integer','min'=>0,'max'=>255,'default'=>0],'port'=>['type'=>'integer','required'=>true,'min'=>0,'max'=>255],'name'=>['type'=>'string','max'=>200,'nullable'=>true],'technology'=>['type'=>'enum','values'=>['GPON','EPON','XGSPON'],'default'=>'GPON'],'capacity'=>['type'=>'integer','min'=>1,'max'=>1024,'default'=>128]],
        'vlans'=>['olt_id'=>$requiredId,'vlan'=>['type'=>'integer','required'=>true,'min'=>1,'max'=>4094],'name'=>$name,'description'=>$text],
        'profiles'=>['olt_id'=>$requiredId,'name'=>$name,'kind'=>['type'=>'enum','required'=>true,'values'=>['DBA','LINE','SERVICE','TRAFFIC']], 'profile_index'=>['type'=>'integer','min'=>0,'max'=>65535,'nullable'=>true], 'tcont'=>['type'=>'integer','min'=>0,'max'=>255,'nullable'=>true], 'gem_port'=>['type'=>'integer','min'=>0,'max'=>65535,'nullable'=>true], 'download_kbps'=>['type'=>'integer','min'=>1,'max'=>2147483647,'nullable'=>true], 'upload_kbps'=>['type'=>'integer','min'=>1,'max'=>2147483647,'nullable'=>true], 'fixed_kbps'=>['type'=>'integer','min'=>0,'max'=>2147483647,'nullable'=>true], 'assured_kbps'=>['type'=>'integer','min'=>0,'max'=>2147483647,'nullable'=>true], 'maximum_kbps'=>['type'=>'integer','min'=>0,'max'=>2147483647,'nullable'=>true], 'priority'=>['type'=>'integer','min'=>0,'max'=>7,'default'=>0], 'description'=>$text],
        'zones'=>['name'=>$name,'description'=>$text]+$location,
        'naps'=>['name'=>$name,'zone_id'=>$id,'capacity'=>['type'=>'integer','min'=>1,'max'=>512,'default'=>8],'description'=>$text]+$location,
        'splitters'=>['name'=>$name,'nap_id'=>$id,'parent_id'=>$id,'ports'=>['type'=>'integer','min'=>1,'max'=>512,'default'=>8],'loss_db'=>['type'=>'number','min'=>0,'max'=>100,'nullable'=>true]]+$location,
        'links'=>['name'=>$name,'from_type'=>['type'=>'enum','required'=>true,'values'=>['OLT','PON','NAP','SPLITTER']],'from_id'=>$requiredId,'from_port'=>['type'=>'integer','min'=>1,'max'=>1024,'default'=>1], 'to_type'=>['type'=>'enum','required'=>true,'values'=>['OLT','PON','NAP','SPLITTER']],'to_id'=>$requiredId,'to_port'=>['type'=>'integer','min'=>1,'max'=>1024,'default'=>1], 'fiber'=>['type'=>'integer','min'=>1,'max'=>1024,'default'=>1],'length_meters'=>['type'=>'integer','min'=>0,'max'=>10000000,'nullable'=>true],'color'=>['type'=>'string','max'=>40,'nullable'=>true],'description'=>$text],
        'onus'=>['name'=>['type'=>'string','max'=>200,'nullable'=>true],'client_id'=>$id,'zone_id'=>$id,'nap_id'=>$id,'nap_port'=>['type'=>'integer','min'=>1,'max'=>512,'nullable'=>true],'notes'=>$text]+$location,
        'queries'=>['olt_id'=>$requiredId,'name'=>$name,'kind'=>['type'=>'enum','required'=>true,'values'=>['TEST','SYNC','DISCOVER','SIGNAL']], 'command'=>['type'=>'string','max'=>1000,'nullable'=>true], 'pattern'=>['type'=>'string','max'=>2000,'nullable'=>true], 'oid'=>['type'=>'string','max'=>500,'nullable'=>true,'pattern'=>'/^\.?[0-9]+(?:\.[0-9]+)+$/D'],'enabled'=>['type'=>'boolean','default'=>true]],
        default=>throw new HttpError(405, 'Este registro sólo admite consulta.', 'METHOD_NOT_ALLOWED'),
    };
}

function fiberValidate(array $input, array $rules, bool $partial = false): array
{
    $exact = [];
    foreach (['password','snmp_community','wifi_password','pppoe_password'] as $secret) if (isset($input[$secret]) && is_string($input[$secret])) {
        if (preg_match('//u', $input[$secret]) !== 1 || preg_match_all('/./us', $input[$secret]) < 1 || preg_match_all('/./us', $input[$secret]) > ($rules[$secret]['max'] ?? 1024)) throw new HttpError(422, 'Longitud de credencial inválida.', 'VALIDATION_ERROR');
        $exact[$secret] = $input[$secret];
    }
    foreach ($rules as $key=>&$rule) {
        if (($rule['type'] ?? '') === 'boolean') {
            if (array_key_exists($key, $input) && !is_bool($input[$key])) throw new HttpError(422, 'Usa un booleano en ' . $key . '.', 'VALIDATION_ERROR');
            $rule['type'] = 'integer'; $rule['min'] = 0; $rule['max'] = 1;
            if (array_key_exists('default', $rule)) $rule['default'] = (int)$rule['default'];
            if (array_key_exists($key, $input)) $input[$key] = (int)$input[$key];
        }
    }
    unset($rule);
    $result = operationsValidate($input, $rules, $partial);
    foreach ($exact as $key=>$value) if (array_key_exists($key, $result)) $result[$key] = $value;
    foreach ($result as $key=>$value) if (is_string($value) && !in_array($key, ['notes','description'], true) && preg_match('/[\x00-\x1f\x7f]/', $value)) throw new HttpError(422, 'Texto con controles en ' . $key . '.', 'VALIDATION_ERROR');
    return $result;
}

function fiberRequireReference(string $resource, ?string $identifier, bool $forUpdate = false): ?array
{
    if ($identifier === null) return null;
    return fetchOne('SELECT * FROM `' . fiberTable($resource) . '` WHERE id=?' . ($forUpdate ? ' FOR UPDATE' : ''), [$identifier]) ?? throw new HttpError(422, 'Una referencia FTTH no existe.', 'INVALID_REFERENCE');
}

function fiberReferenceChecks(string $resource, array $data, ?string $identifier = null): void
{
    foreach (['olt_id'=>'olts','pon_id'=>'pons','profile_id'=>'profiles','zone_id'=>'zones','nap_id'=>'naps','parent_id'=>'splitters'] as $field=>$reference) if (isset($data[$field])) fiberRequireReference($reference, $data[$field]);
    if (isset($data['client_id']) && fetchOne('SELECT id FROM `Client` WHERE id=?', [$data['client_id']]) === null) throw new HttpError(422, 'Cliente no encontrado.', 'INVALID_REFERENCE');
    if ($resource === 'olts') {
        $host = $data['host'];
        if (filter_var($host, FILTER_VALIDATE_IP) === false && preg_match('/^(?=.{1,253}$)[A-Za-z0-9](?:[A-Za-z0-9.-]*[A-Za-z0-9])?$/D', $host) !== 1) throw new HttpError(422, 'Host de OLT inválido.', 'VALIDATION_ERROR');
        if ($identifier !== null) {
            $old = fiberRecord('olts', $identifier);
            if (($old['host'] !== $host || $old['vendor'] !== $data['vendor']) && fetchOne('SELECT id FROM `FiberOnu` WHERE olt_id=? LIMIT 1', [$identifier])) throw new HttpError(409, 'Una OLT con inventario no puede reasignarse a otro host o fabricante.', 'OLT_IDENTITY_LOCKED');
        }
    }
    if ($resource === 'profiles' && isset($data['maximum_kbps']) && ((isset($data['fixed_kbps']) && $data['fixed_kbps'] > $data['maximum_kbps']) || (isset($data['assured_kbps']) && $data['assured_kbps'] > $data['maximum_kbps']))) throw new HttpError(422, 'La velocidad máxima debe cubrir la fija y asegurada.', 'VALIDATION_ERROR');
    if ($resource === 'onus') {
        if (($data['nap_id'] ?? null) === null xor ($data['nap_port'] ?? null) === null) throw new HttpError(422, 'Indica juntos caja NAP y puerto.', 'VALIDATION_ERROR');
        if (isset($data['nap_id'])) {
            $nap = fiberRecord('naps', $data['nap_id'], true);
            if ($data['nap_port'] > (int)$nap['capacity']) throw new HttpError(422, 'El puerto supera la capacidad de la NAP.', 'NAP_CAPACITY');
            if (isset($data['zone_id']) && $nap['zone_id'] !== null && $nap['zone_id'] !== $data['zone_id']) throw new HttpError(422, 'La NAP pertenece a otra zona.', 'ZONE_CONFLICT');
            if (fetchOne('SELECT id FROM `FiberOnu` WHERE nap_id=? AND nap_port=? AND id<>?', [$data['nap_id'],$data['nap_port'],$identifier ?? ''])) throw new HttpError(409, 'El puerto NAP ya tiene una ONU asignada.', 'NAP_PORT_OCCUPIED');
            if (fetchOne("SELECT id FROM `FiberLink` WHERE (from_type='NAP' AND from_id=? AND from_port=?) OR (to_type='NAP' AND to_id=? AND to_port=?)", [$data['nap_id'],$data['nap_port'],$data['nap_id'],$data['nap_port']])) throw new HttpError(409, 'El puerto NAP ya tiene un enlace asignado.', 'NAP_PORT_OCCUPIED');
        }
    }
    if ($resource === 'naps' && $identifier !== null) {
        if (fetchOne('SELECT id FROM `FiberOnu` WHERE nap_id=? AND nap_port>? LIMIT 1', [$identifier,$data['capacity']]) || fetchOne("SELECT id FROM `FiberLink` WHERE (from_type='NAP' AND from_id=? AND from_port>?) OR (to_type='NAP' AND to_id=? AND to_port>?) LIMIT 1", [$identifier,$data['capacity'],$identifier,$data['capacity']])) throw new HttpError(409, 'La capacidad no puede excluir puertos ocupados.', 'NAP_CAPACITY');
    }
    if ($resource === 'splitters' && isset($data['parent_id'])) {
        $cursor = $data['parent_id']; $seen = [];
        while ($cursor !== null) {
            if ($cursor === $identifier || isset($seen[$cursor])) throw new HttpError(422, 'La jerarquía de splitters no puede contener ciclos.', 'SPLITTER_CYCLE');
            $seen[$cursor] = true; $cursor = fiberRecord('splitters', $cursor)['parent_id'];
            if (count($seen)>100) throw new HttpError(422, 'La jerarquía supera cien niveles.', 'SPLITTER_DEPTH');
        }
    }
    if ($resource === 'links') {
        if ($data['from_type'] === $data['to_type'] && $data['from_id'] === $data['to_id']) throw new HttpError(422, 'Un enlace debe unir elementos distintos.', 'INVALID_LINK');
        $references = ['OLT'=>'olts','PON'=>'pons','NAP'=>'naps','SPLITTER'=>'splitters'];
        foreach (['from','to'] as $end) {
            $type = $data[$end.'_type']; $endId = $data[$end.'_id']; $port = $data[$end.'_port'];
            $record = fiberRequireReference($references[$type], $endId, true);
            $capacity = $type === 'NAP' ? $record['capacity'] : ($type === 'SPLITTER' ? $record['ports'] : 1024);
            if ($port > (int)$capacity) throw new HttpError(422, 'El puerto del enlace supera la capacidad.', 'PORT_CAPACITY');
            if ($type === 'NAP' && fetchOne('SELECT id FROM `FiberOnu` WHERE nap_id=? AND nap_port=? LIMIT 1', [$endId,$port])) throw new HttpError(409, 'El puerto NAP pertenece a una ONU.', 'NAP_PORT_OCCUPIED');
            if (fetchOne('SELECT id FROM `FiberLink` WHERE id<>? AND ((from_type=? AND from_id=? AND from_port=?) OR (to_type=? AND to_id=? AND to_port=?))', [$identifier ?? '',$type,$endId,$port,$type,$endId,$port])) throw new HttpError(409, 'El puerto físico ya tiene un enlace.', 'PORT_OCCUPIED');
        }
    }
    if ($resource === 'queries') {
        if (empty($data['command']) && empty($data['oid'])) throw new HttpError(422, 'Indica una consulta de lectura o un OID.', 'VALIDATION_ERROR');
        if (!empty($data['command']) && (preg_match('/^(?:display|show)\s+[A-Za-z0-9{}_.\/ :?=-]+$/iD', $data['command']) !== 1)) throw new HttpError(422, 'Sólo se admiten consultas display/show de una línea.', 'READ_QUERY_REQUIRED');
        if (!empty($data['command']) && preg_match('/\b(?:configuration|running-config|startup-config|password|community|secret)\b/i', $data['command'])) throw new HttpError(422, 'La consulta no puede solicitar configuración ni credenciales.', 'READ_QUERY_REQUIRED');
        if (!empty($data['pattern']) && @preg_match($data['pattern'], '') === false) throw new HttpError(422, 'Patrón de lectura inválido.', 'VALIDATION_ERROR');
    }
}

function fiberMetadata(string $resource, array $input, array $actor, ?string $identifier = null): array
{
    $data = fiberValidate($input, fiberRules($resource), $identifier !== null);
    $initial = $identifier === null ? [] : fiberRecord($resource, $identifier);
    $oltId = $resource === 'olts' ? $identifier : ($initial['olt_id'] ?? $data['olt_id'] ?? null);
    $keys = ['fiber:metadata']; if ($oltId !== null) $keys[] = 'fiber:olt:' . $oltId;
    return operationsLocks($keys, fn()=>tx(function () use ($resource,$data,$identifier,$actor): array {
        $old = $identifier === null ? [] : fiberRecord($resource, $identifier, true);
        if (isset($old['olt_id'],$data['olt_id']) && $old['olt_id'] !== $data['olt_id']) throw new HttpError(409, 'No se puede trasladar este registro a otra OLT.', 'OLT_IDENTITY_LOCKED');
        $merged = $data + $old;
        if ($resource === 'olts') {
            $merged['port'] ??= match ($merged['transport']) { 'SSH'=>22,'TELNET'=>23,'SNMP'=>161 };
            $data['port'] = $merged['port'];
        }
        fiberReferenceChecks($resource, $merged, $identifier);
        if ($resource === 'olts') {
            foreach (['password'=>'passwordEncrypted','snmp_community'=>'snmpCommunityEncrypted'] as $plain=>$encrypted) if (isset($data[$plain])) { $data[$encrypted] = encryptSecret($data[$plain]); unset($data[$plain]); }
        }
        $row = fiberStore($resource, $data, $identifier);
        audit('fiber.metadata.' . ($identifier === null ? 'create' : 'update'), fiberTable($resource), $row['id'], $actor['id']);
        return fiberDto($resource, $row);
    }));
}

function fiberObservedRules(string $resource): array
{
    $power = ['type'=>'number','min'=>-100,'max'=>100,'nullable'=>true];
    $rules = $resource === 'pons' ? fiberRules('pons') : [
        'sn'=>['type'=>'string','required'=>true,'min'=>1,'max'=>64,'pattern'=>'/^[A-Za-z0-9:._-]+$/D'],
        'frame'=>['type'=>'integer','min'=>0,'max'=>255,'default'=>0], 'slot'=>['type'=>'integer','min'=>0,'max'=>255,'default'=>0],
        'port'=>['type'=>'integer','min'=>0,'max'=>255,'default'=>0], 'onu_index'=>['type'=>'integer','min'=>0,'max'=>4095,'nullable'=>true],
        'mac'=>['type'=>'mac','nullable'=>true,'max'=>17], 'onu_type'=>['type'=>'string','max'=>100,'nullable'=>true], 'name'=>['type'=>'string','max'=>200,'nullable'=>true],
        'authorization'=>['type'=>'enum','values'=>['AUTHORIZED','UNAUTHORIZED'],'default'=>'UNAUTHORIZED'],
        'mode'=>['type'=>'enum','values'=>['BRIDGE','ROUTER'],'nullable'=>true], 'wan_mode'=>['type'=>'enum','values'=>['PPPOE','DHCP','STATIC'],'nullable'=>true],
        'vlan'=>['type'=>'integer','min'=>1,'max'=>4094,'nullable'=>true], 'temperature'=>['type'=>'number','min'=>-100,'max'=>250,'nullable'=>true],
        'distance'=>['type'=>'number','min'=>0,'max'=>1000000,'nullable'=>true],
        'download_bps'=>['type'=>'number','min'=>0,'max'=>1e15,'nullable'=>true], 'upload_bps'=>['type'=>'number','min'=>0,'max'=>1e15,'nullable'=>true],
        'download_bytes'=>['type'=>'string','max'=>24,'pattern'=>'/^[0-9]{1,24}$/D','nullable'=>true], 'upload_bytes'=>['type'=>'string','max'=>24,'pattern'=>'/^[0-9]{1,24}$/D','nullable'=>true],
    ];
    unset($rules['olt_id']);
    return $rules + ['status'=>['type'=>'enum','values'=>['ONLINE','OFFLINE','LOS','UNKNOWN'],'default'=>'UNKNOWN'], 'rx_power'=>$power,'tx_power'=>$power];
}

/** Validate all rows before opening the transaction; no partial inventory saves. */
function fiberImport(string $oltId, array $input, ?string $actorId, string $source = 'USER_IMPORT', bool $lockHeld = false): array
{
    if (!in_array($source, ['USER_IMPORT','DEVICE'], true)) throw new \LogicException('Origen FTTH inválido');
    if (array_diff(array_keys($input), ['pons','onus','olt','complete']) || (!array_key_exists('pons',$input) && !array_key_exists('onus',$input) && !array_key_exists('olt',$input))) throw new HttpError(422, 'Indica pons u onus como inventario.', 'VALIDATION_ERROR');
    if (isset($input['complete']) && !is_bool($input['complete'])) throw new HttpError(422, 'complete debe ser booleano.', 'VALIDATION_ERROR');
    $observations = [];
    foreach (['pons','onus'] as $resource) {
        if (!array_key_exists($resource,$input)) continue;
        if (!is_array($input[$resource]) || !array_is_list($input[$resource]) || count($input[$resource]) > 20000) throw new HttpError(422, 'El inventario debe ser una lista con hasta20000 registros.', 'VALIDATION_ERROR');
        $seen = []; $physical = [];
        foreach ($input[$resource] as $row) {
            if (!is_array($row) || array_is_list($row)) throw new HttpError(422, 'Registro de inventario inválido.', 'VALIDATION_ERROR');
            foreach (['download_bytes','upload_bytes'] as $counter) if (isset($row[$counter]) && is_int($row[$counter]) && $row[$counter]>=0) $row[$counter] = (string)$row[$counter];
            $data = fiberValidate($row, fiberObservedRules($resource));
            if ($resource === 'onus') $data['sn'] = strtoupper($data['sn']);
            $key = $resource === 'pons' ? implode(':',[$data['frame'],$data['slot'],$data['port']]) : $data['sn'];
            if (isset($seen[$key])) throw new HttpError(422, 'El inventario contiene identidades duplicadas.', 'DUPLICATE_INVENTORY');
            $seen[$key] = true;
            if ($resource === 'onus' && isset($data['onu_index'])) {
                $location = implode(':',[$data['frame'],$data['slot'],$data['port'],$data['onu_index']]);
                if (isset($physical[$location])) throw new HttpError(422, 'Dos ONUs ocupan el mismo índice físico.', 'DUPLICATE_INVENTORY');
                $physical[$location] = true;
            }
            $observations[$resource][] = $data;
        }
        $observations[$resource] ??= [];
    }
    $oltObservation = [];
    if (array_key_exists('olt',$input)) {
        if ($source !== 'DEVICE' || !is_array($input['olt'])) throw new HttpError(422, 'El estado de conexión sólo se observa desde el transporte.', 'VALIDATION_ERROR');
        $allowed = ['status','temperature','cpu_percent','uptime','last_seen_at'];
        $data = array_intersect_key($input['olt'], array_flip($allowed)); unset($data['last_seen_at']);
        $oltObservation = fiberValidate($data, ['status'=>['type'=>'enum','values'=>['ONLINE','OFFLINE','UNKNOWN']], 'temperature'=>['type'=>'number','min'=>-100,'max'=>250,'nullable'=>true], 'cpu_percent'=>['type'=>'number','min'=>0,'max'=>100,'nullable'=>true], 'uptime'=>['type'=>'string','max'=>200,'nullable'=>true]]);
    }
    if (!$lockHeld) return operationsLocks(['fiber:olt:'.$oltId], fn()=>fiberImport($oltId,$input,$actorId,$source,true));
    return tx(function () use ($oltId,$input,$observations,$oltObservation,$actorId,$source): array {
        fiberRecord('olts',$oltId,true);
        $timestamp = now(); $summary = ['olt_id'=>$oltId,'source'=>$source,'created'=>0,'updated'=>0,'missing'=>0,'pons'=>0,'onus'=>0,'network_read_only'=>true];
        if ($oltObservation !== []) fiberStore('olts',$oltObservation + ['last_seen_at'=>$timestamp,'last_error'=>null],$oltId);
        foreach (['pons','onus'] as $resource) {
            if (!array_key_exists($resource,$observations)) continue;
            $existing = fetchAll('SELECT * FROM `'.fiberTable($resource).'` WHERE olt_id=? FOR UPDATE',[$oltId]);
            $byIdentity = [];
            foreach ($existing as $old) $byIdentity[$resource==='pons' ? implode(':',[$old['frame'],$old['slot'],$old['port']]) : $old['sn']] = $old;
            $current = [];
            foreach ($observations[$resource] as $data) $current[$resource==='pons' ? implode(':',[$data['frame'],$data['slot'],$data['port']]) : $data['sn']] = true;
            if (($input['complete'] ?? false) === true) foreach ($byIdentity as $key=>$old) if (!isset($current[$key])) {
                $missing = ['present'=>0,'status'=>'UNKNOWN']; if ($resource==='onus') $missing['onu_index']=null;
                fiberStore($resource,$missing,$old['id']); $summary['missing']++;
            }
            foreach ($observations[$resource] as $data) {
                $identity = $resource==='pons' ? implode(':',[$data['frame'],$data['slot'],$data['port']]) : $data['sn'];
                $old = $byIdentity[$identity] ?? null;
                $sample = [];
                if ($resource==='onus') {
                    foreach (['rx_power','tx_power','temperature','distance','download_bps','upload_bps','download_bytes','upload_bytes'] as $field) if (isset($data[$field])) $sample[$field] = $data[$field];
                    unset($data['download_bps'],$data['upload_bps'],$data['download_bytes'],$data['upload_bytes']);
                    $port = fetchOne('SELECT id FROM `FiberPonPort` WHERE olt_id=? AND frame=? AND slot=? AND port=?',[$oltId,$data['frame'],$data['slot'],$data['port']]);
                    if ($port===null) $port=fiberStore('pons',['olt_id'=>$oltId,'frame'=>$data['frame'],'slot'=>$data['slot'],'port'=>$data['port'],'source'=>$source,'present'=>1,'last_seen_at'=>$timestamp]);
                    $data['pon_id']=$port['id']; $data['pon_port']=$data['port']; unset($data['port']);
                    if ($old!==null) unset($data['name']);
                }
                $data += ['olt_id'=>$oltId,'source'=>$source,'present'=>1,'last_seen_at'=>$timestamp];
                $row=fiberStore($resource,$data,$old['id'] ?? null);
                $summary[$old===null ? 'created':'updated']++; $summary[$resource]++;
                if ($sample) fiberStore('samples',$sample+['onu_id'=>$row['id'],'sampled_at'=>$timestamp,'source'=>$source]);
            }
        }
        audit('fiber.inventory.import','FiberOlt',$oltId,$actorId);
        db()->prepare('DELETE FROM `FiberSample` WHERE sampled_at < DATE_SUB(UTC_TIMESTAMP(3),INTERVAL 30 DAY)')->execute();
        return $summary;
    });
}

function fiberDraftRules(): array
{
    $id=['type'=>'id','nullable'=>true,'pattern'=>'/^[a-f0-9]{24}$/D'];
    return [
        'name'=>['type'=>'string','max'=>200,'nullable'=>true],'onu_type'=>['type'=>'string','max'=>100,'nullable'=>true],
        'vlan'=>['type'=>'integer','min'=>1,'max'=>4094,'nullable'=>true],'profile_id'=>$id,'line_profile_id'=>$id,'service_profile_id'=>$id,'dba_profile_id'=>$id,
        'mode'=>['type'=>'enum','values'=>['BRIDGE','ROUTER'],'nullable'=>true],'wan_mode'=>['type'=>'enum','values'=>['PPPOE','DHCP','STATIC'],'nullable'=>true],
        'username'=>['type'=>'string','max'=>200,'nullable'=>true],'password'=>['type'=>'string','min'=>1,'max'=>1024],
        'ssid'=>['type'=>'string','min'=>1,'max'=>32],'wifi_password'=>['type'=>'string','min'=>8,'max'=>63],
        'ip_address'=>['type'=>'string','max'=>45,'nullable'=>true],'gateway'=>['type'=>'string','max'=>45,'nullable'=>true],'netmask'=>['type'=>'string','max'=>45,'nullable'=>true],
        'client_id'=>$id,'zone_id'=>$id,'nap_id'=>$id,'nap_port'=>['type'=>'integer','min'=>1,'max'=>512,'nullable'=>true],
        'description'=>['type'=>'string','max'=>2000,'nullable'=>true],
    ];
}

function fiberPreview(string $onuId, array $input, array $actor): array
{
    if (array_diff(array_keys($input),['action','configuration']) || !is_string($input['action'] ?? null) || !in_array($input['action'],['AUTHORIZE','REBOOT','WIFI','SUSPEND','REACTIVATE','DELETE'],true) || !is_array($input['configuration'] ?? [])) throw new HttpError(422,'Plan de operación inválido.','VALIDATION_ERROR');
    $configuration=fiberValidate($input['configuration'] ?? [],fiberDraftRules());
    $onu=fiberRecord('onus',$onuId); $action=$input['action'];
    if ($action==='AUTHORIZE') {
        if ($onu['authorization']!=='UNAUTHORIZED') throw new HttpError(409,'La ONU ya consta autorizada en el inventario.','ALREADY_AUTHORIZED');
        if (!isset($configuration['vlan'],$configuration['mode'])) throw new HttpError(422,'Selecciona VLAN y modo para preparar la autorización.','VALIDATION_ERROR');
        if (!fetchOne('SELECT id FROM `FiberVlan` WHERE olt_id=? AND vlan=?',[$onu['olt_id'],$configuration['vlan']])) throw new HttpError(422,'La VLAN no está registrada para esta OLT.','INVALID_REFERENCE');
        if (($configuration['mode'] ?? null)==='ROUTER' && !isset($configuration['wan_mode'])) throw new HttpError(422,'Selecciona el modo WAN.','VALIDATION_ERROR');
        if (($configuration['wan_mode'] ?? null)==='PPPOE' && (!isset($configuration['username'],$configuration['password']) || $configuration['username']==='')) throw new HttpError(422,'PPPoE necesita usuario y contraseña.','VALIDATION_ERROR');
        if (($configuration['wan_mode'] ?? null)==='STATIC') foreach (['ip_address','gateway','netmask'] as $field) if (!isset($configuration[$field]) || filter_var($configuration[$field],FILTER_VALIDATE_IP,FILTER_FLAG_IPV4)===false) throw new HttpError(422,'Completa la dirección estática IPv4, máscara y gateway.','VALIDATION_ERROR');
    }
    if ($action==='WIFI' && !isset($configuration['ssid'],$configuration['wifi_password'])) throw new HttpError(422,'Indica SSID y clave WiFi.','VALIDATION_ERROR');
    foreach (['profile_id','line_profile_id','service_profile_id','dba_profile_id'] as $field) if (isset($configuration[$field]) && fiberRecord('profiles',$configuration[$field])['olt_id']!==$onu['olt_id']) throw new HttpError(422,'El perfil corresponde a otra OLT.','OLT_REFERENCE_CONFLICT');
    fiberReferenceChecks('onus',$configuration+$onu,$onuId);
    $public=$configuration;
    foreach (['password','wifi_password'] as $private) if (array_key_exists($private,$public)) { unset($public[$private]); $public['has_'.$private]=true; }
    $summary=['action'=>$action,'configuration'=>$public,'execution'=>'PREVIEW_ONLY','hardware_changed'=>false,'steps'=>match($action){'AUTHORIZE'=>['Verificar identidad y puerto PON','Revisar VLAN, perfiles y ubicación','Preparar configuración sin aplicarla'],'REBOOT'=>['Preparar reinicio sin desconectar la ONU'],'WIFI'=>['Validar SSID y guardar la clave cifrada en el plan'],'SUSPEND'=>['Preparar suspensión sin cortar el servicio'],'REACTIVATE'=>['Preparar reactivación sin cambiar la ONU'],'DELETE'=>['Preparar eliminación sin borrar la ONU ni su historial']}];
    return tx(function () use ($onuId,$action,$configuration,$summary,$actor): array {
        $draft=fiberStore('drafts',['onu_id'=>$onuId,'action'=>$action,'configurationEncrypted'=>encryptSecret(json_encode($configuration,JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE)),'summary'=>json_encode($summary,JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE),'actor_id'=>$actor['id']]);
        audit('fiber.operation.preview','FiberDraft',$draft['id'],$actor['id']);
        return fiberDto('drafts',$draft);
    });
}

function fiberList(string $resource): array
{
    $paging=pagination(); $table=fiberTable($resource); $fields=fiberFields($resource); $where=[]; $parameters=[];
    if ($paging['search']!=='') {
        $searchable=array_values(array_intersect(['name','sn','mac','host','vendor','model','onu_type','id'],$fields));
        $where[]='('.implode(' OR ',array_map(static fn($field)=>'`'.$field.'` LIKE ?',$searchable)).')';
        foreach ($searchable as $_) $parameters[]='%'.$paging['search'].'%';
    }
    foreach (['olt_id','client_id','zone_id','nap_id','pon_id','onu_id','status','authorization','kind','present'] as $field) {
        if (!in_array($field,$fields,true) || !array_key_exists($field,$_GET) || $_GET[$field]==='') continue;
        if (!is_string($_GET[$field]) || strlen($_GET[$field])>100) throw new HttpError(422,'Filtro FTTH inválido.','VALIDATION_ERROR');
        $where[]='`'.$field.'`=?'; $parameters[]=$_GET[$field];
    }
    if ($resource==='onus' && ($_GET['low_signal'] ?? '')==='1') $where[]='rx_power < -27';
    $clause=$where ? ' WHERE '.implode(' AND ',$where) : '';
    $count=(int)fetchOne('SELECT COUNT(*) AS total FROM `'.$table.'`'.$clause,$parameters)['total'];
    $sort=in_array('created_at',$fields,true) ? 'created_at DESC,id' : 'sampled_at DESC,id';
    $rows=fetchAll('SELECT * FROM `'.$table.'`'.$clause.' ORDER BY '.$sort.' LIMIT '.(int)$paging['pageSize'].' OFFSET '.(int)$paging['offset'],$parameters);
    return ['results'=>array_map(static fn($row)=>fiberDto($resource,$row),$rows),'count'=>$count,'page'=>$paging['page'],'pageSize'=>$paging['pageSize']];
}

function fiberSummary(): array
{
    $counts=['olts'=>(int)fetchOne('SELECT COUNT(*) AS total FROM `FiberOlt`')['total'],'onus'=>(int)fetchOne('SELECT COUNT(*) AS total FROM `FiberOnu` WHERE present=1')['total'],'naps'=>(int)fetchOne('SELECT COUNT(*) AS total FROM `FiberNap`')['total']];
    foreach (['online'=>'ONLINE','offline'=>'OFFLINE','los'=>'LOS'] as $key=>$state) $counts[$key]=(int)fetchOne('SELECT COUNT(*) AS total FROM `FiberOnu` WHERE present=1 AND status=?',[$state])['total'];
    $counts['unauthorized']=(int)fetchOne("SELECT COUNT(*) AS total FROM `FiberOnu` WHERE present=1 AND authorization='UNAUTHORIZED'")['total'];
    $counts['low_signal']=(int)fetchOne('SELECT COUNT(*) AS total FROM `FiberOnu` WHERE present=1 AND rx_power < -27')['total'];
    $counts['lowSignal']=$counts['low_signal'];
    return ['counts'=>$counts,'network_read_only'=>networkReadOnly(),'observed_at'=>(new DateTimeImmutable('now',new DateTimeZone('UTC')))->format('Y-m-d\TH:i:s.v\Z')];
}

function fiberMap(): array
{
    $result=[];
    foreach (['olts','zones','naps','splitters','links','pons','onus'] as $resource) {
        $rows=fetchAll('SELECT * FROM `'.fiberTable($resource).'` ORDER BY id LIMIT 5000');
        $result[$resource]=array_map(static fn($row)=>fiberDto($resource,$row),$rows);
        $result['truncated'][$resource]=(int)fetchOne('SELECT COUNT(*) AS total FROM `'.fiberTable($resource).'`')['total']>5000;
    }
    return $result;
}

function fiberQueueJob(string $oltId, string $kind, ?string $onuId, ?string $actorId): array
{
    if (!in_array($kind,['TEST','SYNC','DISCOVER','SIGNAL'],true)) throw new HttpError(422,'Consulta FTTH no válida.','VALIDATION_ERROR');
    $olt=fiberRecord('olts',$oltId);
    if (!(bool)$olt['enabled']) throw new HttpError(409,'La OLT está deshabilitada localmente.','OLT_DISABLED');
    if ($onuId!==null && fiberRecord('onus',$onuId)['olt_id']!==$oltId) throw new HttpError(422,'La ONU pertenece a otra OLT.','INVALID_REFERENCE');
    $active=$oltId.':'.$kind.':'.($onuId ?? 'all');
    return operationsLocks(['fiber:queue:'.$oltId],function () use ($oltId,$kind,$onuId,$actorId,$active): array {
        $existing=fetchOne('SELECT * FROM `FiberJob` WHERE active_key=?',[$active]);
        if ($existing!==null) return fiberDto('jobs',$existing)+['reused'=>true];
        $job=fiberStore('jobs',['olt_id'=>$oltId,'onu_id'=>$onuId,'kind'=>$kind,'active_key'=>$active,'actor_id'=>$actorId]);
        audit('fiber.read.queued','FiberJob',$job['id'],$actorId);
        return fiberDto('jobs',$job)+['reused'=>false];
    });
}

/** Polling is explicitly enabled per OLT; metadata registration does not connect. */
function fiberScheduleReads(): void
{
    if (!lock('fiber:scheduler',0)) return;
    try {
        $rows=fetchAll('SELECT id,poll_interval FROM `FiberOlt` WHERE enabled=1 AND poll_enabled=1 AND (next_poll_at IS NULL OR next_poll_at<=?) ORDER BY next_poll_at,id LIMIT 5',[now()]);
        foreach ($rows as $row) {
            fiberQueueJob($row['id'],'SYNC',null,null);
            $next=(new DateTimeImmutable('now',new DateTimeZone('UTC')))->modify('+'.(int)$row['poll_interval'].' seconds')->format('Y-m-d H:i:s.v');
            db()->prepare('UPDATE `FiberOlt` SET next_poll_at=? WHERE id=?')->execute([$next,$row['id']]);
        }
    } finally { unlock('fiber:scheduler'); }
}

/** The durable queue contains read jobs only. No command-writing job is claimed. */
function fiberProcessJobs(int $maximum = 1): array
{
    $maximum=max(1,min(5,$maximum)); $result=['processed'=>0,'failed'=>0,'deferred'=>0];
    for ($index=0;$index<$maximum;$index++) {
        $owner=bin2hex(random_bytes(16));
        $job=tx(function () use ($owner): ?array {
            $cutoff=(new DateTimeImmutable('now',new DateTimeZone('UTC')))->modify('-5 minutes')->format('Y-m-d H:i:s.v');
            db()->prepare("UPDATE `FiberJob` SET status='FAILED',active_key=NULL,error='La reserva de lectura expiró.',completed_at=?,updated_at=? WHERE status='RUNNING' AND (locked_at IS NULL OR locked_at<?)")->execute([now(),now(),$cutoff]);
            $row=fetchOne("SELECT * FROM `FiberJob` WHERE status='QUEUED' AND next_run_at<=? ORDER BY created_at,id LIMIT 1 FOR UPDATE",[now()]);
            if ($row===null) return null;
            db()->prepare("UPDATE `FiberJob` SET status='RUNNING',attempts=attempts+1,locked_at=?,locked_by=?,updated_at=? WHERE id=?")->execute([now(),$owner,now(),$row['id']]);
            return $row+['owner'=>$owner];
        });
        if ($job===null) break;
        $key='fiber:olt:'.$job['olt_id'];
        if (!lock($key,0)) {
            $next=(new DateTimeImmutable('now',new DateTimeZone('UTC')))->modify('+5 seconds')->format('Y-m-d H:i:s.v');
            db()->prepare("UPDATE `FiberJob` SET status='QUEUED',attempts=GREATEST(0,attempts-1),next_run_at=?,locked_at=NULL,locked_by=NULL,updated_at=? WHERE id=? AND locked_by=?")->execute([$next,now(),$job['id'],$owner]);
            $result['deferred']++; continue;
        }
        try {
            $olt=fiberRecord('olts',$job['olt_id']);
            if (!(bool)$olt['enabled']) throw new HttpError(409,'La OLT está deshabilitada.','OLT_DISABLED');
            $olt['queries']=fetchAll('SELECT * FROM `FiberQuery` WHERE olt_id=? AND enabled=1 ORDER BY id',[$olt['id']]);
            $olt['pons']=fetchAll('SELECT * FROM `FiberPonPort` WHERE olt_id=? AND present=1 ORDER BY frame,slot,port',[$olt['id']]);
            $onu=$job['onu_id']===null ? null : fiberRecord('onus',$job['onu_id']);
            if (!function_exists(__NAMESPACE__.'\\fiberRunReadJob')) throw new HttpError(501,'El transporte de lectura FTTH no está disponible.','TRANSPORT_UNAVAILABLE');
            $observed=fiberRunReadJob($olt,$job['kind'],$onu);
            if (!is_array($observed)) throw new HttpError(502,'El transporte no devolvió un inventario válido.','INVALID_DEVICE_RESPONSE');
            $payload=array_intersect_key($observed,array_flip(['pons','onus','olt','complete']));
            if ($job['kind']!=='SYNC') $payload['complete']=false;
            $summary=fiberImport($olt['id'],$payload,$job['actor_id'],'DEVICE',true);
            // Successful contact is distinct from ONU authorization or online status.
            fiberStore('olts',['status'=>'ONLINE','last_seen_at'=>now(),'last_error'=>null],$olt['id']);
            db()->prepare("UPDATE `FiberJob` SET status='SUCCEEDED',active_key=NULL,result=?,error=NULL,completed_at=?,locked_at=NULL,locked_by=NULL,updated_at=? WHERE id=? AND locked_by=?")
                ->execute([json_encode($summary,JSON_THROW_ON_ERROR),now(),now(),$job['id'],$owner]);
            $result['processed']++;
        } catch (Throwable $error) {
            $code=$error instanceof HttpError ? $error->errorCode : 'READ_FAILED';
            $message='No se completó la lectura de la OLT. Revisa conexión, credenciales, pin SSH y consultas del modelo.';
            if ($code==='TRANSPORT_UNAVAILABLE') $message='El transporte de lectura no está disponible en este servidor.';
            db()->prepare("UPDATE `FiberJob` SET status='FAILED',active_key=NULL,error=?,completed_at=?,locked_at=NULL,locked_by=NULL,updated_at=? WHERE id=? AND locked_by=?")->execute([$message,now(),now(),$job['id'],$owner]);
            fiberStore('olts',['status'=>'UNKNOWN','last_error'=>$message],$job['olt_id']);
            $result['failed']++;
        } finally { unlock($key); }
    }
    return $result;
}

function fiberDetail(string $resource, string $identifier): array
{
    $row=fiberDto($resource,fiberRecord($resource,$identifier));
    if ($resource==='onus') {
        foreach (['samples','drafts','jobs'] as $child) {
            $sort=$child==='samples' ? 'sampled_at DESC' : 'created_at DESC';
            $row[$child]=array_map(static fn($entry)=>fiberDto($child,$entry),fetchAll('SELECT * FROM `'.fiberTable($child).'` WHERE onu_id=? ORDER BY '.$sort.',id LIMIT 120',[$identifier]));
        }
    }
    if ($resource==='olts') {
        $row['queries']=array_map(static fn($query)=>fiberDto('queries',$query),fetchAll('SELECT * FROM `FiberQuery` WHERE olt_id=? ORDER BY id',[$identifier]));
        $row['pons']=array_map(static fn($pon)=>fiberDto('pons',$pon),fetchAll('SELECT * FROM `FiberPonPort` WHERE olt_id=? ORDER BY frame,slot,port',[$identifier]));
    }
    return $row;
}

function fiberDispatch(string $method, string $route): bool
{
    if (!str_starts_with($route,'/fiber')) return false;
    $actor=requireAuth();
    if ($method==='GET' && $route==='/fiber/summary') json(fiberSummary());
    if ($method==='GET' && $route==='/fiber/map') json(fiberMap());
    if ($method==='GET' && $route==='/fiber/capabilities') json(['network_read_only'=>networkReadOnly(),'writes_supported'=>false,'vendors'=>['HUAWEI','ZTE','FIBERHOME','VSOL','GENERIC'],'transports'=>['SSH','TELNET','SNMP'],'read_only_queries'=>true,'api_compatibility'=>'GIGARED_NATIVE','hardware_verified'=>false]);
    if (preg_match('#^/fiber/clients/([a-f0-9]{24})/onus$#D',$route,$match) && $method==='GET') {
        if (!fetchOne('SELECT id FROM `Client` WHERE id=?',[$match[1]])) throw new HttpError(404,'Cliente no encontrado.','NOT_FOUND');
        json(['results'=>array_map(static fn($row)=>fiberDto('onus',$row),fetchAll('SELECT * FROM `FiberOnu` WHERE client_id=? ORDER BY id',[$match[1]]))]);
    }
    if ($route==='/fiber/tick' && $method==='POST') {
        permit('ADMIN','TECHNICIAN'); if (body()!==[]) throw new HttpError(422,'La lectura no admite parámetros.','VALIDATION_ERROR');
        if (function_exists('set_time_limit')) set_time_limit(120);
        ignore_user_abort(true);
        rateLimit('fiber-tick:'.$actor['id'],60,60); fiberScheduleReads(); json(fiberProcessJobs(1));
    }
    if (preg_match('#^/fiber/olts/([a-f0-9]{24})/(test|sync|discover|import)$#D',$route,$match) && $method==='POST') {
        permit('ADMIN','TECHNICIAN'); rateLimit('fiber-read:'.$actor['id'],60,60);
        if ($match[2]==='import') json(fiberImport($match[1],body(),$actor['id']));
        if (body()!==[]) throw new HttpError(422,'La consulta no admite parámetros.','VALIDATION_ERROR');
        json(fiberQueueJob($match[1],strtoupper($match[2]),null,$actor['id']),202);
    }
    if (preg_match('#^/fiber/onus/([a-f0-9]{24})/(preview|signal|diagnostic|samples|authorize|reboot|wifi|suspend|reactivate|delete)$#D',$route,$match)) {
        if ($match[2]==='samples' && $method==='GET') {
            fiberRecord('onus',$match[1]); json(['results'=>array_map(static fn($row)=>fiberDto('samples',$row),fetchAll('SELECT * FROM `FiberSample` WHERE onu_id=? ORDER BY sampled_at DESC,id LIMIT 500',[$match[1]]))]);
        }
        if ($method==='POST') {
            permit('ADMIN','TECHNICIAN');
            if ($match[2]==='preview') json(fiberPreview($match[1],body(),$actor),201);
            if (in_array($match[2],['signal','diagnostic'],true)) {
                if (body()!==[]) throw new HttpError(422,'La consulta no admite parámetros.','VALIDATION_ERROR');
                $onu=fiberRecord('onus',$match[1]); json(fiberQueueJob($onu['olt_id'],'SIGNAL',$onu['id'],$actor['id']),202);
            }
            requireNetworkWrite(); throw new HttpError(501,'La escritura en OLT no está habilitada para este modelo. Prepara primero un plan local.','OLT_WRITE_UNSUPPORTED');
        }
    }
    if (preg_match('#^/fiber/drafts/([a-f0-9]{24})/(commit|cancel)$#D',$route,$match) && $method==='POST') {
        permit('ADMIN');
        if ($match[2]==='commit') { requireNetworkWrite(); throw new HttpError(501,'No hay escritura de OLT habilitada; el plan permanece sin aplicar.','OLT_WRITE_UNSUPPORTED'); }
        if (body()!==[]) throw new HttpError(422,'La cancelación no admite parámetros.','VALIDATION_ERROR');
        fiberRecord('drafts',$match[1]); $row=fiberStore('drafts',['status'=>'CANCELLED'],$match[1]); audit('fiber.operation.cancel','FiberDraft',$row['id'],$actor['id']); json(fiberDto('drafts',$row));
    }
    if (preg_match('#^/fiber/([a-z]+)(?:/([a-f0-9]{24}))?$#D',$route,$match)) {
        $resource=$match[1]; fiberTable($resource); $identifier=$match[2] ?? null;
        if ($method==='GET') json($identifier===null ? fiberList($resource) : fiberDetail($resource,$identifier));
        if ($resource==='olts' || in_array($resource,['queries','links'],true)) permit('ADMIN'); else permit('ADMIN','TECHNICIAN');
        if ($resource==='onus' && $method==='POST' && $identifier===null) {
            $input=body(); $oltId=$input['olt_id'] ?? null;
            if (!is_string($oltId)) throw new HttpError(422,'Indica la OLT.','VALIDATION_ERROR');
            unset($input['olt_id']);
            if (array_diff(array_keys($input),['sn','frame','slot','port','onu_index','mac','onu_type','name'])) throw new HttpError(422,'El alta local no define estado observado.','VALIDATION_ERROR');
            fiberImport($oltId,['onus'=>[$input]],$actor['id']);
            $row=fetchOne('SELECT * FROM `FiberOnu` WHERE olt_id=? AND sn=?',[$oltId,strtoupper($input['sn'] ?? '')]); json(fiberDto('onus',$row),201);
        }
        if ($method==='POST' && $identifier===null && !in_array($resource,['jobs','drafts','samples'],true)) json(fiberMetadata($resource,body(),$actor),201);
        if ($method==='PATCH' && $identifier!==null && !in_array($resource,['jobs','drafts','samples'],true)) json(fiberMetadata($resource,body(),$actor,$identifier));
        if ($method==='DELETE' && $identifier!==null) {
            permit('ADMIN'); if ($resource==='onus') { requireNetworkWrite(); throw new HttpError(501,'No se elimina una ONU física desde el inventario local.','OLT_WRITE_UNSUPPORTED'); }
            if (in_array($resource,['jobs','drafts','samples'],true)) throw new HttpError(405,'Este historial no se elimina desde la API.','METHOD_NOT_ALLOWED');
            operationsLocks(['fiber:metadata'],function () use ($resource,$identifier,$actor): void {
                fiberRecord($resource,$identifier,true);
                if (in_array($resource,['olts','pons'],true) && fetchOne('SELECT id FROM `FiberOnu` WHERE '.($resource==='olts'?'olt_id':'pon_id').'=? LIMIT 1',[$identifier])) throw new HttpError(409,'El recurso conserva inventario e historial asociado.','RESOURCE_IN_USE');
                db()->prepare('DELETE FROM `'.fiberTable($resource).'` WHERE id=?')->execute([$identifier]); audit('fiber.metadata.delete',fiberTable($resource),$identifier,$actor['id']);
            }); json(null,204);
        }
    }
    throw new HttpError(404,'Ruta FTTH no encontrada.','NOT_FOUND');
}
