import { useEffect, useState } from 'react';
import { api } from './api';
import type { ClientIpAddress } from './types';
import type { ClientIpLiveState } from './ClientIpAccess';

interface ClientObservation {
  clientId: string;
  addresses: ClientIpAddress[];
  status: 'FRESH' | 'NO_SESSION' | 'NO_ACCOUNT' | 'PENDING' | 'STALE';
  stale: boolean;
  observedAt: string | null;
  message: string;
}
interface BatchObservation { intervalSeconds: number; processed: number; serverTime?: string; results: ClientObservation[] }
export interface ClientLiveObservation { addresses: ClientIpAddress[]; state: ClientIpLiveState; expiresAt?: number }

/** One batch for the current page; router polling is shared by the PHP cache. */
export function useClientLiveIps(clientIds: string[], enabled: boolean): Record<string, ClientLiveObservation> {
  const key = enabled ? JSON.stringify([...new Set(clientIds)].sort()) : '[]';
  const [observations, setObservations] = useState<Record<string, ClientLiveObservation>>({});
  useEffect(() => {
    const ids = JSON.parse(key) as string[];
    setObservations({});
    if (!ids.length) return;
    let stopped = false;
    let timer: number | undefined;
    let pending: AbortController | undefined;
    let deadline: number | undefined;
    const isVisible = () => document.visibilityState !== 'hidden';
    // Expire a previously rendered session even if the next request stalls or
    // the browser temporarily suspends polling. Configured IPs remain labelled.
    const expiry = window.setInterval(() => setObservations(old => {
      let changed = false;
      const next = Object.fromEntries(Object.entries(old).map(([id, row]) => {
        if (row.addresses.length && row.expiresAt !== undefined && row.expiresAt <= Date.now()) {
          changed = true;
          return [id, { addresses: [], state: { ...row.state, stale: true, message: 'La observación de IP de sesión caducó. Se actualizará automáticamente.' } }];
        }
        return [id, row];
      }));
      return changed ? next : old;
    }), 1000);
    const tick = async () => {
      window.clearTimeout(timer);
      if (stopped || pending || !isVisible()) return;
      pending = new AbortController();
      deadline = window.setTimeout(() => pending?.abort(), 90000);
      setObservations(old => Object.fromEntries(ids.map(id => [id, { ...old[id], addresses: old[id]?.addresses || [], state: { ...old[id]?.state, loading: true } }])));
      let delay = 15000;
      try {
        const result = await api<BatchObservation>('/clients/ip-addresses/active', { method: 'POST', body: JSON.stringify({ clientIds: ids }), cache: 'no-store', signal: pending.signal });
        if (stopped) return;
        const byId = new Map(result.results.map(row => [row.clientId, row]));
        setObservations(Object.fromEntries(ids.map(id => {
          const row = byId.get(id);
          const observedAt = row?.observedAt ? Date.parse(row.observedAt) : NaN;
          const serverTime = result.serverTime ? Date.parse(result.serverTime) : NaN;
          const age = Number.isFinite(observedAt) ? Math.max(0, Math.min(30000, (Number.isFinite(serverTime) ? serverTime : Date.now()) - observedAt)) : 30000;
          return [id, { addresses: row && !row.stale ? row.addresses : [], expiresAt: Date.now() + 30000 - age, state: { loading: false, stale: !row || row.stale, observedAt: row?.observedAt, message: row?.message || 'La IP de sesión está pendiente de actualizar.' } }];
        })));
        if (result.results.some(row => row.status === 'PENDING')) delay = result.processed > 0 ? 1000 : 5000;
      } catch {
        if (!stopped) setObservations(Object.fromEntries(ids.map(id => [id, { addresses: [], state: { loading: false, stale: true, error: 'No se pudo actualizar la IP de sesión. Se reintentará automáticamente.' } }])));
      } finally {
        window.clearTimeout(deadline); pending = undefined;
        if (!stopped && isVisible()) timer = window.setTimeout(() => void tick(), delay);
      }
    };
    const visibility = () => { if (isVisible()) void tick(); else window.clearTimeout(timer); };
    document.addEventListener('visibilitychange', visibility);
    timer = window.setTimeout(() => void tick(), 100);
    return () => { stopped = true; window.clearInterval(expiry); window.clearTimeout(timer); window.clearTimeout(deadline); pending?.abort(); document.removeEventListener('visibilitychange', visibility); };
  }, [key]);
  return observations;
}
