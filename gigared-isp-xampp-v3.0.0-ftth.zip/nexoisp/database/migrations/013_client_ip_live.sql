-- Caché local de sesiones PPP observadas; no modifica la configuración RouterOS.
CREATE TABLE IF NOT EXISTS `RouterPppActiveCache` (
  `routerId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `status` VARCHAR(16) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'WAITING',
  `lastStartedAt` DATETIME(3) NULL,
  `lastSuccessAt` DATETIME(3) NULL,
  `nextQueryAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `sessions` JSON NULL,
  `lastErrorCode` VARCHAR(64) CHARACTER SET ascii COLLATE ascii_bin NULL,
  `lastError` VARCHAR(500) NULL,
  `failures` INT UNSIGNED NOT NULL DEFAULT 0,
  `updatedAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`routerId`),
  KEY `ppp_active_due_idx` (`nextQueryAt`),
  CONSTRAINT `ppp_active_router_fk` FOREIGN KEY (`routerId`) REFERENCES `Router` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ppp_active_status_check` CHECK (`status` IN ('WAITING','RUNNING','SUCCESS','ERROR','DEFERRED'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
