-- FTTH: inventario observado, organización local y planes sin escritura de equipos.
CREATE TABLE IF NOT EXISTS `FiberZone` (
 `id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 `name` VARCHAR(200) NOT NULL, `description` TEXT NULL,
 `latitude` DOUBLE NULL, `longitude` DOUBLE NULL,
 `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), `updated_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
 PRIMARY KEY (`id`), CHECK (CHAR_LENGTH(`name`)>0),
 CHECK (`latitude` IS NULL OR `latitude` BETWEEN -90 AND 90), CHECK (`longitude` IS NULL OR `longitude` BETWEEN -180 AND 180)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `FiberOlt` (
 `id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 `name` VARCHAR(200) NOT NULL, `vendor` VARCHAR(20) NOT NULL, `model` VARCHAR(100) NULL, `software_version` VARCHAR(100) NULL,
 `host` VARCHAR(253) NOT NULL, `transport` VARCHAR(10) NOT NULL, `port` INT UNSIGNED NOT NULL,
 `username` VARCHAR(200) NULL, `passwordEncrypted` TEXT NULL, `snmpCommunityEncrypted` TEXT NULL, `ssh_fingerprint` VARCHAR(200) NULL,
 `enabled` TINYINT(1) NOT NULL DEFAULT 1, `poll_enabled` TINYINT(1) NOT NULL DEFAULT 0, `poll_interval` INT UNSIGNED NOT NULL DEFAULT 60,
 `next_poll_at` DATETIME(3) NULL, `zone_id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NULL,
 `latitude` DOUBLE NULL, `longitude` DOUBLE NULL, `status` VARCHAR(16) NOT NULL DEFAULT 'UNKNOWN',
 `temperature` DOUBLE NULL, `cpu_percent` DOUBLE NULL, `uptime` VARCHAR(200) NULL,
 `last_seen_at` DATETIME(3) NULL, `last_error` VARCHAR(500) NULL,
 `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), `updated_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
 PRIMARY KEY (`id`), KEY `fiber_olt_poll` (`enabled`,`poll_enabled`,`next_poll_at`),
 FOREIGN KEY (`zone_id`) REFERENCES `FiberZone` (`id`) ON DELETE RESTRICT,
 CHECK (`vendor` IN ('HUAWEI','ZTE','FIBERHOME','VSOL','GENERIC')),
 CHECK (`transport` IN ('SSH','TELNET','SNMP')), CHECK (`port` BETWEEN 1 AND 65535),
 CHECK (`enabled` IN (0,1) AND `poll_enabled` IN (0,1) AND `poll_interval` BETWEEN 15 AND 3600),
 CHECK (`status` IN ('UNKNOWN','ONLINE','OFFLINE')), CHECK (CHAR_LENGTH(`name`)>0),
 CHECK (`latitude` IS NULL OR `latitude` BETWEEN -90 AND 90), CHECK (`longitude` IS NULL OR `longitude` BETWEEN -180 AND 180)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `FiberPonPort` (
 `id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL, `olt_id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 `frame` INT UNSIGNED NOT NULL DEFAULT 0, `slot` INT UNSIGNED NOT NULL DEFAULT 0, `port` INT UNSIGNED NOT NULL,
 `name` VARCHAR(200) NULL, `technology` VARCHAR(16) NOT NULL DEFAULT 'GPON', `capacity` INT UNSIGNED NOT NULL DEFAULT 128,
 `status` VARCHAR(16) NOT NULL DEFAULT 'UNKNOWN', `rx_power` DOUBLE NULL, `tx_power` DOUBLE NULL,
 `source` VARCHAR(16) NOT NULL DEFAULT 'LOCAL', `present` TINYINT(1) NOT NULL DEFAULT 1, `last_seen_at` DATETIME(3) NULL,
 `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), `updated_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
 PRIMARY KEY (`id`), UNIQUE KEY `fiber_pon_identity` (`olt_id`,`frame`,`slot`,`port`),
 FOREIGN KEY (`olt_id`) REFERENCES `FiberOlt` (`id`) ON DELETE RESTRICT,
 CHECK (`frame`<=255 AND `slot`<=255 AND `port`<=255 AND `capacity` BETWEEN 1 AND 1024),
 CHECK (`technology` IN ('GPON','EPON','XGSPON')), CHECK (`status` IN ('UNKNOWN','ONLINE','OFFLINE','LOS')),
 CHECK (`source` IN ('LOCAL','USER_IMPORT','DEVICE')), CHECK (`present` IN (0,1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `FiberVlan` (
 `id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL, `olt_id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 `vlan` INT UNSIGNED NOT NULL, `name` VARCHAR(200) NOT NULL, `description` TEXT NULL,
 `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), `updated_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
 PRIMARY KEY (`id`), UNIQUE KEY `fiber_vlan_identity` (`olt_id`,`vlan`),
 FOREIGN KEY (`olt_id`) REFERENCES `FiberOlt` (`id`) ON DELETE RESTRICT, CHECK (`vlan` BETWEEN 1 AND 4094)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `FiberProfile` (
 `id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL, `olt_id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 `name` VARCHAR(200) NOT NULL, `kind` VARCHAR(16) NOT NULL,
 `profile_index` INT UNSIGNED NULL, `tcont` INT UNSIGNED NULL, `gem_port` INT UNSIGNED NULL,
 `download_kbps` INT UNSIGNED NULL, `upload_kbps` INT UNSIGNED NULL,
 `fixed_kbps` INT UNSIGNED NULL, `assured_kbps` INT UNSIGNED NULL, `maximum_kbps` INT UNSIGNED NULL,
 `priority` INT UNSIGNED NOT NULL DEFAULT 0, `description` TEXT NULL,
 `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), `updated_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
 PRIMARY KEY (`id`), UNIQUE KEY `fiber_profile_identity` (`olt_id`,`kind`,`name`),
 FOREIGN KEY (`olt_id`) REFERENCES `FiberOlt` (`id`) ON DELETE RESTRICT,
 CHECK (`kind` IN ('DBA','LINE','SERVICE','TRAFFIC')), CHECK (`priority`<=7),
 CHECK (`profile_index` IS NULL OR `profile_index`<=65535), CHECK (`tcont` IS NULL OR `tcont`<=255), CHECK (`gem_port` IS NULL OR `gem_port`<=65535)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `FiberNap` (
 `id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL, `zone_id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NULL,
 `name` VARCHAR(200) NOT NULL, `capacity` INT UNSIGNED NOT NULL DEFAULT 8, `description` TEXT NULL,
 `latitude` DOUBLE NULL, `longitude` DOUBLE NULL,
 `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), `updated_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
 PRIMARY KEY (`id`), FOREIGN KEY (`zone_id`) REFERENCES `FiberZone` (`id`) ON DELETE RESTRICT,
 CHECK (`capacity` BETWEEN 1 AND 512), CHECK (`latitude` IS NULL OR `latitude` BETWEEN -90 AND 90), CHECK (`longitude` IS NULL OR `longitude` BETWEEN -180 AND 180)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `FiberSplitter` (
 `id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL, `nap_id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NULL,
 `parent_id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NULL, `name` VARCHAR(200) NOT NULL,
 `ports` INT UNSIGNED NOT NULL DEFAULT 8, `loss_db` DOUBLE NULL, `latitude` DOUBLE NULL, `longitude` DOUBLE NULL,
 `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), `updated_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
 PRIMARY KEY (`id`), FOREIGN KEY (`nap_id`) REFERENCES `FiberNap` (`id`) ON DELETE RESTRICT,
 FOREIGN KEY (`parent_id`) REFERENCES `FiberSplitter` (`id`) ON DELETE RESTRICT,
 CHECK (`ports` BETWEEN 1 AND 512), CHECK (`loss_db` IS NULL OR `loss_db` BETWEEN 0 AND 100),
 CHECK (`latitude` IS NULL OR `latitude` BETWEEN -90 AND 90), CHECK (`longitude` IS NULL OR `longitude` BETWEEN -180 AND 180)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `FiberLink` (
 `id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL, `name` VARCHAR(200) NOT NULL,
 `from_type` VARCHAR(16) NOT NULL, `from_id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL, `from_port` INT UNSIGNED NOT NULL DEFAULT 1,
 `to_type` VARCHAR(16) NOT NULL, `to_id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL, `to_port` INT UNSIGNED NOT NULL DEFAULT 1,
 `fiber` INT UNSIGNED NOT NULL DEFAULT 1, `length_meters` INT UNSIGNED NULL, `color` VARCHAR(40) NULL, `description` TEXT NULL,
 `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), `updated_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
 PRIMARY KEY (`id`), UNIQUE KEY `fiber_link_origin` (`from_type`,`from_id`,`from_port`), UNIQUE KEY `fiber_link_destination` (`to_type`,`to_id`,`to_port`),
 CHECK (`from_type` IN ('OLT','PON','NAP','SPLITTER')), CHECK (`to_type` IN ('OLT','PON','NAP','SPLITTER')),
 CHECK (`from_port` BETWEEN 1 AND 1024 AND `to_port` BETWEEN 1 AND 1024 AND `fiber` BETWEEN 1 AND 1024),
 CHECK (`from_type`<>`to_type` OR `from_id`<>`to_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `FiberOnu` (
 `id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL, `olt_id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 `pon_id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NULL, `frame` INT UNSIGNED NOT NULL DEFAULT 0, `slot` INT UNSIGNED NOT NULL DEFAULT 0,
 `pon_port` INT UNSIGNED NOT NULL DEFAULT 0, `onu_index` INT UNSIGNED NULL,
 `sn` VARCHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL, `mac` VARCHAR(17) NULL, `onu_type` VARCHAR(100) NULL, `name` VARCHAR(200) NULL,
 `status` VARCHAR(16) NOT NULL DEFAULT 'UNKNOWN', `authorization` VARCHAR(16) NOT NULL DEFAULT 'UNAUTHORIZED',
 `mode` VARCHAR(16) NULL, `wan_mode` VARCHAR(16) NULL, `vlan` INT UNSIGNED NULL,
 `profile_id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NULL,
 `rx_power` DOUBLE NULL, `tx_power` DOUBLE NULL, `temperature` DOUBLE NULL, `distance` DOUBLE NULL,
 `client_id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NULL, `zone_id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NULL,
 `nap_id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NULL, `nap_port` INT UNSIGNED NULL,
 `latitude` DOUBLE NULL, `longitude` DOUBLE NULL, `notes` TEXT NULL,
 `source` VARCHAR(16) NOT NULL DEFAULT 'LOCAL', `present` TINYINT(1) NOT NULL DEFAULT 1,
 `last_seen_at` DATETIME(3) NULL, `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), `updated_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
 PRIMARY KEY (`id`), UNIQUE KEY `fiber_onu_serial` (`olt_id`,`sn`), UNIQUE KEY `fiber_onu_physical` (`olt_id`,`frame`,`slot`,`pon_port`,`onu_index`),
 UNIQUE KEY `fiber_onu_nap_port` (`nap_id`,`nap_port`), KEY `fiber_onu_filters` (`status`,`authorization`,`present`), KEY `fiber_onu_client` (`client_id`),
 FOREIGN KEY (`olt_id`) REFERENCES `FiberOlt` (`id`) ON DELETE RESTRICT, FOREIGN KEY (`pon_id`) REFERENCES `FiberPonPort` (`id`) ON DELETE RESTRICT,
 FOREIGN KEY (`profile_id`) REFERENCES `FiberProfile` (`id`) ON DELETE RESTRICT, FOREIGN KEY (`client_id`) REFERENCES `Client` (`id`) ON DELETE RESTRICT,
 FOREIGN KEY (`zone_id`) REFERENCES `FiberZone` (`id`) ON DELETE RESTRICT, FOREIGN KEY (`nap_id`) REFERENCES `FiberNap` (`id`) ON DELETE RESTRICT,
 CHECK (`status` IN ('ONLINE','OFFLINE','LOS','UNKNOWN')), CHECK (`authorization` IN ('AUTHORIZED','UNAUTHORIZED')),
 CHECK (`source` IN ('LOCAL','USER_IMPORT','DEVICE')), CHECK (`present` IN (0,1)),
 CHECK (`frame`<=255 AND `slot`<=255 AND `pon_port`<=255 AND (`onu_index` IS NULL OR `onu_index`<=4095)),
 CHECK (`vlan` IS NULL OR `vlan` BETWEEN 1 AND 4094), CHECK (`nap_port` IS NULL OR `nap_port` BETWEEN 1 AND 512),
 CHECK ((`nap_id` IS NULL AND `nap_port` IS NULL) OR (`nap_id` IS NOT NULL AND `nap_port` IS NOT NULL)),
 CHECK (`latitude` IS NULL OR `latitude` BETWEEN -90 AND 90), CHECK (`longitude` IS NULL OR `longitude` BETWEEN -180 AND 180)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `FiberSample` (
 `id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL, `onu_id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 `sampled_at` DATETIME(3) NOT NULL, `source` VARCHAR(16) NOT NULL,
 `rx_power` DOUBLE NULL, `tx_power` DOUBLE NULL, `temperature` DOUBLE NULL, `distance` DOUBLE NULL,
 `download_bps` DOUBLE NULL, `upload_bps` DOUBLE NULL, `download_bytes` DECIMAL(24,0) NULL, `upload_bytes` DECIMAL(24,0) NULL,
 PRIMARY KEY (`id`), KEY `fiber_sample_history` (`onu_id`,`sampled_at`),
 FOREIGN KEY (`onu_id`) REFERENCES `FiberOnu` (`id`) ON DELETE RESTRICT,
 CHECK (`source` IN ('USER_IMPORT','DEVICE')), CHECK (`download_bps` IS NULL OR `download_bps`>=0), CHECK (`upload_bps` IS NULL OR `upload_bps`>=0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `FiberQuery` (
 `id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL, `olt_id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 `kind` VARCHAR(16) NOT NULL, `name` VARCHAR(200) NOT NULL, `command` VARCHAR(1000) NULL, `pattern` VARCHAR(2000) NULL, `oid` VARCHAR(500) NULL,
 `enabled` TINYINT(1) NOT NULL DEFAULT 1,
 `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), `updated_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
 PRIMARY KEY (`id`), FOREIGN KEY (`olt_id`) REFERENCES `FiberOlt` (`id`) ON DELETE RESTRICT,
 CHECK (`kind` IN ('TEST','SYNC','DISCOVER','SIGNAL')), CHECK (`enabled` IN (0,1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `FiberDraft` (
 `id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL, `onu_id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 `action` VARCHAR(16) NOT NULL, `status` VARCHAR(16) NOT NULL DEFAULT 'PREPARED', `configurationEncrypted` LONGTEXT NOT NULL,
 `summary` JSON NOT NULL, `actor_id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), `updated_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
 PRIMARY KEY (`id`), KEY `fiber_draft_onu` (`onu_id`,`created_at`), FOREIGN KEY (`onu_id`) REFERENCES `FiberOnu` (`id`) ON DELETE RESTRICT,
 FOREIGN KEY (`actor_id`) REFERENCES `User` (`id`) ON DELETE RESTRICT,
 CHECK (`action` IN ('AUTHORIZE','REBOOT','WIFI','SUSPEND','REACTIVATE','DELETE')), CHECK (`status` IN ('PREPARED','CANCELLED'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `FiberJob` (
 `id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL, `olt_id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 `onu_id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NULL, `kind` VARCHAR(16) NOT NULL, `status` VARCHAR(16) NOT NULL DEFAULT 'QUEUED',
 `active_key` VARCHAR(100) CHARACTER SET ascii COLLATE ascii_bin NULL, `attempts` INT UNSIGNED NOT NULL DEFAULT 0,
 `next_run_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), `locked_at` DATETIME(3) NULL, `locked_by` VARCHAR(64) NULL,
 `result` JSON NULL, `error` VARCHAR(500) NULL, `actor_id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NULL,
 `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), `updated_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), `completed_at` DATETIME(3) NULL,
 PRIMARY KEY (`id`), UNIQUE KEY `fiber_job_active` (`active_key`), KEY `fiber_job_due` (`status`,`next_run_at`),
 FOREIGN KEY (`olt_id`) REFERENCES `FiberOlt` (`id`) ON DELETE RESTRICT, FOREIGN KEY (`onu_id`) REFERENCES `FiberOnu` (`id`) ON DELETE RESTRICT,
 FOREIGN KEY (`actor_id`) REFERENCES `User` (`id`) ON DELETE RESTRICT,
 CHECK (`kind` IN ('TEST','SYNC','DISCOVER','SIGNAL')), CHECK (`status` IN ('QUEUED','RUNNING','SUCCEEDED','FAILED'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
