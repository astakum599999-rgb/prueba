<?php
declare(strict_types=1);
namespace Nexo;

function headerValue(string $name): ?string
{
    $key = 'HTTP_' . strtoupper(str_replace('-', '_', $name));
    $keys = [$key];
    if (strcasecmp($name, 'Authorization') === 0) $keys[] = 'REDIRECT_HTTP_AUTHORIZATION';
    foreach ($keys as $serverKey) {
        $value = $_SERVER[$serverKey] ?? null;
        if (is_string($value) && trim($value) !== '') return trim($value);
    }
    if (function_exists('getallheaders')) foreach (getallheaders() as $header => $candidate) if (strcasecmp($header, $name) === 0 && is_string($candidate) && trim($candidate) !== '') return trim($candidate);
    return null;
}

/** Browser origins contain only a scheme, host and optional port. */
function normalizeWebOrigin(string $origin): ?string
{
    if (strlen($origin) > 512 || preg_match('#^https?://(?:\[[0-9a-f:.]+\]|[a-z0-9.\-]+)(?::[0-9]{1,5})?$#iD', $origin) !== 1) return null;
    $parts = parse_url($origin);
    if ($parts === false || !isset($parts['scheme'], $parts['host']) || array_diff(array_keys($parts), ['scheme', 'host', 'port'])) return null;
    $scheme = strtolower($parts['scheme']);
    if (!in_array($scheme, ['http', 'https'], true)) return null;
    $host = strtolower($parts['host']);
    if (str_starts_with($host, '[') && str_ends_with($host, ']')) {
        $address = @inet_pton(substr($host, 1, -1));
        if ($address === false || strlen($address) !== 16) return null;
        $host = '[' . inet_ntop($address) . ']';
    } elseif (filter_var($host, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) !== false) {
        $host = inet_ntop(inet_pton($host));
    } elseif (filter_var($host, FILTER_VALIDATE_DOMAIN, FILTER_FLAG_HOSTNAME) === false) {
        return null;
    }
    $port = $parts['port'] ?? ($scheme === 'https' ? 443 : 80);
    if ($port < 1 || $port > 65535) return null;
    return $scheme . '://' . $host . ($port === ($scheme === 'https' ? 443 : 80) ? '' : ':' . $port);
}

/** Trust local IP access only when it identifies this actual Apache socket. */
function requestLocalOrigin(): ?string
{
    $serverAddress = $_SERVER['SERVER_ADDR'] ?? null;
    $authority = $_SERVER['HTTP_HOST'] ?? null;
    $port = filter_var($_SERVER['SERVER_PORT'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1, 'max_range' => 65535]]);
    if (!is_string($serverAddress) || !is_string($authority) || $port === false) return null;
    $address = @inet_pton($serverAddress);
    if ($address === false) return null;
    if (strlen($address) === 4) {
        $first = ord($address[0]); $second = ord($address[1]);
        $loopback = $first === 127;
        $local = $loopback || $first === 10 || ($first === 172 && $second >= 16 && $second <= 31) || ($first === 192 && $second === 168);
    } else {
        $loopback = $address === inet_pton('::1');
        $local = $loopback || (ord($address[0]) & 0xfe) === 0xfc || (ord($address[0]) === 0xfe && (ord($address[1]) & 0xc0) === 0x80);
    }
    if (!$local) return null;
    // Forwarded headers are deliberately ignored: proxies use explicit origins.
    $https = strtolower((string)($_SERVER['HTTPS'] ?? ''));
    $scheme = !in_array($https, ['', 'off', '0'], true) ? 'https' : 'http';
    $origin = normalizeWebOrigin($scheme . '://' . $authority);
    if ($origin === null) return null;
    $parts = parse_url($origin);
    if (($parts['port'] ?? ($scheme === 'https' ? 443 : 80)) !== $port) return null;
    $host = $parts['host'];
    if ($host === 'localhost') return $loopback ? $origin : null;
    $hostAddress = @inet_pton(trim($host, '[]'));
    return $hostAddress !== false && $hostAddress === $address ? $origin : null;
}

function trustedOrigin(?string $origin): bool
{
    if ($origin === null || ($normalized = normalizeWebOrigin($origin)) === null) return false;
    $configured = config('web_origin');
    if (is_string($configured) && $normalized === normalizeWebOrigin($configured)) return true;
    $additional = config('allowed_web_origins', []);
    if (is_array($additional)) foreach ($additional as $allowed) {
        if (is_string($allowed) && $normalized === normalizeWebOrigin($allowed)) return true;
    }
    return $normalized === requestLocalOrigin();
}

function sessionCookieOptions(int $expires = 0): array
{
    $base = (string)config('base_path', '');
    return ['expires' => $expires, 'path' => $base === '' ? '/' : $base, 'secure' => (bool)config('cookie_secure', false), 'httponly' => true, 'samesite' => 'Strict'];
}

function currentUser(): ?array
{
    if ($GLOBALS['nexo_auth_resolved'] ?? false) return $GLOBALS['nexo_user'] ?? null;
    $GLOBALS['nexo_auth_resolved'] = true;
    $GLOBALS['nexo_user'] = null;
    $authorization = headerValue('Authorization');
    if ($authorization !== null) {
        if (preg_match('/^Api-Key ([A-Za-z0-9_-]{32,200})$/D', $authorization, $match) !== 1) throw new HttpError(401, 'Use Authorization: Api-Key <TOKEN>', 'INVALID_AUTH');
        $record = fetchOne('SELECT k.`id` AS keyId,k.`expiresAt`,k.`revokedAt`,k.`lastUsedAt`,u.`id`,u.`name`,u.`email`,u.`role`,u.`active` FROM `ApiKey` k JOIN `User` u ON u.`id`=k.`userId` WHERE k.`tokenHash`=:hash', ['hash' => hashToken($match[1])]);
        if (!$record || !$record['active'] || $record['revokedAt'] !== null || $record['expiresAt'] !== null && $record['expiresAt'] <= now()) throw new HttpError(401, 'Credencial inválida o expirada', 'INVALID_AUTH');
        if (!$record['lastUsedAt'] || strtotime($record['lastUsedAt'] . ' UTC') < time() - 60) db()->prepare('UPDATE `ApiKey` SET `lastUsedAt`=:used WHERE `id`=:id')->execute(['used' => now(), 'id' => $record['keyId']]);
        $GLOBALS['nexo_auth_method'] = 'api-key';
    } else {
        $token = $_COOKIE['nexoisp_session'] ?? null;
        if (!is_string($token) || preg_match('/^[A-Za-z0-9_-]{32,200}$/D', $token) !== 1) return null;
        $record = fetchOne('SELECT s.`expiresAt`,u.`id`,u.`name`,u.`email`,u.`role`,u.`active` FROM `Session` s JOIN `User` u ON u.`id`=s.`userId` WHERE s.`tokenHash`=:hash', ['hash' => hashToken($token)]);
        if (!$record || !$record['active'] || $record['expiresAt'] <= now()) throw new HttpError(401, 'Sesión inválida o expirada', 'INVALID_AUTH');
        $GLOBALS['nexo_auth_method'] = 'session';
    }
    return $GLOBALS['nexo_user'] = ['id' => $record['id'], 'name' => $record['name'], 'email' => $record['email'], 'role' => $record['role']];
}

function requireAuth(): array
{
    $user = currentUser();
    if (!$user) throw new HttpError(401, 'Autenticación requerida', 'AUTH_REQUIRED');
    if (($GLOBALS['nexo_auth_method'] ?? null) === 'session' && !in_array($_SERVER['REQUEST_METHOD'] ?? 'GET', ['GET', 'HEAD', 'OPTIONS'], true) && !trustedOrigin(headerValue('Origin'))) throw new HttpError(403, 'Origen de la solicitud no autorizado', 'CSRF_REJECTED');
    return $user;
}

function permit(string ...$roles): array
{
    $user = requireAuth();
    if (!in_array($user['role'], $roles, true)) throw new HttpError(403, 'No dispone de permisos para esta operación', 'FORBIDDEN');
    return $user;
}

function rateLimit(string $scope, int $limit, int $seconds): void
{
    $remote = (string)($_SERVER['REMOTE_ADDR'] ?? 'cli');
    $key = $scope . ':' . hash('sha256', $remote);
    tx(function (\PDO $pdo) use ($key, $limit, $seconds): void {
        $timestamp = now();
        $expires = gmdate('Y-m-d H:i:s', time() + $seconds);
        $pdo->prepare('INSERT INTO `RateLimit` (`key`,`attempts`,`windowStartedAt`,`updatedAt`,`expiresAt`) VALUES (:key,0,:started,:updated,:expires) ON DUPLICATE KEY UPDATE `key`=`key`')->execute(['key' => $key, 'started' => $timestamp, 'updated' => $timestamp, 'expires' => $expires]);
        $row = fetchOne('SELECT `attempts`,`windowStartedAt` FROM `RateLimit` WHERE `key`=:key FOR UPDATE', ['key' => $key]);
        $reset = !$row || strtotime($row['windowStartedAt'] . ' UTC') <= time() - $seconds;
        $hits = $reset ? 1 : (int)$row['attempts'] + 1;
        if ($hits > $limit) throw new HttpError(429, 'Demasiadas solicitudes; intente nuevamente más tarde', 'RATE_LIMITED');
        $pdo->prepare('UPDATE `RateLimit` SET `attempts`=:hits,`windowStartedAt`=:started,`updatedAt`=:updated,`expiresAt`=:expires WHERE `key`=:key')->execute(['hits' => $hits, 'started' => $reset ? $timestamp : $row['windowStartedAt'], 'updated' => $timestamp, 'expires' => $reset ? $expires : gmdate('Y-m-d H:i:s', strtotime($row['windowStartedAt'] . ' UTC') + $seconds), 'key' => $key]);
    });
}

function authCapabilities(): array
{
    $upgrade = true;
    try { $upgrade = migrationNeedsUpgrade(); } catch (\Throwable) { $upgrade = true; }
    return ['simulatedRouters' => (bool)config('allow_simulated_routers', false), 'browserWorker' => !$upgrade, 'extensions' => !$upgrade, 'secretImport' => !$upgrade, 'secretAutoSync' => !$upgrade, 'profileImport' => !$upgrade, 'pppoeCredentials' => !$upgrade, 'manualPppoeEditing' => !$upgrade, 'clientNameSync' => !$upgrade, 'clientNotes' => !$upgrade, 'clientIpAccess' => !$upgrade, 'fiber' => !$upgrade, 'clientIpLive' => !$upgrade, 'networkReadOnly' => networkReadOnly(), 'defaultCurrency' => localCurrency(), 'upgradeRequired' => $upgrade, 'version' => '3.0.1'];
}

function loginUser(array $input): array
{
    rateLimit('login', 15, 900);
    $origin = headerValue('Origin');
    if ($origin !== null && !trustedOrigin($origin)) throw new HttpError(403, 'Origen no autorizado', 'CSRF_REJECTED');
    $data = validate('login', $input);
    $user = fetchOne('SELECT * FROM `User` WHERE `email`=:email', ['email' => $data['email']]);
    $valid = verifyPassword($data['password'], $user['passwordHash'] ?? '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.');
    if (!$user || !$user['active'] || !$valid) throw new HttpError(401, 'Email o contraseña incorrectos', 'INVALID_CREDENTIALS');
    $token = rtrim(strtr(base64_encode(random_bytes(32)), '+/', '-_'), '=');
    $hours = max(1, min(168, (int)config('session_hours', 12)));
    tx(function (\PDO $pdo) use ($user, $token, $hours): void {
        $pdo->exec('DELETE FROM `Session` WHERE `expiresAt`<UTC_TIMESTAMP(3) LIMIT 100');
        $pdo->prepare('INSERT INTO `Session` (`id`,`userId`,`tokenHash`,`expiresAt`,`createdAt`) VALUES (:id,:user,:hash,:expires,:created)')->execute(['id' => id(), 'user' => $user['id'], 'hash' => hashToken($token), 'expires' => gmdate('Y-m-d H:i:s', time() + $hours * 3600), 'created' => now()]);
        audit('LOGIN', 'User', $user['id'], $user['id']);
    });
    setcookie('nexoisp_session', $token, sessionCookieOptions(time() + $hours * 3600));
    return ['user' => ['id' => $user['id'], 'name' => $user['name'], 'email' => $user['email'], 'role' => $user['role']], 'capabilities' => authCapabilities()];
}

function canRetryTask(string $role, string $kind): bool
{
    if ($role === 'ADMIN') return true;
    if ($role === 'BILLING') return in_array($kind, ['BILLING_RUN', 'AUTOCUT_RUN'], true);
    if ($role === 'TECHNICIAN') return in_array($kind, ['SERVICE_SYNC', 'DIAGNOSTIC', 'ROUTER_TEST', 'BULK_SYNC'], true);
    return false;
}
