import { useCallback, useState } from 'react';
import { createPortal } from 'react-dom';
import { ArrowRight, RefreshCw } from 'lucide-react';
import type { ClientIpAddress } from './types';
import { date, Modal } from './ui';

/** Only literal IP hosts are accepted; pool names, credentials and URLs are not. */
export function clientIpHost(address: string): string | null {
  if (/^(?:0|[1-9]\d{0,2})(?:\.(?:0|[1-9]\d{0,2})){3}$/.test(address)) {
    const parts = address.split('.').map(Number);
    if (parts.some(part => part > 255) || parts[0] === 0 || parts[0] === 127 || parts[0]! >= 224) return null;
    return address;
  }
  if (!address.includes(':') || !/^[a-f\d:.]+$/i.test(address)) return null;
  try {
    const host = new URL(`http://[${address}]/`).hostname;
    if (host === '[::]' || host === '[::1]' || /^\[ff/i.test(host)) return null;
    const mapped = /^\[::ffff:([a-f\d]{1,4}):([a-f\d]{1,4})\]$/i.exec(host);
    if (mapped) {
      const high = Number.parseInt(mapped[1]!, 16), low = Number.parseInt(mapped[2]!, 16);
      if (clientIpHost([high >> 8, high & 255, low >> 8, low & 255].join('.')) === null) return null;
    }
    return host;
  } catch { return null; }
}

export function clientIpUrl(address: string, protocol: string, port: string): string | null {
  const host = clientIpHost(address);
  if (!host || !['http', 'https'].includes(protocol) || !/^\d{1,5}$/.test(port) || Number(port) < 1 || Number(port) > 65535) return null;
  try {
    const url = new URL(`${protocol}://${host}:${Number(port)}/`);
    return url.href;
  } catch { return null; }
}

function ClientIpDialog({ entry, clientName, close }: { entry: ClientIpAddress; clientName: string; close: () => void }) {
  const initialProtocol = 'http';
  const [protocol, setProtocol] = useState(initialProtocol), [port, setPort] = useState('80');
  const [loadedUrl, setLoadedUrl] = useState(() => clientIpUrl(entry.address, initialProtocol, '80'));
  const [reload, setReload] = useState(0);
  const draftUrl = clientIpUrl(entry.address, protocol, port);
  const directUrl = draftUrl !== null && new URL(draftUrl).origin !== window.location.origin ? draftUrl : null;
  const sameOrigin = loadedUrl !== null && new URL(loadedUrl).origin === window.location.origin;
  const mixedContent = loadedUrl !== null && window.location.protocol === 'https:' && new URL(loadedUrl).protocol === 'http:';
  return <Modal title={`Acceso al router del cliente · ${entry.address}`} description={clientName} close={close} wide>
    <p className="field-hint">Inicia sesión con el usuario y la contraseña propios de la ONU o router del cliente.</p>
    <div className="client-ip-origin"><strong className="mono">{entry.address}</strong><span>{entry.routerName || 'Router asignado'} · {entry.source === 'PPP_ACTIVE' ? 'IP observada en sesión PPP activa' : entry.source === 'SERVICE' ? 'IP asignada al servicio' : 'IP configurada en el secret PPP'}</span>{entry.observedAt && <span>Última observación: {date(entry.observedAt, true)}</span>}</div>
    <div className="client-ip-access-form">
      <label className="field"><span className="field-label">Protocolo web</span><select aria-label="Protocolo web" value={protocol} onChange={event => { setProtocol(event.target.value); setPort(event.target.value === 'https' ? '443' : '80'); }}><option value="http">HTTP</option><option value="https">HTTPS</option></select></label>
      <label className="field"><span className="field-label">Puerto web</span><input aria-label="Puerto web" type="number" inputMode="numeric" min={1} max={65535} step={1} required value={port} onChange={event => setPort(event.target.value)} /></label>
      <button className="button primary" type="button" disabled={draftUrl === null} onClick={() => { setLoadedUrl(draftUrl); setReload(value => value + 1); }}><RefreshCw size={16} />Cargar acceso</button>
    </div>
    {!draftUrl && <div className="alert error" role="alert">Elige HTTP o HTTPS y un puerto entre 1 y 65535.</div>}
    <div className="client-ip-direct-access">
      <div><strong>Si el recuadro muestra «página bloqueada»</strong><p>Abre el equipo directamente en esta pestaña. Usa Atrás del navegador para regresar a Clientes.</p></div>
      {directUrl ? <a className="button primary" href={directUrl} target="_self" rel="noreferrer" referrerPolicy="no-referrer" tabIndex={0}><ArrowRight size={16} />Abrir en esta misma pestaña</a> : <button className="button primary" type="button" disabled><ArrowRight size={16} />Abrir en esta misma pestaña</button>}
    </div>
    {loadedUrl && <div className="client-ip-url"><span>Dirección del recuadro: <span className="mono">{loadedUrl}</span></span></div>}
    {sameOrigin ? <div className="alert warning" role="status">Esta dirección corresponde al mismo origen del panel. No se carga el sistema dentro de sí mismo. Revisa la IP y el puerto web del equipo.</div> : mixedContent ? <div className="alert warning" role="status">El navegador bloquea esta web HTTP dentro del panel HTTPS. Usa Abrir en esta misma pestaña o elige HTTPS si el equipo lo admite.</div> : loadedUrl && <iframe key={`${loadedUrl}:${reload}`} className="client-ip-frame" title={`Interfaz web del router del cliente ${entry.address}`} src={loadedUrl} referrerPolicy="no-referrer" sandbox="allow-forms allow-scripts allow-same-origin" />}
    <p className="field-hint client-ip-frame-note">ERR_BLOCKED_BY_RESPONSE puede indicar que el equipo impide mostrar su web dentro de otra página. El acceso directo evita esa restricción de incrustación. Tu PC debe poder llegar a la IP y al puerto elegidos; la autenticación y los certificados siguen dependiendo del equipo.</p>
  </Modal>;
}

export interface ClientIpLiveState {
  loading?: boolean;
  error?: string;
  message?: string;
  observedAt?: string | null;
  stale?: boolean;
}

export function ClientIpAddresses({ addresses, clientName, activeAddresses, liveState }: { addresses: ClientIpAddress[] | undefined; clientName: string; clientId?: string; activeAddresses?: ClientIpAddress[]; liveState?: ClientIpLiveState }) {
  const [selected, setSelected] = useState<ClientIpAddress | null>(null);
  const close = useCallback(() => setSelected(null), []);
  const entries = [...(!liveState?.stale && Array.isArray(activeAddresses) ? activeAddresses : []), ...(Array.isArray(addresses) ? addresses : [])];
  const seen = new Set<string>();
  const valid = entries.filter(entry => {
    if (!entry || typeof entry.address !== 'string' || clientIpHost(entry.address) === null) return false;
    const key = `${entry.routerId}:${entry.address}`;
    if (seen.has(key)) return false;
    seen.add(key); return true;
  });
  return <>
    {valid.length ? <div className="client-ip-list">{valid.map(entry => <div className="client-ip-entry" key={`${entry.routerId}:${entry.address}`}><button className="text-link mono client-ip-button" type="button" aria-label={`Abrir router del cliente en ${entry.address} (${entry.routerName})`} onClick={() => setSelected(entry)}>{entry.address}</button></div>)}</div> : <span className="subtle">Sin IP registrada</span>}
    {selected && createPortal(<ClientIpDialog entry={selected} clientName={clientName} close={close} />, document.body)}
  </>;
}
