<?php
declare(strict_types=1);
namespace Nexo;

use DateTimeImmutable;
use DateTimeZone;
use PDO;
use Throwable;

function financeInput(array $data, array $allowed, array $required = []): array
{
    if (array_diff(array_keys($data), $allowed)) throw new HttpError(422, 'Hay campos no admitidos.', 'VALIDATION_ERROR');
    foreach ($required as $key) if (!array_key_exists($key, $data)) throw new HttpError(422, 'Falta el campo ' . $key . '.', 'VALIDATION_ERROR');
    return $data;
}
function financeText(mixed $value, int $max = 200, bool $empty = false): string
{
    if (!is_string($value)) throw new HttpError(422, 'Se esperaba un texto.', 'VALIDATION_ERROR');
    $value = trim($value);
    if ((!$empty && $value === '') || strlen($value) > $max || preg_match('/[\x00-\x08\x0B\x0C\x0E-\x1F]/', $value)) throw new HttpError(422, 'Longitud o contenido de texto inválido.', 'VALIDATION_ERROR');
    return $value;
}
function financeInt(mixed $value, int $min = 0, int $max = 2147483647): int
{
    if ((!is_int($value) && !(is_float($value) && is_finite($value) && floor($value) === $value)) || $value < $min || $value > $max) throw new HttpError(422, 'El importe debe ser un entero válido en centavos.', 'VALIDATION_ERROR');
    return (int)$value;
}
function financeId(mixed $value): string
{
    if (!is_string($value) || !preg_match('/^[a-f0-9]{24}$/D', $value)) throw new HttpError(422, 'Identificador inválido.', 'VALIDATION_ERROR');
    return $value;
}
function financeCurrency(mixed $value): string
{
    if (!is_string($value) || !preg_match('/^[A-Z]{3}$/D', $value)) throw new HttpError(422, 'Moneda ISO de tres letras requerida.', 'VALIDATION_ERROR');
    return $value;
}
function financeDate(string $value): string
{
    $d = DateTimeImmutable::createFromFormat('!Y-m-d', $value, new DateTimeZone('UTC'));
    $error = DateTimeImmutable::getLastErrors();
    if (!$d || ($error !== false && ($error['warning_count'] || $error['error_count'])) || $d->format('Y-m-d') !== $value) throw new HttpError(422, 'Use fechas válidas con formato YYYY-MM-DD.', 'VALIDATION_ERROR');
    return $value;
}
function financeOccurred(mixed $value): string
{
    if ($value === null) return now();
    if (!is_string($value) || !preg_match('/^\d{4}-\d{2}-\d{2}T.+(?:Z|[+-]\d{2}:\d{2})$/D', $value)) throw new HttpError(422, 'La fecha debe indicar su zona horaria.', 'VALIDATION_ERROR');
    financeDate(substr($value, 0, 10));
    try { $date = new DateTimeImmutable($value); }
    catch (Throwable) { throw new HttpError(422, 'Fecha del movimiento inválida.', 'VALIDATION_ERROR'); }
    if ($date->getTimestamp() > time() + 300) throw new HttpError(422, 'No se registran movimientos futuros.', 'VALIDATION_ERROR');
    return $date->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s.v');
}
function financePage(): array
{
    $parse = function(string $key, int $default, int $max): int {
        $value = $_GET[$key] ?? (string)$default;
        if (!is_string($value) || !preg_match('/^[1-9][0-9]{0,5}$/D', $value) || (int)$value > $max) throw new HttpError(422, 'Paginación inválida.', 'VALIDATION_ERROR');
        return (int)$value;
    };
    $page = $parse('page', 1, 100000); $size = $parse('pageSize', 20, 100);
    return [$page,$size,($page - 1) * $size];
}
function financeLocks(array $keys, callable $operation): mixed
{
    $keys = array_values(array_unique($keys)); sort($keys); $held = [];
    try {
        foreach ($keys as $key) {
            if (!lock($key, 10)) throw new HttpError(409, 'Otra operación está utilizando estos registros. Reintente.', 'BUSY');
            $held[] = $key;
        }
        return $operation();
    } finally { foreach (array_reverse($held) as $key) unlock($key); }
}
function financeAccount(string $identifier, bool $active = false): array
{
    $row = fetchOne('SELECT * FROM CashAccount WHERE id = ?', [$identifier]);
    if (!$row) throw new HttpError(404, 'Cuenta de caja no encontrada.');
    if ($active && !(bool)$row['active']) throw new HttpError(409, 'La cuenta está inactiva.');
    $sum = fetchOne("SELECT COALESCE(SUM(CASE WHEN type='INCOME' THEN amountCents ELSE -amountCents END),0) AS net FROM CashMovement WHERE accountId=?", [$identifier]);
    $row['balanceCents'] = (int)$row['openingCents'] + (int)($sum['net'] ?? 0);
    return $row;
}
function financeMovement(string $identifier): array
{
    $row = fetchOne('SELECT m.*,a.name AS accountName,a.currency,EXISTS(SELECT 1 FROM CashMovement r WHERE r.reversalOf=m.id) AS reversed FROM CashMovement m JOIN CashAccount a ON a.id=m.accountId WHERE m.id=?', [$identifier]);
    if (!$row) throw new HttpError(404, 'Movimiento no encontrado.');
    $row['account'] = ['id'=>$row['accountId'],'name'=>$row['accountName'],'currency'=>$row['currency']];
    $row['reversed'] = (bool)$row['reversed'];
    return $row;
}
function financeInsertMovement(array $input, string $userId, string $source = 'MANUAL', ?string $reversal = null, ?string $transfer = null): array
{
    $identifier = id();
    db()->prepare('INSERT INTO CashMovement (id,accountId,type,amountCents,category,description,occurredAt,paymentId,reversalOf,transferId,source,createdBy) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)')
        ->execute([$identifier,$input['accountId'],$input['type'],$input['amountCents'],$input['category'],$input['description'],$input['occurredAt'],$input['paymentId'] ?? null,$reversal,$transfer,$source,$userId]);
    audit('cash.movement.create','CashMovement',$identifier,$userId);
    return financeMovement($identifier);
}
function fetchCompanyProfile(): array
{
    return fetchOne("SELECT name,address,taxId,phone,email,currency,invoiceNotes FROM CompanyProfile WHERE id='primary'") ??
        ['name'=>'','address'=>'','taxId'=>'','phone'=>'','email'=>'','currency'=>'PEN','invoiceNotes'=>''];
}
function financeRead(): array { return permit('ADMIN','BILLING','VIEWER'); }
function financeWrite(): array { return permit('ADMIN','BILLING'); }

function financeDispatch(string $method, string $route): bool
{
    if ($route === '/company-settings') {
        requireAuth();
        if ($method === 'GET') json(fetchCompanyProfile());
        if ($method === 'PATCH') {
            $user = permit('ADMIN');
            $data = financeInput(body(), ['name','address','taxId','phone','email','currency','invoiceNotes']);
            $profile = fetchCompanyProfile();
            foreach ($data as $key=>$value) {
                $profile[$key] = $key === 'currency' ? financeCurrency($value) : financeText($value, match($key) {'address'=>500,'invoiceNotes'=>4000,'email'=>254,default=>200}, true);
            }
            if ($profile['email'] !== '' && !filter_var($profile['email'], FILTER_VALIDATE_EMAIL)) throw new HttpError(422, 'Email de empresa inválido.');
            tx(function(PDO $pdo) use($profile,$user): void {
                $pdo->prepare("INSERT INTO CompanyProfile (id,name,address,taxId,phone,email,currency,invoiceNotes) VALUES ('primary',?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE name=VALUES(name),address=VALUES(address),taxId=VALUES(taxId),phone=VALUES(phone),email=VALUES(email),currency=VALUES(currency),invoiceNotes=VALUES(invoiceNotes)")
                    ->execute([$profile['name'],$profile['address'],$profile['taxId'],$profile['phone'],$profile['email'],$profile['currency'],$profile['invoiceNotes']]);
                audit('company.update','CompanyProfile','primary',$user['id']);
            });
            json(fetchCompanyProfile());
        }
    }
    if ($route === '/cash-accounts') {
        if ($method === 'GET') {
            financeRead(); [$page,$size,$skip] = financePage();
            $search = financeText($_GET['search'] ?? '',100,true);
            $where = $search !== '' ? ' WHERE name LIKE ?' : '';
            $params = $search !== '' ? ['%'.$search.'%'] : [];
            $count = (int)fetchOne('SELECT COUNT(*) AS n FROM CashAccount'.$where,$params)['n'];
            $rows = fetchAll('SELECT id FROM CashAccount'.$where." ORDER BY name,id LIMIT $size OFFSET $skip",$params);
            $rows = array_map(fn($row)=>financeAccount($row['id']),$rows);
            json(['results'=>$rows,'count'=>$count,'page'=>$page,'pageSize'=>$size]);
        }
        if ($method === 'POST') {
            $user=financeWrite(); $data=financeInput(body(),['name','currency','openingCents'],['name','currency']);
            $name=financeText($data['name']); $currency=financeCurrency($data['currency']); $opening=financeInt($data['openingCents'] ?? 0);
            $identifier=id();
            tx(function(PDO $pdo) use($identifier,$name,$currency,$opening,$user): void {
                $pdo->prepare('INSERT INTO CashAccount (id,name,currency,openingCents) VALUES (?,?,?,?)')->execute([$identifier,$name,$currency,$opening]);
                audit('cash.account.create','CashAccount',$identifier,$user['id']);
            });
            json(financeAccount($identifier),201);
        }
    }
    if (preg_match('#^/cash-accounts/([a-f0-9]{24})$#D',$route,$match)) {
        if ($method==='GET') { financeRead(); json(financeAccount($match[1])); }
        if ($method==='PATCH') {
            $user=financeWrite(); $data=financeInput(body(),['name','active']);
            financeLocks(['cash-account:'.$match[1]],function() use($data,$match,$user): void {
                tx(function(PDO $pdo) use($data,$match,$user): void {
                    $row=financeAccount($match[1]);
                    $name=array_key_exists('name',$data)?financeText($data['name']):$row['name'];
                    $active=$row['active'];
                    if (array_key_exists('active',$data)) {
                        if (!is_bool($data['active'])) throw new HttpError(422,'Estado de cuenta inválido.');
                        $active=(int)$data['active'];
                    }
                    $pdo->prepare('UPDATE CashAccount SET name=?,active=? WHERE id=?')->execute([$name,$active,$match[1]]);
                    audit('cash.account.update','CashAccount',$match[1],$user['id']);
                });
            });
            json(financeAccount($match[1]));
        }
    }
    if ($route === '/cash-movements') {
        if ($method === 'GET') {
            financeRead(); [$page,$size,$skip]=financePage(); [$where,$params]=financeMovementFilters();
            $count=(int)fetchOne('SELECT COUNT(*) AS n FROM CashMovement m JOIN CashAccount a ON a.id=m.accountId'.$where,$params)['n'];
            $rows=fetchAll('SELECT m.id FROM CashMovement m JOIN CashAccount a ON a.id=m.accountId'.$where." ORDER BY m.occurredAt DESC,m.id DESC LIMIT $size OFFSET $skip",$params);
            json(['results'=>array_map(fn($r)=>financeMovement($r['id']),$rows),'count'=>$count,'page'=>$page,'pageSize'=>$size]);
        }
        if ($method === 'POST') {
            $user=financeWrite(); $data=financeInput(body(),['accountId','type','amountCents','category','description','occurredAt','paymentId'],['accountId','type','amountCents','category','description']);
            $data['accountId']=financeId($data['accountId']); $data['amountCents']=financeInt($data['amountCents'],1);
            if (!in_array($data['type'],['INCOME','EXPENSE'],true)) throw new HttpError(422,'Tipo de movimiento inválido.');
            $data['category']=financeText($data['category'],100); $data['description']=financeText($data['description'],1000);
            $data['occurredAt']=financeOccurred($data['occurredAt'] ?? null);
            if (isset($data['paymentId'])) $data['paymentId']=financeId($data['paymentId']);
            $keys=['cash-account:'.$data['accountId']];
            if (isset($data['paymentId'])) $keys[]='cash-payment:'.$data['paymentId'];
            $movement=financeLocks($keys,fn()=>tx(function(PDO $pdo) use($data,$user): array {
                $account=financeAccount($data['accountId'],true); $source='MANUAL';
                if (isset($data['paymentId'])) {
                    if ($data['type']!=='INCOME') throw new HttpError(422,'Un pago sólo se registra como ingreso.');
                    $payment=fetchOne('SELECT p.id,p.amountCents,i.currency FROM Payment p JOIN Invoice i ON i.id=p.invoiceId WHERE p.id=?',[$data['paymentId']]);
                    if (!$payment) throw new HttpError(404,'Pago no encontrado.');
                    if ((int)$payment['amountCents']!==$data['amountCents'] || $payment['currency']!==$account['currency']) throw new HttpError(409,'Importe o moneda no coinciden con el pago.');
                    if (fetchOne('SELECT id FROM CashMovement WHERE paymentId=?',[$payment['id']])) throw new HttpError(409,'Este pago ya tiene un movimiento de caja.');
                    $source='PAYMENT';
                }
                return financeInsertMovement($data,$user['id'],$source);
            }));
            json($movement,201);
        }
    }
    if (preg_match('#^/cash-movements/([a-f0-9]{24})(?:/(reverse))?$#D',$route,$match)) {
        if ($method==='GET' && empty($match[2])) { financeRead(); json(financeMovement($match[1])); }
        if ($method==='POST' && ($match[2] ?? '')==='reverse') {
            $user=financeWrite(); $input=financeInput(body(),['reason'],['reason']); $reason=financeText($input['reason'],800);
            $original=financeMovement($match[1]);
            $result=financeLocks(['cash-account:'.$original['accountId'],'cash-reverse:'.$original['id']],fn()=>tx(function(PDO $pdo) use($original,$reason,$user): array {
                $current=financeMovement($original['id']);
                if ($current['reversalOf']!==null || $current['transferId']!==null) throw new HttpError(409,'No se revierte de forma individual una contrapartida o transferencia.');
                if ($current['reversed']) throw new HttpError(409,'El movimiento ya tiene una contrapartida.');
                $entry=['accountId'=>$current['accountId'],'type'=>$current['type']==='INCOME'?'EXPENSE':'INCOME','amountCents'=>(int)$current['amountCents'],'category'=>$current['category'],'description'=>'Contrapartida: '.$reason,'occurredAt'=>now()];
                return financeInsertMovement($entry,$user['id'],'REVERSAL',$current['id']);
            }));
            json($result,201);
        }
    }
    if ($route === '/cash-transfers') {
        if ($method==='GET') {
            financeRead(); [$page,$size,$skip]=financePage();
            $count=(int)fetchOne('SELECT COUNT(*) AS n FROM CashTransfer')['n'];
            $rows=fetchAll("SELECT t.*,a.name AS fromAccountName,b.name AS toAccountName,a.currency FROM CashTransfer t JOIN CashAccount a ON a.id=t.fromAccountId JOIN CashAccount b ON b.id=t.toAccountId ORDER BY t.createdAt DESC,t.id DESC LIMIT $size OFFSET $skip");
            json(['results'=>$rows,'count'=>$count,'page'=>$page,'pageSize'=>$size]);
        }
        if ($method==='POST') {
            $user=financeWrite(); $data=financeInput(body(),['fromAccountId','toAccountId','amountCents','description','externalReference'],['fromAccountId','toAccountId','amountCents','description','externalReference']);
            $from=financeId($data['fromAccountId']); $to=financeId($data['toAccountId']);
            if ($from===$to) throw new HttpError(422,'Seleccione dos cuentas diferentes.');
            $amount=financeInt($data['amountCents'],1); $description=financeText($data['description'],1000); $reference=financeText($data['externalReference'],191);
            $result=financeLocks(['cash-account:'.$from,'cash-account:'.$to,'cash-transfer:'.$reference],fn()=>tx(function(PDO $pdo) use($from,$to,$amount,$description,$reference,$user): array {
                $prior=fetchOne('SELECT * FROM CashTransfer WHERE externalReference=?',[$reference]);
                if ($prior) {
                    if ($prior['fromAccountId']!==$from || $prior['toAccountId']!==$to || (int)$prior['amountCents']!==$amount) throw new HttpError(409,'Referencia utilizada por una transferencia distinta.');
                    return ['transfer'=>$prior,'replayed'=>true];
                }
                $a=financeAccount($from,true); $b=financeAccount($to,true);
                if ($a['currency']!==$b['currency']) throw new HttpError(409,'Sólo se transfieren fondos entre cuentas de la misma moneda.');
                $identifier=id();
                $pdo->prepare('INSERT INTO CashTransfer (id,fromAccountId,toAccountId,amountCents,description,externalReference,createdBy) VALUES (?,?,?,?,?,?,?)')->execute([$identifier,$from,$to,$amount,$description,$reference,$user['id']]);
                foreach ([[$from,'EXPENSE'],[$to,'INCOME']] as [$account,$type]) {
                    financeInsertMovement(['accountId'=>$account,'type'=>$type,'amountCents'=>$amount,'category'=>'Transferencia interna','description'=>$description,'occurredAt'=>now()],$user['id'],'TRANSFER',null,$identifier);
                }
                audit('cash.transfer','CashTransfer',$identifier,$user['id']);
                return ['transfer'=>fetchOne('SELECT * FROM CashTransfer WHERE id=?',[$identifier]),'replayed'=>false];
            }));
            json($result,$result['replayed']?200:201);
        }
    }
    if ($route==='/reports' && $method==='GET') { financeRead(); json(financeReports()); }
    if (preg_match('#^/exports/(clients|services|invoices|payments|tickets|cash|inventory)\.csv$#D',$route,$match) && $method==='GET') {
        if (in_array($match[1],['clients','services','tickets','inventory'],true)) requireAuth(); else financeRead();
        financeExport($match[1]);
    }
    return false;
}
function financeMovementFilters(): array
{
    $parts=[]; $params=[];
    if (isset($_GET['accountId']) && $_GET['accountId']!=='') { $parts[]='m.accountId=?'; $params[]=financeId($_GET['accountId']); }
    if (isset($_GET['type']) && $_GET['type']!=='') {
        if (!in_array($_GET['type'],['INCOME','EXPENSE'],true)) throw new HttpError(422,'Tipo inválido.');
        $parts[]='m.type=?'; $params[]=$_GET['type'];
    }
    foreach (['from'=>'>=','to'=>'<='] as $key=>$operator) if (isset($_GET[$key]) && $_GET[$key]!=='') { $parts[]='m.occurredAt '.$operator.' ?'; $params[]=financeDate((string)$_GET[$key]).($key==='to'?' 23:59:59.999':' 00:00:00'); }
    $search=financeText($_GET['search'] ?? '',100,true);
    if ($search!=='') { $parts[]='(m.description LIKE ? OR m.category LIKE ? OR a.name LIKE ?)'; for($i=0;$i<3;$i++) $params[]='%'.$search.'%'; }
    return [$parts?' WHERE '.implode(' AND ',$parts):'',$params];
}
function financeReports(): array
{
    $from=financeDate((string)($_GET['from'] ?? gmdate('Y-m-01'))); $to=financeDate((string)($_GET['to'] ?? gmdate('Y-m-d')));
    if ($from>$to || (strtotime($to.' UTC')-strtotime($from.' UTC'))>366*5*86400) throw new HttpError(422,'Seleccione un rango ordenado de hasta cinco años.');
    $start=$from.' 00:00:00'; $end=$to.' 23:59:59.999'; $currencies=[];
    $group=function(string $currency) use(&$currencies): void {
        $currencies[$currency] ??= ['currency'=>$currency,'invoicedCents'=>0,'paidCents'=>0,'outstandingCents'=>0,'overdueCents'=>0,'cashIncomeCents'=>0,'cashExpenseCents'=>0];
    };
    foreach(fetchAll("SELECT currency,COALESCE(SUM(amountCents),0) AS total FROM Invoice WHERE status<>'VOID' AND issuedAt BETWEEN ? AND ? GROUP BY currency",[$start,$end]) as $r) { $group($r['currency']); $currencies[$r['currency']]['invoicedCents']=(int)$r['total']; }
    foreach(fetchAll('SELECT i.currency,COALESCE(SUM(p.amountCents),0) AS total FROM Payment p JOIN Invoice i ON i.id=p.invoiceId WHERE p.receivedAt BETWEEN ? AND ? GROUP BY i.currency',[$start,$end]) as $r) { $group($r['currency']); $currencies[$r['currency']]['paidCents']=(int)$r['total']; }
    foreach(fetchAll("SELECT currency,SUM(amountCents-paidCents) AS outstanding,SUM(CASE WHEN graceUntil<=UTC_TIMESTAMP(3) THEN amountCents-paidCents ELSE 0 END) AS overdue FROM Invoice WHERE status='OPEN' GROUP BY currency") as $r) { $group($r['currency']); $currencies[$r['currency']]['outstandingCents']=(int)$r['outstanding']; $currencies[$r['currency']]['overdueCents']=(int)$r['overdue']; }
    foreach(fetchAll("SELECT a.currency,SUM(CASE WHEN m.type='INCOME' THEN m.amountCents ELSE 0 END) AS income,SUM(CASE WHEN m.type='EXPENSE' THEN m.amountCents ELSE 0 END) AS expense FROM CashMovement m JOIN CashAccount a ON a.id=m.accountId WHERE m.source<>'TRANSFER' AND m.occurredAt BETWEEN ? AND ? GROUP BY a.currency",[$start,$end]) as $r) { $group($r['currency']); $currencies[$r['currency']]['cashIncomeCents']=(int)$r['income']; $currencies[$r['currency']]['cashExpenseCents']=(int)$r['expense']; }
    ksort($currencies);
    $counts=['clients'=>(int)fetchOne('SELECT COUNT(*) AS n FROM Client')['n'],'activeClients'=>(int)fetchOne("SELECT COUNT(*) AS n FROM Client WHERE status='ACTIVE'")['n'],'suspendedClients'=>(int)fetchOne("SELECT COUNT(*) AS n FROM Client WHERE status='SUSPENDED'")['n'],'services'=>(int)fetchOne("SELECT COUNT(*) AS n FROM Service WHERE desiredState<>'RETIRED'")['n'],'openTickets'=>(int)fetchOne("SELECT COUNT(*) AS n FROM Ticket WHERE status IN ('OPEN','IN_PROGRESS')")['n']];
    $receivables=fetchAll("SELECT i.id AS invoiceId,i.number,c.name AS clientName,i.currency,i.amountCents-i.paidCents AS balanceCents,i.dueAt,i.graceUntil,GREATEST(DATEDIFF(UTC_DATE(),i.dueAt),0) AS daysOverdue FROM Invoice i JOIN Client c ON c.id=i.clientId WHERE i.status='OPEN' ORDER BY i.graceUntil,i.id LIMIT 1000");
    $zones=fetchAll("SELECT COALESCE(NULLIF(zone,''),'Sin zona') AS zone,COUNT(*) AS clients,SUM(status='ACTIVE') AS active,SUM(status='SUSPENDED') AS suspended FROM Client GROUP BY COALESCE(NULLIF(zone,''),'Sin zona') ORDER BY zone");
    return ['range'=>['from'=>$from,'to'=>$to,'timezone'=>'UTC'],'balancesAsOf'=>gmdate('c'),'currencies'=>array_values($currencies),'counts'=>$counts,'receivables'=>$receivables,'receivablesTruncated'=>(int)fetchOne("SELECT COUNT(*) AS n FROM Invoice WHERE status='OPEN'")['n']>1000,'zones'=>$zones,'notes'=>'Los flujos usan el rango seleccionado. Los saldos pendientes y vencidos corresponden al estado actual. Transferencias internas excluidas de ingresos y egresos.'];
}
function financeCsvCell(mixed $value): string
{
    $value=$value===null?'':(is_bool($value)?($value?'1':'0'):(string)$value);
    if (preg_match('/^[\s]*[=+\-@]/u',$value) || preg_match('/^[\t\r\n]/',$value)) return "'".$value;
    return $value;
}
function financeExport(string $kind): never
{
    $queries=[
        'clients'=>'SELECT code,name,email,phone,document,address,latitude,longitude,zone,status,createdAt FROM Client ORDER BY createdAt,id LIMIT 50000',
        'services'=>'SELECT c.code AS clientCode,c.name AS clientName,s.type,s.ipAddress,s.macAddress,s.username,p.name AS planName,r.name AS routerName,s.desiredState,s.appliedState,s.syncStatus,s.createdAt,(l.serviceId IS NOT NULL) AS billingOnly FROM Service s JOIN Client c ON c.id=s.clientId JOIN Plan p ON p.id=s.planId LEFT JOIN Router r ON r.id=s.routerId LEFT JOIN LocalBillingService l ON l.serviceId=s.id ORDER BY s.createdAt,s.id LIMIT 50000',
        'invoices'=>'SELECT i.number,c.code AS clientCode,c.name AS clientName,i.period,i.currency,i.amountCents,i.paidCents,i.amountCents-i.paidCents AS balanceCents,i.status,i.issuedAt,i.dueAt,i.graceUntil FROM Invoice i JOIN Client c ON c.id=i.clientId ORDER BY i.issuedAt,i.id LIMIT 50000',
        'payments'=>'SELECT p.id,i.number AS invoice,c.name AS clientName,i.currency,p.amountCents,p.provider,p.externalReference,p.receivedAt FROM Payment p JOIN Invoice i ON i.id=p.invoiceId JOIN Client c ON c.id=i.clientId ORDER BY p.receivedAt,p.id LIMIT 50000',
        'tickets'=>'SELECT t.id,c.name AS clientName,t.subject,t.body,t.priority,t.status,t.createdAt,t.updatedAt FROM Ticket t JOIN Client c ON c.id=t.clientId ORDER BY t.createdAt,t.id LIMIT 50000',
        'cash'=>'SELECT m.id,a.name AS account,a.currency,m.type,m.amountCents,m.category,m.description,m.source,m.paymentId,m.reversalOf,m.occurredAt FROM CashMovement m JOIN CashAccount a ON a.id=m.accountId ORDER BY m.occurredAt,m.id LIMIT 50000',
        'inventory'=>'SELECT a.id,a.name,a.category,a.serialNumber,a.macAddress,a.location,a.state,c.name AS clientName,a.createdAt FROM InventoryAsset a LEFT JOIN Client c ON c.id=a.clientId ORDER BY a.createdAt,a.id LIMIT 50000',
    ];
    $rows=fetchAll($queries[$kind]);
    audit('export.csv',$kind,null,currentUser()['id'] ?? null);
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="nexoisp-'.$kind.'-'.gmdate('Y-m-d').'.csv"');
    header('Cache-Control: no-store'); header('X-Content-Type-Options: nosniff');
    $out=fopen('php://output','wb');
    fwrite($out,"\xEF\xBB\xBF");
    if ($rows) {
        fputcsv($out,array_keys($rows[0]),',','"', '');
        foreach($rows as $row) fputcsv($out,array_map(__NAMESPACE__.'\\financeCsvCell',array_values($row)),',','"', '');
    } else { fputcsv($out,['Sin registros'],',','"', ''); }
    fclose($out); exit;
}
