<?php
declare(strict_types=1);
namespace Nexo;

/** Local billing services never acquire a router or a provisioning lifecycle. */
function billingLocalWarm(array $serviceIds): void
{
    $ids = array_values(array_unique(array_filter($serviceIds, 'is_string')));
    $missing = array_values(array_filter($ids, static fn(string $id): bool => !array_key_exists($id, $GLOBALS['nexo_local_billing_services'] ?? [])));
    foreach (array_chunk($missing, 500) as $batch) {
        if (!$batch) continue;
        foreach ($batch as $id) $GLOBALS['nexo_local_billing_services'][$id] = false;
        $slots = implode(',', array_fill(0, count($batch), '?'));
        foreach (fetchAll('SELECT `serviceId` FROM `LocalBillingService` WHERE `serviceId` IN (' . $slots . ')', $batch) as $row) {
            $GLOBALS['nexo_local_billing_services'][$row['serviceId']] = true;
        }
    }
}

function billingLocalIsService(string $serviceId): bool
{
    billingLocalWarm([$serviceId]);
    return $GLOBALS['nexo_local_billing_services'][$serviceId] ?? false;
}

/** Fail closed for local services and incomplete records, before network I/O. */
function billingLocalRequireNetworkService(string $serviceId): void
{
    $service = fetchOne('SELECT `routerId`,`type`,`ipAddress` FROM `Service` WHERE `id`=?', [$serviceId]);
    if ($service === null) throw new HttpError(404, 'Servicio no encontrado.', 'NOT_FOUND');
    if (billingLocalIsService($serviceId) || empty($service['routerId']) || empty($service['type']) || empty($service['ipAddress'])) {
        throw new HttpError(409, 'Este servicio es sólo para facturación local. No admite operaciones de red ni conversión a un servicio MikroTik.', 'BILLING_ONLY_SERVICE');
    }
}

function billingLocalInput(array $input, bool $patch = false): array
{
    $allowed = $patch ? ['planId','billingDay','dueDays','graceDays'] : ['clientId','planId','billingDay','dueDays','graceDays'];
    if (array_diff(array_keys($input), $allowed) || $input !== [] && array_is_list($input)) throw new HttpError(422, 'El servicio de facturación contiene campos no permitidos.', 'VALIDATION_ERROR');
    foreach ($patch ? [] : ['clientId','planId'] as $required) if (!array_key_exists($required, $input)) throw new HttpError(422, 'Campo obligatorio: ' . $required, 'VALIDATION_ERROR');
    $output = [];
    foreach (['clientId','planId'] as $field) if (array_key_exists($field, $input)) {
        if (!is_string($input[$field]) || preg_match('/^[a-f0-9]{24}$/D', $input[$field]) !== 1) throw new HttpError(422, 'Identificador inválido: ' . $field, 'VALIDATION_ERROR');
        $output[$field] = $input[$field];
    }
    foreach (['billingDay' => [1,28,1], 'dueDays' => [0,90,10], 'graceDays' => [0,90,3]] as $field => [$minimum,$maximum,$default]) {
        if (!array_key_exists($field, $input)) { if (!$patch) $output[$field] = $default; continue; }
        if (!is_int($input[$field]) || $input[$field] < $minimum || $input[$field] > $maximum) throw new HttpError(422, 'Valor fuera de rango: ' . $field, 'VALIDATION_ERROR');
        $output[$field] = $input[$field];
    }
    if ($patch && $output === []) throw new HttpError(422, 'Indica el plan o las fechas de cobro que deseas modificar.', 'VALIDATION_ERROR');
    return $output;
}

function billingLocalPlan(string $planId): array
{
    $plan = apiRecord('Plan', $planId, true);
    if (!$plan['active']) throw new HttpError(409, 'Activa el plan y configura su precio antes de asignarlo al cliente.', 'PLAN_INACTIVE');
    profileImportAssertBillable($planId);
    return $plan;
}

function billingLocalDuplicate(string $clientId, string $planId, ?string $except = null): ?array
{
    $params = [$clientId, $planId];
    $exclude = '';
    if ($except !== null) { $exclude = ' AND s.`id`<>?'; $params[] = $except; }
    return fetchOne("SELECT s.* FROM `Service` s JOIN `LocalBillingService` b ON b.`serviceId`=s.`id` WHERE s.`clientId`=? AND s.`planId`=? AND s.`desiredState`<>'RETIRED'" . $exclude . ' ORDER BY s.`id` LIMIT 1 FOR UPDATE', $params);
}

function billingLocalCreate(array $input, array $actor): array
{
    $data = billingLocalInput($input);
    return apiLocks(['client:' . $data['clientId']], fn(): array => tx(function (\PDO $pdo) use ($data, $actor): array {
        $client = apiRecord('Client', $data['clientId'], true);
        if ($client['status'] === 'RETIRED') throw new HttpError(409, 'No se puede asignar un plan a un cliente retirado.', 'CLIENT_RETIRED');
        billingLocalPlan($data['planId']);
        $existing = billingLocalDuplicate($data['clientId'], $data['planId']);
        if ($existing !== null) {
            foreach (['billingDay','dueDays','graceDays'] as $field) if ((int)$existing[$field] !== $data[$field]) throw new HttpError(409, 'El cliente ya tiene este plan para facturación. Edita su servicio para cambiar las fechas de cobro.', 'BILLING_SERVICE_EXISTS');
            return ['service' => $existing, 'created' => false];
        }
        $service = apiInsert('Service', $data + ['routerId' => null, 'type' => null, 'ipAddress' => null, 'username' => null, 'passwordEncrypted' => null, 'desiredState' => 'ACTIVE', 'appliedState' => null, 'syncStatus' => 'PENDING']);
        $pdo->prepare('INSERT INTO `LocalBillingService` (`serviceId`,`createdBy`,`createdAt`) VALUES (?,?,?)')->execute([$service['id'], $actor['id'], now()]);
        $GLOBALS['nexo_local_billing_services'][$service['id']] = true;
        audit('BILLING_SERVICE_CREATE', 'Service', $service['id'], $actor['id']);
        return ['service' => $service, 'created' => true];
    }));
}

function billingLocalPatch(string $serviceId, array $input, array $actor): array
{
    $data = billingLocalInput($input, true);
    $initial = apiRecord('Service', $serviceId);
    return apiLocks(['client:' . $initial['clientId']], fn(): array => tx(function (\PDO $pdo) use ($serviceId, $data, $actor): array {
        $old = apiRecord('Service', $serviceId, true);
        if (!billingLocalIsService($serviceId)) throw new HttpError(409, 'Este endpoint sólo permite editar servicios de facturación local.', 'BILLING_ONLY_SERVICE_REQUIRED');
        if ($old['desiredState'] === 'RETIRED' || apiRecord('Client', $old['clientId'], true)['status'] === 'RETIRED') throw new HttpError(409, 'El cliente o servicio está retirado.', 'SERVICE_RETIRED');
        $planId = $data['planId'] ?? $old['planId'];
        billingLocalPlan($planId);
        if (billingLocalDuplicate($old['clientId'], $planId, $serviceId) !== null) throw new HttpError(409, 'El cliente ya tiene otro servicio de facturación con ese plan.', 'BILLING_SERVICE_EXISTS');
        $changes = [];
        foreach ($data as $field => $value) if (is_int($value) ? (int)$old[$field] !== $value : $old[$field] !== $value) $changes[$field] = $value;
        if (!$changes) return $old;
        $service = apiUpdate('Service', $serviceId, $changes);
        audit('BILLING_SERVICE_UPDATE', 'Service', $serviceId, $actor['id']);
        return $service;
    }));
}

function billingLocalDispatch(string $method, string $route): bool
{
    if ($route !== '/billing-services' && preg_match('#^/billing-services/([a-f0-9]{24})$#D', $route, $match) !== 1) return false;
    $actor = permit('ADMIN', 'BILLING');
    if ($method === 'POST' && $route === '/billing-services') {
        $result = billingLocalCreate(body(), $actor);
        json(apiDto('Service', $result['service']), $result['created'] ? 201 : 200);
    }
    if ($method === 'PATCH' && isset($match[1])) json(apiDto('Service', billingLocalPatch($match[1], body(), $actor)));
    throw new HttpError(405, 'Método no permitido para los servicios de facturación local.', 'METHOD_NOT_ALLOWED');
}
