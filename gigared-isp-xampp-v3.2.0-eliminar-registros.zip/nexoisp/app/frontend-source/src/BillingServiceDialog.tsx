import { useEffect, useState, type FormEvent } from 'react';
import { choices, patch, post } from './api';
import type { Row } from './forms';
import type { Client, Plan } from './types';
import { DynamicForm, errorMessage, Loading, Modal, money, type FieldSpec, type FormValues } from './ui';

export default function BillingServiceDialog({ row, close, saved, notify }: { row?: Row; close: () => void; saved: () => void; notify: (message: string, error?: boolean) => void }) {
  const editing = Boolean(row?.id);
  const [values, setValues] = useState<FormValues>(() => ({ clientId: String(row?.clientId || ''), planId: String(row?.planId || ''), billingDay: String(row?.billingDay ?? 1), dueDays: String(row?.dueDays ?? 10), graceDays: String(row?.graceDays ?? 3) }));
  const [clients, setClients] = useState<Client[]>([]), [plans, setPlans] = useState<Plan[]>([]);
  const [loading, setLoading] = useState(true), [busy, setBusy] = useState(false), [error, setError] = useState('');
  useEffect(() => {
    let active = true;
    Promise.all([choices<Client>('/clients'), choices<Plan>('/plans')]).then(([clientRows, planRows]) => {
      if (active) { setClients(clientRows); setPlans(planRows); }
    }).catch(failure => { if (active) setError(errorMessage(failure)); }).finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, []);
  const eligiblePlans = plans.filter(plan => plan.active && (!plan.profileImport || plan.profileImport.priceConfigured && plan.profileImport.rateStatus === 'READY'));
  const fields: FieldSpec[] = [
    { name: 'clientId', label: 'Cliente', type: 'select', required: true, full: true, disabled: editing, options: clients.filter(client => client.status !== 'RETIRED').map(client => ({ value: client.id, label: `${client.name} · ${client.code}` })) },
    { name: 'planId', label: 'Plan de Internet', type: 'select', required: true, full: true, options: eligiblePlans.map(plan => ({ value: plan.id, label: `${plan.name} · ${money(plan.priceCents, plan.currency)} al mes` })), hint: 'Se toma la tarifa del plan. Configura su precio y actívalo en Planes de Internet.' },
    { name: 'billingDay', label: 'Día de facturación', type: 'number', required: true, min: 1, max: 28, step: '1', hint: 'Día del mes a partir del cual puedes emitir la factura.' },
    { name: 'dueDays', label: 'Días para pagar', type: 'number', required: true, min: 0, max: 90, step: '1', hint: 'Días desde la emisión hasta el vencimiento.' },
    { name: 'graceDays', label: 'Días de gracia', type: 'number', required: true, min: 0, max: 90, step: '1', hint: 'Plazo adicional registrado después del vencimiento.' },
  ];
  const submit = async (event: FormEvent) => {
    event.preventDefault(); setBusy(true); setError('');
    try {
      for (const field of ['billingDay', 'dueDays', 'graceDays']) if (!/^\d+$/.test(String(values[field]))) throw new Error('Las fechas de cobro deben expresarse en días enteros.');
      const payload = { planId: values.planId, billingDay: Number(values.billingDay), dueDays: Number(values.dueDays), graceDays: Number(values.graceDays) };
      if (editing) await patch(`/billing-services/${row!.id}`, payload);
      else await post('/billing-services', { clientId: values.clientId, ...payload });
      saved(); notify('Servicio de facturación guardado. Ya puedes crear su factura; el MikroTik permanece sin cambios.'); close();
    } catch (failure) { setError(errorMessage(failure)); }
    finally { setBusy(false); }
  };
  return <Modal title={`${editing ? 'Editar' : 'Nuevo'} servicio de facturación`} description="Vincula el cliente con su plan y fechas de cobro." close={close}>
    <div className="alert info">Solo facturación: este registro no configura el MikroTik ni programa cortes o reconexiones.</div>
    {loading ? <Loading label="Cargando clientes y planes…" /> : <>
      {error && <div className="alert error" role="alert">{error}</div>}
      {!clients.some(client => client.status !== 'RETIRED') ? <div className="alert info">Primero registra o importa un cliente.</div> : !eligiblePlans.length ? <div className="alert info">En Planes de Internet, configura la mensualidad y activa al menos un plan con velocidades válidas.</div> : <DynamicForm fields={fields} values={values} setValues={setValues} submit={event => void submit(event)} busy={busy} submitLabel="Guardar servicio de facturación" />}
    </>}
  </Modal>;
}
