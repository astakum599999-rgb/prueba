import { useEffect, useState, type FormEvent } from 'react';
import { api, choices, patch, post } from './api';
import ClientSearch from './ClientSearch';
import type { Row } from './forms';
import type { Client, Plan } from './types';
import { DynamicForm, errorMessage, Loading, Modal, money, type FieldSpec, type FormValues } from './ui';

export default function BillingServiceDialog({ row, close, saved, notify }: { row?: Row; close: () => void; saved: () => void; notify: (message: string, error?: boolean) => void }) {
  const editing = Boolean(row?.id);
  const [values, setValues] = useState<FormValues>(() => {
    const today = new Date();
    const localDate = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
    return { clientId: String(row?.clientId || ''), planId: String(row?.planId || ''), billingDay: String(row?.billingDay ?? 1), billingStartOn: String(row?.billingStartOn || (editing ? '' : localDate)), dueDays: String(row?.dueDays ?? 10), graceDays: String(row?.graceDays ?? 3) };
  });
  const [client, setClient] = useState<Client | null>((row?.client as Client | undefined) || null), [plans, setPlans] = useState<Plan[]>([]);
  const [loading, setLoading] = useState(true), [busy, setBusy] = useState(false), [error, setError] = useState('');
  useEffect(() => {
    let active = true;
    const controller = new AbortController();
    const clientId = String(row?.clientId || '');
    Promise.all([choices<Plan>('/plans'), clientId && !row?.client ? api<Client>(`/clients/${encodeURIComponent(clientId)}`, { signal: controller.signal }) : Promise.resolve((row?.client as Client | undefined) || null)]).then(([planRows, selectedClient]) => {
      if (active) { setPlans(planRows); setClient(selectedClient); }
    }).catch(failure => { if (active) setError(errorMessage(failure)); }).finally(() => { if (active) setLoading(false); });
    return () => { active = false; controller.abort(); };
  }, []);
  const eligiblePlans = plans.filter(plan => plan.active && (!plan.profileImport || plan.profileImport.priceConfigured && plan.profileImport.rateStatus === 'READY'));
  const fields: FieldSpec[] = [
    { name: 'planId', label: 'Plan de Internet', type: 'select', required: true, full: true, options: eligiblePlans.map(plan => ({ value: plan.id, label: `${plan.name} · ${money(plan.priceCents, plan.currency)} al mes` })), hint: 'Se toma la tarifa del plan. Configura su precio y actívalo en Planes de Internet.' },
    { name: 'billingStartOn', label: 'Inicio de facturación (día, mes y año)', type: 'date', required: !editing, full: true, hint: editing && !row?.billingStartOn ? 'Sin fecha explícita: conserva el inicio anterior del servicio. Elige una fecha sólo si deseas cambiarlo.' : 'Primera fecha desde la que se puede facturar. Si es futura, deberás esperar hasta ese día. Dejar vacío al editar conserva la fecha guardada.' },
    { name: 'billingDay', label: 'Día de facturación', type: 'number', required: true, min: 1, max: 28, step: '1', hint: 'Día de cobro que se repite cada mes (del 1 al 28), respetando la fecha de inicio.' },
    { name: 'dueDays', label: 'Días para pagar', type: 'number', required: true, min: 0, max: 90, step: '1', hint: 'Días desde la emisión hasta el vencimiento.' },
    { name: 'graceDays', label: 'Días de gracia', type: 'number', required: true, min: 0, max: 90, step: '1', hint: 'Plazo adicional registrado después del vencimiento.' },
  ];
  const submit = async (event: FormEvent) => {
    event.preventDefault(); setBusy(true); setError('');
    try {
      if (!client || client.status === 'RETIRED') throw new Error('Busca y selecciona un cliente disponible antes de guardar.');
      for (const field of ['billingDay', 'dueDays', 'graceDays']) if (!/^\d+$/.test(String(values[field]))) throw new Error('Las fechas de cobro deben expresarse en días enteros.');
      const payload = { planId: values.planId, billingDay: Number(values.billingDay), dueDays: Number(values.dueDays), graceDays: Number(values.graceDays), ...(values.billingStartOn ? { billingStartOn: values.billingStartOn } : {}) };
      if (editing) await patch(`/billing-services/${row!.id}`, payload);
      else await post('/billing-services', { clientId: client.id, ...payload });
      saved(); notify('Servicio de facturación guardado. Podrás emitir facturas según su calendario; el MikroTik permanece sin cambios.'); close();
    } catch (failure) { setError(errorMessage(failure)); }
    finally { setBusy(false); }
  };
  return <Modal title={`${editing ? 'Editar' : 'Nuevo'} servicio de facturación`} description="Vincula el cliente con su plan y fechas de cobro." close={close}>
    <div className="alert info">Solo facturación: este registro no configura el MikroTik ni programa cortes o reconexiones.</div>
    {loading ? <Loading label="Cargando datos del servicio…" /> : <>
      {error && <div className="alert error" role="alert">{error}</div>}
      {!eligiblePlans.length ? <div className="alert info">En Planes de Internet, configura la mensualidad y activa al menos un plan con velocidades válidas.</div> : <DynamicForm beforeFields={<ClientSearch selected={client} change={selected => { setClient(selected); setValues({ ...values, clientId: selected?.id || '' }); }} disabled={editing || busy} />} fields={fields} values={values} setValues={setValues} submit={event => void submit(event)} busy={busy} submitDisabled={!client || client.status === 'RETIRED'} submitLabel="Guardar servicio de facturación" />}
    </>}
  </Modal>;
}
