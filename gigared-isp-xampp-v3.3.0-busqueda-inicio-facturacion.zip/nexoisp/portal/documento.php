<?php
declare(strict_types=1);
namespace Nexo;

ini_set('display_errors', '0');
date_default_timezone_set('UTC');
header('Content-Type: text/html; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('Referrer-Policy: no-referrer');

function documentEscape(mixed $value): string { return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function documentMoney(mixed $cents, string $currency): string
{
    $amount = number_format((int)$cents / 100, 2, '.', ',');
    return $currency === 'PEN' ? 'S/ ' . $amount : $amount . ' ' . $currency;
}
function documentDate(?string $date): string
{
    if (!$date) return '—';
    try { return (new \DateTimeImmutable($date, new \DateTimeZone('UTC')))->format('d/m/Y H:i') . ' UTC'; } catch (\Throwable) { return '—'; }
}

try {
    require_once dirname(__DIR__) . '/app/bootstrap.php';
    require_once dirname(__DIR__) . '/app/migrations.php';
    require_once dirname(__DIR__) . '/app/auth.php';
    require_once dirname(__DIR__) . '/app/validation.php';
    require_once dirname(__DIR__) . '/app/portal.php';
    require_once dirname(__DIR__) . '/app/finance.php';
    require_once dirname(__DIR__) . '/app/financial-delete.php';
    if (migrationNeedsUpgrade()) throw new HttpError(503, 'El sistema requiere completar una actualización', 'UPGRADE_REQUIRED');
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'GET') throw new HttpError(405, 'Método no permitido');
    $staff = null;
    try { $staff = currentUser(); } catch (HttpError $error) { if (headerValue('Authorization') !== null) throw $error; }
    $actor = $staff ? null : portalRequire();
    $clientId = $actor['client']['id'] ?? null;
    $type = $_GET['type'] ?? null;
    if (!is_string($type) || !in_array($type, ['invoice','receipt','contract'], true)) throw new HttpError(422, 'Tipo de documento inválido');
    $identifier = portalId($_GET['id'] ?? null);
    $params = [$identifier];
    if ($clientId !== null) $params[] = $clientId;
    $scope = $clientId === null ? '' : ' AND `clientId`=?';
    $payment = null; $contract = null; $invoice = null; $lines = [];
    if ($type === 'receipt') {
        $payment = fetchOne('SELECT p.* FROM `Payment` p JOIN `Invoice` i ON i.`id`=p.`invoiceId` WHERE p.`id`=?' . ($clientId === null ? '' : ' AND i.`clientId`=?'), $params) ?? throw new HttpError(404, 'Documento no encontrado');
        financialRequirePresent('Payment', $payment['id']);
        financialRequirePresent('Invoice', $payment['invoiceId']);
        $invoice = portalRecord('Invoice', $payment['invoiceId']);
        $client = portalClientDto(portalRecord('Client', $invoice['clientId']));
        $reference = fetchOne('SELECT `reference` FROM `PaymentReport` WHERE `paymentId`=?', [$payment['id']]);
        $payment['reportedReference'] = $reference['reference'] ?? null;
        $title = 'Recibo de pago'; $number = $payment['externalReference'];
    } elseif ($type === 'invoice') {
        $invoice = fetchOne('SELECT * FROM `Invoice` WHERE `id`=?' . $scope, $params) ?? throw new HttpError(404, 'Documento no encontrado');
        financialRequirePresent('Invoice', $invoice['id']);
        $client = portalClientDto(portalRecord('Client', $invoice['clientId']));
        $lines = fetchAll('SELECT `description`,`quantity`,`unitCents`,`totalCents`,`currency` FROM `InvoiceLine` WHERE `invoiceId`=? ORDER BY `position` ASC,`id` ASC', [$invoice['id']]);
        $title = 'Factura de servicio'; $number = $invoice['number'];
    } else {
        $contract = fetchOne('SELECT * FROM `ServiceContract` WHERE `id`=?' . $scope, $params) ?? throw new HttpError(404, 'Documento no encontrado');
        $client = ['name' => $contract['clientName'],'document' => $contract['document'],'address' => $contract['address']];
        $title = $contract['title']; $number = strtoupper(substr($contract['id'], -12));
    }
    $company = fetchCompanyProfile();
    $nonce = base64_encode(random_bytes(18));
    header("Content-Security-Policy: default-src 'none'; style-src 'unsafe-inline'; script-src 'nonce-{$nonce}'; frame-ancestors 'none'; base-uri 'none'");
    ?>
<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?= documentEscape($title . ' · ' . $number) ?></title>
<style>
*{box-sizing:border-box}body{font:14px/1.55 system-ui,Segoe UI,sans-serif;color:#172033;background:#edf1f5;margin:0}.toolbar{max-width:900px;margin:22px auto;display:flex;justify-content:flex-end;padding:0 18px}button{border:0;background:#106b66;color:white;border-radius:7px;padding:11px 18px;font:inherit;cursor:pointer}.sheet{max-width:900px;margin:0 auto 40px;background:white;padding:48px;box-shadow:0 12px 35px #17203312}header{display:flex;justify-content:space-between;gap:35px;border-bottom:2px solid #106b66;padding-bottom:25px}h1{font-size:24px;margin:0 0 10px}h2{font-size:18px;margin:25px 0 12px}p{margin:5px 0}.muted{color:#657184}.small{font-size:12px}.company{font-size:20px;font-weight:750}.doc{text-align:right}dl{display:grid;grid-template-columns:165px 1fr;gap:8px;margin:15px 0}dt{color:#657184}dd{margin:0;overflow-wrap:anywhere}table{width:100%;border-collapse:collapse;margin:25px 0}th,td{text-align:left;border-bottom:1px solid #dfe5eb;padding:11px 7px;vertical-align:top}th{font-size:12px;color:#657184;background:#f7f9fb}.right{text-align:right}.totals{margin:20px 0 20px auto;max-width:360px}.totals div{display:flex;justify-content:space-between;gap:25px;padding:7px}.totals .total{font-size:18px;border-top:2px solid #dfe5eb;font-weight:750}.notice{padding:15px;background:#f5f8fa;border-left:3px solid #106b66;font-size:12px;color:#526074;margin-top:25px}.terms{white-space:pre-wrap;overflow-wrap:anywhere}.signature{border-top:1px solid #c7d0db;margin-top:30px;padding-top:14px}footer{border-top:1px solid #dfe5eb;margin-top:35px;padding-top:16px;color:#657184;font-size:11px}@media print{body{background:white}.toolbar{display:none}.sheet{margin:0;max-width:none;box-shadow:none;padding:0}tr{break-inside:avoid}h2{break-after:avoid}@page{size:A4;margin:18mm}}@media(max-width:600px){.sheet{padding:24px}header{display:block}.doc{text-align:left;margin-top:20px}dl{grid-template-columns:120px 1fr}}
</style></head><body><div class="toolbar"><button id="print">Imprimir / guardar PDF</button></div><main class="sheet">
<header><div><div class="company"><?= documentEscape($company['name']) ?></div><?php foreach (['taxId','address','phone','email'] as $field): if (!empty($company[$field])): ?><p class="small muted"><?= documentEscape($company[$field]) ?></p><?php endif; endforeach; ?></div><div class="doc"><h1><?= documentEscape($title) ?></h1><p><?= documentEscape($number) ?></p><p class="muted small"><?= documentEscape($type === 'contract' ? $contract['status'] : ($type === 'invoice' ? $invoice['status'] : 'Pago registrado')) ?></p></div></header>
<h2>Cliente</h2><p><strong><?= documentEscape($client['name']) ?></strong></p><?php foreach (['code','document','address','email','phone'] as $field): if (!empty($client[$field])): ?><p><?= documentEscape($client[$field]) ?></p><?php endif; endforeach; ?>
<?php if ($type === 'invoice'): ?>
<dl><dt>Periodo</dt><dd><?= documentEscape($invoice['period']) ?></dd><dt>Emisión</dt><dd><?= documentEscape(documentDate($invoice['issuedAt'])) ?></dd><dt>Vencimiento</dt><dd><?= documentEscape(documentDate($invoice['dueAt'])) ?></dd><dt>Fin de gracia</dt><dd><?= documentEscape(documentDate($invoice['graceUntil'])) ?></dd></dl>
<table><thead><tr><th>Concepto</th><th class="right">Cantidad</th><th class="right">Precio unitario</th><th class="right">Importe</th></tr></thead><tbody><?php if ($lines): foreach ($lines as $line): ?><tr><td><?= documentEscape($line['description']) ?></td><td class="right"><?= documentEscape($line['quantity']) ?></td><td class="right"><?= documentEscape(documentMoney($line['unitCents'], $line['currency'])) ?></td><td class="right"><?= documentEscape(documentMoney($line['totalCents'], $line['currency'])) ?></td></tr><?php endforeach; else: ?><tr><td>Servicio de Internet · <?= documentEscape($invoice['period']) ?></td><td class="right">1</td><td class="right"><?= documentEscape(documentMoney($invoice['amountCents'], $invoice['currency'])) ?></td><td class="right"><?= documentEscape(documentMoney($invoice['amountCents'], $invoice['currency'])) ?></td></tr><?php endif; ?></tbody></table>
<div class="totals"><div class="total"><span>Total</span><span><?= documentEscape(documentMoney($invoice['amountCents'], $invoice['currency'])) ?></span></div><div><span>Pagado</span><span><?= documentEscape(documentMoney($invoice['paidCents'], $invoice['currency'])) ?></span></div><div><span>Saldo</span><span><?= documentEscape(documentMoney((int)$invoice['amountCents'] - (int)$invoice['paidCents'], $invoice['currency'])) ?></span></div></div>
<?php elseif ($type === 'receipt'): ?>
<dl><dt>Factura</dt><dd><?= documentEscape($invoice['number']) ?></dd><dt>Fecha del registro</dt><dd><?= documentEscape(documentDate($payment['receivedAt'])) ?></dd><dt>Proveedor</dt><dd><?= documentEscape($payment['provider']) ?></dd><dt>Referencia</dt><dd><?= documentEscape($payment['reportedReference'] ?? $payment['externalReference']) ?></dd><dt>Identificador</dt><dd><?= documentEscape($payment['id']) ?></dd></dl><div class="totals"><div class="total"><span>Importe recibido</span><span><?= documentEscape(documentMoney($payment['amountCents'], $invoice['currency'])) ?></span></div></div>
<?php else: ?>
<dl><dt>Fecha de emisión</dt><dd><?= documentEscape(documentDate($contract['createdAt'])) ?></dd><dt>Plan contratado</dt><dd><?= documentEscape($contract['planName']) ?></dd><dt>Conexión</dt><dd><?= documentEscape($contract['serviceType']) ?></dd><dt>Dirección IP</dt><dd><?= documentEscape($contract['ipAddress']) ?></dd><dt>Precio del plan</dt><dd><?= documentEscape(documentMoney($contract['priceCents'], $contract['currency'])) ?></dd></dl><h2>Condiciones</h2><div class="terms"><?= documentEscape($contract['terms']) ?></div><section class="signature"><p><strong>Estado: <?= documentEscape($contract['status']) ?></strong></p><?php if ($contract['acceptedAt']): ?><p>Aceptación registrada por <?= documentEscape($contract['acceptedName']) ?></p><p class="small muted"><?= documentEscape(documentDate($contract['acceptedAt'])) ?></p><?php else: ?><p class="muted">Sin aceptación registrada.</p><?php endif; ?><?php if ($contract['cancelledAt']): ?><p>Cancelación: <?= documentEscape(documentDate($contract['cancelledAt'])) ?></p><?php endif; ?></section><div class="notice">La aceptación mediante nombre escrito deja constancia en el portal. No representa una firma electrónica certificada ni sustituye requisitos legales adicionales.</div>
<?php endif; ?>
<?php if ($type !== 'contract'): ?><div class="notice">Documento administrativo de control del servicio. No constituye un comprobante fiscal electrónico ni una confirmación emitida por un banco.</div><?php endif; ?>
<?php if ($type !== 'contract' && !empty($company['invoiceNotes'])): ?><p class="terms small"><?= documentEscape($company['invoiceNotes']) ?></p><?php endif; ?><footer>Emitido por <?= documentEscape($company['name']) ?> · GIGARED ISP · Las fechas se muestran en UTC.</footer></main><script nonce="<?= documentEscape($nonce) ?>">document.getElementById('print').addEventListener('click',function(){window.print()});</script></body></html>
<?php
} catch (\Throwable $error) {
    $status = $error instanceof HttpError ? $error->status : 500;
    http_response_code($status);
    $message = $error instanceof HttpError ? $error->getMessage() : 'El documento no está disponible en este momento';
    echo '<!doctype html><html lang="es"><meta charset="utf-8"><title>Documento no disponible</title><p>' . documentEscape($message) . '</p></html>';
}
