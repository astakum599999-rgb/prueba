import { useEffect, useState } from 'react';
import { api } from './api';
import type { DashboardOnlineSnapshot } from './types';

interface Observation {
  snapshot: DashboardOnlineSnapshot | null;
  wallDeadline: number;
  monotonicDeadline: number;
}

const emptyObservation = (): Observation => ({ snapshot: null, wallDeadline: 0, monotonicDeadline: 0 });
const visible = () => document.visibilityState !== 'hidden';
const expired = (observation: Observation) => observation.snapshot?.status === 'FRESH' && (Date.now() >= observation.wallDeadline || performance.now() >= observation.monotonicDeadline);
const invalidate = (observation: Observation): Observation => ({ ...observation, snapshot: observation.snapshot ? { ...observation.snapshot, count: null, status: 'STALE', stale: true } : null, wallDeadline: 0, monotonicDeadline: 0 });

function observationFrom(snapshot: DashboardOnlineSnapshot): Observation {
  const wallNow = Date.now(), monotonicNow = performance.now();
  const observedAt = snapshot.observedAt ? Date.parse(snapshot.observedAt) : NaN;
  const serverTime = Date.parse(snapshot.serverTime);
  const maxAge = Math.min(30, Math.max(0, snapshot.expiresAfterSeconds)) * 1000;
  const age = serverTime - observedAt;
  const valid = snapshot.status === 'FRESH' && snapshot.stale !== true && Number.isSafeInteger(snapshot.count) && Number(snapshot.count) >= 0 && snapshot.totalRouters > 0 && snapshot.coveredRouters === snapshot.totalRouters && Number.isFinite(age) && age >= 0 && age < maxAge;
  if (snapshot.status === 'FRESH' && !valid) return { snapshot: { ...snapshot, status: 'STALE', stale: true, count: null }, wallDeadline: 0, monotonicDeadline: 0 };
  return { snapshot: valid ? snapshot : { ...snapshot, count: null }, wallDeadline: valid ? wallNow + maxAge - age : 0, monotonicDeadline: valid ? monotonicNow + maxAge - age : 0 };
}

/** Count observations expire independently of polling, including a stalled router request. */
export function useDashboardOnline(enabled: boolean) {
  const [observation, setObservation] = useState<Observation>(emptyObservation);
  const [failed, setFailed] = useState(false);
  useEffect(() => {
    setObservation(emptyObservation()); setFailed(false);
    if (!enabled) return;
    let stopped = false;
    let pending: AbortController | undefined;
    let timer: number | undefined, deadline: number | undefined;
    const expire = () => setObservation(old => expired(old) ? invalidate(old) : old);
    const expiry = window.setInterval(expire, 1000);
    const tick = async () => {
      window.clearTimeout(timer);
      if (stopped || pending || !visible()) return;
      expire();
      const controller = new AbortController();
      pending = controller;
      deadline = window.setTimeout(() => controller.abort(), 90000);
      let delay = 15000;
      try {
        const snapshot = await api<DashboardOnlineSnapshot>('/dashboard/pppoe-online', { method: 'POST', body: '{}', cache: 'no-store', signal: controller.signal });
        if (stopped || controller.signal.aborted || pending !== controller) return;
        setObservation(observationFrom(snapshot)); setFailed(false);
        if ((snapshot.status === 'PENDING' || snapshot.status === 'PARTIAL') && snapshot.coveredRouters < snapshot.totalRouters && snapshot.processed > 0) delay = 1000;
      } catch {
        if (!stopped && visible()) { setObservation(invalidate); setFailed(true); }
      } finally {
        window.clearTimeout(deadline);
        if (pending === controller) pending = undefined;
        if (!stopped && visible()) timer = window.setTimeout(() => void tick(), controller.signal.aborted ? 250 : delay);
      }
    };
    const visibility = () => {
      expire();
      if (visible()) void tick();
      else { window.clearTimeout(timer); pending?.abort(); }
    };
    document.addEventListener('visibilitychange', visibility);
    timer = window.setTimeout(() => void tick(), 0);
    return () => { stopped = true; window.clearInterval(expiry); window.clearTimeout(timer); window.clearTimeout(deadline); pending?.abort(); document.removeEventListener('visibilitychange', visibility); };
  }, [enabled]);

  const snapshot = observation.snapshot;
  const fresh = enabled && snapshot?.status === 'FRESH' && !expired(observation);
  const count = fresh ? snapshot.count : null;
  let hint = 'Consultando MikroTik…';
  if (!enabled) hint = 'Consulta de sesiones no disponible';
  else if (fresh) hint = 'Sesiones PPPoE activas';
  else if (failed || snapshot?.status === 'STALE' || expired(observation)) hint = 'Sin lectura reciente';
  else if (snapshot?.status === 'EMPTY') hint = 'Sin routers MikroTik';
  else if (snapshot?.status === 'PARTIAL') hint = `Lectura parcial · ${snapshot.coveredRouters} de ${snapshot.totalRouters} routers`;
  return { count, fresh, hint, status: fresh ? 'FRESH' : failed || expired(observation) ? 'STALE' : snapshot?.status || 'PENDING' };
}
