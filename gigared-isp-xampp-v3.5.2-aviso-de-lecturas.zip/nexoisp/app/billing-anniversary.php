<?php
declare(strict_types=1);
namespace Nexo;

use DateTimeImmutable;
use DateTimeZone;

require_once __DIR__ . '/billing-calculations.php';

const BILLING_INSTALLATION_TIMEZONE = 'America/Lima';

/** The period identifies the month in which payment is due. */
function billingAnniversaryDates(string $startOn, string $period, int $graceDays, DateTimeImmutable $at): ?array
{
    $installation = billingCalculationDate($startOn, 'Inicio de facturación');
    if ($installation->format('Y') < '2000' || $installation->format('Y') > '2100' || $graceDays < 0 || $graceDays > 90) {
        throw new HttpError(400, 'Calendario de instalación inválido.');
    }
    $month = billingCalculationDate($period . '-01', 'period');
    // Installation is a Peruvian calendar date, not midnight in UTC (19:00 yesterday).
    $zone = new DateTimeZone(BILLING_INSTALLATION_TIMEZONE);
    $installation = new DateTimeImmutable($startOn . ' 00:00:00', $zone);
    $month = new DateTimeImmutable($period . '-01 00:00:00', $zone);
    if ($month < $installation->modify('first day of next month')) return null;
    // Reuse the ORIGINAL installation day for every month, including after February.
    $day = min((int)$installation->format('d'), (int)$month->format('t'));
    $due = $month->setDate((int)$month->format('Y'), (int)$month->format('m'), $day);
    $issue = $due->modify('-2 days');
    if ($issue > $at) return null;
    return [
        'issuedAt' => $issue->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s.v'),
        'dueAt' => $due->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s.v'),
        // Exclusive boundary: the whole payment day plus the additional grace days.
        'graceUntil' => $due->modify('+' . ($graceDays + 1) . ' days')->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s.v'),
    ];
}

/** Include next month so a payment on its first day can be invoiced this month. */
function billingAnniversaryPeriods(string $startOn, DateTimeImmutable $at): array
{
    $cursor = billingCalculationDate($startOn, 'Inicio de facturación')->modify('first day of next month');
    $last = $at->setTimezone(new DateTimeZone(BILLING_INSTALLATION_TIMEZONE))->modify('first day of next month')->setTime(0, 0);
    $periods = [];
    while ($cursor <= $last) {
        $periods[] = $cursor->format('Y-m');
        $cursor = $cursor->modify('first day of next month');
    }
    return $periods;
}
