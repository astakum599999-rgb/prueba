<?php
declare(strict_types=1);
namespace Nexo;

use DateTimeImmutable;
use DateTimeZone;

/** No identities belong in this table: only a count and its exact snapshot time. */
function dashboardOnlineStore(string $routerId, int $count, string $observedAt): void
{
    if ($count < 0 || $count > CLIENT_IP_LIVE_LIMIT) throw new \LogicException('Conteo PPPoE fuera de rango.');
    db()->prepare('INSERT INTO `RouterPppOnlineCount` (`routerId`,`pppoeCount`,`observedAt`,`updatedAt`) VALUES (?,?,?,?) ON DUPLICATE KEY UPDATE `pppoeCount`=VALUES(`pppoeCount`),`observedAt`=VALUES(`observedAt`),`updatedAt`=VALUES(`updatedAt`)')
        ->execute([$routerId, $count, $observedAt, $observedAt]);
}

function dashboardOnlineIso(?string $value): ?string
{
    return $value === null ? null : (new DateTimeImmutable($value, new DateTimeZone('UTC')))->format('Y-m-d\TH:i:s.v\Z');
}

/** A fresh number requires coverage of every configured real RouterOS router. */
function dashboardOnlineCount(int $processed = 0): array
{
    $rows = fetchAll("SELECT r.id,c.status,c.lastSuccessAt,c.failures,n.pppoeCount,n.observedAt FROM `Router` r LEFT JOIN `RouterPppActiveCache` c ON c.routerId=r.id LEFT JOIN `RouterPppOnlineCount` n ON n.routerId=r.id WHERE r.transport IN ('REST','SOCKET') ORDER BY r.id");
    $covered = 0;
    $sum = 0;
    $oldest = null;
    $pending = false;
    $failed = false;
    foreach ($rows as $row) {
        if (clientIpLiveFresh($row) && is_string($row['observedAt']) && $row['observedAt'] === $row['lastSuccessAt'] && $row['pppoeCount'] !== null) {
            $covered++;
            $sum += (int)$row['pppoeCount'];
            $oldest = $oldest === null || $row['observedAt'] < $oldest ? $row['observedAt'] : $oldest;
        } elseif ($row['status'] === 'ERROR') {
            $failed = true;
        } elseif ($row['status'] === null || in_array($row['status'], ['WAITING','RUNNING','DEFERRED'], true) || $row['observedAt'] === null) {
            $pending = true;
        }
    }
    $total = count($rows);
    $fresh = $total > 0 && $covered === $total;
    $status = $total === 0 ? 'EMPTY' : ($fresh ? 'FRESH' : ($covered > 0 ? 'PARTIAL' : ($pending && !$failed ? 'PENDING' : 'STALE')));
    return [
        'count' => $fresh ? $sum : null,
        'status' => $status,
        'stale' => !$fresh,
        'observedAt' => $fresh ? dashboardOnlineIso($oldest) : null,
        'serverTime' => dashboardOnlineIso(now()),
        'intervalSeconds' => CLIENT_IP_LIVE_INTERVAL,
        'expiresAfterSeconds' => CLIENT_IP_LIVE_MAX_AGE,
        'coveredRouters' => $covered,
        'totalRouters' => $total,
        'processed' => $processed,
    ];
}

/** Share /ppp/active reservations with the client-IP reader; never mutate RouterOS. */
function dashboardOnlineRefresh(): array
{
    $rows = fetchAll("SELECT r.*,c.nextQueryAt AS cacheNextQueryAt FROM `Router` r LEFT JOIN `RouterPppActiveCache` c ON c.routerId=r.id WHERE r.transport IN ('REST','SOCKET') ORDER BY COALESCE(c.nextQueryAt,'1970-01-01'),r.id");
    $processed = 0;
    foreach ($rows as $router) {
        if ($processed >= 5) break;
        if (clientIpLiveRefresh($router)) $processed++;
    }
    return dashboardOnlineCount($processed);
}

function dashboardOnlineDispatch(string $method, string $route): bool
{
    if ($route !== '/dashboard/pppoe-online') return false;
    $actor = permit('ADMIN', 'BILLING', 'TECHNICIAN', 'VIEWER');
    if ($method === 'GET') json(dashboardOnlineCount());
    if ($method !== 'POST') throw new HttpError(405, 'Método no permitido.', 'METHOD_NOT_ALLOWED');
    if (($GLOBALS['nexo_raw_body'] ?? '') !== '' && body() !== []) throw new HttpError(422, 'La consulta agregada no admite parámetros.', 'VALIDATION_ERROR');
    rateLimit('dashboard-pppoe-online:' . $actor['id'], 600, 60);
    if (function_exists('set_time_limit')) set_time_limit(90);
    ignore_user_abort(true);
    json(dashboardOnlineRefresh());
}
