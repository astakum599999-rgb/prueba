<?php
declare(strict_types=1);
namespace Nexo;

use PDO;

function financialEntityType(string $type): string
{
    if (!in_array($type, ['Invoice', 'Payment', 'Service'], true)) throw new \LogicException('Entidad financiera no admitida.');
    return $type;
}

/** Marker queries remain uncached so transactions always see their own writes. */
function financialDeleted(string $type, string $identifier): bool
{
    financialEntityType($type);
    return fetchOne('SELECT `entityId` FROM `FinanceDeletion` WHERE `entityType`=? AND `entityId`=?', [$type, $identifier]) !== null;
}

function financialRequirePresent(string $type, string $identifier): void
{
    if (financialDeleted($type, $identifier)) throw new HttpError(410, 'El registro fue eliminado del sistema. Su historial de eliminación se conserva.', 'RECORD_DELETED');
}

/** Only fixed entity types and SQL identifiers can form a visibility predicate. */
function financialDeletionClause(string $type, string $alias): string
{
    financialEntityType($type);
    if (preg_match('/^[A-Za-z_][A-Za-z0-9_]*$/D', $alias) !== 1) throw new \LogicException('Alias financiero no admitido.');
    return "NOT EXISTS (SELECT 1 FROM `FinanceDeletion` fd WHERE fd.`entityType`='" . $type . "' AND fd.`entityId`=`" . $alias . "`.`id`)";
}

function financialMarkDeleted(string $type, array $record, string $clientId, array $snapshot, array $actor): void
{
    financialEntityType($type);
    $identifier = $record['id'];
    $encoded = json_encode($snapshot, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    db()->prepare('INSERT INTO `FinanceDeletion` (`entityType`,`entityId`,`clientId`,`actorId`,`deletedAt`,`snapshot`) VALUES (?,?,?,?,?,?)')
        ->execute([$type, $identifier, $clientId, $actor['id'], now(), $encoded]);
    audit('FINANCIAL_DELETE', $type, $identifier, $actor['id']);
}

function financialDeleteInvoice(string $identifier, array $actor): void
{
    if (financialDeleted('Invoice', $identifier)) return;
    $initial = fetchOne('SELECT `clientId`,`serviceId` FROM `Invoice` WHERE `id`=?', [$identifier]) ?? throw new HttpError(404, 'Factura no encontrada.', 'NOT_FOUND');
    billingWithLocks(['billing:' . $initial['serviceId'], 'client:' . $initial['clientId']], function () use ($identifier, $actor): void {
        tx(function (PDO $pdo) use ($identifier, $actor): void {
            $invoice = fetchOne('SELECT * FROM `Invoice` WHERE `id`=? FOR UPDATE', [$identifier]) ?? throw new HttpError(404, 'Factura no encontrada.', 'NOT_FOUND');
            if (financialDeleted('Invoice', $identifier)) return;
            $paymentCount = (int)fetchOne('SELECT COUNT(*) AS n FROM `Payment` p WHERE p.`invoiceId`=? AND ' . financialDeletionClause('Payment', 'p'), [$identifier])['n'];
            if ($paymentCount > 0 || (int)$invoice['paidCents'] !== 0) throw new HttpError(409, 'La factura tiene pagos registrados. Elimina primero sus pagos para corregir el saldo antes de eliminarla.', 'INVOICE_HAS_PAYMENTS');
            if ((int)fetchOne("SELECT COUNT(*) AS n FROM `PaymentReport` WHERE `invoiceId`=? AND `status`='SUBMITTED'", [$identifier])['n'] > 0) {
                throw new HttpError(409, 'La factura tiene pagos reportados pendientes de revisión. Resuélvelos antes de eliminarla.', 'INVOICE_HAS_PENDING_REPORTS');
            }
            $snapshot = ['record' => $invoice,
                'lines' => fetchAll('SELECT * FROM `InvoiceLine` WHERE `invoiceId`=? ORDER BY `position`,`id`', [$identifier]),
                'promises' => fetchAll('SELECT * FROM `PaymentPromise` WHERE `invoiceId`=? ORDER BY `createdAt`,`id`', [$identifier]),
            ];
            financialMarkDeleted('Invoice', $invoice, $invoice['clientId'], $snapshot, $actor);
            $pdo->prepare("UPDATE `Invoice` SET `status`='VOID',`updatedAt`=? WHERE `id`=?")->execute([now(), $identifier]);
            $pdo->prepare("UPDATE `PaymentPromise` SET `status`='CANCELLED',`resolvedAt`=? WHERE `invoiceId`=? AND `status`='ACTIVE'")->execute([now(), $identifier]);
            // InvoiceLine and one-time-charge reservations remain immutable.
            // This operation never invokes network reconciliation or enqueues jobs.
        });
    });
}

function financialDeletePayment(string $identifier, array $actor): void
{
    if (financialDeleted('Payment', $identifier)) return;
    $initial = fetchOne('SELECT p.*,i.`clientId` FROM `Payment` p JOIN `Invoice` i ON i.`id`=p.`invoiceId` WHERE p.`id`=?', [$identifier]) ?? throw new HttpError(404, 'Pago no encontrado.', 'NOT_FOUND');
    // Caja holds cash-payment while linking a movement. Payment registration
    // acquires payment-reference before client; preserve that shared ordering.
    $keys = ['cash-payment:' . $identifier, 'payment:' . $initial['provider'] . ':' . $initial['externalReference'], 'client:' . $initial['clientId']];
    billingWithLocks($keys, function () use ($identifier, $actor): void {
        tx(function (PDO $pdo) use ($identifier, $actor): void {
            $payment = fetchOne('SELECT * FROM `Payment` WHERE `id`=? FOR UPDATE', [$identifier]) ?? throw new HttpError(404, 'Pago no encontrado.', 'NOT_FOUND');
            if (financialDeleted('Payment', $identifier)) return;
            $invoice = fetchOne('SELECT * FROM `Invoice` WHERE `id`=? FOR UPDATE', [$payment['invoiceId']]) ?? throw new HttpError(404, 'Factura no encontrada.', 'NOT_FOUND');
            $unreversed = fetchOne('SELECT m.`id` FROM `CashMovement` m WHERE m.`paymentId`=? AND NOT EXISTS (SELECT 1 FROM `CashMovement` r WHERE r.`reversalOf`=m.`id`) LIMIT 1 FOR UPDATE', [$identifier]);
            if ($unreversed !== null) throw new HttpError(409, 'El pago está vinculado a un ingreso de Caja. Registra primero su contrapartida en Ingresos y gastos y después elimina el pago.', 'PAYMENT_HAS_CASH_MOVEMENT');
            financialMarkDeleted('Payment', $payment, $invoice['clientId'], ['record' => $payment, 'invoiceBefore' => array_intersect_key($invoice, array_flip(['id','number','clientId','serviceId','amountCents','paidCents','currency','status']))], $actor);
            $remaining = (int)fetchOne('SELECT COALESCE(SUM(p.`amountCents`),0) AS total FROM `Payment` p WHERE p.`invoiceId`=? AND ' . financialDeletionClause('Payment', 'p'), [$payment['invoiceId']])['total'];
            if ($remaining < 0 || $remaining > (int)$invoice['amountCents']) throw new HttpError(409, 'El saldo de la factura requiere revisión antes de eliminar este pago.', 'PAYMENT_BALANCE_INVALID');
            $status = $invoice['status'] === 'VOID' ? 'VOID' : ($remaining === (int)$invoice['amountCents'] ? 'PAID' : 'OPEN');
            $pdo->prepare('UPDATE `Invoice` SET `paidCents`=?,`status`=?,`updatedAt`=? WHERE `id`=?')->execute([$remaining, $status, now(), $invoice['id']]);
            // The original payment and reference remain reserved for idempotency.
            // Fulfilled promises and the cash ledger retain their own history.
        });
    });
}

function financialDeleteService(string $identifier, array $actor): void
{
    if (financialDeleted('Service', $identifier)) return;
    $initial = fetchOne('SELECT `clientId` FROM `Service` WHERE `id`=?', [$identifier]) ?? throw new HttpError(404, 'Servicio no encontrado.', 'NOT_FOUND');
    billingWithLocks(['billing:' . $identifier, 'client:' . $initial['clientId']], function () use ($identifier, $actor): void {
        tx(function (PDO $pdo) use ($identifier, $actor): void {
            $service = fetchOne('SELECT * FROM `Service` WHERE `id`=? FOR UPDATE', [$identifier]) ?? throw new HttpError(404, 'Servicio no encontrado.', 'NOT_FOUND');
            if (financialDeleted('Service', $identifier)) return;
            if (!billingLocalIsService($identifier)) throw new HttpError(409, 'Sólo se eliminan aquí los servicios de facturación local. Los servicios de red conservan su protección.', 'BILLING_ONLY_SERVICE_REQUIRED');
            if ((int)fetchOne('SELECT COUNT(*) AS n FROM `Invoice` i WHERE i.`serviceId`=? AND ' . financialDeletionClause('Invoice', 'i'), [$identifier])['n'] > 0) {
                throw new HttpError(409, 'El servicio conserva facturas. Elimina primero sus pagos y facturas antes de eliminarlo.', 'SERVICE_HAS_INVOICES');
            }
            if ((int)fetchOne("SELECT COUNT(*) AS n FROM `ServiceContract` WHERE `serviceId`=? AND `status` IN ('DRAFT','ACCEPTED')", [$identifier])['n'] > 0) {
                throw new HttpError(409, 'El servicio conserva un contrato vigente. Cancela el contrato antes de eliminarlo.', 'SERVICE_HAS_CONTRACTS');
            }
            // apiFields intentionally excludes passwordEncrypted and credentials.
            $snapshot = ['record' => apiPick($service, apiFields('Service'))];
            financialMarkDeleted('Service', $service, $service['clientId'], $snapshot, $actor);
            $pdo->prepare("UPDATE `Service` SET `desiredState`='RETIRED',`updatedAt`=? WHERE `id`=?")->execute([now(), $identifier]);
            // Do not claim a retirement was applied to a router; no task is queued.
        });
    });
}

function financialDeleteDispatch(string $method, string $route): bool
{
    if (preg_match('#^/(invoices|payments|services|billing-services)/([a-f0-9]{24})$#D', $route, $match) !== 1) return false;
    $type = match ($match[1]) { 'invoices' => 'Invoice', 'payments' => 'Payment', default => 'Service' };
    $identifier = $match[2];
    if ($method === 'GET') {
        requireAuth();
        financialRequirePresent($type, $identifier);
        return false;
    }
    if ($method !== 'DELETE') return false;
    if ($type === 'Service' && $match[1] === 'services' && !billingLocalIsService($identifier)) return false;
    $actor = permit('ADMIN', 'BILLING');
    if (($GLOBALS['nexo_raw_body'] ?? '') !== '' && body() !== []) throw new HttpError(422, 'La eliminación no admite campos adicionales.', 'VALIDATION_ERROR');
    match ($type) {
        'Invoice' => financialDeleteInvoice($identifier, $actor),
        'Payment' => financialDeletePayment($identifier, $actor),
        'Service' => financialDeleteService($identifier, $actor),
    };
    json(null, 204);
}
