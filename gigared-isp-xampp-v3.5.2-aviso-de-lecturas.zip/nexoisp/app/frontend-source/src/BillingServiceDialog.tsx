import { useEffect, useState, type FormEvent } from 'react';
import { api, choices, patch, post } from './api';
import ClientSearch from './ClientSearch';
import type { Row } from './forms';
import type { Client, Plan } from './types';
import { DynamicForm, errorMessage, Loading, Modal, money, type FieldSpec, type FormValues } from './ui';

function firstCycle(value: string): { issue: string; due: string } | null {
  const parts = /^(20\d{2}|2100)-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])$/.exec(value);
  if (!parts) return null;
  const year = Number(parts[1]), month = Number(parts[2]), day = Number(parts[3]);
  const installed = new Date(Date.UTC(year, month - 1, day));
  if (installed.toISOString().slice(0, 10) !== value) return null;
  const lastDay = new Date(Date.UTC(year, month + 1, 0)).getUTCDate();
  const due = new Date(Date.UTC(year, month, Math.min(day, lastDay)));
  const issue = new Date(due.getTime() - 2 * 86400000);
  const format = (date: Date) => `${String(date.getUTCDate()).padStart(2, '0')}/${String(date.getUTCMonth() + 1).padStart(2, '0')}/${date.getUTCFullYear()}`;
  return { issue: format(issue), due: format(due) };
}

export default function BillingServiceDialog({ row, close, saved, notify }: { row?: Row; close: () => void; saved: () => void; notify: (message: string, error?: boolean) => void }) {
  const editing = Boolean(row?.id);
  const [values, setValues] = useState<FormValues>(() => {
    const today = new Date();
    const localDate = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
    return { clientId: String(row?.clientId || ''), planId: String(row?.planId || ''), billingStartOn: String(row?.billingStartOn || (editing ? '' : localDate)), graceDays: String(row?.graceDays ?? 3) };
  });
  const [client, setClient] = useState<Client | null>((row?.client as Client | undefined) || null), [plans, setPlans] = useState<Plan[]>([]);
  const [loading, setLoading] = useState(true), [busy, setBusy] = useState(false), [error, setError] = useState('');
  useEffect(() => {
    let active = true;
    const controller = new AbortController();
    const clientId = String(row?.clientId || '');
    Promise.all([choices<Plan>('/plans'), clientId && !row?.client ? api<Client>(`/clients/${encodeURIComponent(clientId)}`, { signal: controller.signal }) : Promise.resolve((row?.client as Client | undefined) || null)]).then(([planRows, selectedClient]) => {
      if (active) { setPlans(planRows); setClient(selectedClient); }
    }).catch(failure => { if (active) setError(errorMessage(failure)); }).finally(() => { if (active) setLoading(false); });
    return () => { active = false; controller.abort(); };
  }, []);
  const eligiblePlans = plans.filter(plan => plan.active && (!plan.profileImport || plan.profileImport.priceConfigured && plan.profileImport.rateStatus === 'READY'));
  const fields: FieldSpec[] = [
    { name: 'planId', label: 'Plan de Internet', type: 'select', required: true, full: true, options: eligiblePlans.map(plan => ({ value: plan.id, label: `${plan.name} · ${money(plan.priceCents, plan.currency)} al mes` })), hint: 'Se toma la tarifa del plan. Configura su precio y actívalo en Planes de Internet.' },
    { name: 'billingStartOn', label: 'Inicio de facturación', type: 'date', required: !editing || Boolean(row?.billingStartOn), full: true, hint: editing && !row?.billingStartOn ? 'Fecha de instalación. Si dejas este campo vacío, el servicio conserva su calendario anterior. Al elegir una fecha, el primer cobro será un mes después.' : 'Fecha de instalación. El primer cobro es un mes después, en el mismo día. Si un mes tiene menos días, se usa su último día.' },
    { name: 'graceDays', label: 'Días de gracia', type: 'number', required: true, min: 0, max: 90, step: '1', hint: 'Días adicionales después de la fecha de pago; el vencimiento mensual no cambia.' },
  ];
  const preview = firstCycle(String(values.billingStartOn || ''));
  const submit = async (event: FormEvent) => {
    event.preventDefault(); setBusy(true); setError('');
    try {
      if (!client || client.status === 'RETIRED') throw new Error('Busca y selecciona un cliente disponible antes de guardar.');
      if (!/^\d+$/.test(String(values.graceDays))) throw new Error('Los días de gracia deben expresarse como un número entero.');
      if (values.billingStartOn && !preview) throw new Error('Selecciona una fecha de instalación válida entre 2000 y 2100.');
      const payload = { planId: values.planId, graceDays: Number(values.graceDays), ...(values.billingStartOn ? { billingStartOn: values.billingStartOn } : {}) };
      if (editing) await patch(`/billing-services/${row!.id}`, payload);
      else await post('/billing-services', { clientId: client.id, ...payload });
      saved(); notify('Servicio de facturación guardado. Podrás emitir facturas según su calendario; el MikroTik permanece sin cambios.'); close();
    } catch (failure) { setError(errorMessage(failure)); }
    finally { setBusy(false); }
  };
  return <Modal title={`${editing ? 'Editar' : 'Nuevo'} servicio de facturación`} description="Vincula el cliente con su plan, fecha de instalación y días de gracia." close={close}>
    <div className="alert info">Se factura dos días antes de cada vencimiento. El primer cobro es un mes después de la instalación.</div>
    {loading ? <Loading label="Cargando datos del servicio…" /> : <>
      {error && <div className="alert error" role="alert">{error}</div>}
      {!eligiblePlans.length ? <div className="alert info">En Planes de Internet, configura la mensualidad y activa al menos un plan con velocidades válidas.</div> : <DynamicForm beforeFields={<ClientSearch selected={client} change={selected => { setClient(selected); setValues({ ...values, clientId: selected?.id || '' }); }} disabled={editing || busy} />} fields={fields} values={values} setValues={setValues} submit={event => void submit(event)} busy={busy} submitDisabled={!client || client.status === 'RETIRED'} submitLabel="Guardar servicio de facturación">{preview && <div className="alert info" role="status" aria-live="polite"><div><strong>Primer ciclo</strong><div>Emisión de factura: <strong>{preview.issue}</strong></div><div>Fecha de pago: <strong>{preview.due}</strong></div></div></div>}</DynamicForm>}
    </>}
  </Modal>;
}
