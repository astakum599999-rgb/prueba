import type { ClientIpAddress } from './types';

/** Only literal IP hosts are accepted; pool names, credentials and URLs are not. */
export function clientIpHost(address: string): string | null {
  if (/^(?:0|[1-9]\d{0,2})(?:\.(?:0|[1-9]\d{0,2})){3}$/.test(address)) {
    const parts = address.split('.').map(Number);
    if (parts.some(part => part > 255) || parts[0] === 0 || parts[0] === 127 || parts[0]! >= 224) return null;
    return address;
  }
  if (!address.includes(':') || !/^[a-f\d:.]+$/i.test(address)) return null;
  try {
    const host = new URL(`http://[${address}]/`).hostname;
    if (host === '[::]' || host === '[::1]' || /^\[ff/i.test(host)) return null;
    const mapped = /^\[::ffff:([a-f\d]{1,4}):([a-f\d]{1,4})\]$/i.exec(host);
    if (mapped) {
      const high = Number.parseInt(mapped[1]!, 16), low = Number.parseInt(mapped[2]!, 16);
      if (clientIpHost([high >> 8, high & 255, low >> 8, low & 255].join('.')) === null) return null;
    }
    return host;
  } catch { return null; }
}

export function clientIpUrl(address: string, protocol: string, port: string): string | null {
  const host = clientIpHost(address);
  if (!host || !['http', 'https'].includes(protocol) || !/^\d{1,5}$/.test(port) || Number(port) < 1 || Number(port) > 65535) return null;
  try {
    const url = new URL(`${protocol}://${host}:${Number(port)}/`);
    return url.href;
  } catch { return null; }
}

export interface ClientIpLiveState {
  loading?: boolean;
  error?: string;
  message?: string;
  observedAt?: string | null;
  stale?: boolean;
}

export function ClientIpAddresses({ addresses, clientName, activeAddresses, liveState }: { addresses: ClientIpAddress[] | undefined; clientName: string; clientId?: string; activeAddresses?: ClientIpAddress[]; liveState?: ClientIpLiveState }) {
  const entries = [...(!liveState?.stale && Array.isArray(activeAddresses) ? activeAddresses : []), ...(Array.isArray(addresses) ? addresses : [])];
  const seen = new Set<string>();
  const valid = entries.filter(entry => {
    if (!entry || typeof entry.address !== 'string' || clientIpHost(entry.address) === null) return false;
    const key = `${entry.routerId}:${entry.address}`;
    if (seen.has(key)) return false;
    seen.add(key); return true;
  });
  return valid.length ? <div className="client-ip-list">{valid.map(entry => <div className="client-ip-entry" key={`${entry.routerId}:${entry.address}`}><a className="text-link mono client-ip-button" href={clientIpUrl(entry.address, 'http', '80')!} target="_blank" rel="noopener noreferrer" referrerPolicy="no-referrer" aria-label={`Abrir router del cliente en ${entry.address} (${entry.routerName})`} title={`${clientName} · Abrir en una nueva pestaña`}>{entry.address}</a></div>)}</div> : <span className="subtle">Sin IP registrada</span>;
}
