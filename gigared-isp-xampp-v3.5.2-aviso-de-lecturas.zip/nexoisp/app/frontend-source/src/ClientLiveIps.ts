import { useEffect, useState } from 'react';
import { api } from './api';
import type { ClientIpAddress } from './types';
import type { ClientIpLiveState } from './ClientIpAccess';

interface ClientObservation {
  clientId: string;
  addresses: ClientIpAddress[];
  status: 'FRESH' | 'NO_SESSION' | 'NO_ACCOUNT' | 'PENDING' | 'STALE';
  stale: boolean;
  observedAt: string | null;
  message: string;
}
interface BatchObservation { intervalSeconds: number; expiresAfterSeconds: number; processed: number; serverTime?: string; results: ClientObservation[] }
export interface ClientLiveObservation { addresses: ClientIpAddress[]; state: ClientIpLiveState; expiresAt?: number; monotonicExpiresAt?: number }

/** One batch for the current page; router polling is shared by the PHP cache. */
export function useClientLiveIps(clientIds: string[], enabled: boolean): Record<string, ClientLiveObservation> {
  const key = enabled ? JSON.stringify([...new Set(clientIds)].sort()) : '[]';
  const [observations, setObservations] = useState<Record<string, ClientLiveObservation>>({});
  useEffect(() => {
    const ids = JSON.parse(key) as string[];
    setObservations({});
    if (!ids.length) return;
    let stopped = false;
    let timer: number | undefined;
    let pending: AbortController | undefined;
    let deadline: number | undefined;
    const isVisible = () => document.visibilityState !== 'hidden';
    // Expire a previously rendered session even if the next request stalls or
    // the browser temporarily suspends polling. Configured IPs remain labelled.
    const expire = () => setObservations(old => {
      let changed = false;
      const next = Object.fromEntries(Object.entries(old).map(([id, row]) => {
        if (row.addresses.length && (row.expiresAt !== undefined && row.expiresAt <= Date.now() || row.monotonicExpiresAt !== undefined && row.monotonicExpiresAt <= performance.now())) {
          changed = true;
          return [id, { addresses: [], state: { ...row.state, stale: true, message: 'La observación de IP de sesión caducó. Se actualizará automáticamente.' } }];
        }
        return [id, row];
      }));
      return changed ? next : old;
    });
    const expiry = window.setInterval(expire, 250);
    const tick = async () => {
      window.clearTimeout(timer);
      if (stopped || pending || !isVisible()) return;
      expire();
      const started = performance.now();
      const controller = new AbortController();
      pending = controller;
      let timedOut = false;
      const requestDeadline = window.setTimeout(() => { timedOut = true; controller.abort(); }, 90000);
      deadline = requestDeadline;
      setObservations(old => Object.fromEntries(ids.map(id => [id, { ...old[id], addresses: old[id]?.addresses || [], state: { ...old[id]?.state, loading: true } }])));
      try {
        const result = await api<BatchObservation>('/clients/ip-addresses/active', { method: 'POST', body: JSON.stringify({ clientIds: ids }), cache: 'no-store', signal: controller.signal });
        if (stopped || controller.signal.aborted || pending !== controller) return;
        if (!Array.isArray(result.results)) throw new Error('La respuesta de sesiones no es válida.');
        const byId = new Map(result.results.map(row => [row.clientId, row]));
        const wallNow = Date.now(), monotonicNow = performance.now();
        const requestAge = Math.max(0, monotonicNow - started);
        const maxAge = Number.isFinite(result.expiresAfterSeconds) ? Math.min(5, Math.max(0, result.expiresAfterSeconds)) * 1000 : 0;
        const serverTime = result.serverTime ? Date.parse(result.serverTime) : NaN;
        setObservations(Object.fromEntries(ids.map(id => {
          const row = byId.get(id);
          const observedAt = row?.observedAt ? Date.parse(row.observedAt) : NaN;
          // A held HTTP response cannot restore an IP that already exceeded its TTL.
          const age = serverTime - observedAt + requestAge;
          const fresh = Number.isFinite(age) && age >= 0 && age < maxAge;
          const requiresObservation = row?.status === 'FRESH' || row?.status === 'NO_SESSION';
          const stale = !row || row.stale || (requiresObservation && !fresh);
          const remaining = fresh ? maxAge - age : 0;
          return [id, { addresses: !stale && row?.status === 'FRESH' && Array.isArray(row.addresses) ? row.addresses : [], expiresAt: wallNow + remaining, monotonicExpiresAt: monotonicNow + remaining, state: { loading: false, stale, observedAt: row?.observedAt, message: row?.message || 'La IP de sesión está pendiente de actualizar.' } }];
        })));
      } catch {
        if (!stopped && isVisible() && pending === controller && (!controller.signal.aborted || timedOut)) setObservations(Object.fromEntries(ids.map(id => [id, { addresses: [], state: { loading: false, stale: true, error: 'No se pudo actualizar la IP de sesión. Se reintentará automáticamente.' } }])));
      } finally {
        window.clearTimeout(requestDeadline); deadline = undefined;
        if (pending === controller) pending = undefined;
        const delay = controller.signal.aborted && !timedOut ? 0 : Math.max(0, 1000 - (performance.now() - started));
        if (!stopped && isVisible()) timer = window.setTimeout(() => void tick(), delay);
      }
    };
    const visibility = () => { expire(); if (isVisible()) void tick(); else { window.clearTimeout(timer); pending?.abort(); } };
    document.addEventListener('visibilitychange', visibility);
    timer = window.setTimeout(() => void tick(), 0);
    return () => { stopped = true; window.clearInterval(expiry); window.clearTimeout(timer); window.clearTimeout(deadline); pending?.abort(); document.removeEventListener('visibilitychange', visibility); };
  }, [key]);
  return observations;
}
