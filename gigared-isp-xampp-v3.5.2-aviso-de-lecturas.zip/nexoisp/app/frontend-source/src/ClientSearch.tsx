import { useEffect, useId, useRef, useState, type KeyboardEvent } from 'react';
import { LoaderCircle, Search, X } from 'lucide-react';
import { api } from './api';
import type { Client, PageResult } from './types';
import { errorMessage } from './ui';

export default function ClientSearch({ selected, change, disabled = false }: { selected: Client | null; change: (client: Client | null) => void; disabled?: boolean }) {
  const inputId = useId(), listId = useId(), hintId = useId();
  const input = useRef<HTMLInputElement>(null), list = useRef<HTMLUListElement>(null);
  const [query, setQuery] = useState(selected?.name || '');
  const [rows, setRows] = useState<Client[]>([]), [count, setCount] = useState(0);
  const [open, setOpen] = useState(false), [loading, setLoading] = useState(false), [searched, setSearched] = useState(false);
  const [error, setError] = useState(''), [activeIndex, setActiveIndex] = useState(-1);

  useEffect(() => {
    if (selected) { setQuery(selected.name); setOpen(false); }
  }, [selected]);

  useEffect(() => {
    setRows([]); setCount(0); setError(''); setSearched(false); setActiveIndex(-1);
    const term = query.trim();
    if (disabled || selected || term.length < 2) { setLoading(false); return; }
    let current = true;
    const controller = new AbortController();
    setLoading(true);
    const timer = window.setTimeout(() => {
      api<PageResult<Client>>(`/clients?q=${encodeURIComponent(term)}&excludeRetired=true&page=1&pageSize=10`, { signal: controller.signal }).then(result => {
        if (!current) return;
        setRows(result.results.filter(client => client.status !== 'RETIRED').slice(0, 10));
        setCount(result.count); setSearched(true);
      }).catch(failure => {
        if (current && !controller.signal.aborted) { setError(errorMessage(failure)); setSearched(true); }
      }).finally(() => { if (current) setLoading(false); });
    }, 250);
    return () => { current = false; window.clearTimeout(timer); controller.abort(); };
  }, [query, selected, disabled]);

  useEffect(() => {
    if (open && activeIndex >= 0) list.current?.children[activeIndex]?.scrollIntoView({ block: 'nearest' });
  }, [activeIndex, open]);

  const choose = (client: Client) => { change(client); setQuery(client.name); setOpen(false); setActiveIndex(-1); };
  const keyDown = (event: KeyboardEvent<HTMLInputElement>) => {
    if (event.key === 'Escape' && open) { event.preventDefault(); event.stopPropagation(); setOpen(false); return; }
    if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
      event.preventDefault();
      if (!selected && query.trim().length >= 2) {
        setOpen(true);
        if (rows.length) setActiveIndex(index => event.key === 'ArrowDown' ? (index + 1) % rows.length : (index <= 0 ? rows.length - 1 : index - 1));
      }
    }
    if (event.key === 'Enter' && !selected) {
      event.preventDefault();
      if (open && activeIndex >= 0 && rows[activeIndex]) choose(rows[activeIndex]);
    }
  };
  const visible = open && !selected && query.trim().length >= 2 && !disabled;
  return <div className="field full client-search" onBlur={event => { if (!event.currentTarget.contains(event.relatedTarget as Node | null)) setOpen(false); }}>
    <label className="field-label" htmlFor={inputId}>Cliente<span aria-hidden="true"> *</span></label>
    <div className="client-search-input">
      <Search size={16} aria-hidden="true" />
      <input ref={input} id={inputId} role="combobox" aria-autocomplete="list" aria-expanded={visible && rows.length > 0} aria-controls={listId} aria-activedescendant={visible && activeIndex >= 0 ? `${listId}-${activeIndex}` : undefined} aria-describedby={hintId} type="text" autoComplete="off" placeholder="Escribe nombre, código o documento…" value={query} disabled={disabled} required maxLength={200} onFocus={() => { if (!selected && query.trim().length >= 2) setOpen(true); }} onChange={event => { if (selected) change(null); setQuery(event.target.value); setRows([]); setActiveIndex(-1); setSearched(false); setError(''); setOpen(true); }} onKeyDown={keyDown} />
      {selected && !disabled && <button type="button" className="icon-button" aria-label="Quitar cliente seleccionado" onClick={() => { change(null); setQuery(''); setOpen(false); input.current?.focus(); }}><X size={16} /></button>}
    </div>
    {selected ? <span id={hintId} className="client-search-selected">{selected.code}{selected.document ? ` · ${selected.document}` : ''}<span>Cliente seleccionado</span></span> : <span id={hintId} className="field-hint">Escribe al menos 2 caracteres y selecciona un resultado. Puedes buscar por nombre, código, documento o correo.</span>}
    {visible && <div className="client-search-results">
      {loading ? <div className="client-search-status" role="status"><LoaderCircle size={15} className="spinner" />Buscando clientes…</div> : error ? <div className="client-search-status error" role="alert">{error}</div> : searched && !rows.length ? <div className="client-search-status" role="status">No se encontraron clientes disponibles. Prueba con otro nombre o código.</div> : null}
      {!!rows.length && <ul ref={list} id={listId} role="listbox" aria-label="Clientes encontrados">{rows.map((client, index) => <li key={client.id} id={`${listId}-${index}`} role="option" aria-selected={index === activeIndex} className={`client-search-option ${index === activeIndex ? 'active' : ''}`} onMouseDown={event => event.preventDefault()} onMouseEnter={() => setActiveIndex(index)} onClick={() => choose(client)}><span>{client.name}</span><small>{client.code}{client.document ? ` · ${client.document}` : ''}</small></li>)}</ul>}
      {!loading && !error && count > 10 && <div className="client-search-status" role="status">Hay más coincidencias. Escribe más datos para afinar la búsqueda.</div>}
    </div>}
  </div>;
}
