import { useEffect, useState } from 'react';
import { api } from './api';
import type { DashboardOnlineSnapshot } from './types';

interface Observation {
  snapshot: DashboardOnlineSnapshot | null;
  wallDeadline: number;
  monotonicDeadline: number;
}

const emptyObservation = (): Observation => ({ snapshot: null, wallDeadline: 0, monotonicDeadline: 0 });
const visible = () => document.visibilityState !== 'hidden';
const expired = (observation: Observation) => observation.snapshot?.status === 'FRESH' && (Date.now() >= observation.wallDeadline || performance.now() >= observation.monotonicDeadline);
const invalidate = (observation: Observation): Observation => ({ ...observation, snapshot: observation.snapshot ? { ...observation.snapshot, count: null, status: 'STALE', stale: true } : null, wallDeadline: 0, monotonicDeadline: 0 });

function observationFrom(snapshot: DashboardOnlineSnapshot, requestAge: number): Observation {
  const wallNow = Date.now(), monotonicNow = performance.now();
  const observedAt = snapshot.observedAt ? Date.parse(snapshot.observedAt) : NaN;
  const serverTime = Date.parse(snapshot.serverTime);
  const maxAge = Number.isFinite(snapshot.expiresAfterSeconds) ? Math.min(5, Math.max(0, snapshot.expiresAfterSeconds)) * 1000 : 0;
  // Include the request duration: a delayed HTTP response must not revive an old count.
  const age = serverTime - observedAt + Math.max(0, requestAge);
  const valid = snapshot.status === 'FRESH' && snapshot.stale !== true && Number.isSafeInteger(snapshot.count) && Number(snapshot.count) >= 0 && snapshot.totalRouters > 0 && snapshot.coveredRouters === snapshot.totalRouters && Number.isFinite(age) && age >= 0 && age < maxAge;
  if (snapshot.status === 'FRESH' && !valid) return { snapshot: { ...snapshot, status: 'STALE', stale: true, count: null }, wallDeadline: 0, monotonicDeadline: 0 };
  return { snapshot: valid ? snapshot : { ...snapshot, count: null }, wallDeadline: valid ? wallNow + maxAge - age : 0, monotonicDeadline: valid ? monotonicNow + maxAge - age : 0 };
}

/** Count observations expire independently of polling, including a stalled router request. */
export function useDashboardOnline(enabled: boolean) {
  const [observation, setObservation] = useState<Observation>(emptyObservation);
  const [failed, setFailed] = useState(false);
  useEffect(() => {
    setObservation(emptyObservation()); setFailed(false);
    if (!enabled) return;
    let stopped = false;
    let pending: AbortController | undefined;
    let timer: number | undefined, deadline: number | undefined;
    const expire = () => setObservation(old => expired(old) ? invalidate(old) : old);
    const expiry = window.setInterval(expire, 250);
    const tick = async () => {
      window.clearTimeout(timer);
      if (stopped || pending || !visible()) return;
      expire();
      const started = performance.now();
      const controller = new AbortController();
      pending = controller;
      let timedOut = false;
      const requestDeadline = window.setTimeout(() => { timedOut = true; controller.abort(); }, 90000);
      deadline = requestDeadline;
      try {
        const snapshot = await api<DashboardOnlineSnapshot>('/dashboard/pppoe-online', { method: 'POST', body: '{}', cache: 'no-store', signal: controller.signal });
        if (stopped || controller.signal.aborted || pending !== controller) return;
        setObservation(observationFrom(snapshot, performance.now() - started)); setFailed(false);
      } catch {
        if (!stopped && visible() && pending === controller && (!controller.signal.aborted || timedOut)) { setObservation(invalidate); setFailed(true); }
      } finally {
        window.clearTimeout(requestDeadline);
        deadline = undefined;
        if (pending === controller) pending = undefined;
        // Keep a one-second start-to-start cadence, without overlapping requests.
        const delay = controller.signal.aborted && !timedOut ? 0 : Math.max(0, 1000 - (performance.now() - started));
        if (!stopped && visible()) timer = window.setTimeout(() => void tick(), delay);
      }
    };
    const visibility = () => {
      expire();
      if (visible()) void tick();
      else { window.clearTimeout(timer); pending?.abort(); }
    };
    document.addEventListener('visibilitychange', visibility);
    timer = window.setTimeout(() => void tick(), 0);
    return () => { stopped = true; window.clearInterval(expiry); window.clearTimeout(timer); window.clearTimeout(deadline); pending?.abort(); document.removeEventListener('visibilitychange', visibility); };
  }, [enabled]);

  const snapshot = observation.snapshot;
  const fresh = enabled && snapshot?.status === 'FRESH' && !expired(observation);
  const count = fresh ? snapshot.count : null;
  let hint = 'Consultando MikroTik…';
  if (!enabled) hint = 'Consulta de sesiones no disponible';
  else if (fresh) hint = 'Sesiones PPPoE activas';
  else if (failed || snapshot?.status === 'STALE' || expired(observation)) hint = 'Sin lectura reciente';
  else if (snapshot?.status === 'EMPTY') hint = 'Sin routers MikroTik';
  else if (snapshot?.status === 'PARTIAL') hint = `Lectura parcial · ${snapshot.coveredRouters} de ${snapshot.totalRouters} routers`;
  return { count, fresh, hint, status: fresh ? 'FRESH' : failed || expired(observation) ? 'STALE' : snapshot?.status || 'PENDING' };
}
