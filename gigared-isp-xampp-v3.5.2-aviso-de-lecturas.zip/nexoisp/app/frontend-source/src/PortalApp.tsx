import { useCallback, useEffect, useState, type FormEvent, type ReactNode } from 'react';
import { ArrowRight, CheckCircle2, CreditCard, FileText, Home, LifeBuoy, LogOut, Moon, Network, RefreshCw, Send, Sun, Wallet, Wifi } from 'lucide-react';
import { api, post } from './api';
import { Badge, date, EmptyState, errorMessage, Loading, Modal, money, Pagination, text } from './ui';
import type { PageResult } from './types';
import { setDefaultCurrency } from './currency';

interface PortalClient { id: string; code: string; name: string; email?: string | null; phone?: string | null; document?: string | null; address?: string | null; zone?: string | null; status: string }
interface PortalSession { client: PortalClient; account: { id: string; username: string }; capabilities?: { browserWorker: boolean; version?: string; defaultCurrency?: string } }
interface PortalService { id: string; type: string | null; ipAddress: string | null; billingOnly?: boolean; desiredState: string; appliedState?: string | null; syncStatus: string; createdAt: string; plan: { id: string; name: string; downloadKbps: number; uploadKbps: number; priceCents: number; currency: string } }
interface PortalPayment { id: string; invoiceId: string; amountCents: number; provider: string; externalReference: string; receivedAt: string; invoice?: PortalInvoice }
interface PortalInvoice { id: string; number: string; period: string; amountCents: number; paidCents: number; currency: string; status: string; issuedAt: string; dueAt: string; graceUntil: string; service?: PortalService; lines?: { id: string; description: string; quantity: number; unitCents: number; totalCents: number; currency: string }[]; payments?: PortalPayment[] }
interface PortalComment { id: string; authorName: string; body: string; createdAt: string }
interface PortalTicket { id: string; subject: string; body: string; priority: string; status: string; createdAt: string; updatedAt: string; comments?: PortalComment[] }
interface PortalContract { id: string; title: string; terms: string; clientName: string; document?: string | null; address?: string | null; planName: string; serviceType: string; ipAddress: string; priceCents: number; currency: string; status: string; acceptedName?: string | null; acceptedAt?: string | null; createdAt: string }
interface PortalReport { id: string; invoiceId: string; amountCents: number; currency: string; reference: string; note?: string | null; status: string; rejectionReason?: string | null; createdAt: string }
interface PortalSummary { client: PortalClient; services: PortalService[]; stats: { openInvoices: number; outstanding: { currency: string; amountCents: number }[]; openTickets: number }; invoices: PortalInvoice[]; tickets: PortalTicket[]; contracts: PortalContract[] }
type PortalPage = 'home' | 'invoices' | 'payments' | 'tickets' | 'contracts' | 'payment-reports';
type PortalDialog = { kind: 'invoice'; id: string } | { kind: 'ticket'; id: string } | { kind: 'contract'; id: string } | { kind: 'new-ticket' } | { kind: 'report'; invoice?: PortalInvoice };

const portalPages: { id: PortalPage; title: string; icon: typeof Home }[] = [
  { id: 'home', title: 'Mi cuenta', icon: Home }, { id: 'invoices', title: 'Mis facturas', icon: FileText },
  { id: 'payments', title: 'Mis pagos', icon: Wallet }, { id: 'tickets', title: 'Soporte', icon: LifeBuoy },
  { id: 'contracts', title: 'Contratos', icon: FileText }, { id: 'payment-reports', title: 'Pagos informados', icon: CreditCard },
];
const statusLabels: Record<string, string> = { SUBMITTED: 'En revisión', APPROVED: 'Aprobado', REJECTED: 'Rechazado', DRAFT: 'Pendiente de aceptación', ACCEPTED: 'Aceptado', CANCELLED: 'Cancelado' };
const portalStyles = [
  '.portal-page{min-height:100vh;background:var(--canvas);color:var(--text)}',
  '.portal-header{border-bottom:1px solid var(--line);background:var(--surface)}',
  '.portal-header-inner,.portal-main,.portal-nav{width:min(1180px,100%);margin:auto;padding:20px 24px}',
  '.portal-header-inner{display:flex;justify-content:space-between;align-items:center;gap:16px;flex-wrap:wrap}',
  '.portal-brand{display:flex;align-items:center;gap:10px;font-size:20px;font-weight:750;letter-spacing:-.7px}',
  '.portal-brand small{display:block;font-size:10px;font-weight:500;letter-spacing:.15em;color:var(--muted);margin-top:3px}',
  '.portal-account{display:flex;align-items:center;gap:12px;font-size:12px;min-width:0}.portal-account-name{max-width:230px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
  '.portal-nav{display:flex;align-items:center;gap:6px;overflow:auto;padding-top:0;padding-bottom:14px}',
  '.portal-nav button{display:flex;align-items:center;gap:8px;white-space:nowrap;border:0;border-radius:8px;background:transparent;color:var(--muted);padding:10px 13px;font-size:12px}',
  '.portal-nav button[aria-current=page]{color:var(--accent);background:var(--accent-soft);font-weight:650}',
  '.portal-main{padding-top:30px;padding-bottom:60px;min-width:0}.portal-heading{display:flex;justify-content:space-between;align-items:flex-start;gap:14px;margin-bottom:25px;flex-wrap:wrap}.portal-heading h1{font-size:26px;letter-spacing:-.8px;margin-bottom:7px}',
  '.portal-actions{display:flex;gap:9px;align-items:center;flex-wrap:wrap}.portal-stack{display:grid;gap:18px}',
  '.portal-hero{padding:28px;border-radius:16px;background:linear-gradient(120deg,#10384c,#0c6673);color:#f1fcff;display:flex;justify-content:space-between;align-items:center;gap:22px;flex-wrap:wrap}.portal-hero h2{font-size:24px;margin:0 0 9px}.portal-hero p{color:#bddce6;max-width:650px;line-height:1.6;font-size:13px;margin:0}.portal-hero small{display:block;color:#a3d9df;margin-bottom:9px}',
  '.portal-cards{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:16px}.portal-card{padding:23px;background:var(--surface);border:1px solid var(--line);border-radius:13px;min-width:0}.portal-card h3{font-size:12px;color:var(--muted);font-weight:550;margin:0 0 12px;display:flex;gap:8px;align-items:center}.portal-amount{font-size:25px;font-weight:700;letter-spacing:-.8px}.portal-card small{color:var(--muted);font-size:11px}',
  '.portal-two{display:grid;grid-template-columns:1.2fr 1fr;gap:18px}.portal-panel-title{padding:20px 22px;border-bottom:1px solid var(--line);display:flex;justify-content:space-between;align-items:center;gap:12px}.portal-panel-title h2{font-size:15px;margin:0}',
  '.portal-service{padding:20px 22px;border-bottom:1px solid var(--line)}.portal-service:last-child{border-bottom:0}.portal-service-top{display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:12px}.portal-service p{font-size:12px;color:var(--muted);line-height:1.8;margin:0}.portal-service strong{font-size:14px}',
  '.portal-detail-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:18px;margin:18px 0}.portal-detail-grid dt{font-size:11px;color:var(--muted);margin-bottom:5px}.portal-detail-grid dd{margin:0;font-size:13px;overflow-wrap:anywhere}',
  '.portal-body-text{white-space:pre-wrap;overflow-wrap:anywhere;font-size:13px;line-height:1.8}.portal-table-message{padding:25px;color:var(--muted);font-size:13px}',
  '.portal-comment{padding:14px 16px;border:1px solid var(--line);background:var(--surface-raised);border-radius:10px;margin:10px 0}.portal-comment header{display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap;font-size:11px;margin-bottom:8px}.portal-comment header time{color:var(--muted)}',
  '.portal-form{display:grid;gap:17px}.portal-form label{display:grid;gap:7px;font-size:12px;font-weight:550}.portal-form textarea{min-height:110px;resize:vertical}.portal-form input,.portal-form select,.portal-form textarea{width:100%;min-width:0;background:var(--surface-raised);color:var(--text);border:1px solid var(--line);border-radius:8px;padding:11px 12px;font:inherit}.portal-form .portal-check{display:flex;gap:9px;align-items:flex-start;line-height:1.6}.portal-check input{width:18px;flex-shrink:0;margin-top:3px}',
  '.portal-notice{position:fixed;bottom:24px;right:24px;z-index:150;max-width:min(420px,calc(100vw - 40px));padding:14px 18px;background:var(--surface);border:1px solid var(--line);box-shadow:0 8px 40px #0002;border-radius:12px;display:flex;align-items:center;gap:12px;font-size:13px}',
  '.portal-login{min-height:100vh;display:grid;place-items:center;padding:30px 20px;background:radial-gradient(ellipse at top,#124b60 0%,var(--canvas) 65%)}.portal-login-card{width:min(440px,100%);padding:32px;border:1px solid var(--line);background:var(--surface);border-radius:18px;box-shadow:0 18px 80px #0002}.portal-login-card h1{font-size:26px;letter-spacing:-.9px;margin-top:30px;margin-bottom:8px}.portal-login-card p{color:var(--muted);font-size:12px;line-height:1.7}.portal-login-card .button{justify-content:center;min-height:45px}',
  '.portal-footer{text-align:center;font-size:11px;color:var(--muted);padding:24px;border-top:1px solid var(--line)}',
  '@media(max-width:700px){.portal-header-inner,.portal-main,.portal-nav{padding-left:16px;padding-right:16px}.portal-cards,.portal-two{grid-template-columns:1fr}.portal-main{padding-top:22px}.portal-hero{padding:22px}.portal-hero h2{font-size:22px}.portal-account-name{display:none}.portal-detail-grid{grid-template-columns:1fr}.portal-heading h1{font-size:23px}.portal-login-card{padding:25px}.portal-nav{max-width:100vw}.portal-cards{gap:10px}.portal-card{padding:20px}.portal-notice{right:16px;bottom:16px}}',
].join('\n');

function portalRoute(): PortalPage {
  const candidate = window.location.hash.replace(/^#\/?/, '');
  return portalPages.some(page => page.id === candidate) ? candidate as PortalPage : 'home';
}
function initialPortalTheme(): 'light' | 'dark' {
  try { const value = localStorage.getItem('nexoisp-portal-theme'); if (value === 'light' || value === 'dark') return value; } catch { /* Theme storage is optional. */ }
  return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
}
function documentUrl(type: 'invoice' | 'receipt' | 'contract', id: string): string {
  const url = new URL('documento.php', window.location.href);
  url.searchParams.set('type', type); url.searchParams.set('id', id); url.hash = '';
  return url.pathname + url.search;
}
function PortalStatus({ status }: { status: string }) { return <Badge value={status}>{statusLabels[status]}</Badge>; }
function ErrorBox({ message, retry }: { message: string; retry?: () => void }) { return <div className="alert error" role="alert"><span>{message}</span>{retry && <button className="button small" onClick={retry}>Reintentar</button>}</div>; }
function usePortalData<T>(path: string | null, refresh = 0) {
  const [data, setData] = useState<T | null>(null), [loading, setLoading] = useState(Boolean(path)), [error, setError] = useState('');
  const [retry, setRetry] = useState(0);
  useEffect(() => {
    let active = true;
    setData(null); setError('');
    if (!path) { setLoading(false); return () => { active = false; }; }
    setLoading(true);
    api<T>('/portal' + path).then(value => { if (active) setData(value); }).catch(err => { if (active) setError(errorMessage(err)); }).finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [path, refresh, retry]);
  return { data, loading, error, retry: () => setRetry(value => value + 1) };
}
function PrintLink({ type, id, children = 'Imprimir / guardar PDF' }: { type: 'invoice' | 'receipt' | 'contract'; id: string; children?: ReactNode }) {
  return <a className="button small" href={documentUrl(type, id)} target="_blank" rel="noopener noreferrer"><FileText size={15} />{children}</a>;
}
function Login({ theme, toggleTheme, authenticated }: { theme: string; toggleTheme: () => void; authenticated: (session: PortalSession) => void }) {
  const [username, setUsername] = useState(''), [password, setPassword] = useState(''), [busy, setBusy] = useState(false), [error, setError] = useState('');
  const submit = async (event: FormEvent) => {
    event.preventDefault(); setBusy(true); setError('');
    try { const session = await post<PortalSession>('/portal/auth/login', { username: username.trim(), password }); setPassword(''); setDefaultCurrency(session.capabilities?.defaultCurrency); authenticated(session); }
    catch (err) { setError(errorMessage(err)); } finally { setBusy(false); }
  };
  return <main className="portal-login"><section className="portal-login-card"><div className="portal-heading" style={{ marginBottom: 0 }}><div className="portal-brand"><div className="brand-mark"><Network size={23} /></div><span>GIGARED ISP<small>PORTAL DEL CLIENTE</small></span></div><button className="icon-button" aria-label={theme === 'dark' ? 'Activar tema claro' : 'Activar tema oscuro'} onClick={toggleTheme}>{theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}</button></div><h1>Tu conexión, más cerca</h1><p>Consulta tus facturas, informa un pago y recibe ayuda con tu servicio.</p><form className="portal-form" onSubmit={event => void submit(event)}>{error && <ErrorBox message={error} />}<label>Usuario<input aria-label="Usuario del portal" autoComplete="username" required maxLength={100} value={username} onChange={event => setUsername(event.target.value)} disabled={busy} /></label><label>Contraseña<input aria-label="Contraseña del portal" autoComplete="current-password" type="password" required maxLength={128} value={password} onChange={event => setPassword(event.target.value)} disabled={busy} /></label><button className="button primary" type="submit" disabled={busy}>{busy ? 'Verificando acceso…' : 'Entrar a mi cuenta'}<ArrowRight size={17} /></button></form><p style={{ marginTop: 24, marginBottom: 0 }}>Tu proveedor de Internet administra el usuario y la contraseña de este portal. Contáctalo si necesitas recuperar tu acceso.</p></section></main>;
}

function HomePage({ refresh, go, open }: { refresh: number; go: (page: PortalPage) => void; open: (dialog: PortalDialog) => void }) {
  const query = usePortalData<PortalSummary>('/summary', refresh);
  if (query.loading) return <Loading label="Consultando tu cuenta…" />;
  if (query.error) return <ErrorBox message={query.error} retry={query.retry} />;
  if (!query.data) return null;
  const data = query.data;
  return <div className="portal-stack"><section className="portal-hero"><div><small>BIENVENIDO A TU PORTAL</small><h2>Hola, {data.client.name.split(' ')[0]}</h2><p>Aquí tienes el estado de tus servicios y los movimientos de tu cuenta.</p></div><button className="button" style={{ color: '#113843', background: '#daf8f4', borderColor: 'transparent' }} onClick={() => open({ kind: 'new-ticket' })}><LifeBuoy size={17} />Necesito ayuda</button></section><section className="portal-cards"><div className="portal-card"><h3><Wallet size={17} />Saldo pendiente</h3>{data.stats.outstanding.length ? data.stats.outstanding.map(balance => <div className="portal-amount" key={balance.currency}>{money(balance.amountCents, balance.currency)}</div>) : <div className="portal-amount">Sin saldo pendiente</div>}<small>Importes separados por moneda.</small></div><div className="portal-card"><h3><FileText size={17} />Facturas por pagar</h3><div className="portal-amount">{data.stats.openInvoices}</div><button className="button small ghost" style={{ marginTop: 8 }} onClick={() => go('invoices')}>Ver mis facturas<ArrowRight size={14} /></button></div><div className="portal-card"><h3><LifeBuoy size={17} />Solicitudes abiertas</h3><div className="portal-amount">{data.stats.openTickets}</div><button className="button small ghost" style={{ marginTop: 8 }} onClick={() => go('tickets')}>Consultar soporte<ArrowRight size={14} /></button></div></section><div className="portal-two"><section className="panel"><header className="portal-panel-title"><h2>Mis servicios</h2><Wifi size={18} /></header>{data.services.length ? data.services.map(service => <article className="portal-service" key={service.id}><div className="portal-service-top"><strong>{service.plan.name}</strong>{service.appliedState ? <PortalStatus status={service.appliedState} /> : <Badge value="PENDING">Activación pendiente</Badge>}</div><p>{service.plan.downloadKbps / 1000} Mbps de descarga · {service.plan.uploadKbps / 1000} Mbps de subida<br />Mensualidad: {money(service.plan.priceCents, service.plan.currency)}<br />IP asignada: {service.billingOnly ? 'Solo facturación' : service.ipAddress}</p>{service.desiredState !== service.appliedState && <p style={{ marginTop: 9 }}>Hay un cambio de servicio pendiente de confirmación.</p>}</article>) : <EmptyState title="Aún no hay servicios asociados" description="Tu proveedor puede ayudarte a revisar el alta de tu conexión." />}</section><section className="panel"><header className="portal-panel-title"><h2>Datos de mi cuenta</h2><PortalStatus status={data.client.status} /></header><div style={{ padding: '4px 22px 20px' }}><dl className="portal-detail-grid">{[['Titular', data.client.name], ['Código de cliente', data.client.code], ['Documento', data.client.document], ['Correo', data.client.email], ['Teléfono', data.client.phone], ['Dirección', data.client.address]].map(([label, value]) => <div key={label}><dt>{label}</dt><dd>{text(value)}</dd></div>)}</dl><p className="subtle">Para actualizar tus datos, envía una solicitud a soporte.</p></div></section></div><section className="panel"><header className="portal-panel-title"><h2>Facturas recientes</h2><button className="button small ghost" onClick={() => go('invoices')}>Ver todas<ArrowRight size={14} /></button></header>{data.invoices.length ? <InvoiceTable rows={data.invoices} open={open} /> : <EmptyState title="Sin facturas emitidas" description="Tus facturas aparecerán aquí cuando se generen." />}</section></div>;
}

function InvoiceTable({ rows, open }: { rows: PortalInvoice[]; open: (dialog: PortalDialog) => void }) {
  return <div className="table-wrap"><table className="data-table"><thead><tr><th>Factura</th><th>Vencimiento</th><th>Total</th><th>Pendiente</th><th>Estado</th><th>Acciones</th></tr></thead><tbody>{rows.map(invoice => <tr key={invoice.id}><td><strong>{invoice.number}</strong><div className="subtle">Periodo {invoice.period}</div></td><td>{date(invoice.dueAt)}</td><td>{money(invoice.amountCents, invoice.currency)}</td><td>{money(Math.max(0, invoice.amountCents - invoice.paidCents), invoice.currency)}</td><td><PortalStatus status={invoice.status} /></td><td><div className="portal-actions"><button className="button small" onClick={() => open({ kind: 'invoice', id: invoice.id })}>Ver factura</button>{invoice.status === 'OPEN' && <button className="button small" onClick={() => open({ kind: 'report', invoice })}>Informar pago</button>}</div></td></tr>)}</tbody></table></div>;
}
function ListPage({ page, refresh, open }: { page: Exclude<PortalPage, 'home'>; refresh: number; open: (dialog: PortalDialog) => void }) {
  const [number, setNumber] = useState(1), [status, setStatus] = useState('');
  const params = new URLSearchParams({ page: String(number), pageSize: '15', ...(status ? { status } : {}) });
  const query = usePortalData<PageResult<PortalInvoice | PortalPayment | PortalTicket | PortalContract | PortalReport>>('/' + page + '?' + params, refresh);
  const filters: Record<string, string[]> = { invoices: ['OPEN', 'PAID', 'VOID'], tickets: ['OPEN', 'IN_PROGRESS', 'RESOLVED', 'CLOSED'], contracts: ['DRAFT', 'ACCEPTED', 'CANCELLED'], 'payment-reports': ['SUBMITTED', 'APPROVED', 'REJECTED'] };
  const names: Record<string, string> = { OPEN: 'Abierto', PAID: 'Pagada', VOID: 'Anulada', IN_PROGRESS: 'En atención', RESOLVED: 'Resuelto', CLOSED: 'Cerrado', ...statusLabels };
  let content: ReactNode = null;
  const rows = query.data?.results ?? [];
  if (page === 'invoices') content = <InvoiceTable rows={rows as PortalInvoice[]} open={open} />;
  if (page === 'payments') content = <div className="table-wrap"><table className="data-table"><thead><tr><th>Fecha</th><th>Factura</th><th>Importe</th><th>Referencia</th><th>Comprobante</th></tr></thead><tbody>{(rows as PortalPayment[]).map(payment => <tr key={payment.id}><td>{date(payment.receivedAt, true)}</td><td>{payment.invoice?.number ?? payment.invoiceId}</td><td>{payment.invoice?.currency ? money(payment.amountCents, payment.invoice.currency) : `${(payment.amountCents / 100).toFixed(2)} · moneda no informada`}</td><td>{payment.externalReference}</td><td><PrintLink type="receipt" id={payment.id}>Ver recibo</PrintLink></td></tr>)}</tbody></table></div>;
  if (page === 'tickets') content = <div className="table-wrap"><table className="data-table"><thead><tr><th>Solicitud</th><th>Prioridad</th><th>Estado</th><th>Última actualización</th><th>Seguimiento</th></tr></thead><tbody>{(rows as PortalTicket[]).map(ticket => <tr key={ticket.id}><td><strong>{ticket.subject}</strong></td><td><Badge value={ticket.priority} /></td><td><PortalStatus status={ticket.status} /></td><td>{date(ticket.updatedAt, true)}</td><td><button className="button small" onClick={() => open({ kind: 'ticket', id: ticket.id })}>Ver conversación</button></td></tr>)}</tbody></table></div>;
  if (page === 'contracts') content = <div className="table-wrap"><table className="data-table"><thead><tr><th>Documento</th><th>Plan</th><th>Estado</th><th>Fecha</th><th>Acciones</th></tr></thead><tbody>{(rows as PortalContract[]).map(contract => <tr key={contract.id}><td><strong>{contract.title}</strong></td><td>{contract.planName}</td><td><PortalStatus status={contract.status} /></td><td>{date(contract.acceptedAt ?? contract.createdAt)}</td><td><button className="button small" onClick={() => open({ kind: 'contract', id: contract.id })}>{contract.status === 'DRAFT' ? 'Leer y aceptar' : 'Ver documento'}</button></td></tr>)}</tbody></table></div>;
  if (page === 'payment-reports') content = <div className="table-wrap"><table className="data-table"><thead><tr><th>Enviado</th><th>Referencia</th><th>Importe informado</th><th>Estado</th><th>Observación</th></tr></thead><tbody>{(rows as PortalReport[]).map(report => <tr key={report.id}><td>{date(report.createdAt, true)}</td><td>{report.reference}</td><td>{money(report.amountCents, report.currency)}</td><td><PortalStatus status={report.status} /></td><td>{text(report.rejectionReason ?? report.note)}</td></tr>)}</tbody></table></div>;
  return <div className="portal-stack">{page === 'payment-reports' && <div className="alert info">Informar un pago permite que tu proveedor lo revise. El saldo y la reconexión se actualizan cuando se confirma el cobro.</div>}<section className="panel"><header className="portal-panel-title"><h2>{portalPages.find(item => item.id === page)?.title}</h2><div className="portal-actions">{filters[page] && <select aria-label="Filtrar por estado" value={status} onChange={event => { setStatus(event.target.value); setNumber(1); }}><option value="">Todos los estados</option>{filters[page]?.map(item => <option key={item} value={item}>{names[item]}</option>)}</select>}<button className="icon-button" aria-label="Actualizar listado" onClick={query.retry}><RefreshCw size={17} /></button></div></header>{query.error ? <ErrorBox message={query.error} retry={query.retry} /> : query.loading ? <Loading /> : rows.length ? <>{content}<Pagination page={number} pageSize={15} count={query.data?.count ?? 0} change={setNumber} /></> : <EmptyState title="No hay registros para mostrar" description={status ? 'Prueba con otro estado.' : 'Los movimientos de tu cuenta aparecerán aquí.'} action={page === 'tickets' ? <button className="button" onClick={() => open({ kind: 'new-ticket' })}>Crear una solicitud</button> : undefined} />}</section></div>;
}

function NewTicket({ close, saved }: { close: () => void; saved: (message: string) => void }) {
  const [subject, setSubject] = useState(''), [body, setBody] = useState(''), [priority, setPriority] = useState('NORMAL'), [busy, setBusy] = useState(false), [error, setError] = useState('');
  const submit = async (event: FormEvent) => {
    event.preventDefault(); setError(''); setBusy(true);
    try { await post('/portal/tickets', { subject: subject.trim(), body: body.trim(), priority }); saved('Tu solicitud fue enviada a soporte.'); close(); }
    catch (err) { setError(errorMessage(err)); } finally { setBusy(false); }
  };
  return <Modal title="Solicitar ayuda" description="Describe lo que sucede para que tu proveedor pueda ayudarte." close={close}><form className="portal-form" onSubmit={event => void submit(event)}>{error && <ErrorBox message={error} />}<label>Asunto<input aria-label="Asunto" required maxLength={200} value={subject} onChange={event => setSubject(event.target.value)} disabled={busy} /></label><label>Descripción<textarea aria-label="Descripción de la solicitud" required maxLength={20000} value={body} onChange={event => setBody(event.target.value)} disabled={busy} /></label><label>Prioridad<select aria-label="Prioridad" value={priority} onChange={event => setPriority(event.target.value)} disabled={busy}><option value="LOW">Baja</option><option value="NORMAL">Normal</option><option value="HIGH">Alta</option><option value="URGENT">Urgente</option></select></label><button className="button primary" type="submit" disabled={busy || !subject.trim() || !body.trim()}><Send size={16} />{busy ? 'Enviando…' : 'Enviar solicitud'}</button></form></Modal>;
}
function TicketDetail({ id, close, saved }: { id: string; close: () => void; saved: (message: string) => void }) {
  const [refresh, setRefresh] = useState(0), [reply, setReply] = useState(''), [busy, setBusy] = useState(false), [error, setError] = useState('');
  const query = usePortalData<PortalTicket>('/tickets/' + encodeURIComponent(id), refresh);
  const submit = async (event: FormEvent) => {
    event.preventDefault(); setError(''); setBusy(true);
    try { await post('/portal/tickets/' + encodeURIComponent(id) + '/comments', { body: reply.trim() }); setReply(''); setRefresh(value => value + 1); saved('Tu respuesta fue enviada.'); }
    catch (err) { setError(errorMessage(err)); } finally { setBusy(false); }
  };
  const ticket = query.data;
  return <Modal title={ticket?.subject ?? 'Detalle de la solicitud'} close={close} wide>{query.loading ? <Loading /> : query.error ? <ErrorBox message={query.error} retry={query.retry} /> : ticket && <><div className="portal-actions"><PortalStatus status={ticket.status} /><Badge value={ticket.priority} /><span className="subtle">Creado {date(ticket.createdAt, true)}</span></div><p className="portal-body-text" style={{ marginTop: 20 }}>{ticket.body}</p><h3 style={{ fontSize: 14 }}>Conversación</h3>{ticket.comments?.length ? ticket.comments.map(comment => <article className="portal-comment" key={comment.id}><header><strong>{comment.authorName}</strong><time>{date(comment.createdAt, true)}</time></header><div className="portal-body-text">{comment.body}</div></article>) : <p className="subtle">Aún no hay respuestas.</p>}{ticket.status === 'CLOSED' ? <div className="alert info">Esta solicitud está cerrada. Crea una nueva si necesitas ayuda adicional.</div> : <form className="portal-form" onSubmit={event => void submit(event)} style={{ marginTop: 20 }}>{error && <ErrorBox message={error} />}<label>Agregar respuesta<textarea aria-label="Agregar respuesta" required maxLength={20000} value={reply} onChange={event => setReply(event.target.value)} disabled={busy} /></label><button className="button primary" type="submit" disabled={busy || !reply.trim()}><Send size={16} />{busy ? 'Enviando…' : 'Enviar respuesta'}</button></form>}</>}</Modal>;
}
function InvoiceDetail({ id, close, openReport }: { id: string; close: () => void; openReport: (invoice: PortalInvoice) => void }) {
  const query = usePortalData<PortalInvoice>('/invoices/' + encodeURIComponent(id));
  const invoice = query.data;
  return <Modal title={invoice ? 'Factura ' + invoice.number : 'Detalle de factura'} close={close} wide>{query.loading ? <Loading /> : query.error ? <ErrorBox message={query.error} retry={query.retry} /> : invoice && <div className="portal-stack"><div className="portal-actions"><PortalStatus status={invoice.status} /><PrintLink type="invoice" id={invoice.id} />{invoice.status === 'OPEN' && <button className="button primary small" onClick={() => openReport(invoice)}>Informar un pago</button>}</div><dl className="portal-detail-grid">{[['Periodo', invoice.period], ['Fecha de emisión', date(invoice.issuedAt)], ['Vencimiento', date(invoice.dueAt)], ['Total', money(invoice.amountCents, invoice.currency)], ['Pagado', money(invoice.paidCents, invoice.currency)], ['Saldo pendiente', money(Math.max(0, invoice.amountCents - invoice.paidCents), invoice.currency)]].map(([label, value]) => <div key={label}><dt>{label}</dt><dd>{value}</dd></div>)}</dl>{invoice.lines?.length ? <div className="table-wrap"><table className="data-table"><thead><tr><th>Concepto</th><th>Cantidad</th><th>Precio unitario</th><th>Importe</th></tr></thead><tbody>{invoice.lines.map(line => <tr key={line.id}><td>{line.description}</td><td>{line.quantity}</td><td>{money(line.unitCents, line.currency)}</td><td>{money(line.totalCents, line.currency)}</td></tr>)}</tbody></table></div> : <p className="subtle">Servicio: {invoice.service?.plan.name ?? 'Servicio de Internet'}</p>}<div><h3 style={{ fontSize: 14 }}>Pagos registrados</h3>{invoice.payments?.length ? invoice.payments.map(payment => <div className="portal-comment" key={payment.id}><div className="portal-service-top"><strong>{money(payment.amountCents, invoice.currency)}</strong><PrintLink type="receipt" id={payment.id}>Ver recibo</PrintLink></div><span className="subtle">{date(payment.receivedAt, true)} · {payment.externalReference}</span></div>) : <p className="subtle">No hay pagos acreditados a esta factura.</p>}</div></div>}</Modal>;
}
function centsFromInput(value: string): number | null {
  if (!/^\d{1,8}(?:[.,]\d{1,2})?$/.test(value.trim())) return null;
  const [whole, fraction = ''] = value.trim().replace(',', '.').split('.');
  const amount = Number(whole) * 100 + Number(fraction.padEnd(2, '0'));
  return Number.isSafeInteger(amount) && amount > 0 ? amount : null;
}
function ReportPayment({ invoice: initialInvoice, close, saved }: { invoice?: PortalInvoice; close: () => void; saved: (message: string) => void }) {
  const [invoices, setInvoices] = useState<PortalInvoice[]>(initialInvoice ? [initialInvoice] : []), [selected, setSelected] = useState(initialInvoice?.id ?? '');
  const [amount, setAmount] = useState(initialInvoice ? ((initialInvoice.amountCents - initialInvoice.paidCents) / 100).toFixed(2) : ''), [reference, setReference] = useState(''), [note, setNote] = useState('');
  const [loading, setLoading] = useState(!initialInvoice), [busy, setBusy] = useState(false), [error, setError] = useState(''), [retry, setRetry] = useState(0);
  useEffect(() => {
    if (initialInvoice) return;
    let active = true; setLoading(true); setError('');
    void (async () => {
      const result: PortalInvoice[] = [];
      for (let page = 1; ; page++) {
        const list = await api<PageResult<PortalInvoice>>('/portal/invoices?status=OPEN&pageSize=100&page=' + page);
        result.push(...list.results);
        if (result.length >= list.count || list.results.length === 0) break;
      }
      if (active) setInvoices(result);
    })().catch(err => { if (active) setError(errorMessage(err)); }).finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [initialInvoice, retry]);
  const invoice = invoices.find(row => row.id === selected);
  const submit = async (event: FormEvent) => {
    event.preventDefault(); setError('');
    const cents = centsFromInput(amount);
    if (!invoice || !cents || cents > invoice.amountCents - invoice.paidCents || !reference.trim()) { setError('Selecciona una factura e indica un importe válido, sin exceder su saldo, y una referencia.'); return; }
    setBusy(true);
    try { await post('/portal/payment-reports', { invoiceId: invoice.id, amountCents: cents, currency: invoice.currency, reference: reference.trim(), note: note.trim() }); saved('Tu pago fue informado y está pendiente de revisión.'); close(); }
    catch (err) { setError(errorMessage(err)); } finally { setBusy(false); }
  };
  return <Modal title="Informar un pago" description="Tu proveedor revisará esta información antes de acreditar el importe." close={close}>{loading ? <Loading /> : <form className="portal-form" onSubmit={event => void submit(event)}>{error && <ErrorBox message={error} retry={!initialInvoice ? () => setRetry(value => value + 1) : undefined} />}{!invoices.length && !error ? <EmptyState title="No tienes facturas pendientes" description="No es necesario informar un pago en este momento." /> : <><label>Factura<select aria-label="Factura del pago" value={selected} required disabled={busy || Boolean(initialInvoice)} onChange={event => { setSelected(event.target.value); const row = invoices.find(item => item.id === event.target.value); setAmount(row ? ((row.amountCents - row.paidCents) / 100).toFixed(2) : ''); }}><option value="" disabled>Selecciona una factura</option>{invoices.map(row => <option key={row.id} value={row.id}>{row.number + ' · Saldo ' + money(row.amountCents - row.paidCents, row.currency)}</option>)}</select></label><label>Importe {invoice ? '(' + invoice.currency + ')' : ''}<input aria-label="Importe informado" required inputMode="decimal" maxLength={12} value={amount} onChange={event => setAmount(event.target.value)} disabled={busy} /></label><label>Referencia del pago<input aria-label="Referencia del pago" required maxLength={180} value={reference} onChange={event => setReference(event.target.value)} disabled={busy} /></label><label>Comentario, opcional<textarea aria-label="Comentario del pago" maxLength={2000} value={note} onChange={event => setNote(event.target.value)} disabled={busy} /></label><div className="alert info">Este aviso no registra un cobro ni reconecta automáticamente tu servicio.</div><button className="button primary" type="submit" disabled={busy || !invoice}><Send size={16} />{busy ? 'Enviando…' : 'Enviar para revisión'}</button></>}</form>}</Modal>;
}
function ContractDetail({ id, close, saved }: { id: string; close: () => void; saved: (message: string) => void }) {
  const [refresh, setRefresh] = useState(0), [name, setName] = useState(''), [agreed, setAgreed] = useState(false), [busy, setBusy] = useState(false), [error, setError] = useState('');
  const query = usePortalData<PortalContract>('/contracts/' + encodeURIComponent(id), refresh);
  const contract = query.data;
  const submit = async (event: FormEvent) => {
    event.preventDefault(); if (!agreed || !name.trim()) return; setBusy(true); setError('');
    try { await post('/portal/contracts/' + encodeURIComponent(id) + '/accept', { name: name.trim() }); setRefresh(value => value + 1); saved('La aceptación del contrato quedó registrada.'); }
    catch (err) { setError(errorMessage(err)); } finally { setBusy(false); }
  };
  return <Modal title={contract?.title ?? 'Contrato de servicio'} close={close} wide>{query.loading ? <Loading /> : query.error ? <ErrorBox message={query.error} retry={query.retry} /> : contract && <div className="portal-stack"><div className="portal-actions"><PortalStatus status={contract.status} /><PrintLink type="contract" id={contract.id} /></div><dl className="portal-detail-grid">{[['Titular', contract.clientName], ['Documento', text(contract.document)], ['Dirección', text(contract.address)], ['Plan', contract.planName], ['Mensualidad', money(contract.priceCents, contract.currency)], ['Fecha de emisión', date(contract.createdAt)]].map(([label, value]) => <div key={label}><dt>{label}</dt><dd>{value}</dd></div>)}</dl><div className="portal-body-text">{contract.terms}</div>{contract.status === 'DRAFT' && <form className="portal-form" onSubmit={event => void submit(event)} style={{ borderTop: '1px solid var(--line)', paddingTop: 20 }}>{error && <ErrorBox message={error} />}<label>Tu nombre completo<input aria-label="Nombre para aceptar el contrato" required maxLength={200} value={name} onChange={event => setName(event.target.value)} disabled={busy} /></label><label className="portal-check"><input aria-label="He leído y acepto las condiciones del contrato" type="checkbox" checked={agreed} onChange={event => setAgreed(event.target.checked)} disabled={busy} /><span>He leído y acepto las condiciones de este contrato.</span></label><p className="subtle">La aceptación registra tu nombre y la fecha en tu cuenta. No constituye una firma electrónica certificada.</p><button className="button primary" type="submit" disabled={busy || !agreed || !name.trim()}><CheckCircle2 size={16} />{busy ? 'Registrando…' : 'Registrar mi aceptación'}</button></form>}{contract.status === 'ACCEPTED' && <div className="alert success">Aceptado por {text(contract.acceptedName)} el {date(contract.acceptedAt, true)}.</div>}{contract.status === 'CANCELLED' && <div className="alert info">Este documento está cancelado y no admite aceptación.</div>}</div>}</Modal>;
}

export default function PortalApp() {
  const [session, setSession] = useState<PortalSession | null>(null), [initializing, setInitializing] = useState(true), [initialError, setInitialError] = useState('');
  const [page, setPage] = useState<PortalPage>(portalRoute), [theme, setTheme] = useState(initialPortalTheme), [dialog, setDialog] = useState<PortalDialog | null>(null);
  const [refresh, setRefresh] = useState(0), [notice, setNotice] = useState(''), [logoutBusy, setLogoutBusy] = useState(false);
  const close = useCallback(() => setDialog(null), []);
  const saved = useCallback((message: string) => { setRefresh(value => value + 1); setNotice(message); }, []);
  useEffect(() => {
    let active = true;
    const unauthorized = () => { setSession(null); setDialog(null); };
    window.addEventListener('nexoisp:unauthorized', unauthorized);
    api<PortalSession>('/portal/auth/me').then(value => { if (active) { setDefaultCurrency(value.capabilities?.defaultCurrency); setSession(value); } }).catch(err => { if (active && !(err && typeof err === 'object' && 'status' in err && err.status === 401)) setInitialError(errorMessage(err)); }).finally(() => { if (active) setInitializing(false); });
    return () => { active = false; window.removeEventListener('nexoisp:unauthorized', unauthorized); };
  }, []);
  useEffect(() => { const changed = () => { setPage(portalRoute()); setDialog(null); }; window.addEventListener('hashchange', changed); return () => window.removeEventListener('hashchange', changed); }, []);
  useEffect(() => { document.documentElement.dataset.theme = theme; try { localStorage.setItem('nexoisp-portal-theme', theme); } catch { /* No authentication data is stored in the browser. */ } }, [theme]);
  useEffect(() => { if (!notice) return; const timer = window.setTimeout(() => setNotice(''), 7000); return () => window.clearTimeout(timer); }, [notice]);
  const go = (next: PortalPage) => { setPage(next); setDialog(null); window.location.hash = '/' + next; };
  const toggleTheme = () => setTheme(value => value === 'dark' ? 'light' : 'dark');
  const logout = async () => {
    setLogoutBusy(true);
    try { await post('/portal/auth/logout'); setSession(null); setDialog(null); setNotice(''); }
    catch (err) { setNotice(errorMessage(err)); } finally { setLogoutBusy(false); }
  };
  const title = portalPages.find(item => item.id === page)?.title ?? 'Mi cuenta';
  return <div className="portal-page"><style>{portalStyles}</style>{initializing ? <Loading label="Abriendo tu portal…" /> : !session ? <>{initialError && <ErrorBox message={initialError} retry={() => window.location.reload()} />}<Login theme={theme} toggleTheme={toggleTheme} authenticated={value => { setSession(value); setInitialError(''); setRefresh(value => value + 1); }} /></> : <><header className="portal-header"><div className="portal-header-inner"><div className="portal-brand"><div className="brand-mark"><Network size={23} /></div><span>GIGARED ISP<small>MI PORTAL</small></span></div><div className="portal-account"><span className="portal-account-name">{session.client.name}</span><button className="icon-button" aria-label={theme === 'dark' ? 'Activar tema claro' : 'Activar tema oscuro'} onClick={toggleTheme}>{theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}</button><button className="button small" onClick={() => void logout()} disabled={logoutBusy}><LogOut size={15} />Cerrar sesión</button></div></div><nav className="portal-nav" aria-label="Menú del portal del cliente">{portalPages.map(item => { const Icon = item.icon; return <button key={item.id} aria-current={page === item.id ? 'page' : undefined} onClick={() => go(item.id)}><Icon size={16} />{item.title}</button>; })}</nav></header><main className="portal-main"><div className="portal-heading"><div><h1>{title}</h1><p className="page-description">Tu servicio de Internet y los movimientos de tu cuenta, en un solo lugar.</p></div><div className="portal-actions">{page === 'tickets' && <button className="button primary" onClick={() => setDialog({ kind: 'new-ticket' })}><LifeBuoy size={16} />Nueva solicitud</button>}{(page === 'invoices' || page === 'payment-reports') && <button className="button primary" onClick={() => setDialog({ kind: 'report' })}><CreditCard size={16} />Informar un pago</button>}<button className="icon-button" aria-label="Actualizar mi cuenta" onClick={() => setRefresh(value => value + 1)}><RefreshCw size={18} /></button></div></div>{page === 'home' ? <HomePage refresh={refresh} go={go} open={setDialog} /> : <ListPage key={page} page={page} refresh={refresh} open={setDialog} />}</main><footer className="portal-footer">GIGARED ISP · Portal del cliente</footer></>}{notice && <div className="portal-notice" role="status"><CheckCircle2 size={19} /><span>{notice}</span><button className="icon-button" aria-label="Cerrar aviso" onClick={() => setNotice('')}>×</button></div>}{session && dialog?.kind === 'new-ticket' && <NewTicket close={close} saved={saved} />}{session && dialog?.kind === 'ticket' && <TicketDetail key={dialog.id} id={dialog.id} close={close} saved={saved} />}{session && dialog?.kind === 'invoice' && <InvoiceDetail key={dialog.id} id={dialog.id} close={close} openReport={invoice => setDialog({ kind: 'report', invoice })} />}{session && dialog?.kind === 'report' && <ReportPayment key={dialog.invoice?.id ?? 'choose'} invoice={dialog.invoice} close={close} saved={saved} />}{session && dialog?.kind === 'contract' && <ContractDetail key={dialog.id} id={dialog.id} close={close} saved={saved} />}</div>;
}
