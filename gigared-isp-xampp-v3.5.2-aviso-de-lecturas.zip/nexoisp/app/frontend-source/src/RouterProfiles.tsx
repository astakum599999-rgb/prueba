import { useEffect, useState } from 'react';
import { ClipboardList, Pencil, RefreshCw } from 'lucide-react';
import { api } from './api';
import type { Row } from './forms';
import type { PageResult, RouterProfile } from './types';
import { Badge, date, EmptyState, errorMessage, Loading, Pagination, SearchBox } from './ui';

const speed = (value?: number | null) => typeof value === 'number' && value > 0 ? `${new Intl.NumberFormat('es', { maximumFractionDigits: 3 }).format(value / 1000)} Mbps` : 'Sin velocidad base';

export default function RouterProfiles({ refresh, canEdit, editPlan }: { refresh: number; canEdit: boolean; editPlan: (row: Row) => void }) {
  const [data, setData] = useState<PageResult<RouterProfile>>({ results: [], count: 0, page: 1, pageSize: 15 });
  const [search, setSearch] = useState(''), [query, setQuery] = useState(''), [page, setPage] = useState(1), [reload, setReload] = useState(0);
  const [loading, setLoading] = useState(true), [error, setError] = useState(''), [opening, setOpening] = useState<string | null>(null);
  useEffect(() => { const timer = window.setTimeout(() => { setQuery(search); setPage(1); }, 300); return () => window.clearTimeout(timer); }, [search]);
  useEffect(() => {
    let active = true; setLoading(true);
    const params = new URLSearchParams({ page: String(page), pageSize: '15', search: query });
    void api<PageResult<RouterProfile>>(`/router-profiles?${params}`).then(result => { if (active) { setData(result); setError(''); if (!result.results.length && result.count > 0 && page > 1) setPage(Math.ceil(result.count / 15)); } }).catch(err => { if (active) setError(errorMessage(err)); }).finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [page, query, refresh, reload]);
  const openPlan = async (id: string) => {
    setOpening(id); setError('');
    try { editPlan(await api<Row>(`/plans/${encodeURIComponent(id)}`)); }
    catch (err) { setError(errorMessage(err)); }
    finally { setOpening(null); }
  };
  return <section className="panel router-profiles-panel"><header className="table-toolbar"><div className="inline-gap"><h2 className="panel-title">Perfiles MikroTik</h2><span className="count-pill">{data.count}</span></div><div className="inline-gap"><SearchBox value={search} onChange={setSearch} label="Buscar perfiles MikroTik" /><button className="icon-button" aria-label="Actualizar perfiles MikroTik" onClick={() => setReload(value => value + 1)}><RefreshCw size={17} className={loading ? 'spinner' : ''} /></button></div></header><div className="profile-import-note">Aquí aparecen todos los perfiles observados, incluidos los que no tienen rate-limit. Sus velocidades son las bases declaradas en el perfil; el precio y la moneda se configuran localmente.</div>{error && <div className="alert error" role="alert">{error}</div>}{loading && !data.results.length ? <Loading label="Consultando perfiles importados…" /> : data.results.length ? <><div className="table-wrap"><table className="data-table"><thead><tr><th>Perfil</th><th>Velocidad base</th><th>Rate-limit observado</th><th>Revisión local</th><th>Última lectura</th><th className="right">Acciones</th></tr></thead><tbody>{data.results.map(row => <tr key={row.id}><td><div className="table-primary">{row.profileName}</div></td><td><div>Bajada: {speed(row.downloadKbps)}</div><div className="table-secondary">Subida: {speed(row.uploadKbps)}</div></td><td><code className="profile-rate-limit">{row.rateLimit || 'Sin rate-limit configurado'}</code></td><td><Badge value={row.status === 'READY' ? 'ACTIVE' : 'PENDING'}>{row.present === false ? 'No observado' : !row.planId ? 'Revisar velocidad / perfil' : row.priceConfigured ? row.status === 'READY' ? 'Tarifa configurada' : 'Revisar perfil' : 'Precio pendiente'}</Badge>{row.reason && <div className="table-secondary profile-reason">{row.reason}</div>}</td><td>{date(row.lastSeenAt, true)}</td><td>{row.planId && canEdit ? <button className="button small" disabled={opening !== null} onClick={() => void openPlan(row.planId!)}><Pencil size={14} />{opening === row.planId ? 'Abriendo…' : 'Editar plan local'}</button> : <span className="table-secondary">{row.planId ? 'Tarifa: administrador' : 'Sin plan facturable'}</span>}</td></tr>)}</tbody></table></div><Pagination page={page} pageSize={15} count={data.count} change={setPage} /></> : !error && <EmptyState icon={<ClipboardList size={25} />} title={query ? 'No encontramos perfiles coincidentes' : 'Todavía no hay perfiles importados'} description={query ? 'Prueba otro nombre de perfil o router.' : 'Pulsa Importar perfiles de MikroTik para leerlos sin configurar tu router.'} />}</section>;
}
