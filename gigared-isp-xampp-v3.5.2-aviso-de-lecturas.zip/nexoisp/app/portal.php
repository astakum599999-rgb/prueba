<?php
declare(strict_types=1);
namespace Nexo;

require_once __DIR__ . '/billing-local.php';
require_once __DIR__ . '/financial-delete.php';

function portalOnly(array $input, array $allowed, array $required = []): void
{
    if (array_diff(array_keys($input), $allowed)) throw new HttpError(422, 'La solicitud contiene campos no permitidos', 'VALIDATION_ERROR');
    foreach ($required as $field) if (!array_key_exists($field, $input)) throw new HttpError(422, 'Campo obligatorio: ' . $field, 'VALIDATION_ERROR');
}

function portalText(mixed $input, string $field, int $max = 200): string
{
    if (!is_string($input) || trim($input) === '' || strlen($input) > $max * 4 || (function_exists('mb_strlen') ? mb_strlen($input, 'UTF-8') : preg_match_all('/./us', $input)) > $max) throw new HttpError(422, 'Texto inválido: ' . $field, 'VALIDATION_ERROR');
    return trim($input);
}

function portalId(mixed $value): string
{
    if (!is_string($value) || preg_match('/^[a-f0-9]{24}$/D', $value) !== 1) throw new HttpError(422, 'Identificador inválido', 'VALIDATION_ERROR');
    return $value;
}

function portalRecord(string $table, string $identifier, bool $forUpdate = false): array
{
    if (!in_array($table, ['PortalAccount','PortalSession','PaymentReport','ServiceContract','Client','Service','Plan','Invoice','Payment','Ticket'], true)) throw new \LogicException('Entidad no admitida');
    return fetchOne('SELECT * FROM `' . $table . '` WHERE `id`=?' . ($forUpdate ? ' FOR UPDATE' : ''), [$identifier]) ?? throw new HttpError(404, 'Registro no encontrado', 'NOT_FOUND');
}

function portalInsert(string $table, array $data): array
{
    if (!in_array($table, ['PortalAccount','PortalSession','PaymentReport','ServiceContract'], true)) throw new \LogicException('Entidad no admitida');
    $data['id'] ??= id();
    foreach (array_keys($data) as $key) if (preg_match('/^[A-Za-z][A-Za-z0-9]*$/D', $key) !== 1) throw new \LogicException('Campo SQL inválido');
    $fields = array_keys($data);
    $values = array_map(fn(mixed $value): mixed => is_bool($value) ? (int)$value : $value, array_values($data));
    db()->prepare('INSERT INTO `' . $table . '` (`' . implode('`,`', $fields) . '`) VALUES (' . implode(',', array_fill(0, count($fields), '?')) . ')')->execute($values);
    return portalRecord($table, $data['id']);
}

function portalUpdate(string $table, string $identifier, array $data): array
{
    if (!in_array($table, ['PortalAccount','PaymentReport','ServiceContract'], true)) throw new \LogicException('Entidad no admitida');
    $data['updatedAt'] = now(); $set = [];
    foreach (array_keys($data) as $key) {
        if (preg_match('/^[A-Za-z][A-Za-z0-9]*$/D', $key) !== 1 || $key === 'id') throw new \LogicException('Campo SQL inválido');
        $set[] = '`' . $key . '`=?';
    }
    $values = array_map(fn(mixed $value): mixed => is_bool($value) ? (int)$value : $value, array_values($data)); $values[] = $identifier;
    db()->prepare('UPDATE `' . $table . '` SET ' . implode(',', $set) . ' WHERE `id`=?')->execute($values);
    return portalRecord($table, $identifier);
}

function portalAudit(string $action, string $type, string $entityId, array $actor): void
{
    db()->prepare('INSERT INTO `AuditLog` (`id`,`action`,`entityType`,`entityId`,`details`) VALUES (?,?,?,?,?)')->execute([id(), $action, $type, $entityId, json_encode(['portalAccountId' => $actor['account']['id'], 'clientId' => $actor['client']['id']], JSON_THROW_ON_ERROR)]);
}

function portalClientDto(array $row): array
{
    return array_intersect_key($row, array_flip(['id','code','name','email','phone','document','address','zone','status']));
}

function portalServiceDto(array $row): array
{
    $data = array_intersect_key($row, array_flip(['id','type','ipAddress','desiredState','appliedState','syncStatus','createdAt']));
    $plan = portalRecord('Plan', $row['planId']);
    $data['plan'] = array_intersect_key($plan, array_flip(['id','name','downloadKbps','uploadKbps','priceCents','currency']));
    $data['billingOnly'] = billingLocalIsService($row['id']);
    $data['billingStartOn'] = null;
    if ($data['billingOnly']) $data = array_merge($data, billingLocalCalendarFields($row));
    return $data;
}

function portalInvoiceDto(array $row, bool $detail = false): array
{
    $data = array_intersect_key($row, array_flip(['id','number','clientId','serviceId','period','amountCents','paidCents','currency','status','issuedAt','dueAt','graceUntil','createdAt']));
    $data['service'] = portalServiceDto(portalRecord('Service', $row['serviceId']));
    if ($detail) {
        $data['payments'] = fetchAll('SELECT `id`,`invoiceId`,`amountCents`,`provider`,`externalReference`,`receivedAt` FROM `Payment` WHERE `invoiceId`=? AND ' . financialDeletionClause('Payment', 'Payment') . ' ORDER BY `receivedAt` ASC,`id` ASC', [$row['id']]);
        $data['lines'] = fetchAll('SELECT `id`,`type`,`position`,`description`,`quantity`,`unitCents`,`totalCents`,`currency` FROM `InvoiceLine` WHERE `invoiceId`=? ORDER BY `position` ASC,`id` ASC', [$row['id']]);
    }
    return $data;
}

function portalTicketDto(array $row, bool $detail = false): array
{
    $data = array_intersect_key($row, array_flip(['id','clientId','subject','body','priority','status','createdAt','updatedAt']));
    if ($detail) $data['comments'] = fetchAll('SELECT `id`,`authorName`,`body`,`createdAt` FROM `TicketComment` WHERE `ticketId`=? ORDER BY `createdAt` ASC,`id` ASC', [$row['id']]);
    return $data;
}

function portalContractDto(array $row, bool $staff = false): array
{
    unset($row['acceptedIp']);
    if ($staff) {
        $row['client'] = portalClientDto(portalRecord('Client', $row['clientId']));
        $row['serviceDeleted'] = financialDeleted('Service', $row['serviceId']);
        $row['service'] = $row['serviceDeleted'] ? null : portalServiceDto(portalRecord('Service', $row['serviceId']));
    }
    return $row;
}

function portalReportDto(array $row, bool $staff = false): array
{
    if (!$staff) unset($row['decidedBy']);
    if ($staff) {
        $row['client'] = portalClientDto(portalRecord('Client', $row['clientId']));
        $row['invoiceDeleted'] = financialDeleted('Invoice', $row['invoiceId']);
        $row['invoice'] = $row['invoiceDeleted'] ? null : portalInvoiceDto(portalRecord('Invoice', $row['invoiceId']));
    }
    return $row;
}

function portalCurrent(): ?array
{
    if ($GLOBALS['nexo_portal_resolved'] ?? false) return $GLOBALS['nexo_portal_actor'] ?? null;
    $GLOBALS['nexo_portal_resolved'] = true;
    $token = $_COOKIE['nexoisp_client_session'] ?? null;
    if (!is_string($token) || preg_match('/^[A-Za-z0-9_-]{43}$/D', $token) !== 1) return null;
    $row = fetchOne('SELECT a.`id`,a.`clientId`,a.`username`,a.`active`,s.`expiresAt` FROM `PortalSession` s JOIN `PortalAccount` a ON a.`id`=s.`accountId` WHERE s.`tokenHash`=?', [hashToken($token)]);
    if (!$row || !$row['active'] || $row['expiresAt'] <= now()) return null;
    return $GLOBALS['nexo_portal_actor'] = ['account' => ['id' => $row['id'], 'username' => $row['username']], 'client' => portalClientDto(portalRecord('Client', $row['clientId']))];
}

function portalRequire(): array
{
    $actor = portalCurrent();
    if (!$actor) throw new HttpError(401, 'Acceso de cliente requerido', 'PORTAL_AUTH_REQUIRED');
    if (!in_array($_SERVER['REQUEST_METHOD'] ?? 'GET', ['GET','HEAD','OPTIONS'], true) && !trustedOrigin(headerValue('Origin'))) throw new HttpError(403, 'Origen no autorizado', 'CSRF_REJECTED');
    return $actor;
}

function portalOwned(string $table, string $identifier, array $actor, bool $forUpdate = false): array
{
    if (!in_array($table, ['Invoice','PaymentReport','ServiceContract','Ticket'], true)) throw new \LogicException('Recurso no admitido');
    $row = fetchOne('SELECT * FROM `' . $table . '` WHERE `id`=? AND `clientId`=?' . ($forUpdate ? ' FOR UPDATE' : ''), [$identifier, $actor['client']['id']]) ?? throw new HttpError(404, 'Registro no encontrado', 'NOT_FOUND');
    if ($table === 'Invoice') financialRequirePresent('Invoice', $identifier);
    return $row;
}

function portalLogin(array $input): array
{
    rateLimit('portal-login', 15, 900); portalOnly($input, ['username','password'], ['username','password']);
    if (headerValue('Origin') !== null && !trustedOrigin(headerValue('Origin'))) throw new HttpError(403, 'Origen no autorizado', 'CSRF_REJECTED');
    $username = strtolower(portalText($input['username'], 'username', 100));
    if (!is_string($input['password']) || strlen($input['password']) > 128) throw new HttpError(422, 'Contraseña inválida');
    $account = fetchOne('SELECT * FROM `PortalAccount` WHERE `username`=?', [$username]);
    $valid = verifyPassword($input['password'], $account['passwordHash'] ?? '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.');
    if (!$account || !$account['active'] || !$valid) throw new HttpError(401, 'Usuario o contraseña incorrectos', 'INVALID_CREDENTIALS');
    $token = base64urlEncode(random_bytes(32)); $expires = time() + max(1, min(168, (int)config('session_hours', 12))) * 3600;
    $actor = ['account' => ['id' => $account['id'], 'username' => $account['username']], 'client' => portalClientDto(portalRecord('Client', $account['clientId']))];
    tx(function (\PDO $pdo) use ($account, $token, $expires, $actor): void {
        $pdo->exec('DELETE FROM `PortalSession` WHERE `expiresAt`<UTC_TIMESTAMP(3) LIMIT 100');
        portalInsert('PortalSession', ['accountId' => $account['id'], 'tokenHash' => hashToken($token), 'expiresAt' => gmdate('Y-m-d H:i:s', $expires)]);
        portalAudit('portal.login', 'PortalAccount', $account['id'], $actor);
    });
    setcookie('nexoisp_client_session', $token, sessionCookieOptions($expires));
    return $actor + ['capabilities' => ['browserWorker' => false, 'defaultCurrency' => localCurrency(), 'version' => '2.3.3']];
}

function portalPage(string $table, array $actor, array $p): array
{
    $clientId = $actor['client']['id'];
    if ($table === 'Payment') {
        $from = ' FROM `Payment` p JOIN `Invoice` i ON i.`id`=p.`invoiceId` WHERE i.`clientId`=? AND ' . financialDeletionClause('Payment', 'p') . ' AND ' . financialDeletionClause('Invoice', 'i');
        $rows = fetchAll('SELECT p.*' . $from . ' ORDER BY p.`receivedAt` DESC,p.`id` DESC LIMIT ' . $p['pageSize'] . ' OFFSET ' . $p['offset'], [$clientId]);
        foreach ($rows as &$row) $row['invoice'] = portalInvoiceDto(portalRecord('Invoice', $row['invoiceId'])); unset($row);
        $count = (int)fetchOne('SELECT COUNT(*) AS n' . $from, [$clientId])['n'];
    } else {
        $where = ' WHERE `clientId`=?'; $params = [$clientId];
        if ($table === 'Invoice') $where .= ' AND ' . financialDeletionClause('Invoice', 'Invoice');
        $statuses = match ($table) { 'Invoice' => ['OPEN','PAID','VOID'], 'Ticket' => ['OPEN','IN_PROGRESS','RESOLVED','CLOSED'], 'ServiceContract' => ['DRAFT','ACCEPTED','CANCELLED'], 'PaymentReport' => ['SUBMITTED','APPROVED','REJECTED'] };
        if (($status = queryEnum('status', $statuses)) !== null) { $where .= ' AND `status`=?'; $params[] = $status; }
        $rows = fetchAll('SELECT * FROM `' . $table . '`' . $where . ' ORDER BY `createdAt` DESC,`id` DESC LIMIT ' . $p['pageSize'] . ' OFFSET ' . $p['offset'], $params);
        $count = (int)fetchOne('SELECT COUNT(*) AS n FROM `' . $table . '`' . $where, $params)['n'];
        $rows = array_map(match ($table) { 'Invoice' => fn(array $row): array => portalInvoiceDto($row), 'Ticket' => fn(array $row): array => portalTicketDto($row), 'ServiceContract' => fn(array $row): array => portalContractDto($row), 'PaymentReport' => fn(array $row): array => portalReportDto($row) }, $rows);
    }
    return ['results' => $rows, 'count' => $count, 'page' => $p['page'], 'pageSize' => $p['pageSize']];
}

function portalDispatch(string $method, string $route): bool
{
    if ($method === 'POST' && $route === '/portal/auth/login') json(portalLogin(body()));
    if ($method === 'GET' && $route === '/portal/auth/me') json(portalRequire() + ['capabilities' => ['browserWorker' => false, 'defaultCurrency' => localCurrency(), 'version' => '2.3.3']]);
    if ($method === 'POST' && $route === '/portal/auth/logout') {
        portalRequire(); $token = $_COOKIE['nexoisp_client_session'] ?? null;
        if (is_string($token)) db()->prepare('DELETE FROM `PortalSession` WHERE `tokenHash`=?')->execute([hashToken($token)]);
        setcookie('nexoisp_client_session', '', sessionCookieOptions(time() - 3600)); json(null, 204);
    }
    if (str_starts_with($route, '/portal/')) return portalClientDispatch($method, $route, portalRequire());
    if ($route === '/portal-accounts' || str_starts_with($route, '/portal-accounts/')) return portalAccountDispatch($method, $route, permit('ADMIN','BILLING'));
    if ($route === '/payment-reports' || str_starts_with($route, '/payment-reports/')) return portalStaffReportDispatch($method, $route, permit('ADMIN','BILLING'));
    if ($route === '/contracts' || str_starts_with($route, '/contracts/')) return portalStaffContractDispatch($method, $route, $method === 'GET' ? requireAuth() : permit('ADMIN','BILLING'));
    return false;
}

function portalClientDispatch(string $method, string $route, array $actor): bool
{
    $clientId = $actor['client']['id'];
    if ($method === 'GET' && $route === '/portal/summary') {
        $services = array_map(fn(array $row): array => portalServiceDto($row), fetchAll('SELECT * FROM `Service` WHERE `clientId`=? AND ' . financialDeletionClause('Service', 'Service') . ' ORDER BY `createdAt` DESC,`id` DESC', [$clientId]));
        $invoices = array_map(fn(array $row): array => portalInvoiceDto($row), fetchAll('SELECT * FROM `Invoice` WHERE `clientId`=? AND ' . financialDeletionClause('Invoice', 'Invoice') . ' ORDER BY `createdAt` DESC,`id` DESC LIMIT 5', [$clientId]));
        $tickets = array_map(fn(array $row): array => portalTicketDto($row), fetchAll('SELECT * FROM `Ticket` WHERE `clientId`=? ORDER BY `updatedAt` DESC,`id` DESC LIMIT 5', [$clientId]));
        $contracts = array_map(fn(array $row): array => portalContractDto($row), fetchAll('SELECT * FROM `ServiceContract` WHERE `clientId`=? ORDER BY `createdAt` DESC,`id` DESC LIMIT 5', [$clientId]));
        $open = (int)fetchOne("SELECT COUNT(*) AS n FROM `Invoice` WHERE `clientId`=? AND `status`='OPEN' AND " . financialDeletionClause('Invoice', 'Invoice'), [$clientId])['n'];
        $openTickets = (int)fetchOne("SELECT COUNT(*) AS n FROM `Ticket` WHERE `clientId`=? AND `status` IN ('OPEN','IN_PROGRESS')", [$clientId])['n'];
        $outstanding = fetchAll("SELECT `currency`,SUM(`amountCents`-`paidCents`) AS amountCents FROM `Invoice` WHERE `clientId`=? AND `status`='OPEN' AND " . financialDeletionClause('Invoice', 'Invoice') . " GROUP BY `currency` ORDER BY `currency`", [$clientId]);
        foreach ($outstanding as &$group) $group['amountCents'] = (int)$group['amountCents']; unset($group);
        json(['client' => $actor['client'], 'services' => $services, 'stats' => ['openInvoices' => $open, 'outstanding' => $outstanding, 'openTickets' => $openTickets], 'invoices' => $invoices, 'tickets' => $tickets, 'contracts' => $contracts]);
    }
    $resources = ['invoices' => 'Invoice','payments' => 'Payment','tickets' => 'Ticket','contracts' => 'ServiceContract','payment-reports' => 'PaymentReport'];
    if (preg_match('#^/portal/(invoices|payments|tickets|contracts|payment-reports)$#D', $route, $match) && $method === 'GET') json(portalPage($resources[$match[1]], $actor, pagination()));
    if (preg_match('#^/portal/(invoices|tickets|contracts)/([a-f0-9]{24})$#D', $route, $match) && $method === 'GET') {
        $row = portalOwned($resources[$match[1]], $match[2], $actor);
        json(match ($match[1]) { 'invoices' => portalInvoiceDto($row, true), 'tickets' => portalTicketDto($row, true), 'contracts' => portalContractDto($row) });
    }
    if ($method === 'POST' && $route === '/portal/tickets') {
        $input = body(); portalOnly($input, ['subject','body','priority'], ['subject','body']);
        $data = validate('ticket', $input + ['clientId' => $clientId]);
        $ticket = tx(function (\PDO $pdo) use ($data, $actor): array { $row = apiInsert('Ticket', $data); portalAudit('portal.ticket.create', 'Ticket', $row['id'], $actor); return $row; });
        json(portalTicketDto($ticket, true), 201);
    }
    if (preg_match('#^/portal/tickets/([a-f0-9]{24})/comments$#D', $route, $match) && $method === 'POST') {
        $data = validate('comment', body());
        $comment = tx(function (\PDO $pdo) use ($match, $data, $actor): array {
            $ticket = portalOwned('Ticket', $match[1], $actor, true);
            if ($ticket['status'] === 'CLOSED') throw new HttpError(409, 'El ticket está cerrado; crea una solicitud nueva');
            $comment = apiInsert('TicketComment', ['ticketId' => $ticket['id'], 'authorName' => $actor['client']['name'], 'body' => $data['body']]);
            apiUpdate('Ticket', $ticket['id'], []); portalAudit('portal.ticket.comment', 'Ticket', $ticket['id'], $actor); return $comment;
        }); json($comment, 201);
    }
    if ($method === 'POST' && $route === '/portal/payment-reports') {
        $input = body(); portalOnly($input, ['invoiceId','amountCents','currency','reference','note'], ['invoiceId','amountCents','currency','reference']);
        $invoiceId = portalId($input['invoiceId']);
        if (!is_int($input['amountCents']) || $input['amountCents'] < 1 || $input['amountCents'] > 2147483647 || !is_string($input['currency']) || preg_match('/^[A-Z]{3}$/D', $input['currency']) !== 1) throw new HttpError(422, 'Importe o moneda inválidos');
        $data = ['invoiceId' => $invoiceId, 'clientId' => $clientId, 'amountCents' => $input['amountCents'], 'currency' => $input['currency'], 'reference' => portalText($input['reference'], 'reference', 180), 'note' => isset($input['note']) && $input['note'] !== '' ? portalText($input['note'], 'note', 5000) : null];
        $result = billingWithLocks(['client:' . $clientId], fn(): array => tx(function (\PDO $pdo) use ($data, $actor): array {
            $invoice = portalOwned('Invoice', $data['invoiceId'], $actor, true);
            if ($invoice['status'] !== 'OPEN' || $invoice['currency'] !== $data['currency'] || $data['amountCents'] > (int)$invoice['amountCents'] - (int)$invoice['paidCents']) throw new HttpError(409, 'La factura, el saldo o la moneda no permiten este reporte');
            $previous = fetchOne("SELECT * FROM `PaymentReport` WHERE `clientId`=? AND `reference`=? AND `status`<>'REJECTED' ORDER BY `createdAt` ASC LIMIT 1 FOR UPDATE", [$data['clientId'],$data['reference']]);
            if ($previous) {
                if ($previous['status'] === 'APPROVED' && financialDeleted('Payment', $previous['paymentId'])) throw new HttpError(409, 'El pago de este reporte fue eliminado; utilice una referencia nueva.', 'PAYMENT_DELETED');
                if ($previous['invoiceId'] !== $data['invoiceId'] || (int)$previous['amountCents'] !== $data['amountCents'] || $previous['currency'] !== $data['currency']) throw new HttpError(409, 'La referencia ya está asociada a otro reporte');
                return ['report' => $previous, 'replayed' => true];
            }
            $report = portalInsert('PaymentReport', $data); portalAudit('portal.payment.report', 'PaymentReport', $report['id'], $actor); return ['report' => $report, 'replayed' => false];
        }));
        json(portalReportDto($result['report']) + ['replayed' => $result['replayed']], $result['replayed'] ? 200 : 201);
    }
    if (preg_match('#^/portal/contracts/([a-f0-9]{24})/accept$#D', $route, $match) && $method === 'POST') {
        $input = body(); portalOnly($input, ['name'], ['name']); $name = portalText($input['name'], 'name');
        $row = tx(function (\PDO $pdo) use ($match, $name, $actor): array {
            $contract = portalOwned('ServiceContract', $match[1], $actor, true);
            if ($contract['status'] === 'CANCELLED') throw new HttpError(409, 'El contrato está cancelado');
            if ($contract['status'] === 'ACCEPTED') { if ($contract['acceptedName'] !== $name) throw new HttpError(409, 'La aceptación registrada es inmutable'); return $contract; }
            $contract = portalUpdate('ServiceContract', $contract['id'], ['status' => 'ACCEPTED','acceptedName' => $name,'acceptedAt' => now(),'acceptedIp' => substr((string)($_SERVER['REMOTE_ADDR'] ?? ''), 0, 45)]);
            portalAudit('portal.contract.accept', 'ServiceContract', $contract['id'], $actor); return $contract;
        }); json(portalContractDto($row));
    }
    return false;
}

function portalAccountDto(array $row): array
{
    unset($row['passwordHash']);
    $row['client'] = portalClientDto(portalRecord('Client', $row['clientId']));
    return $row;
}

function portalAccountDispatch(string $method, string $route, array $user): bool
{
    if ($method === 'GET' && $route === '/portal-accounts') {
        $p = pagination(); $where = ''; $params = [];
        if ($p['search'] !== '') { $where = ' WHERE a.`username` LIKE ? OR c.`name` LIKE ? OR c.`code` LIKE ?'; $params = array_fill(0, 3, '%' . $p['search'] . '%'); }
        $from = ' FROM `PortalAccount` a JOIN `Client` c ON c.`id`=a.`clientId`' . $where;
        $rows = fetchAll('SELECT a.*' . $from . ' ORDER BY a.`createdAt` DESC,a.`id` DESC LIMIT ' . $p['pageSize'] . ' OFFSET ' . $p['offset'], $params);
        json(['results' => array_map(fn(array $row): array => portalAccountDto($row), $rows),'count' => (int)fetchOne('SELECT COUNT(*) AS n' . $from, $params)['n'],'page' => $p['page'],'pageSize' => $p['pageSize']]);
    }
    if ($method === 'POST' && $route === '/portal-accounts') {
        $input = body(); portalOnly($input, ['clientId','username','password','active'], ['clientId','username','password']);
        $clientId = portalId($input['clientId']); $username = strtolower(portalText($input['username'], 'username', 100));
        if (preg_match('/^[a-z0-9][a-z0-9._@+\-]{0,99}$/D', $username) !== 1 || isset($input['active']) && !is_bool($input['active']) || !is_string($input['password'])) throw new HttpError(422, 'Usuario, contraseña o activación inválidos');
        $hash = hashPassword($input['password']);
        $row = tx(function (\PDO $pdo) use ($clientId, $username, $hash, $input, $user): array {
            portalRecord('Client', $clientId); $row = portalInsert('PortalAccount', ['clientId' => $clientId, 'username' => $username, 'passwordHash' => $hash, 'active' => $input['active'] ?? true]);
            audit('portal.account.create', 'PortalAccount', $row['id'], $user['id']); return $row;
        }); json(portalAccountDto($row), 201);
    }
    if (preg_match('#^/portal-accounts/([a-f0-9]{24})$#D', $route, $match)) {
        if ($method === 'GET') json(portalAccountDto(portalRecord('PortalAccount', $match[1])));
        if ($method === 'PATCH') {
            $input = body(); portalOnly($input, ['username','password','active']); $data = [];
            if (array_key_exists('username', $input)) { $data['username'] = strtolower(portalText($input['username'], 'username', 100)); if (preg_match('/^[a-z0-9][a-z0-9._@+\-]{0,99}$/D', $data['username']) !== 1) throw new HttpError(422, 'Usuario inválido'); }
            if (array_key_exists('active', $input)) { if (!is_bool($input['active'])) throw new HttpError(422, 'Activación inválida'); $data['active'] = $input['active']; }
            if (array_key_exists('password', $input)) { if (!is_string($input['password'])) throw new HttpError(422, 'Contraseña inválida'); $data['passwordHash'] = hashPassword($input['password']); }
            $row = tx(function (\PDO $pdo) use ($match, $data, $user): array {
                portalRecord('PortalAccount', $match[1], true); $row = portalUpdate('PortalAccount', $match[1], $data);
                if (isset($data['passwordHash']) || isset($data['username']) || array_key_exists('active', $data) && !$data['active']) $pdo->prepare('DELETE FROM `PortalSession` WHERE `accountId`=?')->execute([$match[1]]);
                audit('portal.account.update', 'PortalAccount', $match[1], $user['id']); return $row;
            }); json(portalAccountDto($row));
        }
    }
    return false;
}

function portalStaffReportDispatch(string $method, string $route, array $user): bool
{
    if ($method === 'GET' && $route === '/payment-reports') {
        $p = pagination(); $where = []; $params = [];
        if (($status = queryEnum('status', ['SUBMITTED','APPROVED','REJECTED'])) !== null) { $where[] = '`status`=?'; $params[] = $status; }
        if ($p['search'] !== '') { $where[] = '(`reference` LIKE ? OR `note` LIKE ? OR `clientId` IN (SELECT `id` FROM `Client` WHERE `name` LIKE ?))'; array_push($params, ...array_fill(0, 3, '%' . $p['search'] . '%')); }
        $from = ' FROM `PaymentReport`' . ($where ? ' WHERE ' . implode(' AND ', $where) : '');
        $rows = fetchAll('SELECT *' . $from . ' ORDER BY `createdAt` DESC,`id` DESC LIMIT ' . $p['pageSize'] . ' OFFSET ' . $p['offset'], $params);
        json(['results' => array_map(fn(array $row): array => portalReportDto($row, true), $rows),'count' => (int)fetchOne('SELECT COUNT(*) AS n' . $from, $params)['n'],'page' => $p['page'],'pageSize' => $p['pageSize']]);
    }
    if (preg_match('#^/payment-reports/([a-f0-9]{24})(?:/(approve|reject))?$#D', $route, $match)) {
        if ($method === 'GET' && !isset($match[2])) json(portalReportDto(portalRecord('PaymentReport', $match[1]), true));
        if ($method === 'POST' && isset($match[2])) {
            $input = body(); $approve = $match[2] === 'approve';
            portalOnly($input, $approve ? [] : ['reason'], $approve ? [] : ['reason']);
            $reason = $approve ? null : portalText($input['reason'], 'reason', 5000);
            $initial = portalRecord('PaymentReport', $match[1]);
            $keys = [];
            if ($approve) $keys[] = 'payment:portal:report-' . $initial['id'];
            $keys[] = 'client:' . $initial['clientId'];
            $keys[] = 'portal-report:' . $initial['id'];
            $result = billingWithLocks($keys, fn(): array => tx(function (\PDO $pdo) use ($initial, $approve, $reason, $user): array {
                $report = portalRecord('PaymentReport', $initial['id'], true);
                if ($approve && $report['status'] === 'APPROVED') {
                    if (financialDeleted('Payment', $report['paymentId'])) throw new HttpError(409, 'El pago aprobado fue eliminado y no puede aplicarse otra vez.', 'PAYMENT_DELETED');
                    financialRequirePresent('Invoice', $report['invoiceId']);
                    return ['report' => portalReportDto($report, true), 'payment' => portalRecord('Payment', $report['paymentId']), 'invoice' => portalInvoiceDto(portalRecord('Invoice', $report['invoiceId'])), 'reconnectionTaskIds' => [], 'replayed' => true];
                }
                if (!$approve && $report['status'] === 'REJECTED') return ['report' => portalReportDto($report, true), 'replayed' => true];
                if ($report['status'] !== 'SUBMITTED') throw new HttpError(409, 'Este reporte ya tiene una decisión definitiva');
                if ($approve) {
                    $payment = applyPayment(['invoiceId' => $report['invoiceId'],'amountCents' => (int)$report['amountCents'],'currency' => $report['currency'],'provider' => 'portal','externalReference' => 'report-' . $report['id']], $user['id']);
                    $report = portalUpdate('PaymentReport', $report['id'], ['status' => 'APPROVED','decidedAt' => now(),'decidedBy' => $user['id'],'paymentId' => $payment['payment']['id']]);
                    audit('portal.payment.approve', 'PaymentReport', $report['id'], $user['id']); return ['report' => portalReportDto($report, true)] + $payment;
                }
                $report = portalUpdate('PaymentReport', $report['id'], ['status' => 'REJECTED','rejectionReason' => $reason,'decidedAt' => now(),'decidedBy' => $user['id']]);
                audit('portal.payment.reject', 'PaymentReport', $report['id'], $user['id']); return ['report' => portalReportDto($report, true), 'replayed' => false];
            })); json($approve ? $result : $result['report']);
        }
    }
    return false;
}

function portalStaffContractDispatch(string $method, string $route, array $user): bool
{
    if ($method === 'GET' && $route === '/contracts') {
        $p = pagination(); $where = []; $params = [];
        if (($status = queryEnum('status', ['DRAFT','ACCEPTED','CANCELLED'])) !== null) { $where[] = '`status`=?'; $params[] = $status; }
        if ($p['search'] !== '') { $where[] = '(`title` LIKE ? OR `clientName` LIKE ?)'; array_push($params, ...array_fill(0, 2, '%' . $p['search'] . '%')); }
        $from = ' FROM `ServiceContract`' . ($where ? ' WHERE ' . implode(' AND ', $where) : '');
        $rows = fetchAll('SELECT *' . $from . ' ORDER BY `createdAt` DESC,`id` DESC LIMIT ' . $p['pageSize'] . ' OFFSET ' . $p['offset'], $params);
        json(['results' => array_map(fn(array $row): array => portalContractDto($row, true), $rows),'count' => (int)fetchOne('SELECT COUNT(*) AS n' . $from, $params)['n'],'page' => $p['page'],'pageSize' => $p['pageSize']]);
    }
    if ($method === 'POST' && $route === '/contracts') {
        $input = body(); portalOnly($input, ['serviceId','title','terms'], ['serviceId','title','terms']);
        $serviceId = portalId($input['serviceId']);
        $initial = portalRecord('Service', $serviceId);
        $title = portalText($input['title'], 'title'); $terms = portalText($input['terms'], 'terms', 100000);
        $row = billingWithLocks(['billing:' . $serviceId, 'client:' . $initial['clientId']], fn(): array => tx(function (\PDO $pdo) use ($serviceId, $title, $terms, $user): array {
            $service = portalRecord('Service', $serviceId, true);
            financialRequirePresent('Service', $serviceId);
            if ($service['desiredState'] === 'RETIRED') throw new HttpError(409, 'No se emite un contrato nuevo para un servicio retirado');
            $client = portalRecord('Client', $service['clientId']); $plan = portalRecord('Plan', $service['planId']);
            $data = ['clientId' => $client['id'],'serviceId' => $service['id'],'title' => $title,'terms' => $terms,'clientName' => $client['name'],'document' => $client['document'],'address' => $client['address'],'planName' => $plan['name'],'serviceType' => $service['type'] ?? 'Solo facturación','ipAddress' => $service['ipAddress'] ?? '','priceCents' => (int)$plan['priceCents'],'currency' => $plan['currency']];
            $row = portalInsert('ServiceContract', $data); audit('contract.create', 'ServiceContract', $row['id'], $user['id']); return $row;
        }));
        json(portalContractDto($row, true), 201);
    }
    if (preg_match('#^/contracts/([a-f0-9]{24})$#D', $route, $match)) {
        if ($method === 'GET') json(portalContractDto(portalRecord('ServiceContract', $match[1]), true));
        if ($method === 'PATCH') {
            $input = body(); portalOnly($input, ['title','terms','status']); $data = [];
            foreach (['title' => 200,'terms' => 100000] as $field => $max) if (array_key_exists($field, $input)) $data[$field] = portalText($input[$field], $field, $max);
            if (array_key_exists('status', $input)) { if ($input['status'] !== 'CANCELLED') throw new HttpError(422, 'El operador sólo puede cancelar el contrato; el cliente registra su aceptación'); $data['status'] = 'CANCELLED'; $data['cancelledAt'] = now(); }
            $row = tx(function (\PDO $pdo) use ($match, $data, $user): array {
                $old = portalRecord('ServiceContract', $match[1], true);
                if ($old['status'] !== 'DRAFT' && (isset($data['title']) || isset($data['terms']))) throw new HttpError(409, 'El texto de un contrato aceptado o cancelado es inmutable');
                $row = portalUpdate('ServiceContract', $old['id'], $data); audit('contract.update', 'ServiceContract', $row['id'], $user['id']); return $row;
            }); json(portalContractDto($row, true));
        }
    }
    return false;
}
