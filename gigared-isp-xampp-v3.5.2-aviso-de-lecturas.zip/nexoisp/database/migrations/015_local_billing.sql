-- Local billing references a client and plan without inventing network data.
-- This exact ALTER is repeatable after an interrupted migration.
ALTER TABLE `Service` MODIFY COLUMN `routerId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NULL, MODIFY COLUMN `type` VARCHAR(20) NULL, MODIFY COLUMN `ipAddress` VARCHAR(45) CHARACTER SET ascii COLLATE ascii_bin NULL;

CREATE TABLE IF NOT EXISTS `LocalBillingService` (
  `serviceId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `createdBy` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`serviceId`),
  KEY `local_billing_actor_idx` (`createdBy`),
  CONSTRAINT `local_billing_service_fk` FOREIGN KEY (`serviceId`) REFERENCES `Service` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `local_billing_actor_fk` FOREIGN KEY (`createdBy`) REFERENCES `User` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
