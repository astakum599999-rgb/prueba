-- Logical deletions preserve financial references, periods and audit history.
CREATE TABLE IF NOT EXISTS `FinanceDeletion` (
  `entityType` VARCHAR(16) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `entityId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `clientId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `actorId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `deletedAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `snapshot` JSON NOT NULL,
  PRIMARY KEY (`entityType`,`entityId`),
  KEY `finance_deletion_client_date_idx` (`clientId`,`deletedAt`),
  KEY `finance_deletion_actor_idx` (`actorId`),
  CONSTRAINT `finance_deletion_client_fk` FOREIGN KEY (`clientId`) REFERENCES `Client` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `finance_deletion_actor_fk` FOREIGN KEY (`actorId`) REFERENCES `User` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `finance_deletion_type_check` CHECK (`entityType` IN ('Invoice','Payment','Service'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
