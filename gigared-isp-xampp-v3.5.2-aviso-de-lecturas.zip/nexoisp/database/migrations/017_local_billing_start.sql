-- Explicit billing starts are separate from immutable service creation dates.
-- Existing services have no schedule row and keep their original calendar.
CREATE TABLE IF NOT EXISTS `LocalBillingSchedule` (
  `serviceId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `startOn` DATE NOT NULL,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`serviceId`),
  CONSTRAINT `local_billing_schedule_service_fk` FOREIGN KEY (`serviceId`) REFERENCES `LocalBillingService` (`serviceId`) ON DELETE RESTRICT,
  CONSTRAINT `local_billing_schedule_date_check` CHECK (`startOn` BETWEEN '2000-01-01' AND '2100-12-31')
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
