-- Store only the total PPPoE sessions from a complete /ppp/active observation.
-- Individual foreign usernames, addresses and credentials are never persisted.
CREATE TABLE IF NOT EXISTS `RouterPppOnlineCount` (
  `routerId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `pppoeCount` INT UNSIGNED NOT NULL,
  `observedAt` DATETIME(3) NOT NULL,
  `updatedAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`routerId`),
  CONSTRAINT `pppoe_online_router_fk` FOREIGN KEY (`routerId`) REFERENCES `Router` (`id`) ON DELETE CASCADE,
  CONSTRAINT `pppoe_online_count_check` CHECK (`pppoeCount` <= 20000)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
