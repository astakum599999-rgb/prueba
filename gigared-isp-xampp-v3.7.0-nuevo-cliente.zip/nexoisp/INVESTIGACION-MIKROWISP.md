# Referencia del alta de clientes

El 4 de noviembre de2026 se consultó el demo oficial indicado por el usuario:
https://demo.mikrosystem.net/admin/.
Se inició sesión con el acceso de demostración proporcionado y se abrió
`#ajax/usuarios?action=adduser`. Se inspeccionaron el DOM, las etiquetas,
los campos y la distribución visual. No se guardaron clientes en el demo.

El formulario observado usa tres pasos, una franja horizontal con número y
nombre del paso, campos con etiqueta a la izquierda y botones Anterior/Siguiente.
El primer paso muestra ID automático, número de identificación, nombre completo,
dirección, ubicación, teléfonos y correo. El bloque de servicios contiene router,
perfil, tipo/red IPv4, IP, usuario y contraseña PPP/Hotspot y coordenadas.

| Referencia observada | Integración en GIGARED ISP |
| --- | --- |
| ID cliente automático | Código GG generado al confirmar la reserva local. |
| N.º Identificación / Nombre Completo | DNI/RUC/cédula y nombre del titular. |
| Dirección, ubicación, teléfonos, E-mail | Dirección, zona, contacto y correo; notas internas existentes. |
| Formulario por pasos | Datos personales, Ubicación GPS y Servicios dentro del modal existente. |
| Router / Perfil Internet | Router real y plan activo con perfil validado en RouterOS. |
| Redes IPv4 / IPv4 | Pools o subredes reales, sugerencia y nueva validación de ocupación al guardar. |
| User PPP/HS / password PPP/HS | Credenciales específicas del servicio, ocultación de contraseña y cifrado local. |
| Coordenadas | Google Maps interactivo con clic y marcador arrastrable; latitud/longitud editables. |

El paso GPS incorpora el mapa solicitado. Se mantienen la marca GIGARED ISP,
sus temas claro/oscuro, roles y módulos de facturación existentes. La entrega
implementa los campos y el aprovisionamiento solicitados sobre PHP/MySQL de
XAMPP; las etiquetas y la organización se adaptan a esos módulos.

El alta usa una reserva durable e intención cifrada, comprobación de duplicados,
un permiso específico de creación y lectura posterior. No hay una transacción
distribuida entre MySQL y RouterOS: un resultado incierto se conserva y se verifica
antes de permitir un reintento. Las APIs propias están descritas en NUEVO-CLIENTE.txt.

Para Google Maps se utiliza Maps JavaScript API e importación de las bibliotecas
`maps` y `marker`, con `AdvancedMarkerElement`. Requiere clave de un proyecto
de Google Cloud, facturación y restricciones de referente/API adecuadas:
https://developers.google.com/maps/documentation/javascript/get-api-key
https://developers.google.com/maps/documentation/javascript/advanced-markers/overview

La validación automatizada del mapa usa una implementación del contrato del SDK
sin llamadas facturables a Google. La validación de cuentas utiliza fixtures reales
de los protocolos REST y Socket, sin conectarse a equipos del operador.
