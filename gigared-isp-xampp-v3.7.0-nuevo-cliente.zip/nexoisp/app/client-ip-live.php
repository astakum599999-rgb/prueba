<?php
declare(strict_types=1);
namespace Nexo;

use DateTimeImmutable;
use DateTimeZone;
use Throwable;

require_once __DIR__ . '/client-ip-access.php';
require_once __DIR__ . '/dashboard-online.php';

const CLIENT_IP_LIVE_INTERVAL = 1;
const CLIENT_IP_LIVE_MAX_AGE = 5;
const CLIENT_IP_LIVE_LIMIT = 20000;

function clientIpLiveAfter(int $seconds, ?string $from = null): string
{
    return (new DateTimeImmutable($from ?? 'now', new DateTimeZone('UTC')))->modify('+' . max(0, $seconds) . ' seconds')->format('Y-m-d H:i:s.v');
}

function clientIpLiveRetrySeconds(int $failures): int
{
    return min(30, 2 * (2 ** min(4, max(0, $failures - 1))));
}

/** Normalize previous 15/30-second reservations without rewriting installed data. */
function clientIpLiveNextQueryAt(array $state): string
{
    $scheduled = $state['nextQueryAt'] ?? '1970-01-01 00:00:00.000';
    $delay = CLIENT_IP_LIVE_INTERVAL;
    if (($state['status'] ?? '') === 'ERROR') {
        $anchor = $state['updatedAt'] ?? null;
        $delay = clientIpLiveRetrySeconds((int)($state['failures'] ?? 1));
    } elseif (($state['status'] ?? '') === 'DEFERRED') {
        $anchor = $state['updatedAt'] ?? null;
    } else {
        $anchor = $state['lastStartedAt'] ?? $state['lastSuccessAt'] ?? $state['updatedAt'] ?? null;
    }
    if (!is_string($anchor)) return $scheduled;
    $currentCadence = clientIpLiveAfter($delay, $anchor);
    return $scheduled < $currentCadence ? $scheduled : $currentCadence;
}

/** Return raw identities only for current, locally associated PPP accounts. */
function clientIpLiveAccounts(array $clientIds = [], ?string $routerId = null): array
{
    if ($clientIds === [] && $routerId === null) return [];
    $parameters = $routerId !== null ? [$routerId] : $clientIds;
    $scope = $routerId !== null ? 's.routerId=?' : 's.clientId IN (' . implode(',', array_fill(0, count($clientIds), '?')) . ')';
    $sources = fetchAll("SELECT s.routerId,s.clientId,s.username,s.id AS secretId,s.pppService FROM `RouterSecretImport` s
        WHERE $scope AND s.present=1 AND s.pppService IN ('pppoe','any')", $parameters);
    $services = fetchAll("SELECT s.routerId,s.clientId,s.username,s.id AS serviceId,'pppoe' AS pppService FROM `Service` s
        WHERE $scope AND s.type='PPPOE' AND s.desiredState<>'RETIRED' AND (s.appliedState IS NULL OR s.appliedState<>'RETIRED')", $parameters);
    $accounts = [];
    foreach (array_merge($sources, $services) as $account) {
        if (!is_string($account['username']) || $account['username'] === '') continue;
        // Keep exact username bytes; presentation decoding is never an identity.
        $key = $account['routerId'] . ':' . $account['clientId'] . ':' . bin2hex($account['username']);
        $accounts[$key] = $account;
    }
    return array_values($accounts);
}

/** Validate the complete bounded print before changing any cached observation. */
function clientIpLiveRead(RouterTransport $transport, ?int &$pppoeCount = null): array
{
    $pppoeCount = null;
    try {
        $rows = $transport->print('/ppp/active', [], ['.proplist' => '.id,name,address,service']);
        if (!array_is_list($rows) || count($rows) > CLIENT_IP_LIVE_LIMIT) throw new HttpError(502, 'La lista de sesiones PPP no es válida.', 'INVALID_ROUTER_RESPONSE');
        $sessions = []; $seen = []; $totalPppoe = 0;
        foreach ($rows as $row) {
            if (!is_array($row) || !is_string($row['.id'] ?? null) || preg_match('/^\*[a-z0-9]{1,32}$/iD', $row['.id']) !== 1 ||
                !is_string($row['name'] ?? null) || $row['name'] === '' || strlen($row['name']) > 1020 ||
                !is_string($row['address'] ?? null) || strlen($row['address']) > 45 ||
                !is_string($row['service'] ?? null) || $row['service'] === '' || strlen($row['service']) > 32 ||
                isset($seen[$row['.id']])) throw new HttpError(502, 'La lista de sesiones PPP no es válida.', 'INVALID_ROUTER_RESPONSE');
            $seen[$row['.id']] = true;
            // Count active CONNECTIONS, including accounts not imported locally.
            if ($row['service'] === 'pppoe') $totalPppoe++;
            $address = clientIpAddress($row['address']);
            if ($address === null) continue;
            // Persist only selected fields; hex preserves legacy Socket names.
            $sessions[] = ['usernameHex' => bin2hex($row['name']), 'address' => $address, 'service' => $row['service']];
        }
        // Publish no partial count if any later row fails validation.
        $pppoeCount = $totalPppoe;
        return $sessions;
    } finally {
        $transport->close();
    }
}

/** Persist a validated observation shared by direct reads and the full router cycle. */
function clientIpLiveStore(array $router, array $sessions, int $pppoeCount, string $started, string $observed): void
{
    $owners = [];
    foreach (clientIpLiveAccounts([], $router['id']) as $account) $owners[bin2hex($account['username'])] = true;
    $sessions = array_values(array_filter($sessions, static fn(array $session): bool => isset($owners[$session['usernameHex']])));
    tx(function (\PDO $pdo) use ($router, $observed, $started, $sessions, $pppoeCount): void {
        $pdo->prepare('INSERT IGNORE INTO `RouterPppActiveCache` (routerId) VALUES (?)')->execute([$router['id']]);
        $pdo->prepare("UPDATE `RouterPppActiveCache` SET status='SUCCESS',lastStartedAt=?,lastSuccessAt=?,nextQueryAt=?,sessions=?,lastErrorCode=NULL,lastError=NULL,failures=0,updatedAt=? WHERE routerId=?")
            ->execute([$started, $observed, clientIpLiveAfter(CLIENT_IP_LIVE_INTERVAL, $started), json_encode($sessions, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES), $observed, $router['id']]);
        dashboardOnlineStore($router['id'], $pppoeCount, $observed);
    });
}

/** A failed complete observation immediately invalidates the shared live cache. */
function clientIpLiveStoreFailure(string $routerId, Throwable $error): void
{
    db()->prepare('INSERT IGNORE INTO `RouterPppActiveCache` (routerId) VALUES (?)')->execute([$routerId]);
    $state = fetchOne('SELECT failures FROM `RouterPppActiveCache` WHERE routerId=?', [$routerId]);
    $failures = min(1000, (int)($state['failures'] ?? 0) + 1);
    $code = $error instanceof HttpError && $error->errorCode === 'INVALID_ROUTER_RESPONSE' ? 'INVALID_ROUTER_RESPONSE' : 'ROUTER_UNAVAILABLE';
    $message = $code === 'INVALID_ROUTER_RESPONSE' ? 'El router devolvió sesiones PPP inválidas. No se muestra una IP antigua como actual.' : 'No se pudieron actualizar las sesiones PPP. Se reintentará automáticamente.';
    db()->prepare("UPDATE `RouterPppActiveCache` SET status='ERROR',nextQueryAt=?,lastErrorCode=?,lastError=?,failures=?,updatedAt=? WHERE routerId=?")
        ->execute([clientIpLiveAfter(clientIpLiveRetrySeconds($failures)), $code, $message, $failures, now(), $routerId]);
}

/** One shared reservation and one print per due router, never one per customer. */
function clientIpLiveRefresh(array $router): bool
{
    $key = 'router:' . $router['id'];
    if (!lock($key, 0)) return false;
    try {
        db()->prepare('INSERT IGNORE INTO `RouterPppActiveCache` (routerId) VALUES (?)')->execute([$router['id']]);
        $state = fetchOne('SELECT * FROM `RouterPppActiveCache` WHERE routerId=?', [$router['id']]);
        if ($state === null || clientIpLiveNextQueryAt($state) > now()) return false;
        if (function_exists(__NAMESPACE__ . '\\clientPppoeEditPending') && clientPppoeEditPending($router['id'])) {
            db()->prepare("UPDATE `RouterPppActiveCache` SET status='DEFERRED',nextQueryAt=?,lastErrorCode='PPPOE_EDIT_PENDING',lastError=?,updatedAt=? WHERE routerId=?")
                ->execute([clientIpLiveAfter(CLIENT_IP_LIVE_INTERVAL), 'La consulta de IP está aplazada hasta verificar el cambio PPP pendiente.', now(), $router['id']]);
            return false;
        }
        $started = now();
        db()->prepare("UPDATE `RouterPppActiveCache` SET status='RUNNING',lastStartedAt=?,nextQueryAt=?,updatedAt=? WHERE routerId=?")
            ->execute([$started, clientIpLiveAfter(90), $started, $router['id']]);
        try {
            $pppoeCount = null;
            $sessions = clientIpLiveRead(secretImportTransport($router), $pppoeCount);
            clientIpLiveStore($router, $sessions, $pppoeCount, $started, now());
        } catch (Throwable $error) {
            clientIpLiveStoreFailure($router['id'], $error);
        }
        return true;
    } finally {
        unlock($key);
    }
}

function clientIpLiveFresh(?array $state): bool
{
    if ($state === null || !in_array($state['status'], ['SUCCESS','RUNNING'], true) || (int)$state['failures'] > 0 || !is_string($state['lastSuccessAt'])) return false;
    try {
        $age = microtime(true) - (float)(new DateTimeImmutable($state['lastSuccessAt'], new DateTimeZone('UTC')))->format('U.u');
        return $age >= 0 && $age < CLIENT_IP_LIVE_MAX_AGE;
    } catch (Throwable) { return false; }
}

function clientIpLiveBatch(array $input, array $actor): array
{
    if (!in_array($actor['role'], ['ADMIN','TECHNICIAN'], true)) throw new HttpError(403, 'No dispone de permisos para consultar sesiones PPP.', 'FORBIDDEN');
    if (array_diff(array_keys($input), ['clientIds']) || !isset($input['clientIds']) || !is_array($input['clientIds']) || !array_is_list($input['clientIds']) || count($input['clientIds']) > 100) {
        throw new HttpError(422, 'Envía clientIds como una lista de hasta 100 clientes.', 'VALIDATION_ERROR');
    }
    foreach ($input['clientIds'] as $id) if (!is_string($id) || preg_match('/^[a-f0-9]{24}$/D', $id) !== 1) throw new HttpError(422, 'La lista contiene un identificador de cliente inválido.', 'VALIDATION_ERROR');
    $ids = array_values(array_unique($input['clientIds']));
    $response = ['intervalSeconds' => CLIENT_IP_LIVE_INTERVAL, 'expiresAfterSeconds' => CLIENT_IP_LIVE_MAX_AGE, 'serverTime' => (new DateTimeImmutable('now', new DateTimeZone('UTC')))->format('Y-m-d\TH:i:s.v\Z'), 'results' => [], 'routers' => [], 'errors' => [], 'processed' => 0];
    if ($ids === []) return $response;
    $slots = implode(',', array_fill(0, count($ids), '?'));
    if (count(fetchAll("SELECT id FROM `Client` WHERE id IN ($slots)", $ids)) !== count($ids)) throw new HttpError(404, 'Uno de los clientes ya no está disponible.', 'NOT_FOUND');
    $accounts = clientIpLiveAccounts($ids);
    $routerIds = array_values(array_unique(array_column($accounts, 'routerId')));
    $routers = []; $states = []; $owners = [];
    if ($routerIds) {
        $routerSlots = implode(',', array_fill(0, count($routerIds), '?'));
        $rows = fetchAll("SELECT r.*,c.nextQueryAt AS cacheNextQueryAt FROM `Router` r LEFT JOIN `RouterPppActiveCache` c ON c.routerId=r.id WHERE r.id IN ($routerSlots) ORDER BY COALESCE(c.nextQueryAt,'1970-01-01'),r.id", $routerIds);
        foreach ($rows as $router) {
            $routers[$router['id']] = $router;
            if (!in_array($router['transport'], ['REST','SOCKET'], true)) continue;
            if ($response['processed'] < 5 && clientIpLiveRefresh($router)) $response['processed']++;
        }
        foreach ($routers as $routerId => $router) {
            $state = fetchOne('SELECT * FROM `RouterPppActiveCache` WHERE routerId=?', [$routerId]);
            $states[$routerId] = $state;
            foreach (clientIpLiveAccounts([], $routerId) as $account) $owners[$routerId][bin2hex($account['username'])][$account['clientId']] = true;
            $response['routers'][] = ['routerId' => $routerId, 'routerName' => $router['name'], 'status' => $state['status'] ?? 'WAITING',
                'lastSuccessAt' => $state['lastSuccessAt'] ?? null, 'nextQueryAt' => $state['nextQueryAt'] ?? null, 'stale' => !clientIpLiveFresh($state)];
            if ($state !== null && $state['lastError'] !== null) $response['errors'][] = ['routerId' => $routerId, 'message' => $state['lastError']];
        }
    }
    $grouped = [];
    foreach ($accounts as $account) $grouped[$account['clientId']][] = $account;
    foreach ($ids as $clientId) {
        $addresses = []; $stale = false; $pending = false; $observed = null;
        foreach ($grouped[$clientId] ?? [] as $account) {
            $state = $states[$account['routerId']] ?? null;
            if (!clientIpLiveFresh($state)) {
                $pending = $pending || $state === null || in_array($state['status'], ['WAITING','RUNNING','DEFERRED'], true);
                $stale = true;
                continue;
            }
            // Ambiguous local ownership must never associate another customer's IP.
            if (count($owners[$account['routerId']][bin2hex($account['username'])] ?? []) !== 1) { $stale = true; continue; }
            $observed = $observed === null || $state['lastSuccessAt'] < $observed ? $state['lastSuccessAt'] : $observed;
            $sessions = is_string($state['sessions']) ? json_decode($state['sessions'], true, 32, JSON_THROW_ON_ERROR) : [];
            foreach ($sessions as $session) {
                if (($session['usernameHex'] ?? null) !== bin2hex($account['username']) || ($account['pppService'] === 'pppoe' && ($session['service'] ?? null) !== 'pppoe')) continue;
                $entry = clientIpEntry(['address' => $session['address'] ?? null, 'routerId' => $account['routerId'], 'routerName' => $routers[$account['routerId']]['name'],
                    'username' => $account['username'], 'observedAt' => $state['lastSuccessAt'], ...array_intersect_key($account, array_flip(['serviceId','secretId']))], 'PPP_ACTIVE');
                if ($entry !== null) $addresses[$entry['routerId'] . ':' . $entry['address']] = $entry;
            }
        }
        // A partial/uncertain observation cannot present old IPs as current.
        if ($stale) { $addresses = []; $observed = null; }
        $status = !isset($grouped[$clientId]) ? 'NO_ACCOUNT' : ($addresses ? 'FRESH' : ($pending ? 'PENDING' : ($stale ? 'STALE' : 'NO_SESSION')));
        $message = match ($status) {
            'NO_ACCOUNT' => 'Este cliente no tiene una cuenta PPP asociada.',
            'NO_SESSION' => 'No se observa una sesión PPP activa.',
            'PENDING' => 'Actualización de IP pendiente; se consultará automáticamente.',
            'STALE' => 'No hay una observación reciente de IP activa. Se reintentará automáticamente.',
            default => 'IP observada en una sesión PPP activa; actualización automática cada segundo.',
        };
        $response['results'][] = ['clientId' => $clientId, 'addresses' => array_values($addresses), 'status' => $status, 'stale' => $stale,
            'observedAt' => $observed, 'message' => $message];
    }
    $response['serverTime'] = (new DateTimeImmutable('now', new DateTimeZone('UTC')))->format('Y-m-d\TH:i:s.v\Z');
    return $response;
}

function clientIpLiveDispatch(string $method, string $route): bool
{
    if ($method !== 'POST' || $route !== '/clients/ip-addresses/active') return false;
    $actor = permit('ADMIN', 'TECHNICIAN');
    rateLimit('client-ip-live:' . $actor['id'], 600, 60);
    if (function_exists('set_time_limit')) set_time_limit(90);
    ignore_user_abort(true);
    json(clientIpLiveBatch(body(), $actor));
}
