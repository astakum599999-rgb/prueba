<?php
declare(strict_types=1);
namespace Nexo;

/** Unsigned IPv4 arithmetic on the 64-bit PHP included in current XAMPP. */
function provisionIpNumber(string $ip): ?int
{
    if (PHP_INT_SIZE < 8 || filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) === false) return null;
    return unpack('N', inet_pton($ip))[1];
}

function provisionIpText(int $ip): string { return inet_ntop(pack('N', $ip)); }

function provisionUsableIp(string $ip): bool
{
    $value = provisionIpNumber($ip);
    return $value !== null && $value >= 16777216 && $value < 3758096384 &&
        !($value >= 2130706432 && $value <= 2147483647) && !($value >= 2851995648 && $value <= 2852061183);
}

/** No expansion into individual addresses, including large CIDR blocks. */
function provisionIpRange(string $value, bool $hostsOnly = false): ?array
{
    $value = trim($value);
    if (preg_match('~^([^/]+)/([0-9]{1,2})$~D', $value, $m)) {
        $address = provisionIpNumber($m[1]); $prefix = (int)$m[2];
        if ($address === null || $prefix > 32) return null;
        $size = 2 ** (32 - $prefix); $start = (int)(intdiv($address, (int)$size) * $size);
        return [$start + ($hostsOnly && $prefix < 31 ? 1 : 0), $start + (int)$size - 1 - ($hostsOnly && $prefix < 31 ? 1 : 0)];
    }
    if (str_contains($value, '-')) {
        $parts = explode('-', $value); if (count($parts) !== 2) return null;
        $a = provisionIpNumber(trim($parts[0])); $b = provisionIpNumber(trim($parts[1]));
        return $a !== null && $b !== null && $a <= $b ? [$a,$b] : null;
    }
    $single = provisionIpNumber($value); return $single === null ? null : [$single,$single];
}

function provisionRanges(string $value, bool $hostsOnly = false): array
{
    if ($value === '' || strlen($value) > 16000) throw new HttpError(502, 'El rango de direcciones del router no es válido.', 'INVALID_ROUTER_RESPONSE');
    $result = [];
    foreach (explode(',', $value) as $part) {
        $range = provisionIpRange($part, $hostsOnly);
        if ($range === null || count($result) >= 1000) throw new HttpError(502, 'El rango de direcciones del router no es válido.', 'INVALID_ROUTER_RESPONSE');
        $result[] = $range;
    }
    return $result;
}

function provisionMergedRanges(array $ranges): array
{
    usort($ranges, static fn(array $a, array $b): int => $a[0] <=> $b[0]);
    $merged = [];
    foreach ($ranges as [$a,$b]) {
        $last = count($merged)-1;
        if ($last >= 0 && $a <= $merged[$last][1]+1) $merged[$last][1] = max($b,$merged[$last][1]);
        else $merged[] = [$a,$b];
    }
    return $merged;
}

function provisionNextIp(array $ranges, array $occupied): ?string
{
    $occupied = provisionMergedRanges([...$occupied,[0,16777215],[2130706432,2147483647],[2851995648,2852061183],[3758096384,4294967295]]);
    foreach (provisionMergedRanges($ranges) as [$start,$end]) {
        $candidate = $start;
        foreach ($occupied as [$a,$b]) {
            if ($b < $candidate) continue;
            if ($a > $candidate) break;
            $candidate = $b+1; if ($candidate > $end) break;
        }
        if ($candidate <= $end) return provisionIpText($candidate);
    }
    return null;
}

function provisionIpInRanges(string $ip, array $ranges): bool
{
    $value = provisionIpNumber($ip); if ($value === null) return false;
    foreach ($ranges as [$a,$b]) if ($value >= $a && $value <= $b) return true;
    return false;
}
