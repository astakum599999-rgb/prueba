import { useEffect, useRef, useState, type FormEvent, type ReactNode } from 'react';
import { ArrowLeft, ArrowRight, Check, CheckCircle2, Eye, EyeOff, LoaderCircle, RefreshCw, Save } from 'lucide-react';
import { api, post } from './api';
import { errorMessage, Modal, money } from './ui';
import GoogleMapPicker, {type MapSettings} from './GoogleMapPicker';
import type { User } from './types';

export interface ProvisionState {id:string;clientId:string;serviceId:string;routerId:string;type:string;status:string;remoteId:string|null;message:string|null;createdAt:string;updatedAt:string}
interface Options {routers:{id:string;name:string}[];plans:{id:string;name:string;pppoeProfile:string;profileRouterId:string|null;priceCents:number;currency:string;downloadKbps:number;uploadKbps:number}[];map:MapSettings;pools:{id:string;label:string;ranges:string;source:string}[];suggestedIp:string|null;defaultPoolId:string|null}
const emptyMap:MapSettings={googleMapsApiKey:'',googleMapsMapId:'DEMO_MAP_ID',centerLatitude:-12.0464,centerLongitude:-77.0428};
function requestKey():string{const bytes=crypto.getRandomValues(new Uint8Array(16));bytes[6]=(bytes[6]&15)|64;bytes[8]=(bytes[8]&63)|128;const hex=[...bytes].map(value=>value.toString(16).padStart(2,'0')).join('');return `${hex.slice(0,8)}-${hex.slice(8,12)}-${hex.slice(12,16)}-${hex.slice(16,20)}-${hex.slice(20)}`;}
function Field({label,children,hint}:{label:string;children:ReactNode;hint?:string}){return <div className="registration-field"><label>{label}</label><div>{children}{hint&&<span className="field-hint">{hint}</span>}</div></div>;}

export function ProvisionStatus({initial,saved}:{initial:ProvisionState;saved:()=>void}){
 const [state,setState]=useState(initial),[busy,setBusy]=useState(false),[error,setError]=useState('');
 useEffect(()=>setState(initial),[initial.id,initial.status,initial.updatedAt]);
 const act=async(action:'verify'|'retry')=>{setBusy(true);setError('');try{const result=await post<ProvisionState>(`/clients/provision/${state.id}/${action}`);setState(result);saved();}catch(reason){setError(errorMessage(reason));}finally{setBusy(false);}};
 return <section className={`registration-result ${state.status==='CONFIRMED'?'confirmed':''}`} aria-label="Estado del alta en MikroTik"><h3>{state.status==='CONFIRMED'?<CheckCircle2 size={21}/>:<RefreshCw size={21}/>} {state.status==='CONFIRMED'?'Cliente registrado y servicio confirmado':'Cliente guardado · activación pendiente'}</h3><p>{state.status==='CONFIRMED'?'El cliente y su servicio están registrados; MikroTik confirmó la cuenta o cola correspondiente.':state.message||'Consulta el router para confirmar el resultado antes de volver a crear el servicio.'}</p><p className="subtle">Referencia de alta: <code>{state.id}</code></p>{state.status!=='CONFIRMED'&&<div className="inline-gap"><button type="button" className="button" disabled={busy} onClick={()=>void act('verify')}><RefreshCw size={16}/>Verificar alta</button><button type="button" className="button primary" disabled={busy} onClick={()=>void act('retry')}>{busy?<LoaderCircle size={16} className="spinner"/>:<Save size={16}/>}Reintentar este servicio</button></div>}{error&&<div className="alert error" role="alert">{error}</div>}</section>;
}

export default function ClientRegistration({user,close,saved,notify}:{user:User;close:()=>void;saved:()=>void;notify:(message:string,error?:boolean)=>void}) {
 const [step,setStep]=useState(0),[options,setOptions]=useState<Options|null>(null),[optionsError,setOptionsError]=useState(''),[loading,setLoading]=useState(false),[revision,setRevision]=useState(0);
 const [person,setPerson]=useState({name:'',document:'',phone:'',email:'',address:'',zone:'',latitude:'',longitude:'',notes:''});
 const [service,setService]=useState({routerId:'',planId:'',type:'PPPOE',ipAddress:'',poolId:'',username:'',password:''});
 const [busy,setBusy]=useState(false),[error,setError]=useState(''),[showPassword,setShowPassword]=useState(false),[result,setResult]=useState<ProvisionState|null>(null);
 const key=useRef(requestKey()),form=useRef<HTMLFormElement>(null),manualIp=useRef(false);
 const [map,setMap]=useState<MapSettings>(emptyMap),[mapKey,setMapKey]=useState(''),[mapId,setMapId]=useState(''),[mapBusy,setMapBusy]=useState(false),[mapError,setMapError]=useState('');
 useEffect(()=>{
   const controller=new AbortController();setLoading(true);setOptionsError('');
   const params=new URLSearchParams();if(service.routerId)params.set('routerId',service.routerId);if(service.planId)params.set('planId',service.planId);if(service.poolId)params.set('poolId',service.poolId);
   void api<Options>('/client-registration/options?'+params,{signal:controller.signal,cache:'no-store'}).then(data=>{if(controller.signal.aborted)return;setOptions(data);setMap(data.map);setMapKey(data.map.googleMapsApiKey);setMapId(data.map.googleMapsMapId);if(service.routerId){const selected=data.pools.some(pool=>pool.id===service.poolId)?service.poolId:data.defaultPoolId||'';setService(old=>({...old,poolId:selected,ipAddress:manualIp.current?old.ipAddress:data.suggestedIp||''}));}}).catch(reason=>{if(!controller.signal.aborted)setOptionsError(errorMessage(reason));}).finally(()=>{if(!controller.signal.aborted)setLoading(false);});
   return()=>controller.abort();
 },[service.routerId,service.planId,service.poolId,revision]);
 const setPersonal=(field:keyof typeof person,value:string)=>setPerson(old=>({...old,[field]:value}));
 const choose=(field:'routerId'|'planId'|'type'|'poolId',value:string)=>{manualIp.current=false;setService(old=>({...old,[field]:value,ipAddress:'',...(field==='routerId'?{planId:'',poolId:''}:field==='planId'?{poolId:''}:{})}));};
 const next=()=>{setError('');if(!form.current?.reportValidity())return;if(step===1&&Boolean(person.latitude)!==Boolean(person.longitude)){setError('Selecciona la ubicación o completa ambas coordenadas.');return;}setStep(value=>Math.min(2,value+1));};
 const recover=async()=>{setBusy(true);try{const state=await api<ProvisionState>('/clients/provision/request/'+key.current);setResult(state);setService(old=>({...old,password:''}));setError('');saved();}catch(reason){setError(errorMessage(reason));}finally{setBusy(false);}};
 const submit=async(event:FormEvent)=>{
   event.preventDefault();if(step<2){next();return;}setBusy(true);setError('');
   try{
    const client={...person,latitude:person.latitude===''?null:Number(person.latitude),longitude:person.longitude===''?null:Number(person.longitude)};
    const state=await post<ProvisionState>('/clients/provision',{requestKey:key.current,client,service:service.type==='SIMPLE_QUEUE'?{routerId:service.routerId,planId:service.planId,type:service.type,ipAddress:service.ipAddress,poolId:service.poolId}:service});
    setResult(state);setService(old=>({...old,password:''}));saved();notify(state.status==='CONFIRMED'?'Cliente y servicio activados en MikroTik.':'Cliente guardado. Comprueba la activación pendiente.');
   }catch(reason){setError(errorMessage(reason));}finally{setBusy(false);}
 };
 const configureMap=async()=>{setMapBusy(true);setMapError('');try{const settings=await api<MapSettings>('/client-registration/settings',{method:'PATCH',body:JSON.stringify({googleMapsApiKey:mapKey.trim(),googleMapsMapId:mapId.trim()||'DEMO_MAP_ID'})});setMap(settings);}catch(reason){setMapError(errorMessage(reason));}finally{setMapBusy(false);}};
 const selectedPlan=options?.plans.find(plan=>plan.id===service.planId);
 const plans=options?.plans.filter(plan=>!plan.profileRouterId||plan.profileRouterId===service.routerId)||[];
 const lat=Number(person.latitude),lng=Number(person.longitude),point=person.latitude!==''&&person.longitude!==''&&Number.isFinite(lat)&&Number.isFinite(lng)?{lat,lng}:null;
 return <Modal title="Nuevo cliente" description="Registra al titular, su ubicación y el servicio de Internet." close={busy?()=>undefined:close} wide><div className="client-registration">
 {result?<><ProvisionStatus initial={result} saved={saved}/><div className="modal-footer"><button className="button primary" onClick={close}>Volver a clientes</button></div></>:<>
 <ol className="registration-steps" aria-label="Pasos del nuevo cliente">{[['Datos personales','Nombre, dirección, contacto'],['Ubicación GPS','Mapa y coordenadas'],['Servicios','Router, plan y cuenta']].map(([title,hint],index)=><li key={title} className={step===index?'current':step>index?'complete':''} aria-current={step===index?'step':undefined}><span>{step>index?<Check size={15}/>:index+1}</span><div><strong>{title}</strong><small>{hint}</small></div></li>)}</ol>
 {error&&<div className="alert error" role="alert"><div>{error}<button className="button small ghost" type="button" onClick={()=>void recover()} disabled={busy}>Consultar estado de esta solicitud</button></div></div>}
 <form ref={form} onSubmit={event=>void submit(event)}><fieldset disabled={busy} className="registration-fields">
 {step===0&&<>
 <Field label="ID cliente" hint="Se genera automáticamente al registrar."><input aria-label="ID cliente" value="Automático" disabled/></Field>
 <Field label="N.º de identificación" hint="DNI, RUC o cédula del titular."><input aria-label="N.º de identificación" maxLength={500} value={person.document} onChange={event=>setPersonal('document',event.target.value)}/></Field>
 <Field label="Nombres y apellidos *"><input aria-label="Nombres y apellidos" autoComplete="name" required maxLength={200} value={person.name} onChange={event=>setPersonal('name',event.target.value)}/></Field>
 <Field label="Dirección principal"><input aria-label="Dirección principal" autoComplete="street-address" maxLength={500} value={person.address} onChange={event=>setPersonal('address',event.target.value)}/></Field>
 <Field label="Zona / ubicación"><input aria-label="Zona / ubicación" maxLength={500} value={person.zone} onChange={event=>setPersonal('zone',event.target.value)}/></Field>
 <Field label="Teléfono / celular"><input aria-label="Teléfono / celular" autoComplete="tel" type="tel" maxLength={500} value={person.phone} onChange={event=>setPersonal('phone',event.target.value)}/></Field>
 <Field label="E-mail"><input aria-label="E-mail" autoComplete="email" type="email" maxLength={254} value={person.email} onChange={event=>setPersonal('email',event.target.value)}/></Field>
 <Field label="Notas"><textarea aria-label="Notas" rows={3} maxLength={5000} value={person.notes} onChange={event=>setPersonal('notes',event.target.value)}/></Field>
 </>}
 {step===1&&<>
 <GoogleMapPicker settings={map} value={point} onChange={value=>setPerson(old=>({...old,latitude:String(value.lat),longitude:String(value.lng)}))} disabled={busy}/>
 <Field label="Latitud"><input aria-label="Latitud" type="number" min={-90} max={90} step="any" value={person.latitude} onChange={event=>setPersonal('latitude',event.target.value)}/></Field>
 <Field label="Longitud"><input aria-label="Longitud" type="number" min={-180} max={180} step="any" value={person.longitude} onChange={event=>setPersonal('longitude',event.target.value)}/></Field>
 {user.role==='ADMIN'?<details className="registration-map-settings"><summary>Configurar Google Maps</summary><p className="subtle">Usa una clave restringida a los sitios web de tu instalación con Maps JavaScript API y facturación habilitadas.</p><label className="field"><span className="field-label">Clave pública de Google Maps</span><input aria-label="Clave pública de Google Maps" value={mapKey} onChange={event=>setMapKey(event.target.value)} autoComplete="off"/></label><label className="field"><span className="field-label">ID del mapa</span><input aria-label="ID del mapa" value={mapId} onChange={event=>setMapId(event.target.value)}/></label><button type="button" className="button small" disabled={mapBusy} onClick={()=>void configureMap()}>{mapBusy?'Guardando…':'Guardar configuración del mapa'}</button>{mapError&&<div role="alert" className="alert error">{mapError}</div>}</details>:!map.googleMapsApiKey&&<p className="subtle">Un administrador puede configurar la clave de Google Maps desde este formulario.</p>}
 </>}
 {step===2&&<>
 <div className="alert info">Al registrar se creará la cuenta o cola de este cliente en el MikroTik seleccionado. Los cortes y demás cambios automáticos conservan sus permisos actuales.</div>
 {optionsError&&<div className="alert error" role="alert">{optionsError}<button type="button" className="button small" onClick={()=>setRevision(value=>value+1)}>Reintentar lectura</button></div>}
 <Field label="Router / servidor *"><select aria-label="Router / servidor" required value={service.routerId} onChange={event=>choose('routerId',event.target.value)}><option value="">Seleccionar router…</option>{options?.routers.map(router=><option key={router.id} value={router.id}>{router.name}</option>)}</select></Field>
 <Field label="Tipo de conexión *"><select aria-label="Tipo de conexión" value={service.type} onChange={event=>choose('type',event.target.value)}><option value="PPPOE">PPPoE</option><option value="HOTSPOT">Hotspot</option><option value="SIMPLE_QUEUE">Simple Queue · IP estática</option></select></Field>
 <Field label="Plan de Internet *" hint={selectedPlan?`${selectedPlan.downloadKbps/1000} Mbps de bajada / ${selectedPlan.uploadKbps/1000} Mbps de subida · ${money(selectedPlan.priceCents,selectedPlan.currency)} al mes`:undefined}><select aria-label="Plan de Internet" required disabled={!service.routerId} value={service.planId} onChange={event=>choose('planId',event.target.value)}><option value="">Seleccionar plan activo…</option>{plans.map(plan=><option key={plan.id} value={plan.id}>{plan.name} · {money(plan.priceCents,plan.currency)}</option>)}</select></Field>
 {selectedPlan&&service.type!=='SIMPLE_QUEUE'&&<Field label="Perfil de acceso"><input aria-label="Perfil de acceso" readOnly value={selectedPlan.pppoeProfile}/></Field>}
 <Field label="Pool / subred IPv4 *" hint="Los rangos se consultan en el router seleccionado."><select aria-label="Pool / subred IPv4" required disabled={!service.routerId||loading} value={service.poolId} onChange={event=>choose('poolId',event.target.value)}><option value="">Seleccionar rango…</option>{options?.pools.map(pool=><option key={pool.id} value={pool.id}>{pool.label}</option>)}</select></Field>
 <Field label="IP del cliente *" hint={loading?'Comprobando direcciones disponibles…':options?.suggestedIp?'La disponibilidad se comprueba otra vez al guardar.':'Selecciona un rango con direcciones disponibles.'}><div className="registration-ip"><input aria-label="IP del cliente" required inputMode="decimal" placeholder="192.168.10.2" value={service.ipAddress} onChange={event=>{manualIp.current=true;setService(old=>({...old,ipAddress:event.target.value}));}}/><button type="button" className="button" disabled={!service.poolId||loading} onClick={()=>{manualIp.current=false;setRevision(value=>value+1);}}><RefreshCw size={15}/>Sugerir IP</button></div></Field>
 {service.type!=='SIMPLE_QUEUE'&&<><Field label="Usuario PPPoE / Hotspot *"><input aria-label="Usuario PPPoE / Hotspot" required maxLength={100} autoComplete="off" value={service.username} onChange={event=>setService(old=>({...old,username:event.target.value}))}/></Field><Field label="Contraseña del servicio *"><div className="registration-password"><input aria-label="Contraseña del servicio" required maxLength={200} type={showPassword?'text':'password'} autoComplete="new-password" value={service.password} onChange={event=>setService(old=>({...old,password:event.target.value}))}/><button type="button" className="icon-button" aria-label={showPassword?'Ocultar contraseña':'Mostrar contraseña'} onClick={()=>setShowPassword(value=>!value)}>{showPassword?<EyeOff size={17}/>:<Eye size={17}/>}</button></div></Field></>}
 {!options?.routers.length&&!loading&&!optionsError&&<p className="alert warning">Primero registra el router en Routers y nodos.</p>}
 {!plans.length&&service.routerId&&!loading&&!optionsError&&<p className="alert warning">Activa un plan con tarifa en Planes de Internet para este router.</p>}
 </>}
 </fieldset><footer className="registration-footer"><button type="button" className="button" disabled={busy||step===0} onClick={()=>{setError('');setStep(value=>value-1);}}><ArrowLeft size={16}/>Anterior</button>{step<2?<button className="button primary" type="submit" disabled={busy}>Siguiente<ArrowRight size={16}/></button>:<button className="button primary" type="submit" disabled={busy||loading||!service.routerId||!service.planId||!service.poolId||Boolean(optionsError)}>{busy?<LoaderCircle size={16} className="spinner"/>:<Save size={16}/>} {busy?'Registrando y verificando…':'Guardar y activar servicio'}</button>}</footer></form>
 </>}
 </div></Modal>;
}
