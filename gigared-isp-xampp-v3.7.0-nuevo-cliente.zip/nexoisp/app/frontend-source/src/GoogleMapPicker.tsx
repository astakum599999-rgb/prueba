import { useEffect, useRef, useState } from 'react';
import { LocateFixed, MapPin, RefreshCw } from 'lucide-react';

export interface MapSettings { googleMapsApiKey: string; googleMapsMapId: string; centerLatitude: number; centerLongitude: number }
type Point = {lat:number;lng:number};
type Removable = {remove:()=>void};
interface MapInstance {addListener:(name:string,listener:(event:{latLng?:{lat:()=>number;lng:()=>number}})=>void)=>Removable;panTo:(point:Point)=>void}
interface MarkerInstance {position: Point | {lat:()=>number;lng:()=>number} | null;map:MapInstance|null;addListener:(name:string,listener:()=>void)=>Removable}
interface GoogleApi {maps:{importLibrary:(name:string)=>Promise<unknown>}}
declare global {interface Window {google?:GoogleApi; __gigaredMapsReady?:()=>void;gm_authFailure?:()=>void}}
let mapsPromise:Promise<GoogleApi>|undefined;
let mapsKey='';

function loadMaps(key:string):Promise<GoogleApi> {
  if(mapsKey&&mapsKey!==key&&(window.google?.maps.importLibrary||mapsPromise))return Promise.reject(new Error('La clave de Google Maps cambió. Conserva tus datos y recarga el panel para usar la nueva clave.'));
  if(window.google?.maps.importLibrary)return Promise.resolve(window.google);
  if(mapsPromise)return mapsPromise;
  mapsPromise=new Promise((resolve,reject)=>{
    mapsKey=key;
    const script=document.createElement('script');let timer:number|undefined;
    const fail=()=>{window.clearTimeout(timer);script.remove();mapsPromise=undefined;mapsKey='';delete window.__gigaredMapsReady;reject(new Error('No se pudo cargar Google Maps. Revisa la clave, sus permisos y la conexión.'));};
    window.__gigaredMapsReady=()=>{window.clearTimeout(timer);delete window.__gigaredMapsReady;if(window.google)resolve(window.google);else fail();};
    window.gm_authFailure=()=>window.dispatchEvent(new Event('gigared:maps-auth-error'));
    const url=new URL('https://maps.googleapis.com/maps/api/js');
    url.search=new URLSearchParams({key,v:'weekly',loading:'async',callback:'__gigaredMapsReady',language:'es',region:'PE',auth_referrer_policy:'origin'}).toString();
    script.src=url.toString();script.referrerPolicy='strict-origin-when-cross-origin';script.async=true;script.onerror=fail;script.dataset.gigaredMaps='true';
    timer=window.setTimeout(fail,20000);document.head.appendChild(script);
  });
  return mapsPromise;
}

export default function GoogleMapPicker({settings,value,onChange,disabled=false}:{settings:MapSettings;value:Point|null;onChange:(point:Point)=>void;disabled?:boolean}) {
  const element=useRef<HTMLDivElement>(null),map=useRef<MapInstance|null>(null),marker=useRef<MarkerInstance|null>(null),latest=useRef(onChange),current=useRef(value),locked=useRef(disabled);
  latest.current=onChange;current.current=value;locked.current=disabled;
  const [error,setError]=useState(''),[ready,setReady]=useState(false),[attempt,setAttempt]=useState(0),[locating,setLocating]=useState(false);
  useEffect(()=>{
    if(!settings.googleMapsApiKey)return;
    let alive=true;const listeners:Removable[]=[];setReady(false);setError('');
    const auth=()=>{if(alive)setError('Google Maps rechazó la clave. Habilita Maps JavaScript API, facturación y los sitios autorizados de tu instalación.');};
    window.addEventListener('gigared:maps-auth-error',auth);
    void loadMaps(settings.googleMapsApiKey).then(async google=>{
      const maps=await google.maps.importLibrary('maps') as {Map:new(element:HTMLElement,options:Record<string,unknown>)=>MapInstance};
      const markers=await google.maps.importLibrary('marker') as {AdvancedMarkerElement:new(options:Record<string,unknown>)=>MarkerInstance};
      if(!alive||!element.current)return;
      const initial=current.current??{lat:settings.centerLatitude,lng:settings.centerLongitude};
      const instance=new maps.Map(element.current,{center:initial,zoom:15,mapId:settings.googleMapsMapId||'DEMO_MAP_ID',mapTypeControl:true,streetViewControl:false,fullscreenControl:true,gestureHandling:'cooperative'});map.current=instance;
      const pin=new markers.AdvancedMarkerElement({map:current.current?instance:null,position:initial,gmpDraggable:!locked.current,title:'Ubicación del cliente'});marker.current=pin;
      listeners.push(instance.addListener('click',event=>{if(!locked.current&&event.latLng)latest.current({lat:Number(event.latLng.lat().toFixed(7)),lng:Number(event.latLng.lng().toFixed(7))});}));
      listeners.push(pin.addListener('dragend',()=>{const position=pin.position;if(locked.current||!position)return;const lat=typeof position.lat==='function'?position.lat():position.lat,lng=typeof position.lng==='function'?position.lng():position.lng;latest.current({lat:Number(lat.toFixed(7)),lng:Number(lng.toFixed(7))});}));
      setReady(true);
    }).catch(reason=>{if(alive)setError(reason instanceof Error?reason.message:'No se pudo mostrar el mapa.');});
    return()=>{alive=false;listeners.forEach(listener=>listener.remove());if(marker.current)marker.current.map=null;marker.current=null;map.current=null;window.removeEventListener('gigared:maps-auth-error',auth);};
  },[settings.googleMapsApiKey,settings.googleMapsMapId,settings.centerLatitude,settings.centerLongitude,attempt]);
  useEffect(()=>{if(marker.current){if(value)marker.current.position=value;marker.current.map=value?map.current:null;}},[value?.lat,value?.lng,ready]);
  const locate=()=>{
    if(!navigator.geolocation){setError('Este navegador no dispone de geolocalización. Selecciona el punto en el mapa.');return;}
    setLocating(true);navigator.geolocation.getCurrentPosition(position=>{setLocating(false);const point={lat:Number(position.coords.latitude.toFixed(7)),lng:Number(position.coords.longitude.toFixed(7))};latest.current(point);map.current?.panTo(point);},()=>{setLocating(false);setError('No se obtuvo la ubicación del dispositivo. Puedes seleccionar el punto en el mapa o escribir sus coordenadas.');},{enableHighAccuracy:true,timeout:12000,maximumAge:30000});
  };
  return <section className="registration-map" aria-label="Ubicación del cliente en Google Maps">
    <div className="registration-map-heading"><span><MapPin size={17}/>Ubicación de instalación</span><button type="button" className="button small" onClick={locate} disabled={disabled||locating}><LocateFixed size={15}/>{locating?'Ubicando…':'Mi ubicación'}</button></div>
    {!settings.googleMapsApiKey?<div className="registration-map-placeholder"><MapPin size={28}/><strong>Configura Google Maps para seleccionar la ubicación</strong><span>También puedes escribir latitud y longitud en los campos de abajo.</span></div>:<><div ref={element} className="registration-map-canvas" data-testid="client-google-map"/>{!ready&&!error&&<p className="subtle" role="status">Cargando Google Maps…</p>}</>}
    {error&&<div className="alert warning" role="status"><span>{error}</span>{settings.googleMapsApiKey&&<button type="button" className="button small" onClick={()=>setAttempt(value=>value+1)}><RefreshCw size={14}/>Reintentar mapa</button>}</div>}
    <p className="field-hint">Haz clic en el mapa o arrastra el marcador. Las coordenadas se guardarán con el cliente.</p>
  </section>;
}
