<?php
declare(strict_types=1);
namespace Nexo;

use DateTimeImmutable;
use DateTimeZone;
use Throwable;

require_once __DIR__ . '/secret-import.php';
// The CLI worker needs the same pending-edit guards as authenticated web imports.
require_once __DIR__ . '/client-name-sync.php';

const SECRET_AUTO_SYNC_INTERVAL = 1;

function secretAutoSyncAfter(int $seconds, ?string $from = null): string
{
    return (new DateTimeImmutable($from ?? 'now', new DateTimeZone('UTC')))->modify('+' . max(0, $seconds) . ' seconds')->format('Y-m-d H:i:s.v');
}

/** A previous successful import is the opt-in; unimported routers are never read. */
function secretAutoSyncEnrollImported(): void
{
    db()->exec("INSERT IGNORE INTO `RouterSecretAutoSync` (routerId,nextRunAt,updatedAt)
        SELECT r.id,UTC_TIMESTAMP(3),UTC_TIMESTAMP(3) FROM `Router` r
        LEFT JOIN `RouterSecretAutoSync` currentSync ON currentSync.routerId=r.id
        WHERE currentSync.routerId IS NULL AND r.transport IN ('REST','SOCKET') AND
        (EXISTS (SELECT 1 FROM `RouterSecretImport` s WHERE s.routerId=r.id)
         OR EXISTS (SELECT 1 FROM `RouterProfileImport` p WHERE p.routerId=r.id)
         OR EXISTS (SELECT 1 FROM `AuditLog` a WHERE a.entityType='Router' AND a.entityId=r.id AND a.action IN ('router.secrets.import','router.profiles.import')))");
}

/** Called in the import's own transaction, including successful empty inventories. */
function secretAutoSyncRecordManual(string $routerId, array $summary): void
{
    $timestamp = now();
    db()->prepare("INSERT INTO `RouterSecretAutoSync` (routerId,status,lastSuccessAt,nextRunAt,lastSummary,updatedAt)
        VALUES (?,'SUCCESS',?,?,?,?) ON DUPLICATE KEY UPDATE status='SUCCESS',lastStartedAt=VALUES(lastSuccessAt),lastSuccessAt=VALUES(lastSuccessAt),nextRunAt=VALUES(nextRunAt),lastErrorCode=NULL,lastError=NULL,consecutiveFailures=0,lastSummary=VALUES(lastSummary),updatedAt=VALUES(updatedAt)")
        ->execute([$routerId, $timestamp, secretAutoSyncAfter(SECRET_AUTO_SYNC_INTERVAL), json_encode($summary, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE), $timestamp]);
}

/** Stable, credential-free projection. This function never contacts any router. */
function secretAutoSyncStatus(): array
{
    $rows = fetchAll("SELECT r.id AS routerId,r.name AS routerName,s.enabled,s.status,s.lastStartedAt,s.lastSuccessAt,s.nextRunAt,s.updatedAt,s.lastErrorCode,s.lastError,s.consecutiveFailures,s.lastSummary
        FROM `Router` r LEFT JOIN `RouterSecretAutoSync` s ON s.routerId=r.id
        WHERE r.transport IN ('REST','SOCKET') AND
        (s.routerId IS NOT NULL OR EXISTS (SELECT 1 FROM `RouterSecretImport` i WHERE i.routerId=r.id)
         OR EXISTS (SELECT 1 FROM `RouterProfileImport` p WHERE p.routerId=r.id)
         OR EXISTS (SELECT 1 FROM `AuditLog` a WHERE a.entityType='Router' AND a.entityId=r.id AND a.action IN ('router.secrets.import','router.profiles.import')))
        ORDER BY r.name,r.id LIMIT 1000");
    foreach ($rows as &$row) {
        $row['enabled'] = $row['enabled'] === null || (bool)$row['enabled'];
        $row['status'] ??= 'WAITING';
        $row['consecutiveFailures'] = (int)($row['consecutiveFailures'] ?? 0);
        $row['lastSummary'] = is_string($row['lastSummary']) ? json_decode($row['lastSummary'], true, 16, JSON_THROW_ON_ERROR) : null;
        $row['nextRunAt'] = secretAutoSyncNextRunAt($row);
        // A terminated PHP process releases its advisory locks. Its reservation
        // expires after two minutes; do not claim a stale process is still live.
        if ($row['status'] === 'RUNNING' && $row['nextRunAt'] !== null && $row['nextRunAt'] <= now()) $row['status'] = 'WAITING';
    }
    unset($row);
    return ['intervalSeconds' => SECRET_AUTO_SYNC_INTERVAL, 'networkReadOnly' => true,
        'mode' => 'worker-or-open-panel', 'serverTime' => now(), 'routers' => $rows];
}

function secretAutoSyncChanged(array $summary): bool
{
    foreach (['created','updated','namesUpdated'] as $field) if (($summary[$field] ?? 0) > 0) return true;
    return (int)($summary['absencesChanged'] ?? $summary['missing'] ?? 0) > 0;
}

/**
 * Run a bounded batch of due routers for browser/worker requests. The scheduler
 * and shared router locks span the complete observation and persistence cycle.
 * No database transaction spans I/O.
 */
function secretAutoSyncTick(?string $actorId = null, int $maximum = 5): array
{
    return mikrotikLiveSyncTick($actorId, $maximum);
}

function secretAutoSyncDispatch(string $method, string $route): bool
{
    if ($route !== '/routers/secrets/auto-sync') return false;
    if ($method === 'GET') {
        requireAuth();
        json(secretAutoSyncStatus());
    }
    if ($method === 'POST') {
        $actor = permit('ADMIN', 'TECHNICIAN');
        if (body() !== []) throw new HttpError(422, 'La actualización automática no admite parámetros ni cambios de configuración.', 'VALIDATION_ERROR');
        rateLimit('secret-auto:' . $actor['id'], 600, 60);
        if (function_exists('set_time_limit')) set_time_limit(60);
        ignore_user_abort(true);
        $result = secretAutoSyncTick($actor['id']);
        json($result + secretAutoSyncStatus());
    }
    return false;
}

require_once __DIR__ . '/mikrotik-live-sync.php';
