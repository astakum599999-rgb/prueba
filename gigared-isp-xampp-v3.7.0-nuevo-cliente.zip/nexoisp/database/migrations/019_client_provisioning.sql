-- Durable, explicit new-customer provisioning. Existing services are unchanged.
CREATE TABLE IF NOT EXISTS `ClientProvisioning` (
  `id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `requestKey` CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `requestHash` CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `actorId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `clientId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `serviceId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `routerId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `connectionType` VARCHAR(20) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `poolId` VARCHAR(1100) NULL,
  `intentEncrypted` TEXT NOT NULL,
  `remoteId` VARCHAR(128) NULL,
  `status` VARCHAR(20) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'PREPARED',
  `lastError` VARCHAR(500) NULL,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `client_provision_request_unique` (`requestKey`),
  UNIQUE KEY `client_provision_service_unique` (`serviceId`),
  KEY `client_provision_client_idx` (`clientId`,`createdAt`),
  KEY `client_provision_router_idx` (`routerId`,`status`),
  CONSTRAINT `client_provision_actor_fk` FOREIGN KEY (`actorId`) REFERENCES `User` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `client_provision_client_fk` FOREIGN KEY (`clientId`) REFERENCES `Client` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `client_provision_service_fk` FOREIGN KEY (`serviceId`) REFERENCES `Service` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `client_provision_router_fk` FOREIGN KEY (`routerId`) REFERENCES `Router` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `client_provision_type_check` CHECK (`connectionType` IN ('PPPOE','HOTSPOT','SIMPLE_QUEUE')),
  CONSTRAINT `client_provision_status_check` CHECK (`status` IN ('PREPARED','APPLYING','UNCERTAIN','CONFIRMED','REJECTED'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Browser-restricted Google Maps public key; never contains router credentials.
CREATE TABLE IF NOT EXISTS `ClientRegistrationSettings` (
  `id` VARCHAR(20) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `googleMapsApiKey` VARCHAR(255) NOT NULL DEFAULT '',
  `googleMapsMapId` VARCHAR(128) NOT NULL DEFAULT 'DEMO_MAP_ID',
  `centerLatitude` DOUBLE NOT NULL DEFAULT -12.0464,
  `centerLongitude` DOUBLE NOT NULL DEFAULT -77.0428,
  `updatedAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  CONSTRAINT `client_registration_primary_check` CHECK (`id`='primary'),
  CONSTRAINT `client_registration_lat_check` CHECK (`centerLatitude` BETWEEN -90 AND 90),
  CONSTRAINT `client_registration_lng_check` CHECK (`centerLongitude` BETWEEN -180 AND 180)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
