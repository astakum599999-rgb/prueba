<?php
declare(strict_types=1);
namespace Nexo;

use PDO;
use Throwable;

require_once __DIR__.'/client-provision-ip.php';
require_once __DIR__.'/profile-import.php';

function provisionSettings(): array
{
    $row = fetchOne("SELECT googleMapsApiKey,googleMapsMapId,centerLatitude,centerLongitude FROM ClientRegistrationSettings WHERE id='primary'");
    return $row === null ? ['googleMapsApiKey'=>'','googleMapsMapId'=>'DEMO_MAP_ID','centerLatitude'=>-12.0464,'centerLongitude'=>-77.0428] : [...$row,'centerLatitude'=>(float)$row['centerLatitude'],'centerLongitude'=>(float)$row['centerLongitude']];
}

function provisionIdentifier(mixed $value): string
{
    if (!is_string($value) || !preg_match('/^[a-f0-9]{24}$/D',$value)) throw new HttpError(422,'Selecciona un router y un plan válidos.','VALIDATION_ERROR');
    return $value;
}

function provisionRows(RouterTransport $transport,string $path,string $properties,bool $named=false,bool $optional=false): array
{
    try{$rows=$transport->print($path,[],['.proplist'=>$properties]);}
    catch(RouterError $error){
        // A package/menu explicitly absent is not an unreadable configured feature.
        if($optional&&($error->httpStatus===404||$error->missingCommand))return [];
        throw $error;
    }
    if (!array_is_list($rows) || count($rows)>20000) throw new HttpError(502,'El inventario del router está incompleto o excede el límite admitido.','INVALID_ROUTER_RESPONSE');
    foreach($rows as $row) {
        if (!is_array($row) || array_is_list($row)) throw new HttpError(502,'El inventario del router no es válido.','INVALID_ROUTER_RESPONSE');
        if ($named && (!is_string($row['name']??null) || $row['name']==='')) throw new HttpError(502,'El inventario del router no contiene las identidades necesarias.','INVALID_ROUTER_RESPONSE');
    }
    return $rows;
}

/** Read complete inventories, never passwords, before deciding an address is free. */
function provisionInventory(RouterTransport $transport): array
{
    return [
        'pools'=>provisionRows($transport,'/ip/pool','.id,name,ranges,next-pool',true),
        'profiles'=>provisionRows($transport,'/ppp/profile',PROFILE_IMPORT_PROPERTIES,true,true),
        'hotspotProfiles'=>provisionRows($transport,'/ip/hotspot/user/profile','.id,name,rate-limit',true,true),
        'secrets'=>provisionRows($transport,'/ppp/secret',SECRET_IMPORT_PROPERTIES,true,true),
        'hotspot'=>provisionRows($transport,'/ip/hotspot/user','.id,name,address,profile,server,comment,disabled',true,true),
        'active'=>provisionRows($transport,'/ppp/active','.id,name,address,service',true,true),
        'leases'=>provisionRows($transport,'/ip/dhcp-server/lease','.id,address,active-address',false,true),
        'used'=>provisionRows($transport,'/ip/pool/used','.id,address,pool'),
        'interfaces'=>provisionRows($transport,'/ip/address','.id,address,network,interface,disabled'),
        'queues'=>provisionRows($transport,'/queue/simple','.id,name,target,max-limit,priority,comment,disabled',true),
    ];
}

function provisionPools(array $inventory): array
{
    $result=[];$seen=[];
    foreach($inventory['pools'] as $row) {
        $name=$row['name'];
        if (strlen($name)>1000 || preg_match('//u',$name)!==1 || preg_match_all('/./us',$name)>255 || isset($seen[$name])) throw new HttpError(502,'La identidad de un pool no es compatible o está duplicada.','INVALID_ROUTER_RESPONSE');
        $ranges=$row['ranges']??null;
        if(!is_string($ranges)) throw new HttpError(502,'Faltan los rangos del pool.','INVALID_ROUTER_RESPONSE');
        $result[]=['id'=>'pool:'.$name,'name'=>$name,'label'=>$name.' · '.$ranges,'ranges'=>$ranges,'source'=>'POOL','intervals'=>provisionRanges($ranges,true)];$seen[$name]=true;
    }
    foreach($inventory['interfaces'] as $row) {
        $address=$row['address']??'';
        if (!is_string($address) || !str_contains($address,'/') || RouterTransportUtil::truthy($row['disabled']??false)) continue;
        $range=provisionIpRange($address,true); if($range===null || $range[0]>=$range[1]) continue;
        $id='subnet:'.$address;if(isset($seen[$id]))continue;$seen[$id]=true;
        $result[]=['id'=>$id,'name'=>$address,'label'=>'Subred '.secretImportDisplayText((string)($row['interface']??'')).' · '.$address,'ranges'=>$address,'source'=>'SUBNET','intervals'=>[$range]];
    }
    return $result;
}

function provisionOccupied(array $inventory,string $routerId,?string $excludeService=null): array
{
    $ranges=[];
    $add=static function(mixed $address)use(&$ranges):void{if(is_string($address) && ($value=provisionIpNumber($address))!==null)$ranges[]=[$value,$value];};
    foreach(['secrets'=>'remote-address','hotspot'=>'address','active'=>'address','leases'=>'address','used'=>'address'] as $source=>$field) foreach($inventory[$source] as $row) {
        if (!array_key_exists($field,$row) && in_array($source,['active','used'],true)) throw new HttpError(502,'Faltan direcciones del inventario de ocupación.','INVALID_ROUTER_RESPONSE');
        $add($row[$field]??null);if($source==='leases')$add($row['active-address']??null);
    }
    foreach($inventory['interfaces'] as $row) {
        $value=$row['address']??'';if(!is_string($value))throw new HttpError(502,'Dirección de interfaz inválida.','INVALID_ROUTER_RESPONSE');
        $add(explode('/',$value)[0]);$range=provisionIpRange($value);
        if($range!==null && $range[1]-$range[0]>1){$ranges[]=[$range[0],$range[0]];$ranges[]=[$range[1],$range[1]];}
    }
    foreach($inventory['queues'] as $row) {
        $targets=$row['target']??'';if(!is_string($targets))throw new HttpError(502,'Destino de cola inválido.','INVALID_ROUTER_RESPONSE');
        foreach(explode(',',$targets) as $target)if(($range=provisionIpRange(trim($target)))!==null)$ranges[]=$range;
    }
    foreach(fetchAll("SELECT id,ipAddress FROM Service WHERE routerId=? AND (appliedState IS NULL OR appliedState<>'RETIRED')",[$routerId]) as $row)if($row['id']!==$excludeService)$add($row['ipAddress']);
    foreach(fetchAll('SELECT remoteAddress FROM RouterSecretImport WHERE routerId=? AND present=1',[$routerId]) as $row)$add($row['remoteAddress']);
    return provisionMergedRanges($ranges);
}

function provisionUsernameFree(array $inventory,string $routerId,string $username,?string $excludeService=null): bool
{
    foreach([...$inventory['secrets'],...$inventory['hotspot'],...$inventory['active']] as $row)if($row['name']===$username)return false;
    foreach(fetchAll("SELECT id,username FROM Service WHERE routerId=? AND (appliedState IS NULL OR appliedState<>'RETIRED')",[$routerId]) as $row)if($row['id']!==$excludeService && $row['username']===$username)return false;
    foreach(fetchAll('SELECT username FROM RouterSecretImport WHERE routerId=? AND present=1',[$routerId]) as $row)if($row['username']===$username)return false;
    return true;
}

function provisionRouter(string $routerId): array
{
    $router=fetchOne('SELECT * FROM Router WHERE id=?',[$routerId])??throw new HttpError(404,'Router no encontrado.','NOT_FOUND');
    if(!in_array($router['transport'],['REST','SOCKET'],true))throw new HttpError(422,'El alta requiere un router real con API Socket o REST.','INVALID_ROUTER');
    if(clientPppoeEditPending($routerId) || clientNameSyncPending($routerId))throw new HttpError(409,'Verifica primero el cambio manual pendiente en este router.','PPPOE_EDIT_PENDING');
    return $router;
}

function provisionTransport(array $router): RouterTransport
{
    $password=decryptSecret($router['passwordEncrypted']);
    return $router['transport']==='REST'?new RouterRestTransport($router,$password,15.0,false,true):new RouterSocketTransport($router,$password,15.0,false,true);
}

function provisionValidate(array $body): array
{
    if(array_diff(array_keys($body),['requestKey','client','service']) || !is_string($body['requestKey']??null) || !preg_match('/^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/D',$body['requestKey']) || !is_array($body['client']??null) || !is_array($body['service']??null))throw new HttpError(422,'El alta requiere datos del cliente, servicio y una clave de solicitud válida.','VALIDATION_ERROR');
    if(array_diff(array_keys($body['client']),['name','document','phone','email','address','zone','latitude','longitude','notes']))throw new HttpError(422,'Campo de cliente no admitido.','VALIDATION_ERROR');
    $client=validate('client',['code'=>'AUTO',...$body['client']]);unset($client['code']);
    if(($client['latitude']??null)===null xor ($client['longitude']??null)===null)throw new HttpError(422,'Completa latitud y longitud juntas o selecciona el punto en el mapa.','VALIDATION_ERROR');
    if(preg_match('/[\x00-\x1F\x7F-\x{009F}]/u',$client['name']))throw new HttpError(422,'El nombre debe escribirse en una sola línea.','VALIDATION_ERROR');
    $s=$body['service'];
    if(array_diff(array_keys($s),['routerId','planId','type','ipAddress','poolId','username','password']))throw new HttpError(422,'Campo de servicio no admitido.','VALIDATION_ERROR');
    $s['routerId']=provisionIdentifier($s['routerId']??null);$s['planId']=provisionIdentifier($s['planId']??null);
    if(!in_array($s['type']??null,['PPPOE','HOTSPOT','SIMPLE_QUEUE'],true) || !is_string($s['ipAddress']??null) || !provisionUsableIp($s['ipAddress']) || !is_string($s['poolId']??null) || strlen($s['poolId'])>1100)throw new HttpError(422,'Selecciona el tipo de conexión, el rango y una IPv4 válida.','VALIDATION_ERROR');
    if($s['type']!=='SIMPLE_QUEUE')foreach(['username'=>100,'password'=>200] as $field=>$limit){
        if($s['type']==='PPPOE'&&!array_key_exists($field,$s))$s[$field]='';
        $value=$s[$field]??null;
        if(!is_string($value)||strlen($value)>$limit*4||preg_match('//u',$value)!==1||preg_match_all('/./us',$value)>$limit)throw new HttpError(422,'Usuario o contraseña de acceso no válidos.','VALIDATION_ERROR');
        // Empty PPPoE fields are stable request sentinels, not generated values.
        if($s['type']==='PPPOE'&&preg_match('/^[\s\p{Z}]*$/uD',$value)){ $s[$field]='';continue; }
        if($value===''||preg_match('/[\x00-\x1F\x7F-\x{009F}]/u',$value))throw new HttpError(422,'Usuario o contraseña de acceso no válidos.','VALIDATION_ERROR');
    }
    else {unset($s['username'],$s['password']);}
    ksort($s);
    return ['requestKey'=>$body['requestKey'],'client'=>$client,'service'=>$s];
}

/** Generate only omitted PPPoE values, after idempotency lookup and router locking. */
function provisionGeneratePppoeCredentials(array $service,callable $usernameAvailable): array
{
    if($service['type']!=='PPPOE')return $service;
    if($service['username']===''){
        for($attempt=0;$attempt<16;$attempt++){
            $candidate='gg-'.bin2hex(random_bytes(8));
            if($usernameAvailable($candidate)){ $service['username']=$candidate;break; }
        }
        if($service['username']==='')throw new HttpError(409,'No se pudo reservar un usuario PPPoE disponible. Intenta el alta de nuevo.','USERNAME_CONFLICT');
    }
    if($service['password']==='')$service['password']=strtr(base64_encode(random_bytes(24)),'+/','-_');
    return $service;
}

function provisionPlan(array $router,array $service,array $inventory): array
{
    $plan=fetchOne('SELECT * FROM Plan WHERE id=?',[$service['planId']])??throw new HttpError(422,'El plan ya no existe.','INVALID_PLAN');
    if(!(bool)$plan['active'])throw new HttpError(422,'Selecciona un plan activo.','INVALID_PLAN');
    profileImportAssertBillable($plan['id']);
    $source=fetchOne('SELECT routerId FROM RouterProfileImport WHERE planId=?',[$plan['id']]);
    if($source!==null && $source['routerId']!==$router['id'])throw new HttpError(409,'Este plan corresponde al perfil de otro router.','PROFILE_PLAN_CONFLICT');
    if($service['type']!=='SIMPLE_QUEUE') {
        $matches=array_values(array_filter($inventory[$service['type']==='PPPOE'?'profiles':'hotspotProfiles'],static fn(array $row):bool=>$row['name']===$plan['pppoeProfile']));
        if(count($matches)!==1 || $plan['pppoeProfile']===$router['cutProfile'])throw new HttpError(409,'El perfil de acceso del plan no existe o no es válido en este router.','MISSING_PROFILE');
        $rate=profileImportParseRateLimit((string)($matches[0]['rate-limit']??''));
        if($rate['rateStatus']!=='READY' || $rate['downloadKbps']!==(int)$plan['downloadKbps'] || $rate['uploadKbps']!==(int)$plan['uploadKbps'])throw new HttpError(409,'La velocidad del perfil no coincide con el plan. Actualiza su lectura o selecciona el perfil/plan correcto.','PROFILE_RATE_PENDING');
    }
    return $plan;
}

function provisionPreflight(array $router,array $service,array $inventory,?string $excludeService=null): array
{
    $plan=provisionPlan($router,$service,$inventory);
    $pool=null;foreach(provisionPools($inventory) as $candidate)if($candidate['id']===$service['poolId'])$pool=$candidate;
    if($pool===null || !provisionIpInRanges($service['ipAddress'],$pool['intervals']))throw new HttpError(422,'La IP no pertenece al rango seleccionado del router.','IP_OUTSIDE_POOL');
    if(provisionIpInRanges($service['ipAddress'],provisionOccupied($inventory,$router['id'],$excludeService)))throw new HttpError(409,'La IP ya está ocupada en MikroTik o reservada en el sistema. Solicita otra IP disponible.','IP_CONFLICT');
    if($service['type']!=='SIMPLE_QUEUE' && !provisionUsernameFree($inventory,$router['id'],$service['username'],$excludeService))throw new HttpError(409,'El usuario ya existe en MikroTik o está reservado localmente.','USERNAME_CONFLICT');
    return [$plan,$pool];
}

function provisionBuildValues(array $service,array $plan,array $client,array $router): array
{
    $common=['name'=>$service['username'],'password'=>$service['passwordEncrypted']?decryptSecret($service['passwordEncrypted']):'','profile'=>$plan['pppoeProfile']];
    $values=match($service['type']){
        'PPPOE'=>[...$common,'service'=>'pppoe','remote-address'=>$service['ipAddress']],
        'HOTSPOT'=>[...$common,'address'=>$service['ipAddress'],'server'=>$router['hotspotServer']],
        'SIMPLE_QUEUE'=>['name'=>'gg-'.$service['id'],'target'=>$service['ipAddress'].'/32','max-limit'=>$plan['uploadKbps'].'k/'.$plan['downloadKbps'].'k','priority'=>$plan['priority'].'/'.$plan['priority']],
    };
    return $values+['comment'=>$client['name'],'disabled'=>'false'];
}

function provisionValues(array $row): array
{
    $service=fetchOne('SELECT * FROM Service WHERE id=?',[$row['serviceId']])??throw new HttpError(409,'El servicio del alta no está disponible.');
    $expected=json_decode(decryptSecret($row['intentEncrypted']),true,32,JSON_THROW_ON_ERROR);
    if(!is_array($expected))throw new HttpError(409,'La intención del alta no está disponible.');
    return [$service,$expected];
}

function provisionPath(string $type): string {return match($type){'PPPOE'=>'/ppp/secret','HOTSPOT'=>'/ip/hotspot/user','SIMPLE_QUEUE'=>'/queue/simple'};}

/** Resolve only a matching durable PPP reservation; never merge clients by name. */
function provisionImportedClient(string $routerId,array $entry): ?string
{
    $rows=fetchAll("SELECT s.clientId,s.ipAddress,p.pppoeProfile FROM Service s JOIN ClientProvisioning c ON c.serviceId=s.id JOIN Plan p ON p.id=s.planId WHERE s.routerId=? AND BINARY s.username=? AND s.type='PPPOE' AND s.desiredState<>'RETIRED'",[$routerId,$entry['username']]);
    if(count($rows)!==1 || $rows[0]['ipAddress']!==$entry['remoteAddress'] || $rows[0]['pppoeProfile']!==$entry['profile'])return null;
    return $rows[0]['clientId'];
}

/** True only after reading the exact created resource; never adopts a different account. */
function provisionVerify(array $row,RouterTransport $transport): bool
{
    [$service,$expected]=provisionValues($row);$path=provisionPath($service['type']);
    $properties=array_keys($expected);
    if($row['remoteId']!==null)$properties=array_values(array_diff($properties,['password']));
    $rows=$transport->print($path,['name'=>$expected['name']],['.proplist'=>implode(',',array_unique(['.id',...$properties]))]);
    if(!array_is_list($rows) || count($rows)>1)throw new HttpError(409,'El router devuelve varias cuentas o colas con esa identidad. Revisa el alta antes de continuar.','PROVISION_CONFLICT');
    if($rows===[])return false;
    $actual=$rows[0];$remoteId=$actual['.id']??null;
    if(!is_string($remoteId)||!preg_match('/^\*[a-z0-9]{1,32}$/iD',$remoteId)||($row['remoteId']!==null && $row['remoteId']!==$remoteId))throw new HttpError(409,'El recurso observado no coincide con el identificador del alta.','PROVISION_CONFLICT');
    foreach($expected as $field=>$value){
        if($field==='password' && $row['remoteId']!==null)continue; // Acknowledged ID proves ownership even when password read is denied.
        $observed=$actual[$field]??null;
        $matches=$field==='disabled'?($observed!==null && !RouterTransportUtil::truthy($observed)):($field==='max-limit'?(profileImportParseRateLimit((string)$observed)['downloadKbps']===profileImportParseRateLimit($value)['downloadKbps'] && profileImportParseRateLimit((string)$observed)['uploadKbps']===profileImportParseRateLimit($value)['uploadKbps']):($observed===$value));
        if(!$matches)throw new HttpError(409,'La cuenta observada no coincide con los datos del alta. No se ha modificado ni sobrescrito.','PROVISION_CONFLICT');
    }
    tx(function(PDO $pdo)use($row,$service,$remoteId,$actual):void{
        $pdo->prepare("UPDATE ClientProvisioning SET status='CONFIRMED',remoteId=?,lastError=NULL,updatedAt=? WHERE id=?")->execute([$remoteId,now(),$row['id']]);
        $pdo->prepare("UPDATE Service SET appliedState='ACTIVE',syncStatus='SYNCED',lastSyncAt=?,lastError=NULL,updatedAt=? WHERE id=?")->execute([now(),now(),$service['id']]);
        if($service['type']==='PPPOE') {
            // Seed the same client's source identity before the1s importer runs.
            $entry=secretImportNormalize([$actual])[0];
            $existing=fetchOne('SELECT clientId FROM RouterSecretImport WHERE routerId=? AND username=?',[$row['routerId'],$service['username']]);
            if($existing!==null && $existing['clientId']!==$row['clientId'])throw new HttpError(409,'La cuenta está vinculada a otro cliente.','PROVISION_CONFLICT');
            if($existing===null)$pdo->prepare('INSERT INTO RouterSecretImport(id,routerId,clientId,remoteId,username,pppService,profile,remoteAddress,localAddress,callerId,disabled,comment,present,snapshotHash,firstSeenAt,lastSeenAt) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,1,?,?,?)')->execute([id(),$row['routerId'],$row['clientId'],$entry['remoteId'],$entry['username'],$entry['pppService'],$entry['profile'],$entry['remoteAddress'],$entry['localAddress'],$entry['callerId'],(int)$entry['disabled'],$entry['comment'],$entry['snapshotHash'],now(),now()]);
        }
        audit('client.provision.confirmed','Client',$row['clientId'],$row['actorId']);
    });
    return true;
}

function provisionPublic(array $row): array
{
    $service=fetchOne('SELECT username FROM Service WHERE id=?',[$row['serviceId']]);
    return ['id'=>$row['id'],'clientId'=>$row['clientId'],'serviceId'=>$row['serviceId'],'routerId'=>$row['routerId'],'type'=>$row['connectionType'],'username'=>$service['username']??null,'status'=>$row['status'],'remoteId'=>$row['remoteId'],'message'=>$row['lastError'],'createdAt'=>$row['createdAt'],'updatedAt'=>$row['updatedAt']];
}

function provisionPending(string $clientId): bool
{
    return fetchOne("SELECT p.id FROM ClientProvisioning p JOIN Service s ON s.id=p.serviceId WHERE p.clientId=? AND p.status<>'CONFIRMED' AND s.desiredState<>'RETIRED' LIMIT 1",[$clientId])!==null;
}

/** New accounts use the person's name as comment and a durable ownership ID. */
function provisionManagedRemoteId(string $serviceId): ?string
{
    return fetchOne("SELECT remoteId FROM ClientProvisioning WHERE serviceId=? AND connectionType='PPPOE' AND status='CONFIRMED'",[$serviceId])['remoteId']??null;
}

function provisionOwnsRemote(array $service,array $remote): bool
{
    $row=fetchOne("SELECT routerId,clientId,remoteId FROM ClientProvisioning WHERE serviceId=? AND connectionType='PPPOE' AND status='CONFIRMED'",[$service['id']]);
    return $row!==null && $row['remoteId']===($remote['.id']??null) && $row['routerId']===$service['routerId'] && $row['clientId']===$service['clientId'] && $service['username']===($remote['name']??null) && $service['ipAddress']===($remote['remote-address']??null);
}

function provisionMarkUncertain(array $row,string $message): array
{
    tx(function(PDO $pdo)use($row,$message):void{
        $pdo->prepare("UPDATE ClientProvisioning SET status='UNCERTAIN',lastError=?,updatedAt=? WHERE id=?")->execute([$message,now(),$row['id']]);
        $pdo->prepare("UPDATE Service SET syncStatus='FAILED',lastError=?,updatedAt=? WHERE id=?")->execute([$message,now(),$row['serviceId']]);
    });
    return fetchOne('SELECT * FROM ClientProvisioning WHERE id=?',[$row['id']]);
}

/** Local durable reservation is committed before the only authorized network add. */
function provisionApply(array $row,array $router,RouterTransport $transport): array
{
    [$service,$values]=provisionValues($row);
    $message='El cliente y servicio se guardaron; falta confirmar el alta en MikroTik. Usa Verificar y, si no existe, Reintentar.';
    db()->prepare("UPDATE ClientProvisioning SET status='APPLYING',lastError=NULL,updatedAt=? WHERE id=?")->execute([now(),$row['id']]);
    try {
        $remoteId=$transport->createClientResource(provisionPath($service['type']),$values);
        db()->prepare('UPDATE ClientProvisioning SET remoteId=?,updatedAt=? WHERE id=?')->execute([$remoteId,now(),$row['id']]);
        $row['remoteId']=$remoteId;
    }catch(Throwable $error){
        if($error instanceof RouterError && in_array($error->httpStatus,[401,403],true))$message='MikroTik rechazó el alta. Comprueba los permisos de escritura de su usuario API; después verifica o reintenta este mismo servicio.';
        // A lost acknowledgement is verified, never blindly added twice.
    }
    try {
        if(provisionVerify($row,$transport))return fetchOne('SELECT * FROM ClientProvisioning WHERE id=?',[$row['id']]);
    }catch(Throwable){ /* Return a durable pending state with no raw credentials/error payload. */ }
    return provisionMarkUncertain($row,$message);
}

function provisionRegister(array $input,array $actor): array
{
    $data=provisionValidate($input);$s=$data['service'];
    $hash=hash_hmac('sha256',json_encode([$data['client'],$s],JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE),encryptionKey());
    if(!lock('client-provision:'.$data['requestKey'],0))throw new HttpError(409,'Esta alta ya se está procesando. Espera y consulta su estado.','RESOURCE_BUSY');
    $transport=null;$routerLocked=false;
    try{
        $old=fetchOne('SELECT * FROM ClientProvisioning WHERE requestKey=?',[$data['requestKey']]);
        if($old!==null){if($old['actorId']!==$actor['id']||!hash_equals($old['requestHash'],$hash))throw new HttpError(409,'La clave de solicitud ya pertenece a otra alta.','IDEMPOTENCY_CONFLICT');return provisionPublic($old);}
        $routerLocked=lock('router:'.$s['routerId'],10);if(!$routerLocked)throw new HttpError(409,'El router está ocupado. Intenta de nuevo.','RESOURCE_BUSY');
        $router=provisionRouter($s['routerId']);$transport=provisionTransport($router);
        $inventory=provisionInventory($transport);
        $s=provisionGeneratePppoeCredentials($s,static fn(string $candidate):bool=>provisionUsernameFree($inventory,$router['id'],$candidate));
        [$plan,$pool]=provisionPreflight($router,$s,$inventory);
        if($s['type']==='SIMPLE_QUEUE')foreach(provisionRows($transport,'/ip/firewall/filter','.id,action,disabled') as $rule)if(($rule['action']??'')==='fasttrack-connection'&&!RouterTransportUtil::truthy($rule['disabled']??false))throw new HttpError(409,'FastTrack activo evita garantizar la velocidad de Simple Queue. Revisa la política QoS del router.','FASTTRACK_CONFLICT');
        $row=tx(function(PDO $pdo)use($data,$s,$hash,$actor,$plan,$pool,$router):array{
            $clientId=id();$serviceId=id();$operationId=id();$timestamp=now();
            apiInsert('Client',['id'=>$clientId,'code'=>'GG-'.substr($clientId,0,16),...$data['client']]);
            $pdo->prepare("INSERT INTO Service(id,clientId,planId,routerId,type,ipAddress,username,passwordEncrypted,desiredState,syncStatus,createdAt,updatedAt) VALUES (?,?,?,?,?,?,?,?,'ACTIVE','PENDING',?,?)")->execute([$serviceId,$clientId,$plan['id'],$s['routerId'],$s['type'],$s['ipAddress'],$s['username']??null,isset($s['password'])?encryptSecret($s['password']):null,$timestamp,$timestamp]);
            $reservedService=fetchOne('SELECT * FROM Service WHERE id=?',[$serviceId]);
            $intent=encryptSecret(json_encode(provisionBuildValues($reservedService,$plan,$data['client'],$router),JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE));
            $pdo->prepare('INSERT INTO ClientProvisioning(id,requestKey,requestHash,actorId,clientId,serviceId,routerId,connectionType,poolId,intentEncrypted,createdAt,updatedAt) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)')->execute([$operationId,$data['requestKey'],$hash,$actor['id'],$clientId,$serviceId,$s['routerId'],$s['type'],$pool['id'],$intent,$timestamp,$timestamp]);
            audit('client.provision.requested','Client',$clientId,$actor['id']);
            return fetchOne('SELECT * FROM ClientProvisioning WHERE id=?',[$operationId]);
        });
        return provisionPublic(provisionApply($row,$router,$transport));
    }finally{if($transport!==null)$transport->close();if($routerLocked)unlock('router:'.$s['routerId']);unlock('client-provision:'.$data['requestKey']);}
}

function provisionReconcile(string $id,array $actor,bool $retry): array
{
    $row=fetchOne('SELECT * FROM ClientProvisioning WHERE id=?',[$id])??throw new HttpError(404,'Alta no encontrada.','NOT_FOUND');
    if(!lock('router:'.$row['routerId'],10))throw new HttpError(409,'El router está ocupado.','RESOURCE_BUSY');
    $transport=null;
    try{
        $row=fetchOne('SELECT * FROM ClientProvisioning WHERE id=?',[$id]);
        if($row['status']==='CONFIRMED')return provisionPublic($row);
        $router=provisionRouter($row['routerId']);$transport=provisionTransport($router);
        try{if(provisionVerify($row,$transport))return provisionPublic(fetchOne('SELECT * FROM ClientProvisioning WHERE id=?',[$id]));}
        catch(RouterError){return provisionPublic(provisionMarkUncertain($row,'No se pudo verificar la cuenta. Se conserva la reserva; no se reenviaron cambios.'));}
        if(!$retry)return provisionPublic(provisionMarkUncertain($row,'El recurso no se observó en MikroTik. Puedes reintentar el alta de este mismo cliente.'));
        if($row['remoteId']!==null)throw new HttpError(409,'El router confirmó un identificador anteriormente; revisa por qué ya no aparece antes de crear otro recurso.','PROVISION_CONFLICT');
        [$service,$intent]=provisionValues($row);$inventory=provisionInventory($transport);
        $currentPlan=fetchOne('SELECT * FROM Plan WHERE id=?',[$service['planId']]);
        if($service['type']!=='SIMPLE_QUEUE'&&($currentPlan['pppoeProfile']??null)!==$intent['profile'])throw new HttpError(409,'El perfil del plan cambió después de solicitar el alta. Revisa la reserva antes de reintentar.','PROVISION_CONFLICT');
        provisionPreflight($router,$service+['poolId'=>$row['poolId']],$inventory,$service['id']);
        if($service['type']==='SIMPLE_QUEUE'){
            if($intent['max-limit']!==$currentPlan['uploadKbps'].'k/'.$currentPlan['downloadKbps'].'k'||$intent['priority']!==$currentPlan['priority'].'/'.$currentPlan['priority'])throw new HttpError(409,'La velocidad del plan cambió después de solicitar el alta. Revisa la reserva antes de reintentar.','PROVISION_CONFLICT');
            foreach(provisionRows($transport,'/ip/firewall/filter','.id,action,disabled') as $rule)if(($rule['action']??'')==='fasttrack-connection'&&!RouterTransportUtil::truthy($rule['disabled']??false))throw new HttpError(409,'FastTrack activo impide garantizar la velocidad de la cola.','FASTTRACK_CONFLICT');
        }
        audit('client.provision.retry','Client',$row['clientId'],$actor['id']);
        return provisionPublic(provisionApply($row,$router,$transport));
    }finally{if($transport!==null)$transport->close();unlock('router:'.$row['routerId']);}
}

function provisionDispatch(string $method,string $route): bool
{
    if($method==='GET'&&preg_match('#^/clients/provision/request/([a-f0-9-]{36})$#D',$route,$key)){
        $actor=permit('ADMIN','TECHNICIAN');$row=fetchOne('SELECT * FROM ClientProvisioning WHERE requestKey=? AND actorId=?',[$key[1],$actor['id']])??throw new HttpError(404,'La solicitud todavía no tiene un alta registrada.','NOT_FOUND');json(provisionPublic($row));
    }
    if($route==='/client-registration/settings'){
        if($method==='GET'){permit('ADMIN','TECHNICIAN');json(provisionSettings());}
        if($method==='PATCH'){
            $actor=permit('ADMIN');$data=body();
            if(array_diff(array_keys($data),['googleMapsApiKey','googleMapsMapId','centerLatitude','centerLongitude']))throw new HttpError(422,'Configuración de mapa no admitida.');
            $values=array_merge(provisionSettings(),$data);
            foreach(['googleMapsApiKey'=>255,'googleMapsMapId'=>128] as $field=>$limit)if(!is_string($values[$field])||strlen($values[$field])>$limit||($values[$field]!==''&&!preg_match('/^[a-z0-9_-]+$/iD',$values[$field])))throw new HttpError(422,'Clave o identificador de Google Maps inválido.');
            foreach(['centerLatitude'=>90,'centerLongitude'=>180] as $field=>$max)if(!is_numeric($values[$field])||!is_finite((float)$values[$field])||abs((float)$values[$field])>$max)throw new HttpError(422,'Centro de mapa inválido.');
            db()->prepare("INSERT INTO ClientRegistrationSettings(id,googleMapsApiKey,googleMapsMapId,centerLatitude,centerLongitude,updatedAt) VALUES ('primary',?,?,?,?,?) ON DUPLICATE KEY UPDATE googleMapsApiKey=VALUES(googleMapsApiKey),googleMapsMapId=VALUES(googleMapsMapId),centerLatitude=VALUES(centerLatitude),centerLongitude=VALUES(centerLongitude),updatedAt=VALUES(updatedAt)")->execute([$values['googleMapsApiKey'],$values['googleMapsMapId']?:'DEMO_MAP_ID',$values['centerLatitude'],$values['centerLongitude'],now()]);
            audit('client.map.settings','ClientRegistrationSettings','primary',$actor['id']);json(provisionSettings());
        }
    }
    if($method==='GET'&&$route==='/client-registration/options'){
        permit('ADMIN','TECHNICIAN');
        if(function_exists('set_time_limit'))set_time_limit(180);
        $result=['routers'=>fetchAll("SELECT id,name FROM Router WHERE transport IN ('REST','SOCKET') ORDER BY name LIMIT 1000"),'plans'=>fetchAll("SELECT p.id,p.name,p.pppoeProfile,p.downloadKbps,p.uploadKbps,p.priceCents,p.currency,i.routerId AS profileRouterId FROM Plan p LEFT JOIN RouterProfileImport i ON i.planId=p.id WHERE p.active=1 ORDER BY p.name LIMIT 2000"),'map'=>provisionSettings(),'pools'=>[],'suggestedIp'=>null,'defaultPoolId'=>null];
        if(isset($_GET['routerId'])&&$_GET['routerId']!==''){
            $id=provisionIdentifier($_GET['routerId']);if(!lock('router:'.$id,5))throw new HttpError(409,'El router está ocupado. Reintenta la consulta.','RESOURCE_BUSY');$transport=null;
            try{
                $router=provisionRouter($id);$transport=secretImportTransport($router);$inventory=provisionInventory($transport);$pools=provisionPools($inventory);
                $planId=$_GET['planId']??'';$plan=null;foreach($result['plans'] as $p)if($p['id']===$planId)$plan=$p;
                if($plan!==null)foreach($inventory['profiles'] as $profile)if($profile['name']===$plan['pppoeProfile'])foreach($pools as $pool)if($pool['source']==='POOL'&&$pool['name']===($profile['remote-address']??''))$result['defaultPoolId']=$pool['id'];
                $onlyPools=array_values(array_filter($pools,static fn(array $p):bool=>$p['source']==='POOL'));if($result['defaultPoolId']===null&&count($onlyPools)===1)$result['defaultPoolId']=$onlyPools[0]['id'];
                $selected=$_GET['poolId']??$result['defaultPoolId'];$occupied=provisionOccupied($inventory,$id);
                foreach($pools as $pool){if($pool['id']===$selected)$result['suggestedIp']=provisionNextIp($pool['intervals'],$occupied);unset($pool['intervals']);$result['pools'][]=$pool;}
            }catch(RouterError){throw new HttpError(502,'No se pudo consultar el inventario del router. Comprueba conectividad y permisos de lectura de la API.','ROUTER_UNAVAILABLE');}
            finally{if($transport!==null)$transport->close();unlock('router:'.$id);}
        }
        json($result);
    }
    if($method==='POST'&&$route==='/clients/provision'){
        $actor=permit('ADMIN','TECHNICIAN');rateLimit('client-provision:'.$actor['id'],30,60);if(function_exists('set_time_limit'))set_time_limit(180);ignore_user_abort(true);
        try{$result=provisionRegister(body(),$actor);json($result,$result['status']==='CONFIRMED'?201:202);}catch(RouterError){throw new HttpError(502,'No se pudo validar el inventario del MikroTik. Comprueba su API y permisos; no se creó el alta.','ROUTER_UNAVAILABLE');}
    }
    if(preg_match('#^/clients/provision/([a-f0-9]{24})(?:/(verify|retry))?$#D',$route,$m)){
        $actor=permit('ADMIN','TECHNICIAN');
        if($method==='GET'&&!isset($m[2]))json(provisionPublic(fetchOne('SELECT * FROM ClientProvisioning WHERE id=?',[$m[1]])??throw new HttpError(404,'Alta no encontrada.')));
        if($method==='POST'&&isset($m[2])){
            if(body()!==[])throw new HttpError(422,'La verificación no admite parámetros.');rateLimit('client-provision:'.$actor['id'],30,60);
            if(function_exists('set_time_limit'))set_time_limit(180);ignore_user_abort(true);
            try{json(provisionReconcile($m[1],$actor,$m[2]==='retry'));}
            catch(RouterError){throw new HttpError(502,'No se pudo completar la lectura del router. El alta y su reserva se conservan para verificar de nuevo.','ROUTER_UNAVAILABLE');}
        }
    }
    return false;
}
