<?php
declare(strict_types=1);
namespace Nexo;

require_once __DIR__ . '/secret-import.php';
require_once __DIR__ . '/client-pppoe-edit.php';

function clientNameSyncPending(string $routerId): ?array
{
    return fetchOne("SELECT * FROM `ClientNameSync` WHERE routerId=? AND status IN ('PREPARED','UNCERTAIN') ORDER BY createdAt,id LIMIT 1", [$routerId]);
}

function clientNameSyncOwnPending(string $clientId): ?array
{
    return fetchOne("SELECT * FROM `ClientNameSync` WHERE clientId=? AND status IN ('PREPARED','UNCERTAIN') ORDER BY createdAt,id LIMIT 1", [$clientId]);
}

function clientNameSyncSource(string $clientId): ?array
{
    return fetchOne('SELECT * FROM `RouterSecretImport` WHERE clientId=?', [$clientId]);
}

function clientNameSyncClientHash(array $client): string
{
    $fields = apiPick($client, apiFields('Client'));
    $notes = clientNotesGet($client['id']);
    // Older pending operations predate internal notes. Keep their empty-note
    // hash identical while including actual notes in new optimistic versions.
    if ($notes !== null && $notes !== '') $fields['notes'] = $notes;
    return hash('sha256', json_encode($fields, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE));
}

function clientNameSyncVersion(array $client, array $source): string
{
    return hash('sha256', clientNameSyncClientHash($client) . "\0" . $source['id'] . "\0" . $source['routerId'] . "\0" . $source['remoteId'] . "\0" .
        $source['username'] . "\0" . $source['snapshotHash'] . "\0" . $source['present'] . "\0" . $source['pppService']);
}

/** These comments identify resources to the provisioning controller. */
function clientNameSyncReservedComment(string $comment): bool
{
    return preg_match('/^\s*nexoisp:/i', $comment) === 1;
}

function clientNameSyncBlocked(array $source): ?string
{
    if (!in_array($source['pppService'], ['pppoe','any'], true)) return 'La sincronización de nombre sólo admite cuentas PPPoE o any.';
    if (!(bool)$source['present']) return 'La cuenta no aparece en la última importación. Lee sus secrets antes de cambiar el nombre.';
    if (clientNameSyncReservedComment($source['comment'])) return 'El comentario de esta cuenta identifica un servicio gestionado y debe conservarse.';
    $linked = fetchAll("SELECT * FROM `Service` WHERE routerId=? AND type='PPPOE' AND CAST(username AS BINARY)=? AND desiredState<>'RETIRED'", [$source['routerId'],$source['username']]);
    foreach ($linked as $service) {
        $remote=['.id'=>$source['remoteId'],'name'=>$source['username'],'remote-address'=>$source['remoteAddress']];
        if(!(function_exists(__NAMESPACE__ . '\\provisionOwnsRemote') && provisionOwnsRemote($service,$remote)))return 'La cuenta tiene un servicio gestionado vinculado. Su comentario de propiedad no se reemplaza por un nombre.';
    }
    return null;
}

function clientNameSyncMetadata(string $clientId, array $actor): array
{
    $client = apiRecord('Client', $clientId);
    $source = clientNameSyncSource($clientId);
    $admin = $actor['role'] === 'ADMIN';
    $canEditLocal = in_array($actor['role'], ['ADMIN','BILLING','TECHNICIAN'], true);
    if (!$source) return ['supported'=>false,'canSync'=>false,'canChangeName'=>$canEditLocal,'pending'=>null,'blockedReason'=>null,'editVersion'=>null,'currentName'=>$client['name'],'syncNeeded'=>false];
    $pending = clientNameSyncPending($source['routerId']);
    $ownPending = $pending && $pending['clientId'] === $clientId;
    $blocked = clientNameSyncBlocked($source);
    if (clientPppoeEditPending($source['routerId'])) $blocked = 'Hay una edición de credenciales pendiente en este router. Verifícala antes de cambiar el nombre.';
    if ($pending) $blocked = $ownPending ? 'El cambio de nombre está pendiente de confirmar. Usa Verificar nombre pendiente.' : 'Hay otro cambio de nombre pendiente en este router. Verifícalo antes de cambiar este nombre.';
    if (!$admin && $blocked === null) $blocked = 'Sólo un administrador puede sincronizar el nombre con MikroTik.';
    return ['supported'=>true,'canSync'=>$admin && $blocked === null,'canChangeName'=>$admin && $blocked === null,
        'pending'=>$ownPending ? ['id'=>$pending['id'],'status'=>$pending['status']] : null,
        'blockedReason'=>$blocked,'editVersion'=>clientNameSyncVersion($client,$source),'currentName'=>$client['name'],
        'syncNeeded'=>$client['name'] !== secretImportClientName($source['username'],$source['comment'])];
}

function clientNameSyncCanonical(string $name): string
{
    if (preg_match('//u', $name) !== 1 || preg_match('/[\x00-\x1F\x7F-\x{009F}]/u', $name) || preg_match_all('/./us', $name) > 200) {
        throw new HttpError(422, 'El nombre debe ser texto UTF-8 de hasta 200 caracteres, sin controles ni saltos de línea.', 'VALIDATION_ERROR');
    }
    $name = secretImportCommentName($name);
    if ($name === '') throw new HttpError(422, 'El nombre completo no puede quedar vacío.', 'VALIDATION_ERROR');
    return $name;
}

function clientNameSyncRead(RouterTransport $transport, array $source): array
{
    $rows = $transport->print('/ppp/secret', ['.id'=>$source['remoteId']], ['.proplist'=>SECRET_IMPORT_PROPERTIES]);
    if (count($rows) !== 1 || !is_array($rows[0]) || ($rows[0]['.id'] ?? null) !== $source['remoteId'] || ($rows[0]['name'] ?? null) !== $source['username'] ||
        !in_array($rows[0]['service'] ?? null, ['pppoe','any'], true)) {
        throw new HttpError(409, 'La cuenta cambió de identidad o desapareció. Vuelve a leer sus secrets antes de editar el nombre.', 'CLIENT_NAME_STALE');
    }
    if (!is_string($rows[0]['comment'] ?? '')) throw new HttpError(502, 'El router no entregó un comentario válido.', 'INVALID_ROUTER_RESPONSE');
    return $rows[0];
}

function clientNameSyncConfirm(array $operation, array $remote, array $actor): array
{
    if (($remote['.id'] ?? null) !== $operation['remoteId'] || ($remote['name'] ?? null) !== $operation['expectedUsername'] || ($remote['comment'] ?? '') !== $operation['desiredComment']) {
        throw new HttpError(409, 'No se pudo confirmar el comentario solicitado en la cuenta esperada.', 'CLIENT_NAME_STALE');
    }
    $normalized = secretImportNormalize([$remote])[0];
    $client = tx(function (\PDO $pdo) use ($operation,$normalized,$actor): array {
        $client = apiRecord('Client', $operation['clientId'], true);
        if (!hash_equals($operation['oldClientHash'], clientNameSyncClientHash($client))) throw new HttpError(409, 'Los datos locales cambiaron mientras se verificaba el nombre. Es necesario revisar el cambio pendiente.', 'CLIENT_NAME_STALE');
        $source = fetchOne('SELECT * FROM `RouterSecretImport` WHERE id=? AND clientId=? FOR UPDATE', [$operation['secretId'],$operation['clientId']]);
        if (!$source || $source['routerId'] !== $operation['routerId'] || $source['remoteId'] !== $operation['remoteId'] || $source['username'] !== $operation['expectedUsername']) {
            throw new HttpError(409, 'El origen del cliente cambió. No se puede completar la sincronización del nombre.', 'CLIENT_NAME_STALE');
        }
        $patch = is_array($operation['localPatch']) ? $operation['localPatch'] : json_decode((string)$operation['localPatch'], true, 128, JSON_THROW_ON_ERROR);
        $patch = validate('client', $patch, true);
        if (($patch['name'] ?? null) !== $operation['desiredComment']) throw new HttpError(409, 'La intención del nombre no es válida.', 'CLIENT_NAME_STALE');
        $pdo->prepare('UPDATE `RouterSecretImport` SET pppService=?,profile=?,remoteAddress=?,localAddress=?,callerId=?,disabled=?,comment=?,present=1,snapshotHash=?,lastSeenAt=? WHERE id=?')->execute([
            $normalized['pppService'],$normalized['profile'],$normalized['remoteAddress'],$normalized['localAddress'],$normalized['callerId'],(int)$normalized['disabled'],$normalized['comment'],$normalized['snapshotHash'],now(),$source['id'],
        ]);
        $client = apiUpdate('Client', $operation['clientId'], $patch);
        $pdo->prepare("UPDATE `ClientNameSync` SET status='CONFIRMED',localPatch=NULL,updatedAt=? WHERE id=?")->execute([now(),$operation['id']]);
        audit('CLIENT_NAME_SYNC_CONFIRMED','ClientNameSync',$operation['id'],$actor['id']);
        return $client;
    });
    unset($GLOBALS['nexo_secret_import_cache']);
    return ['status'=>'CONFIRMED','message'=>'Nombre guardado en GIGARED ISP y en el comentario PPPoE del MikroTik.','operationId'=>$operation['id'],'client'=>apiDto('Client',$client)];
}

function clientNameSyncUncertain(array $operation): array
{
    db()->prepare("UPDATE `ClientNameSync` SET status='UNCERTAIN',updatedAt=? WHERE id=? AND status IN ('PREPARED','UNCERTAIN')")->execute([now(),$operation['id']]);
    return ['status'=>'UNCERTAIN','operationId'=>$operation['id'],'message'=>'No se pudo confirmar el nombre en MikroTik. Los datos locales no se guardaron. Usa Verificar nombre pendiente antes de volver a guardar.'];
}

/** The normal Save action is local unless an explicitly included name needs sync. */
function clientNameSyncPatch(string $clientId, array $data, array $actor, mixed $version): array
{
    $initial = apiRecord('Client', $clientId);
    $initialSource = clientNameSyncSource($clientId);
    $keys = ['client:' . $clientId];
    if ($initialSource) $keys[] = 'router:' . $initialSource['routerId'];
    return apiLocks($keys, function () use ($clientId,$data,$actor,$version): array {
        $client = apiRecord('Client', $clientId);
        if(array_key_exists('name',$data) && $data['name']!==$client['name'] && function_exists(__NAMESPACE__ . '\\clientPppRequireSettled'))clientPppRequireSettled($clientId);
        if(array_key_exists('name',$data) && $data['name']!==$client['name'] && function_exists(__NAMESPACE__ . '\\provisionPending') && provisionPending($clientId))throw new HttpError(409,'Confirma primero el alta del cliente antes de cambiar su nombre.','PROVISION_PENDING');
        if (clientNameSyncOwnPending($clientId)) throw new HttpError(409, 'El cliente tiene un nombre pendiente de confirmar. Verifícalo antes de guardar otros datos.', 'CLIENT_NAME_PENDING');
        $source = clientNameSyncSource($clientId);
        if ($source && array_key_exists('name',$data)) {
            $data['name'] = clientNameSyncCanonical($data['name']);
            if ($data['name'] !== $client['name'] && $actor['role'] !== 'ADMIN') throw new HttpError(403, 'Sólo un administrador puede cambiar el nombre de un cliente importado de MikroTik.', 'FORBIDDEN');
        }
        $needsSync = $source && array_key_exists('name',$data) && $data['name'] !== secretImportClientName($source['username'],$source['comment']);
        if (!$needsSync) {
            $record = tx(function (\PDO $pdo) use ($clientId,$data,$actor): array {
                $record = apiUpdate('Client',$clientId,$data);
                audit('UPDATE','Client',$clientId,$actor['id']);
                return $record;
            });
            return apiDto('Client',$record);
        }
        if ($actor['role'] !== 'ADMIN') throw new HttpError(403, 'Sólo un administrador puede sincronizar el nombre de este cliente con MikroTik.', 'FORBIDDEN');
        if (!is_string($version) || preg_match('/^[a-f0-9]{64}$/D',$version) !== 1) throw new HttpError(409, 'Abre de nuevo Editar cliente para obtener la versión de su nombre antes de guardarlo.', 'CLIENT_NAME_VERSION_REQUIRED');
        if (!hash_equals(clientNameSyncVersion($client,$source),$version)) throw new HttpError(409, 'El cliente o su cuenta cambiaron desde que abriste el formulario. Recarga sus datos.', 'CLIENT_NAME_STALE');
        if (($blocked = clientNameSyncBlocked($source)) !== null) throw new HttpError(409,$blocked,'CLIENT_NAME_UNSUPPORTED');
        if (clientPppoeEditPending($source['routerId']) || clientNameSyncPending($source['routerId'])) throw new HttpError(409, 'Hay una edición pendiente en este router. Verifícala antes de cambiar el nombre.', 'CLIENT_NAME_PENDING');
        $data['name'] = clientNameSyncCanonical($data['name']);
        if (isset($data['code']) && fetchOne('SELECT id FROM `Client` WHERE code=? AND id<>?', [$data['code'],$clientId])) throw new HttpError(409, 'Ese código ya está asignado a otro cliente.', 'DATA_CONFLICT');
        $router = fetchOne('SELECT * FROM `Router` WHERE id=?',[$source['routerId']]) ?? throw new HttpError(404,'Router no encontrado.','NOT_FOUND');
        try { $transport = clientPppoeEditTransport($router); }
        catch (\Throwable) { throw new HttpError(502,'No se pudo abrir el acceso de sincronización al router.','ROUTER_UNAVAILABLE'); }
        try {
            $remote = clientNameSyncRead($transport,$source);
            if (clientNameSyncReservedComment($remote['comment'] ?? '')) throw new HttpError(409,'El comentario remoto identifica un servicio gestionado y debe conservarse.','CLIENT_NAME_UNSUPPORTED');
            if (secretImportDisplayText($remote['comment'] ?? '',true) !== $source['comment']) throw new HttpError(409,'El comentario cambió directamente en el router. Vuelve a leer los secrets antes de guardar.','CLIENT_NAME_STALE');
            if (preg_match('/^\*[a-z0-9]{1,32}$/iD',$source['remoteId']) !== 1) throw new HttpError(409,'El identificador remoto no admite una actualización segura.','CLIENT_NAME_STALE');
            try { RouterTransportUtil::requirePppoeCommentEdit(true,$source['remoteId'],$data['name']); }
            catch (RouterError) { throw new HttpError(422,'El nombre no tiene un formato válido para el comentario PPPoE. No se guardaron cambios.','VALIDATION_ERROR'); }
            $operation = ['id'=>id(),'routerId'=>$source['routerId'],'clientId'=>$clientId,'secretId'=>$source['id'],'remoteId'=>$source['remoteId'],
                'expectedUsername'=>$source['username'],'oldComment'=>$source['comment'],'desiredComment'=>$data['name'],'oldClientHash'=>clientNameSyncClientHash($client),
                'localPatch'=>$data,'writeAcknowledged'=>0];
            tx(function (\PDO $pdo) use ($operation,$actor): void {
                $pdo->prepare('INSERT INTO `ClientNameSync` (id,routerId,clientId,secretId,remoteId,expectedUsername,oldComment,desiredComment,oldClientHash,localPatch,writeAcknowledged,status,actorId,createdAt,updatedAt) VALUES (?,?,?,?,?,?,?,?,?,?,0,\'PREPARED\',?,?,?)')->execute([
                    $operation['id'],$operation['routerId'],$operation['clientId'],$operation['secretId'],$operation['remoteId'],$operation['expectedUsername'],$operation['oldComment'],$operation['desiredComment'],$operation['oldClientHash'],
                    json_encode($operation['localPatch'],JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE),$actor['id'],now(),now(),
                ]);
                audit('CLIENT_NAME_SYNC_REQUESTED','ClientNameSync',$operation['id'],$actor['id']);
            });
            try {
                $transport->setPppoeComment($source['remoteId'],$operation['desiredComment']);
                $operation['writeAcknowledged'] = 1;
                db()->prepare('UPDATE `ClientNameSync` SET writeAcknowledged=1,updatedAt=? WHERE id=?')->execute([now(),$operation['id']]);
                $after = clientNameSyncRead($transport,$source);
                $result = clientNameSyncConfirm($operation,$after,$actor);
                return $result['client'] + ['nameSync'=>['status'=>$result['status'],'message'=>$result['message']]];
            } catch (RouterError $error) {
                if (!(bool)$operation['writeAcknowledged'] && (in_array($error->httpStatus,[400,401,403,404,405,422],true) || $error->httpStatus === null && $error->routerCode === 'ROUTER_TRAP')) {
                    db()->prepare("UPDATE `ClientNameSync` SET status='FAILED',localPatch=NULL,updatedAt=? WHERE id=?")->execute([now(),$operation['id']]);
                    audit('CLIENT_NAME_SYNC_REJECTED','ClientNameSync',$operation['id'],$actor['id']);
                    throw new HttpError(502,'MikroTik rechazó el comentario. Los datos locales no se guardaron. Revisa los permisos de escritura y vuelve a cargar el cliente.','CLIENT_NAME_REJECTED');
                }
            } catch (\Throwable) { /* Remote success and local/verification failure is uncertain. */ }
            clientNameSyncUncertain($operation);
            throw new HttpError(409,'El resultado del nombre en MikroTik no pudo confirmarse. Los datos locales no se guardaron. Usa Verificar nombre pendiente.','CLIENT_NAME_UNCERTAIN');
        } catch (RouterError) { throw new HttpError(502,'No se pudo comprobar el comentario o los permisos del router. No se guardaron datos locales.','ROUTER_UNAVAILABLE'); }
        finally { $transport->close(); }
    });
}

function clientNameSyncReconcile(string $clientId, array $actor): array
{
    if ($actor['role'] !== 'ADMIN') throw new HttpError(403,'Sólo un administrador puede verificar el nombre pendiente.','FORBIDDEN');
    $initial = clientNameSyncOwnPending($clientId) ?? throw new HttpError(409,'Este cliente no tiene un nombre pendiente.','CLIENT_NAME_NO_PENDING');
    return apiLocks(['client:' . $clientId,'router:' . $initial['routerId']],function () use ($clientId,$actor): array {
        $operation = clientNameSyncOwnPending($clientId) ?? throw new HttpError(409,'Este cliente no tiene un nombre pendiente.','CLIENT_NAME_NO_PENDING');
        $source = clientNameSyncSource($clientId);
        if (!$source || $source['id'] !== $operation['secretId'] || $source['remoteId'] !== $operation['remoteId'] || $source['username'] !== $operation['expectedUsername']) return clientNameSyncUncertain($operation);
        $router = fetchOne('SELECT * FROM `Router` WHERE id=?',[$operation['routerId']]);
        try { $transport = secretImportTransport($router); }
        catch (\Throwable) { return clientNameSyncUncertain($operation); }
        try {
            $remote = clientNameSyncRead($transport,$source);
            if (($remote['comment'] ?? '') !== $operation['desiredComment']) return clientNameSyncUncertain($operation);
            return clientNameSyncConfirm($operation,$remote,$actor);
        } catch (\Throwable) { return clientNameSyncUncertain($operation); }
        finally { $transport->close(); }
    });
}

function clientNameSyncDispatch(string $method, string $route): bool
{
    if ($method === 'GET' && preg_match('#^/clients/([a-f0-9]{24})/name-sync$#D',$route,$match)) json(clientNameSyncMetadata($match[1],requireAuth()));
    if ($method === 'POST' && preg_match('#^/clients/([a-f0-9]{24})/name-sync/reconcile$#D',$route,$match)) {
        $actor = permit('ADMIN');
        if (body() !== []) throw new HttpError(422,'La verificación del nombre sólo admite un objeto vacío.','VALIDATION_ERROR');
        rateLimit('client-name-verify:' . $actor['id'],60,60);
        json(clientNameSyncReconcile($match[1],$actor));
    }
    return false;
}
