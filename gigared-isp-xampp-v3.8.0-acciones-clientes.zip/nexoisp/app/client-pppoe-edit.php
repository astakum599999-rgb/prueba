<?php
declare(strict_types=1);
namespace Nexo;

/** A separate, explicit administrative action; never enables generic network writes. */
function clientPppoeEditTransport(array $router): RouterTransport
{
    $password = decryptSecret((string)$router['passwordEncrypted']);
    return match ($router['transport']) {
        'REST' => new RouterRestTransport($router, $password, 15.0, true),
        'SOCKET' => new RouterSocketTransport($router, $password, 15.0, true),
        default => throw new HttpError(422, 'La edición requiere un router real con API Socket o REST.', 'INVALID_ROUTER'),
    };
}

function clientPppoeEditVersion(array $row, string $source): string
{
    return hash('sha256', $source . "\0" . $row['id'] . "\0" . ($row['username'] ?? '') . "\0" .
        ($source === 'imported' ? $row['snapshotHash'] . "\0" . $row['remoteId'] . "\0" . $row['present'] : $row['revision'] . "\0" . ($row['passwordEncrypted'] ?? '') . "\0" . $row['updatedAt']));
}

function clientPppoeEditPending(string $routerId): ?array
{
    return fetchOne("SELECT * FROM `PppoeAccountEdit` WHERE routerId=? AND status IN ('PREPARED','UNCERTAIN') ORDER BY createdAt,id LIMIT 1", [$routerId]);
}

function clientPppoeEditMetadata(array $row, string $source, bool $admin): array
{
    $pending = clientPppoeEditPending($row['routerId']);
    $namePending = function_exists(__NAMESPACE__ . '\clientNameSyncPending') ? clientNameSyncPending($row['routerId']) : null;
    $ownPending = $pending && $pending['sourceType'] === $source && $pending['sourceId'] === $row['id'];
    $provisionPending = function_exists(__NAMESPACE__ . '\\provisionPending') && provisionPending($row['clientId']);
    if(function_exists(__NAMESPACE__ . '\\clientPppPending') && clientPppPending($row['clientId'])) $provisionPending=true;
    $available = $source === 'imported' ? (bool)$row['present'] : $row['desiredState'] !== 'RETIRED' && is_string($row['username']) && $row['username'] !== '';
    return ['canEdit' => $admin && $available && !$pending && !$namePending && !$provisionPending, 'editVersion' => clientPppoeEditVersion($row, $source),
        'editBlockedReason' => !$admin ? 'Solo un administrador puede editar credenciales PPPoE.' : ($provisionPending ? 'Primero confirma el alta de este cliente en Ver detalle.' : ($namePending ? 'Hay un nombre pendiente de verificar en este router. Usa Verificar nombre pendiente en Editar cliente.' : ($pending ? 'Hay un cambio pendiente de verificar en este router. Usa Verificar cambios pendientes en la cuenta correspondiente.' : (!$available ? 'La cuenta no está disponible para editar.' : null)))),
        'pendingEdit' => $ownPending ? ['id' => $pending['id'], 'status' => $pending['status'], 'createdAt' => $pending['createdAt']] : null];
}

function clientPppoeEditValidate(array $input, string $source): array
{
    if (array_diff(array_keys($input), ['editVersion','username','password']) || !is_string($input['editVersion'] ?? null) || !preg_match('/^[a-f0-9]{64}$/D', $input['editVersion'])) {
        throw new HttpError(422, 'La edición requiere la versión de la cuenta y sólo admite usuario o contraseña.', 'VALIDATION_ERROR');
    }
    $output = ['editVersion' => $input['editVersion']];
    foreach (['username','password'] as $field) {
        if (!array_key_exists($field, $input)) continue;
        $value = $input[$field];
        $limit = $field === 'username' ? ($source === 'service' ? 100 : 255) : 200;
        if (!is_string($value) || $value === '' || strlen($value) > $limit * 4 || preg_match('//u', $value) !== 1 || preg_match('/[\x00-\x1F\x7F-\x{009F}]/u', $value) || preg_match_all('/./us', $value) > $limit) {
            throw new HttpError(422, 'El nuevo ' . ($field === 'username' ? 'usuario' : 'valor de contraseña') . ' no tiene un formato admitido. No se aplicó ningún cambio.', 'VALIDATION_ERROR');
        }
        $output[$field] = $value; // Deliberately no trim/encoding conversion.
    }
    if (count($output) === 1) throw new HttpError(422, 'Escribe al menos un cambio de usuario o contraseña.', 'VALIDATION_ERROR');
    return $output;
}

function clientPppoeEditSource(string $clientId, string $source, string $id): array
{
    $row = $source === 'imported'
        ? fetchOne("SELECT * FROM `RouterSecretImport` WHERE id=? AND clientId=? AND pppService IN ('pppoe','any')", [$id,$clientId])
        : fetchOne("SELECT * FROM `Service` WHERE id=? AND clientId=? AND type='PPPOE'", [$id,$clientId]);
    if (!$row) throw new HttpError(404, 'Cuenta PPPoE no encontrada para este cliente.', 'NOT_FOUND');
    return $row;
}

function clientPppoeEditRead(RouterTransport $transport, string $remoteId, bool $password = false): array
{
    $rows = $transport->print('/ppp/secret', ['.id' => $remoteId], ['.proplist' => SECRET_IMPORT_PROPERTIES . ($password ? ',password' : '')]);
    if (count($rows) !== 1 || !is_array($rows[0]) || ($rows[0]['.id'] ?? null) !== $remoteId) throw new HttpError(409, 'La cuenta cambió o desapareció del router. Revisa su identidad antes de editar.', 'STALE_ACCOUNT');
    if (!in_array($rows[0]['service'] ?? null, ['pppoe','any'], true)) throw new HttpError(409, 'La cuenta ya no permite conexiones PPPoE.', 'STALE_ACCOUNT');
    return $rows[0];
}

function clientPppoeEditLinkedServices(array $sourceRow, string $source): array
{
    $linked = fetchAll("SELECT * FROM `Service` WHERE routerId=? AND type='PPPOE' AND CAST(username AS BINARY)=? AND desiredState<>'RETIRED'", [$sourceRow['routerId'],$sourceRow['username']]);
    foreach ($linked as $service) if ($service['clientId'] !== $sourceRow['clientId']) throw new HttpError(409, 'La cuenta también está vinculada a otro cliente. Resuelve ese vínculo antes de editar.', 'ACCOUNT_CONFLICT');
    if ($source === 'service' && !array_filter($linked, fn($row) => $row['id'] === $sourceRow['id'])) throw new HttpError(409, 'Un servicio retirado no puede editar credenciales.', 'ACCOUNT_CONFLICT');
    return $linked;
}

function clientPppoeEditCheckCollisions(array $sourceRow, string $source, string $newUsername, array $linked, RouterTransport $transport, string $remoteId): void
{
    $snapshots = fetchAll('SELECT id,clientId,username FROM `RouterSecretImport` WHERE routerId=? AND username=?', [$sourceRow['routerId'],$newUsername]);
    foreach ($snapshots as $snapshot) if (!($source === 'imported' && $snapshot['id'] === $sourceRow['id']) && !($source === 'service' && $snapshot['clientId'] === $sourceRow['clientId'] && $snapshot['username'] === $sourceRow['username'])) throw new HttpError(409, 'Ese usuario ya está vinculado a un cliente en GIGARED ISP.', 'ACCOUNT_CONFLICT');
    $allowed = array_column($linked, 'id');
    $services = fetchAll("SELECT id FROM `Service` WHERE routerId=? AND occupiedUsername=?", [$sourceRow['routerId'],$newUsername]);
    foreach ($services as $service) if (!in_array($service['id'], $allowed, true)) throw new HttpError(409, 'Ese usuario ya está reservado por otro servicio.', 'ACCOUNT_CONFLICT');
    // Binary legacy names cannot be represented in REST query JSON. Their existing
    // identity is checked by id; a new username has already passed UTF-8 validation.
    if ($newUsername === $sourceRow['username']) return;
    $remote = $transport->print('/ppp/secret', ['name' => $newUsername], ['.proplist' => '.id,name']);
    foreach ($remote as $row) if (($row['.id'] ?? null) !== $remoteId) throw new HttpError(409, 'Ese usuario ya existe en el MikroTik.', 'ACCOUNT_CONFLICT');
}

/** Commit only after a read verifies the selected id and desired exact username. */
function clientPppoeEditConfirm(array $operation, array $remote, array $actor): array
{
    if (($remote['.id'] ?? null) !== $operation['remoteId'] || ($remote['name'] ?? null) !== $operation['newUsername']) throw new HttpError(409, 'No se pudo verificar la identidad resultante.', 'STALE_ACCOUNT');
    $normalized = secretImportNormalize([$remote])[0];
    tx(function (\PDO $pdo) use ($operation,$normalized,$actor): void {
        $sourceRow = clientPppoeEditSource($operation['clientId'],$operation['sourceType'],$operation['sourceId']);
        $linked = clientPppoeEditLinkedServices($sourceRow,$operation['sourceType']);
        foreach ($linked as $service) {
            if (preg_match_all('/./us', $operation['newUsername']) > 100) throw new HttpError(409, 'El nuevo usuario supera el límite del servicio gestionado.', 'ACCOUNT_CONFLICT');
            $params = [$operation['newUsername'],now(),$service['id']];
            $passwordClause = '';
            if ((bool)$operation['passwordChanged']) { $passwordClause = ',passwordEncrypted=?'; $params = [$operation['newUsername'],now(),$operation['passwordEncrypted'],$service['id']]; }
            $pdo->prepare('UPDATE `Service` SET username=?,updatedAt=?,revision=revision+1' . $passwordClause . ' WHERE id=?')->execute($params);
        }
        $snapshots = fetchAll('SELECT * FROM `RouterSecretImport` WHERE routerId=? AND clientId=? AND username=? FOR UPDATE', [$operation['routerId'],$operation['clientId'],$operation['oldUsername']]);
        foreach ($snapshots as $snapshot) {
            // Preserve customer/code, first seen, contacts, and status. The selected
            // secret is refreshed as an observation, without provisioning anything.
            if ($snapshot['remoteId'] !== $operation['remoteId']) throw new HttpError(409, 'El vínculo observado cambió. Debe revisarlo el administrador.', 'ACCOUNT_CONFLICT');
            $pdo->prepare('UPDATE `RouterSecretImport` SET username=?,pppService=?,profile=?,remoteAddress=?,localAddress=?,callerId=?,disabled=?,comment=?,present=1,snapshotHash=?,lastSeenAt=? WHERE id=?')->execute([
                $normalized['username'],$normalized['pppService'],$normalized['profile'],$normalized['remoteAddress'],$normalized['localAddress'],$normalized['callerId'],(int)$normalized['disabled'],$normalized['comment'],$normalized['snapshotHash'],now(),$snapshot['id'],
            ]);
        }
        $pdo->prepare("UPDATE `PppoeAccountEdit` SET status='CONFIRMED',passwordEncrypted=NULL,updatedAt=? WHERE id=?")->execute([now(),$operation['id']]);
        audit('PPPOE_EDIT_CONFIRMED','PppoeAccountEdit',$operation['id'],$actor['id']);
    });
    unset($GLOBALS['nexo_secret_import_cache']);
    return ['status' => 'CONFIRMED','operationId' => $operation['id'],'message' => 'Credenciales actualizadas en MikroTik y sincronizadas en GIGARED ISP. No se solicitó desconectar sesiones.'];
}

function clientPppoeEditUncertain(array $operation): array
{
    db()->prepare("UPDATE `PppoeAccountEdit` SET status='UNCERTAIN',updatedAt=? WHERE id=? AND status IN ('PREPARED','UNCERTAIN')")->execute([now(),$operation['id']]);
    return ['status' => 'UNCERTAIN','operationId' => $operation['id'],'message' => 'El resultado no pudo confirmarse. No repitas el cambio: usa Verificar cambios pendientes para consultar el router sin volver a escribir.'];
}

function clientPppoeEditRun(string $clientId, string $source, string $id, array $input, array $actor): array
{
    if ($actor['role'] !== 'ADMIN') throw new HttpError(403, 'Solo un administrador puede editar credenciales PPPoE.', 'FORBIDDEN');
    $input = clientPppoeEditValidate($input,$source);
    $initial = clientPppoeEditSource($clientId,$source,$id);
    return apiLocks(['client:' . $clientId,'router:' . $initial['routerId']], function () use ($clientId,$source,$id,$input,$actor): array {
        if(function_exists(__NAMESPACE__ . '\\clientPppRequireSettled'))clientPppRequireSettled($clientId);
        if(function_exists(__NAMESPACE__ . '\\provisionPending') && provisionPending($clientId))throw new HttpError(409,'Confirma primero el alta del cliente antes de editar sus credenciales.','PROVISION_PENDING');
        $row = clientPppoeEditSource($clientId,$source,$id);
        if (!hash_equals(clientPppoeEditVersion($row,$source),$input['editVersion'])) throw new HttpError(409, 'La cuenta cambió desde que abriste el formulario. Recarga sus datos antes de guardar.', 'STALE_ACCOUNT');
        if (clientPppoeEditPending($row['routerId'])) throw new HttpError(409, 'Hay un cambio pendiente de verificar en este router.', 'PPPOE_EDIT_PENDING');
        if (function_exists(__NAMESPACE__ . '\clientNameSyncPending') && clientNameSyncPending($row['routerId'])) throw new HttpError(409, 'Hay un nombre pendiente de verificar en este router.', 'CLIENT_NAME_UNCERTAIN');
        if ($source === 'imported' && !(bool)$row['present']) throw new HttpError(409, 'La cuenta no aparece en la última importación.', 'STALE_ACCOUNT');
        $linked = clientPppoeEditLinkedServices($row,$source);
        $username = $input['username'] ?? $row['username'];
        if (!is_string($username) || $username === '') throw new HttpError(409, 'La cuenta requiere un usuario válido.', 'STALE_ACCOUNT');
        if ($linked && (preg_match('//u',$username) !== 1 || preg_match_all('/./us',$username) > 100)) throw new HttpError(422, 'Un servicio gestionado admite hasta 100 caracteres en su usuario.', 'VALIDATION_ERROR');
        $values = [];
        if ($username !== $row['username']) $values['name'] = $username;
        if (array_key_exists('password',$input)) $values['password'] = $input['password'];
        if (!$values) throw new HttpError(422, 'No hay cambios de credenciales para aplicar.', 'VALIDATION_ERROR');
        $router = fetchOne('SELECT * FROM `Router` WHERE id=?', [$row['routerId']]) ?? throw new HttpError(404, 'Router no encontrado.', 'NOT_FOUND');
        try { $transport = clientPppoeEditTransport($router); }
        catch (\Throwable) { throw new HttpError(502, 'No se pudo abrir el acceso de edición al router.', 'ROUTER_UNAVAILABLE'); }
        try {
            if ($source === 'imported') $remoteId = $row['remoteId'];
            else {
                $provisionedId = function_exists(__NAMESPACE__ . '\\provisionManagedRemoteId') ? provisionManagedRemoteId($row['id']) : null;
                if ($provisionedId !== null) $remoteId = $provisionedId;
                else {
                    $remoteRows = $transport->print('/ppp/secret',['comment' => 'nexoisp:' . $row['id'] . ':pppoe'],['.proplist' => '.id,name,comment,service']);
                    if (count($remoteRows) !== 1 || ($remoteRows[0]['name'] ?? null) !== $row['username'] || ($remoteRows[0]['comment'] ?? null) !== 'nexoisp:' . $row['id'] . ':pppoe') throw new HttpError(409, 'No se encontró una cuenta MikroTik inequívoca gestionada por este servicio.', 'STALE_ACCOUNT');
                    $remoteId = $remoteRows[0]['.id'];
                }
            }
            $remote = clientPppoeEditRead($transport,$remoteId);
            if (($remote['name'] ?? null) !== $row['username']) throw new HttpError(409, 'La cuenta cambió de usuario en el router. Vuelve a importar sus datos.', 'STALE_ACCOUNT');
            foreach ($linked as $service) if (($remote['comment'] ?? null) !== 'nexoisp:' . $service['id'] . ':pppoe' && !(function_exists(__NAMESPACE__ . '\\provisionOwnsRemote') && provisionOwnsRemote($service,$remote))) {
                throw new HttpError(409, 'Existe un servicio local vinculado que no reconoce esta cuenta como propia. Resuelve ese vínculo antes de editar.', 'ACCOUNT_CONFLICT');
            }
            if (!preg_match('/^\*[a-z0-9]{1,32}$/iD',$remoteId)) throw new HttpError(409, 'El identificador remoto no admite una edición segura.', 'STALE_ACCOUNT');
            if ($source === 'service' && ($remote['comment'] ?? null) !== 'nexoisp:' . $row['id'] . ':pppoe' && !(function_exists(__NAMESPACE__ . '\\provisionOwnsRemote') && provisionOwnsRemote($row,$remote))) throw new HttpError(409, 'El router no reconoce la propiedad de este servicio.', 'STALE_ACCOUNT');
            clientPppoeEditCheckCollisions($row,$source,$username,$linked,$transport,$remoteId);
            // A durable intent precedes the ONLY write. If the process dies or its
            // response is lost, import/save remain blocked until a read reconciles it.
            $operation = ['id' => id(),'routerId' => $row['routerId'],'clientId' => $clientId,'sourceType' => $source,'sourceId' => $id,'remoteId' => $remoteId,
                'oldUsername' => $row['username'],'newUsername' => $username,'passwordChanged' => isset($values['password']) ? 1 : 0,'passwordEncrypted' => isset($values['password']) ? encryptSecret($values['password']) : null,'writeAcknowledged' => 0];
            tx(function (\PDO $pdo) use ($operation,$actor): void {
                $pdo->prepare('INSERT INTO `PppoeAccountEdit` (id,routerId,clientId,sourceType,sourceId,remoteId,oldUsername,newUsername,passwordChanged,passwordEncrypted,writeAcknowledged,status,actorId,createdAt,updatedAt) VALUES (?,?,?,?,?,?,?,?,?,?,0,\'PREPARED\',?,?,?)')->execute([
                    $operation['id'],$operation['routerId'],$operation['clientId'],$operation['sourceType'],$operation['sourceId'],$operation['remoteId'],$operation['oldUsername'],$operation['newUsername'],$operation['passwordChanged'],$operation['passwordEncrypted'],$actor['id'],now(),now(),
                ]);
                audit('PPPOE_EDIT_REQUESTED','PppoeAccountEdit',$operation['id'],$actor['id']);
            });
            try {
                $transport->setPppoeCredentials($remoteId,$values);
                $operation['writeAcknowledged'] = 1;
                db()->prepare('UPDATE `PppoeAccountEdit` SET writeAcknowledged=1,updatedAt=? WHERE id=?')->execute([now(),$operation['id']]);
                $after = clientPppoeEditRead($transport,$remoteId);
                return clientPppoeEditConfirm($operation,$after,$actor);
            } catch (RouterError $error) {
                // A permission/validation refusal is definitive; a transport or
                // server failure may have occurred after the account was changed.
                if (!(bool)$operation['writeAcknowledged'] && (in_array($error->httpStatus, [400,401,403,404,405,422], true) || $error->httpStatus === null && $error->routerCode === 'ROUTER_TRAP')) {
                    db()->prepare("UPDATE `PppoeAccountEdit` SET status='FAILED',passwordEncrypted=NULL,updatedAt=? WHERE id=?")->execute([now(),$operation['id']]);
                    audit('PPPOE_EDIT_REJECTED','PppoeAccountEdit',$operation['id'],$actor['id']);
                    return ['status'=>'FAILED','operationId'=>$operation['id'],'message'=>'MikroTik rechazó la edición. Comprueba los permisos de escritura del usuario API y vuelve a cargar la cuenta antes de guardar.'];
                }
                return clientPppoeEditUncertain($operation);
            } catch (\Throwable) { return clientPppoeEditUncertain($operation); }
        } catch (RouterError) { throw new HttpError(502, 'No se pudo comprobar la cuenta o los permisos de edición en MikroTik.', 'ROUTER_UNAVAILABLE'); }
        finally { $transport->close(); }
    });
}

function clientPppoeEditReconcile(string $clientId, string $source, string $id, array $actor): array
{
    if ($actor['role'] !== 'ADMIN') throw new HttpError(403, 'Solo un administrador puede verificar cambios PPPoE.', 'FORBIDDEN');
    $initial = clientPppoeEditSource($clientId,$source,$id);
    return apiLocks(['client:' . $clientId,'router:' . $initial['routerId']],function () use ($clientId,$source,$id,$actor): array {
        $row = clientPppoeEditSource($clientId,$source,$id);
        $operation = clientPppoeEditPending($row['routerId']);
        if (!$operation || $operation['sourceType'] !== $source || $operation['sourceId'] !== $id || $operation['clientId'] !== $clientId) throw new HttpError(409, 'Esta cuenta no tiene un cambio pendiente para verificar.', 'NO_PENDING_EDIT');
        $router = fetchOne('SELECT * FROM `Router` WHERE id=?',[$row['routerId']]);
        try { $transport = secretImportTransport($router); }
        catch (\Throwable) { return clientPppoeEditUncertain($operation); }
        try {
            $remote = clientPppoeEditRead($transport,$operation['remoteId'],(bool)$operation['passwordChanged'] && !(bool)$operation['writeAcknowledged']);
            if (($remote['name'] ?? null) !== $operation['newUsername']) return clientPppoeEditUncertain($operation);
            if ($source === 'service' && ($remote['comment'] ?? null) !== 'nexoisp:' . $id . ':pppoe' && !(function_exists(__NAMESPACE__ . '\\provisionOwnsRemote') && provisionOwnsRemote(array_replace($row,['username'=>$operation['newUsername']]),$remote))) return clientPppoeEditUncertain($operation);
            if ((bool)$operation['passwordChanged'] && !(bool)$operation['writeAcknowledged']) {
                if (!isset($remote['password']) || !is_string($remote['password']) || !hash_equals(decryptSecret($operation['passwordEncrypted']),$remote['password'])) return clientPppoeEditUncertain($operation);
            }
            return clientPppoeEditConfirm($operation,$remote,$actor);
        } catch (\Throwable) { return clientPppoeEditUncertain($operation); }
        finally { $transport->close(); }
    });
}
