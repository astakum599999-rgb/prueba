<?php
declare(strict_types=1);
namespace Nexo;

require_once __DIR__ . '/secret-import.php';
require_once __DIR__ . '/client-pppoe-edit.php';

const CLIENT_PPPOE_PROPERTIES = '.id,name,service,password';

function clientPppoeUnavailable(string $source, string $message): array
{
    return ['status' => 'UNAVAILABLE', 'source' => $source, 'message' => $message];
}

/** Preserve exact credential bytes: never recode, trim or normalize a password. */
function clientPppoePassword(string $password, string $source): array
{
    if (strlen($password) > 4096 || preg_match('//u', $password) !== 1 || preg_match('/[\x00-\x1F\x7F]/', $password)) {
        return clientPppoeUnavailable($source, 'La contraseña contiene bytes que no se pueden mostrar fielmente en este formulario.');
    }
    return ['status' => $password === '' ? 'EMPTY' : 'AVAILABLE', 'password' => $password, 'source' => $source,
        'message' => $password === '' ? 'La cuenta tiene una contraseña vacía.' : ($source === 'MikroTik' ? 'Consultada en MikroTik; no se guarda en GIGARED ISP.' : 'Contraseña guardada en GIGARED ISP; puede diferir de la configuración actual del router.')];
}

/** Read only one selected remote account, checking its binary identity before disclosure. */
function clientPppoeReadPassword(array $snapshot, RouterTransport $transport): array
{
    try {
        $rows = $transport->print('/ppp/secret', ['.id' => $snapshot['remoteId']], ['.proplist' => CLIENT_PPPOE_PROPERTIES]);
        if (count($rows) !== 1 || !is_array($rows[0]) || ($rows[0]['.id'] ?? null) !== $snapshot['remoteId'] || ($rows[0]['name'] ?? null) !== $snapshot['username']) {
            return clientPppoeUnavailable('MikroTik', 'La cuenta cambió o ya no existe en el router. Vuelve a importar los usuarios PPP.');
        }
        $row = $rows[0];
        if (!in_array($row['service'] ?? null, ['pppoe', 'any'], true)) {
            return clientPppoeUnavailable('MikroTik', 'La cuenta ya no permite conexiones PPPoE. Vuelve a importar los usuarios PPP.');
        }
        if (!array_key_exists('password', $row) || !is_string($row['password']) || preg_match('/^(?:\*+|<hidden>|<sensitive>|<not shown>)$/iD', $row['password'])) {
            return clientPppoeUnavailable('MikroTik', 'MikroTik no entregó la contraseña. Comprueba los permisos de lectura de datos sensibles del usuario API.');
        }
        return clientPppoePassword($row['password'], 'MikroTik');
    } catch (RouterError) {
        return clientPppoeUnavailable('MikroTik', 'No se pudo leer la contraseña. Comprueba la conexión y los permisos API del router.');
    } finally {
        $transport->close();
    }
}

function clientPppoeAccounts(string $clientId, array $actor): array
{
    if (!fetchOne('SELECT id FROM `Client` WHERE id=?', [$clientId])) throw new HttpError(404, 'Cliente no encontrado.', 'NOT_FOUND');
    $admin = $actor['role'] === 'ADMIN';
    $rows = fetchAll("SELECT s.*,r.name AS routerName FROM `RouterSecretImport` s JOIN `Router` r ON r.id=s.routerId WHERE s.clientId=? AND s.pppService IN ('pppoe','any') ORDER BY r.name,s.username,s.id", [$clientId]);
    $accounts = [];
    foreach ($rows as $row) {
        if(function_exists(__NAMESPACE__ . '\\clientPppArchived') && ($original=clientPppArchived($row['id']))!==null)$row['username']=$original;
        $accounts[] = ['id' => $row['id'], 'source' => 'imported', 'routerId' => $row['routerId'], 'routerName' => $row['routerName'],
            'username' => secretImportDisplayText($row['username']), 'profile' => $row['profile'], 'present' => (bool)$row['present'],
            'canRevealPassword' => $admin && (bool)$row['present'], 'passwordSource' => 'MikroTik', 'lastSeenAt' => $row['lastSeenAt']] + clientPppoeEditMetadata($row, 'imported', $admin);
    }
    $rows = fetchAll("SELECT s.*,(s.passwordEncrypted IS NOT NULL) AS hasPassword,r.name AS routerName,p.pppoeProfile FROM `Service` s JOIN `Router` r ON r.id=s.routerId JOIN `Plan` p ON p.id=s.planId WHERE s.clientId=? AND s.type='PPPOE' ORDER BY r.name,s.username,s.id", [$clientId]);
    foreach ($rows as $row) {
        $accounts[] = ['id' => $row['id'], 'source' => 'service', 'routerId' => $row['routerId'], 'routerName' => $row['routerName'],
            'username' => $row['username'] ?? '', 'profile' => $row['pppoeProfile'], 'present' => true,
            'canRevealPassword' => $admin && (bool)$row['hasPassword'], 'passwordSource' => 'NexoISP'] + clientPppoeEditMetadata($row, 'service', $admin);
    }
    return ['results' => $accounts, 'canRevealPassword' => $admin, 'canEdit' => $admin];
}

function clientPppoeReveal(string $clientId, string $source, string $identifier, array $actor): array
{
    if ($actor['role'] !== 'ADMIN') throw new HttpError(403, 'Solo un administrador puede consultar contraseñas PPPoE.', 'FORBIDDEN');
    if ($source === 'service') {
        $row = fetchOne("SELECT id,passwordEncrypted FROM `Service` WHERE id=? AND clientId=? AND type='PPPOE'", [$identifier, $clientId]) ?? throw new HttpError(404, 'Cuenta PPPoE no encontrada para este cliente.', 'NOT_FOUND');
        audit('PPPOE_PASSWORD_READ', 'Service', $identifier, $actor['id']);
        if ($row['passwordEncrypted'] === null) return clientPppoeUnavailable('NexoISP', 'Este servicio no tiene una contraseña guardada en GIGARED ISP.');
        try { return clientPppoePassword(decryptSecret($row['passwordEncrypted']), 'NexoISP'); }
        catch (\Throwable) { return clientPppoeUnavailable('NexoISP', 'No se pudo descifrar la contraseña guardada. Comprueba la clave de esta instalación.'); }
    }
    $snapshot = fetchOne("SELECT id,routerId FROM `RouterSecretImport` WHERE id=? AND clientId=? AND pppService IN ('pppoe','any')", [$identifier, $clientId]) ?? throw new HttpError(404, 'Cuenta PPPoE no encontrada para este cliente.', 'NOT_FOUND');
    $key = 'router:' . $snapshot['routerId'];
    if (!lock($key, 10)) throw new HttpError(409, 'El router está ocupado. Intenta la lectura de nuevo.', 'RESOURCE_BUSY');
    try {
        // Re-read under the same advisory lock used by import/router modifications.
        $snapshot = fetchOne("SELECT * FROM `RouterSecretImport` WHERE id=? AND clientId=? AND pppService IN ('pppoe','any')", [$identifier, $clientId]) ?? throw new HttpError(404, 'Cuenta PPPoE no encontrada para este cliente.', 'NOT_FOUND');
        audit('PPPOE_PASSWORD_READ', 'RouterSecretImport', $identifier, $actor['id']);
        if (!(bool)$snapshot['present']) return clientPppoeUnavailable('MikroTik', 'La última importación no encontró esta cuenta en el router.');
        $router = fetchOne('SELECT * FROM `Router` WHERE id=?', [$snapshot['routerId']]) ?? throw new HttpError(404, 'Router no encontrado.', 'NOT_FOUND');
        try { $transport = secretImportTransport($router); }
        catch (\Throwable) { return clientPppoeUnavailable('MikroTik', 'No se pudo abrir la conexión de lectura del router. Comprueba su configuración en GIGARED ISP.'); }
        return clientPppoeReadPassword($snapshot, $transport);
    } finally {
        unlock($key);
    }
}

function clientPppoeDispatch(string $method, string $route): bool
{
    if ($method === 'PATCH' && preg_match('#^/clients/([a-f0-9]{24})/pppoe-accounts/(imported|service)/([a-f0-9]{24})$#D', $route, $match)) {
        $actor = permit('ADMIN');
        rateLimit('pppoe-edit:' . $actor['id'], 30, 60);
        json(clientPppoeEditRun($match[1], $match[2], $match[3], body(), $actor));
    }
    if ($method === 'POST' && preg_match('#^/clients/([a-f0-9]{24})/pppoe-accounts/(imported|service)/([a-f0-9]{24})/reconcile$#D', $route, $match)) {
        $actor = permit('ADMIN');
        if (body() !== []) throw new HttpError(422, 'La verificación sólo admite un objeto vacío.', 'VALIDATION_ERROR');
        rateLimit('pppoe-reconcile:' . $actor['id'], 60, 60);
        json(clientPppoeEditReconcile($match[1], $match[2], $match[3], $actor));
    }
    if ($method === 'GET' && preg_match('#^/clients/([a-f0-9]{24})/pppoe-accounts$#D', $route, $match)) {
        $actor = requireAuth();
        header('Pragma: no-cache');
        json(clientPppoeAccounts($match[1], $actor));
    }
    if ($method === 'POST' && preg_match('#^/clients/([a-f0-9]{24})/pppoe-accounts/(imported|service)/([a-f0-9]{24})/password$#D', $route, $match)) {
        $actor = permit('ADMIN');
        if (body() !== []) throw new HttpError(422, 'La consulta de contraseña no admite cambios ni parámetros.', 'VALIDATION_ERROR');
        rateLimit('pppoe-password:' . $actor['id'], 30, 60);
        header('Pragma: no-cache');
        json(clientPppoeReveal($match[1], $match[2], $match[3], $actor));
    }
    return false;
}
