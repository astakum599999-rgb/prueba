import { useEffect, useRef, useState } from 'react';
import { PauseCircle, RefreshCw, Trash2 } from 'lucide-react';
import { api, post } from './api';
import { errorMessage, Loading, Modal } from './ui';

interface Target { routerName: string; username: string; sessions?: number; disabled?: boolean | null }
interface Operation { id: string; clientId: string; action: 'SUSPEND' | 'DELETE'; status: string; lastError: string | null; targets: Target[] }
interface Preview { clientName: string; token: string; targets: Target[]; expiresAt: string; pending?: Operation }

function requestId(): string {
  const bytes = crypto.getRandomValues(new Uint8Array(16));
  bytes[6] = (bytes[6] & 15) | 64; bytes[8] = (bytes[8] & 63) | 128;
  const hex = Array.from(bytes, value => value.toString(16).padStart(2, '0')).join('');
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
}

export default function ClientPppActions({ clientId, action, close, saved }: { clientId: string; action: 'suspend' | 'delete'; close: () => void; saved: () => void }) {
  const [preview, setPreview] = useState<Preview | null>(null), [operation, setOperation] = useState<Operation | null>(null);
  const [busy, setBusy] = useState(false), [loading, setLoading] = useState(true), [error, setError] = useState(''), [confirmed, setConfirmed] = useState(false);
  const requestKey = useRef(requestId());
  const alive = useRef(true), inFlight = useRef(false);
  const load = async () => {
    setLoading(true); setError(''); setConfirmed(false);
    try { const value = await api<Preview>(`/clients/${clientId}/ppp-actions/${action}/preview`, { cache: 'no-store' }); if (alive.current) { setPreview(value); setOperation(value.pending || null); } }
    catch (reason) { if (alive.current) setError(errorMessage(reason)); }
    finally { if (alive.current) setLoading(false); }
  };
  useEffect(() => { alive.current = true; void load(); return () => { alive.current = false; }; }, [clientId, action]);
  const run = async (mode: 'confirm' | 'verify' | 'continue') => {
    if (inFlight.current) return;
    inFlight.current = true; setBusy(true); setError('');
    try {
      const value = mode === 'confirm'
        ? await post<Operation>(`/clients/${clientId}/ppp-actions/${action}`, { token: preview?.token, requestKey: requestKey.current })
        : await post<Operation>(`/client-ppp-actions/${operation!.id}/${mode}`);
      if (alive.current) { setOperation(value); setConfirmed(false); if (value.status === 'CONFIRMED') saved(); }
    } catch (reason) {
      if (alive.current) {
        setError(errorMessage(reason));
        // If the HTTP response was lost, recover the durable operation without resending writes.
        try { const value = await api<Preview>(`/clients/${clientId}/ppp-actions/${action}/preview`, { cache: 'no-store' }); if (alive.current && value.pending) setOperation(value.pending); }
        catch { /* Keep the original message and the same idempotency key. */ }
      }
    } finally { inFlight.current = false; if (alive.current) setBusy(false); }
  };
  const deleting = operation ? operation.action === 'DELETE' : action === 'delete';
  const done = operation?.status === 'CONFIRMED', targets = operation?.targets || preview?.targets || [];
  const title = deleting ? 'Eliminar cliente' : 'Suspender manual';
  return <Modal title={title} description={preview?.clientName || 'Acción sobre la cuenta PPPoE y sus conexiones activas.'} close={() => { if (!busy) close(); }} footer={<>
    <button className="button" disabled={busy} onClick={close}>{done ? 'Cerrar' : 'Cancelar'}</button>
    {done ? null : operation ? <><button className="button" disabled={busy} onClick={() => void run('verify')}><RefreshCw size={16} />Verificar</button><button className="button danger" disabled={busy || !confirmed} onClick={() => void run('continue')}>{busy ? 'Comprobando…' : 'Continuar operación'}</button></> : <><button className="button" disabled={busy || loading} onClick={() => void load()}>Actualizar vista previa</button><button className="button danger" disabled={busy || loading || !preview?.token || !confirmed} onClick={() => void run('confirm')}>{deleting ? <Trash2 size={16} /> : <PauseCircle size={16} />}{busy ? 'Aplicando…' : `Confirmar ${deleting ? 'eliminación' : 'suspensión'}`}</button></>}
  </>}>
    {loading && <Loading label="Comprobando cuenta y sesiones PPPoE…" />}
    {error && <div className="alert error" role="alert">{error}</div>}
    {!loading && <>
      <div className={`alert ${done ? 'success' : 'info'}`} role="status">{done ? (deleting ? 'Cliente retirado. Se confirmó la eliminación del secret y la desconexión de sus sesiones PPPoE.' : 'Suspensión confirmada. El secret está deshabilitado y sus sesiones PPPoE están desconectadas.') : (deleting ? 'Se deshabilitará y eliminará el secret PPPoE, y se cerrarán sus conexiones activas. El cliente quedará retirado; sus facturas, pagos y notas se conservarán.' : 'Se deshabilitará el secret PPPoE y se cerrarán sus conexiones activas. El cliente no podrá volver a autenticarse mientras siga deshabilitado.')}</div>
      {targets.length > 0 ? <div className="table-scroll"><table><thead><tr><th>Router</th><th>Usuario PPPoE</th>{!operation && <th>Sesiones PPPoE</th>}</tr></thead><tbody>{targets.map((target, i) => <tr key={i}><td>{target.routerName}</td><td>{target.username}</td>{!operation && <td>{target.sessions}</td>}</tr>)}</tbody></table></div> : <p>Este cliente no tiene cuentas PPPoE vinculadas. Se retirará únicamente su registro local.</p>}
      {operation?.lastError && <div className="alert info" role="status">{operation.lastError}</div>}
      {operation && !done && <p>Verificar consulta el router sin enviar cambios. Continuar aplica los cambios que falten de esta misma operación.</p>}
      {!done && (operation || preview?.token) && <label className="inline-gap" style={{ marginTop: 16 }}><input type="checkbox" checked={confirmed} disabled={busy} onChange={event => setConfirmed(event.target.checked)} />Confirmo {deleting ? 'eliminar' : 'suspender'} el acceso PPPoE de este cliente.</label>}
      {done && <p>{deleting ? 'Puedes consultar su historial con el filtro Retirado.' : 'Esta acción no elimina la cuenta. No se programaron cortes automáticos ni cambios de plan.'}</p>}
    </>}
  </Modal>;
}
