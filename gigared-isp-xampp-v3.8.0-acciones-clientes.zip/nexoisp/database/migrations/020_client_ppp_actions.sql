-- Explicit staff actions only; no worker or billing job can initiate these operations.
CREATE TABLE IF NOT EXISTS `ClientPppAction` (
  `id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `clientId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `actorId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `requestKey` CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `action` VARCHAR(10) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `status` VARCHAR(16) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'PREPARED',
  `planJson` MEDIUMTEXT NOT NULL,
  `lastError` VARCHAR(500) NULL,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `activeClientId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin GENERATED ALWAYS AS (CASE WHEN `status`<>'CONFIRMED' THEN `clientId` ELSE NULL END) STORED,
  PRIMARY KEY (`id`),
  UNIQUE KEY `client_ppp_request_unique` (`requestKey`),
  UNIQUE KEY `client_ppp_pending_unique` (`activeClientId`),
  KEY `client_ppp_history_idx` (`clientId`,`createdAt`),
  CONSTRAINT `client_ppp_client_fk` FOREIGN KEY (`clientId`) REFERENCES `Client` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `client_ppp_actor_fk` FOREIGN KEY (`actorId`) REFERENCES `User` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `client_ppp_action_check` CHECK (`action` IN ('SUSPEND','DELETE')),
  CONSTRAINT `client_ppp_status_check` CHECK (`status` IN ('PREPARED','RUNNING','UNCERTAIN','CONFIRMED'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Preserve imported identity/history while freeing a deleted username for a new customer.
CREATE TABLE IF NOT EXISTS `ClientPppRetiredSecret` (
  `secretId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `actionId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `username` VARBINARY(1020) NOT NULL,
  `retiredAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`secretId`),
  CONSTRAINT `client_ppp_retired_secret_fk` FOREIGN KEY (`secretId`) REFERENCES `RouterSecretImport` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `client_ppp_retired_action_fk` FOREIGN KEY (`actionId`) REFERENCES `ClientPppAction` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
