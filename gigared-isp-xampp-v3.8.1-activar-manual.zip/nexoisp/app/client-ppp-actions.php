<?php
declare(strict_types=1);
namespace Nexo;

use PDO;
use Throwable;

function clientPppArchived(string $secretId): ?string
{
    if(!isset($GLOBALS['nexo_ppp_archived'])) {
        $GLOBALS['nexo_ppp_archived']=[];
        foreach(fetchAll('SELECT secretId,username FROM ClientPppRetiredSecret') as $row)$GLOBALS['nexo_ppp_archived'][$row['secretId']]=$row['username'];
    }
    return $GLOBALS['nexo_ppp_archived'][$secretId]??null;
}

function clientPppImportCode(string $routerId,string $username,string $newClientId): string
{
    $code=secretImportClientCode($routerId,$username);
    $previous=fetchOne('SELECT id,status FROM Client WHERE code=?',[$code]);
    if($previous && $previous['status']==='RETIRED' && fetchOne("SELECT id FROM ClientPppAction WHERE clientId=? AND action='DELETE' AND status='CONFIRMED'",[$previous['id']]))return 'MT-'.substr(hash('sha256',$code.':'.$newClientId),0,32);
    return $code;
}

/** Narrow, interactive exceptions to network_read_only. Never called by a job. */
function clientPppTable(string $action): string
{
    return $action==='REACTIVATE'?'ClientPppActivation':'ClientPppAction';
}

function clientPppFind(string $field,string $value): ?array
{
    if(!in_array($field,['id','requestKey'],true))throw new \LogicException('Invalid journal lookup.');
    foreach(['ClientPppAction','ClientPppActivation'] as $table)if($row=fetchOne("SELECT * FROM $table WHERE $field=?",[$value]))return $row;
    return null;
}

function clientPppPending(string $clientId): ?array
{
    return fetchOne('SELECT * FROM ClientPppAction WHERE activeClientId=?',[$clientId])??fetchOne('SELECT * FROM ClientPppActivation WHERE activeClientId=?',[$clientId]);
}

function clientPppUsernameReserved(string $routerId,string $username): bool
{
    foreach(fetchAll("SELECT planJson FROM ClientPppAction WHERE status<>'CONFIRMED' UNION ALL SELECT planJson FROM ClientPppActivation WHERE status<>'CONFIRMED'") as $row) {
        foreach(json_decode($row['planJson'],true,512,JSON_THROW_ON_ERROR)['targets'] as $target) {
            if($target['routerId']===$routerId && $target['usernameHex']===bin2hex($username)) return true;
        }
    }
    return false;
}

function clientPppRequireSettled(string $clientId): void
{
    if(clientPppPending($clientId)) throw new HttpError(409,'Verifica primero la acción PPPoE pendiente de este cliente.','CLIENT_PPP_PENDING');
}

function clientPppManualSuspension(string $clientId): ?array
{
    $row=fetchOne("SELECT * FROM ClientPppAction WHERE clientId=? AND action='SUSPEND' AND status='CONFIRMED' ORDER BY updatedAt DESC,id DESC LIMIT 1",[$clientId]);
    if(!$row || fetchOne("SELECT id FROM ClientPppActivation WHERE suspensionId=? AND status='CONFIRMED' LIMIT 1",[$row['id']]))return null;
    return $row;
}

function clientPppCanActivate(array $client): bool
{
    if($client['status']==='RETIRED')return false;
    if(fetchOne('SELECT id FROM ClientPppActivation WHERE activeClientId=?',[$client['id']]))return true;
    if($client['status']!=='SUSPENDED')return false;
    try {clientPppActivationOrigin($client['id']);return true;}
    catch(HttpError $error) {if($error->status===409)return false;throw $error;}
}

function clientPppActivationOrigin(string $clientId,?string $suspensionId=null): array
{
    if((fetchOne('SELECT status FROM Client WHERE id=?',[$clientId])['status']??'RETIRED')==='RETIRED')clientPppConflict('Un cliente retirado no puede reactivarse.');
    $suspension=clientPppManualSuspension($clientId);
    if(!$suspension || ($suspensionId!==null && $suspension['id']!==$suspensionId))clientPppConflict('Este cliente no tiene una suspensión manual pendiente de reactivar.');
    $original=json_decode($suspension['planJson'],true,512,JSON_THROW_ON_ERROR);
    foreach($original['targets'] as $target)foreach($target['services'] as $serviceId) {
        $service=fetchOne('SELECT desiredState,suspensionReason FROM Service WHERE id=? AND clientId=?',[$serviceId,$clientId]);
        if(!$service || $service['desiredState']==='RETIRED' || $service['suspensionReason']==='BILLING')clientPppConflict('Hay un servicio retirado o suspendido por facturación. Revisa ese servicio antes de activar manualmente.');
    }
    return $suspension;
}

function clientPppFingerprint(array $router): string
{
    return hash('sha256',json_encode(array_intersect_key($router,array_flip(['id','transport','host','port','username','passwordEncrypted','useTls','verifyTls'])),JSON_THROW_ON_ERROR));
}

function clientPppConflict(string $message='La identidad PPPoE cambió. Actualiza la vista y revisa la cuenta antes de continuar.'): never
{
    throw new HttpError(409,$message,'CLIENT_PPP_CONFLICT');
}

/** Bind local history to exact remote IDs; a display comment is never identity. */
function clientPppBindings(string $clientId,string $action): array
{
    $client=fetchOne('SELECT * FROM Client WHERE id=?',[$clientId]) ?? throw new HttpError(404,'Cliente no encontrado.','NOT_FOUND');
    if($client['status']==='RETIRED') clientPppConflict('El cliente ya está retirado. Su historial sigue disponible.');
    $suspension=null;
    if($action==='REACTIVATE') {
        if($client['status']!=='SUSPENDED')clientPppConflict('El cliente ya está activo. Actualiza la lista antes de continuar.');
        $suspension=clientPppActivationOrigin($clientId);
    }
    if(provisionPending($clientId)) clientPppConflict('Confirma primero el alta pendiente del cliente.');
    $targets=[];
    foreach(fetchAll('SELECT s.* FROM RouterSecretImport s LEFT JOIN ClientPppRetiredSecret a ON a.secretId=s.id WHERE s.clientId=? AND a.secretId IS NULL ORDER BY s.id',[$clientId]) as $row) {
        if(!in_array(strtolower($row['pppService']),['pppoe','any'],true)) clientPppConflict('La cuenta importada no corresponde a PPPoE.');
        $key=$row['routerId'].':'.bin2hex($row['username']);
        $targets[$key]=['routerId'=>$row['routerId'],'usernameHex'=>bin2hex($row['username']),'remoteId'=>$row['remoteId'],'snapshots'=>[$row['id']],'services'=>[]];
    }
    foreach(fetchAll("SELECT * FROM Service WHERE clientId=? AND desiredState<>'RETIRED' AND (appliedState IS NULL OR appliedState<>'RETIRED') ORDER BY id",[$clientId]) as $service) {
        if($service['type']===null && $service['routerId']===null) continue; // Local billing has no router resource.
        if($service['type']!=='PPPOE') clientPppConflict('El cliente tiene otro tipo de acceso. Retira primero ese servicio para evitar dejarlo conectado.');
        if(!is_string($service['username']) || $service['username']==='') clientPppConflict('El servicio no tiene un usuario PPPoE válido.');
        $key=$service['routerId'].':'.bin2hex($service['username']);
        $remoteId=provisionManagedRemoteId($service['id']);
        if(isset($targets[$key])) {
            if($remoteId!==null && $remoteId!==$targets[$key]['remoteId']) clientPppConflict();
            $targets[$key]['services'][]=$service['id'];
        } else {
            $targets[$key]=['routerId'=>$service['routerId'],'usernameHex'=>bin2hex($service['username']),'remoteId'=>$remoteId,'snapshots'=>[],'services'=>[$service['id']]];
        }
    }
    if(!$targets && $action!=='DELETE') throw new HttpError(422,'Este cliente no tiene una cuenta PPPoE vinculada.','NO_PPPOE_ACCOUNT');
    ksort($targets,SORT_STRING);
    foreach($targets as &$target) {
        $router=provisionRouter($target['routerId']);
        $target['routerFingerprint']=clientPppFingerprint($router);
        $target['routerName']=$router['name'];
        $username=hex2bin($target['usernameHex']);
        foreach(fetchAll('SELECT clientId,username FROM RouterSecretImport WHERE routerId=? AND present=1',[$router['id']]) as $row) if($row['username']===$username && $row['clientId']!==$clientId) clientPppConflict('La cuenta está vinculada a otro cliente.');
        foreach(fetchAll("SELECT clientId,username FROM Service WHERE routerId=? AND (appliedState IS NULL OR appliedState<>'RETIRED')",[$router['id']]) as $row) if($row['username']===$username && $row['clientId']!==$clientId) clientPppConflict('La cuenta está vinculada a otro cliente.');
    }
    unset($target);
    $plan=['clientId'=>$clientId,'clientName'=>$client['name'],'action'=>$action,'targets'=>array_values($targets)];
    if($suspension!==null)$plan['suspensionId']=$suspension['id'];
    return $plan;
}

function clientPppTransport(array $router,bool $activation=false): RouterTransport
{
    $password=decryptSecret($router['passwordEncrypted']);
    return $router['transport']==='REST' ? new RouterRestTransport($router,$password,15.0,false,false,!$activation,$activation) : new RouterSocketTransport($router,$password,15.0,false,false,!$activation,$activation);
}

function clientPppInventory(RouterTransport $transport): array
{
    $result=[];
    foreach(['secrets'=>['/ppp/secret',SECRET_IMPORT_PROPERTIES],'active'=>['/ppp/active','.id,name,service']] as $key=>[$path,$properties]) {
        $rows=provisionRows($transport,$path,$properties,true);
        $ids=[];
        foreach($rows as $row) {
            if(!is_string($row['.id']??null) || preg_match('/^\*[a-z0-9]{1,32}$/iD',$row['.id'])!==1 || isset($ids[$row['.id']]) || !is_string($row['service']??null)) throw new RouterError('Inventario PPP incompleto.','INVALID_RESPONSE');
            $ids[$row['.id']]=true;
            if($key==='secrets' && !in_array($row['disabled']??null,['true','false','yes','no','1','0'],true))throw new RouterError('Estado PPP incompleto.','INVALID_RESPONSE');
        }
        $result[$key]=$rows;
    }
    return $result;
}

function clientPppSecretSignature(array $row): string
{
    $data=[];
    // Disabled changes are an intended effect; all other account bindings remain frozen.
    foreach(['.id','name','service','profile','remote-address','local-address','caller-id','comment'] as $field) $data[$field]=bin2hex((string)($row[$field]??''));
    return hash('sha256',json_encode($data,JSON_THROW_ON_ERROR));
}

function clientPppRemote(array $target,array $inventory): ?array
{
    $username=hex2bin($target['usernameHex']);$found=null;
    foreach($inventory['secrets'] as $secret) {
        if($secret['.id']===$target['remoteId'] && $secret['name']!==$username) clientPppConflict('El identificador remoto pertenece ahora a otro usuario. No se aplicaron cambios a esa cuenta.');
        if($secret['name']!==$username) continue;
        if($found!==null || ($target['remoteId']!==null && $secret['.id']!==$target['remoteId'])) clientPppConflict('El usuario existe con otra identidad o está duplicado en MikroTik.');
        if(!in_array(strtolower($secret['service']),['pppoe','any'],true)) clientPppConflict('El secret ya no corresponde a PPPoE.');
        if(array_key_exists('signature',$target) && $target['signature']!==clientPppSecretSignature($secret)) clientPppConflict();
        $found=$secret;
    }
    return $found;
}

function clientPppSessions(array $target,array $inventory): array
{
    $username=hex2bin($target['usernameHex']);
    return array_values(array_filter($inventory['active'],static fn(array $row): bool => $row['name']===$username && strtolower($row['service'])==='pppoe'));
}

function clientPppPlan(string $clientId,string $action): array
{
    $plan=clientPppBindings($clientId,$action);$transports=[];
    try {
        foreach($plan['targets'] as &$target) {
            $transport=$transports[$target['routerId']]??=clientPppTransport(provisionRouter($target['routerId']),$action==='REACTIVATE');
            $inventory=clientPppInventory($transport);
            $secret=clientPppRemote($target,$inventory);
            if($target['remoteId']===null) {
                if($secret===null || count($target['services'])!==1 || ($secret['comment']??'')!=='nexoisp:'.$target['services'][0].':pppoe') clientPppConflict('No se pudo verificar la propiedad del secret de este servicio.');
                $target['remoteId']=$secret['.id'];
            }
            if($secret===null && $action!=='DELETE') clientPppConflict('El secret ya no existe. Sincroniza la cuenta antes de continuar.');
            $target['signature']=$secret===null ? null : clientPppSecretSignature($secret);
            $target['observedDisabled']=$secret===null ? null : RouterTransportUtil::truthy($secret['disabled']??false);
            $target['sessions']=count(clientPppSessions($target,$inventory));
        }
        unset($target);
        if($action==='REACTIVATE') {
            $origin=clientPppActivationOrigin($clientId,$plan['suspensionId']);
            $original=json_decode($origin['planJson'],true,512,JSON_THROW_ON_ERROR);
            $identity=static function(array $rows):array {$ids=array_map(static fn(array $t):string=>$t['routerId'].':'.($t['remoteId']??''),$rows);sort($ids,SORT_STRING);return $ids;};
            if($identity($original['targets'])!==$identity($plan['targets']))clientPppConflict('Las cuentas vinculadas cambiaron desde la suspensión. Revisa su identidad antes de activar.');
        }
        return $plan;
    } finally {foreach($transports as $transport)$transport->close();}
}

function clientPppPlanHash(array $plan): string
{
    foreach($plan['targets'] as &$target)unset($target['sessions']);
    unset($target);
    return hash('sha256',json_encode($plan,JSON_THROW_ON_ERROR));
}

function clientPppPublic(array $row): array
{
    $plan=json_decode($row['planJson'],true,512,JSON_THROW_ON_ERROR);
    return ['id'=>$row['id'],'clientId'=>$row['clientId'],'action'=>$row['action'],'status'=>$row['status'],'lastError'=>$row['lastError'],'updatedAt'=>$row['updatedAt'],
        'targets'=>array_map(static fn(array $t): array=>['routerName'=>$t['routerName'],'username'=>secretImportDisplayText(hex2bin($t['usernameHex']))],$plan['targets'])];
}

function clientPppPreview(string $clientId,string $action,array $actor): array
{
    if($pending=clientPppPending($clientId)) {
        if($pending['action']==='DELETE' && $actor['role']!=='ADMIN')throw new HttpError(403,'Un administrador debe resolver la eliminación pendiente.','FORBIDDEN');
        return ['pending'=>clientPppPublic($pending)];
    }
    $bindings=clientPppBindings($clientId,$action);
    return apiLocks(['client:'.$clientId,...array_map(static fn(array $t): string=>'router:'.$t['routerId'],$bindings['targets'])],function()use($clientId,$action,$actor):array {
        $plan=clientPppPlan($clientId,$action);$expires=time()+120;
        $payload=base64_encode(json_encode(['clientId'=>$clientId,'actorId'=>$actor['id'],'action'=>$action,'hash'=>clientPppPlanHash($plan),'expires'=>$expires],JSON_THROW_ON_ERROR));
        return ['clientId'=>$clientId,'clientName'=>$plan['clientName'],'action'=>$action,'token'=>$payload.'.'.hash_hmac('sha256','client-ppp:'.$payload,encryptionKey()),'expiresAt'=>gmdate('c',$expires),
            'targets'=>array_map(static fn(array $t):array=>['routerName'=>$t['routerName'],'username'=>secretImportDisplayText(hex2bin($t['usernameHex'])),'sessions'=>$t['sessions'],'disabled'=>$t['observedDisabled']],$plan['targets'])];
    });
}

function clientPppFinalize(array $row,array $plan): void
{
    tx(function(PDO $pdo)use($row,$plan):void {
        $retired=$row['action']==='DELETE';$activation=$row['action']==='REACTIVATE';$state=$retired?'RETIRED':($activation?'ACTIVE':'SUSPENDED');$stamp=now();$table=clientPppTable($row['action']);
        $pdo->prepare('UPDATE Client SET status=?,updatedAt=? WHERE id=?')->execute([$state,$stamp,$row['clientId']]);
        $types=$retired ? "(type='PPPOE' OR (type IS NULL AND routerId IS NULL))" : "type='PPPOE'";
        $pdo->prepare("UPDATE Service SET desiredState=?,appliedState=?,suspensionReason=?,syncStatus='SYNCED',lastError=NULL,lastSyncAt=?,revision=revision+1,updatedAt=? WHERE clientId=? AND $types AND desiredState<>'RETIRED'")
            ->execute([$state,$state,($retired||$activation)?null:'MANUAL',$stamp,$stamp,$row['clientId']]);
        foreach($plan['targets'] as $target) foreach($target['snapshots'] as $secretId) {
            if($retired) {
                $pdo->prepare('INSERT INTO ClientPppRetiredSecret(secretId,actionId,username,retiredAt) VALUES (?,?,?,?)')->execute([$secretId,$row['id'],hex2bin($target['usernameHex']),$stamp]);
                // NUL is forbidden in imported RouterOS names: this internal
                // archive key can never occupy a valid customer's username.
                $pdo->prepare('UPDATE RouterSecretImport SET username=?,present=0,disabled=1,lastSeenAt=? WHERE id=?')->execute(["\0retired:".$secretId,$stamp,$secretId]);
            } else $pdo->prepare("UPDATE RouterSecretImport SET disabled=?,present=1,snapshotHash=REPEAT('0',64),lastSeenAt=? WHERE id=?")->execute([$activation?0:1,$stamp,$secretId]);
        }
        $pdo->prepare("UPDATE $table SET status='CONFIRMED',lastError=NULL,updatedAt=? WHERE id=?")->execute([$stamp,$row['id']]);
        audit($activation?'client.ppp.reactivate.confirmed':($retired?'client.ppp.delete.confirmed':'client.ppp.suspend.confirmed'),'Client',$row['clientId'],$row['actorId']);
    });
    unset($GLOBALS['nexo_secret_import_cache'],$GLOBALS['nexo_client_ips'],$GLOBALS['nexo_ppp_archived']);
}

/** Verify all targets before any write; verify exact identity again before every mutation. */
function clientPppApply(array $row,bool $write): array
{
    if($row['status']==='CONFIRMED') return clientPppPublic($row);
    $plan=json_decode($row['planJson'],true,512,JSON_THROW_ON_ERROR);$transports=[];$table=clientPppTable($row['action']);$activation=$row['action']==='REACTIVATE';
    try {
        if($activation)clientPppActivationOrigin($row['clientId'],$plan['suspensionId']);
        foreach($plan['targets'] as $target) {
            $router=provisionRouter($target['routerId']);
            if(clientPppFingerprint($router)!==$target['routerFingerprint'])clientPppConflict('La conexión del router cambió. Revisa la operación pendiente.');
            $transport=$transports[$target['routerId']]??=clientPppTransport($router,$activation);
            clientPppRemote($target,clientPppInventory($transport));
        }
        if($write) db()->prepare("UPDATE $table SET status='RUNNING',updatedAt=? WHERE id=?")->execute([now(),$row['id']]);
        $complete=true;
        foreach($plan['targets'] as $target) {
            $transport=$transports[$target['routerId']];$inventory=clientPppInventory($transport);$secret=clientPppRemote($target,$inventory);
            if($write && $activation && $secret!==null && RouterTransportUtil::truthy($secret['disabled']??false)) {
                try{$transport->enableClientPppSecret($secret['.id']);}catch(RouterError){}
                $inventory=clientPppInventory($transport);$secret=clientPppRemote($target,$inventory);
                if($secret===null || RouterTransportUtil::truthy($secret['disabled']??false))throw new RouterError('No se confirmó la habilitación.','CLIENT_PPP_UNCONFIRMED');
            }
            if($write && !$activation && $secret!==null && !RouterTransportUtil::truthy($secret['disabled']??false)) {
                try{$transport->disableClientPppSecret($secret['.id']);}catch(RouterError){/* Read back even after a lost acknowledgement. */}
                $inventory=clientPppInventory($transport);$secret=clientPppRemote($target,$inventory);
                if($secret!==null && !RouterTransportUtil::truthy($secret['disabled']??false))throw new RouterError('No se confirmó la deshabilitación.','CLIENT_PPP_UNCONFIRMED');
            }
            if($write && $row['action']==='DELETE' && $secret!==null) {
                try{$transport->removeClientPppSecret($secret['.id']);}catch(RouterError){}
                $inventory=clientPppInventory($transport);$secret=clientPppRemote($target,$inventory);
                if($secret!==null)throw new RouterError('No se confirmó la eliminación del secret.','CLIENT_PPP_UNCONFIRMED');
            }
            if($write && !$activation) for($round=0;$round<3;$round++) {
                $inventory=clientPppInventory($transport);clientPppRemote($target,$inventory);
                $sessions=clientPppSessions($target,$inventory);if(!$sessions)break;
                foreach($sessions as $session) {
                    $fresh=clientPppInventory($transport);clientPppRemote($target,$fresh);
                    foreach(clientPppSessions($target,$fresh) as $current) if($current['.id']===$session['.id']) {
                        try{$transport->removeClientPppSession($current['.id']);}catch(RouterError){}
                        break;
                    }
                }
            }
            $inventory=clientPppInventory($transport);$secret=clientPppRemote($target,$inventory);
            $secretDone=$row['action']==='DELETE' ? $secret===null : ($secret!==null && RouterTransportUtil::truthy($secret['disabled']??false)!==$activation);
            if(!$secretDone || (!$activation && clientPppSessions($target,$inventory)!==[]))$complete=false;
        }
        if($complete)clientPppFinalize($row,$plan);
        else db()->prepare("UPDATE $table SET status='UNCERTAIN',lastError=?,updatedAt=? WHERE id=?")->execute(['Faltan cambios por confirmar. Verificar solo consulta; Continuar aplica únicamente los cambios pendientes.',now(),$row['id']]);
    } catch(Throwable $error) {
        // Never expose raw RouterOS replies, addresses, commands or credentials.
        $message=$error instanceof HttpError && $error->status===409 ? 'La identidad o configuración cambió. Revisa la cuenta en MikroTik antes de continuar.' : 'No se pudo confirmar toda la operación. Comprueba el router y pulsa Verificar; se conserva el historial y la reserva.';
        db()->prepare("UPDATE $table SET status='UNCERTAIN',lastError=?,updatedAt=? WHERE id=?")->execute([$message,now(),$row['id']]);
    } finally {foreach($transports as $transport)$transport->close();}
    return clientPppPublic(fetchOne("SELECT * FROM $table WHERE id=?",[$row['id']]));
}

function clientPppExecute(string $clientId,string $action,array $data,array $actor): array
{
    if(array_diff(array_keys($data),['token','requestKey']) || !is_string($data['requestKey']??null) || preg_match('/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/iD',$data['requestKey'])!==1)throw new HttpError(422,'Solicitud inválida.','VALIDATION_ERROR');
    return apiLocks(['client:'.$clientId,'client-ppp-key:'.$data['requestKey']],function()use($clientId,$action,$data,$actor):array {
        $previous=clientPppFind('requestKey',$data['requestKey']);
        if($previous) {
            if($previous['clientId']!==$clientId || $previous['action']!==$action || $previous['actorId']!==$actor['id'])clientPppConflict('La clave de solicitud corresponde a otra operación.');
            return clientPppPublic($previous);
        }
        clientPppRequireSettled($clientId);
        $token=$data['token']??null;
        if(!is_string($token) || strlen($token)>2000 || count($parts=explode('.',$token))!==2 || !hash_equals(hash_hmac('sha256','client-ppp:'.$parts[0],encryptionKey()),$parts[1]))throw new HttpError(409,'Actualiza la vista previa antes de confirmar.','CLIENT_PPP_PREVIEW_EXPIRED');
        $payload=json_decode(base64_decode($parts[0],true)?:'',true);
        if(!is_array($payload) || ($payload['expires']??0)<time() || ($payload['clientId']??null)!==$clientId || ($payload['actorId']??null)!==$actor['id'] || ($payload['action']??null)!==$action)throw new HttpError(409,'La vista previa venció. Actualízala para confirmar.','CLIENT_PPP_PREVIEW_EXPIRED');
        $bindings=clientPppBindings($clientId,$action);
        return apiLocks(array_map(static fn(array $t):string=>'router:'.$t['routerId'],$bindings['targets']),function()use($clientId,$action,$payload,$actor,$data):array {
            $plan=clientPppPlan($clientId,$action);
            if(!hash_equals($payload['hash'],clientPppPlanHash($plan)))clientPppConflict('La cuenta cambió desde la vista previa. Actualízala antes de confirmar.');
            $row=['id'=>id(),'clientId'=>$clientId,'actorId'=>$actor['id'],'requestKey'=>$data['requestKey'],'action'=>$action,'status'=>'PREPARED','planJson'=>json_encode($plan,JSON_THROW_ON_ERROR),'lastError'=>null,'createdAt'=>now(),'updatedAt'=>now()];
            if($action==='REACTIVATE')$row['suspensionId']=$plan['suspensionId'];
            tx(function(PDO $pdo)use($row):void {
                $table=clientPppTable($row['action']);$extra=$row['action']==='REACTIVATE'?',suspensionId':'';$slots=implode(',',array_fill(0,count($row),'?'));
                $pdo->prepare("INSERT INTO $table(id,clientId,actorId,requestKey,action,status,planJson,lastError,createdAt,updatedAt$extra) VALUES ($slots)")->execute(array_values($row));
                audit('client.ppp.'.strtolower($row['action']).'.requested','Client',$row['clientId'],$row['actorId']);
            });
            return clientPppApply($row,true);
        });
    });
}

function clientPppActionDispatch(string $method,string $route): bool
{
    if(preg_match('#^/clients/([a-f0-9]{24})/ppp-actions/(suspend|delete|reactivate)(/preview)?$#D',$route,$match)) {
        $action=strtoupper($match[2]);$actor=$action==='DELETE'?permit('ADMIN'):permit('ADMIN','TECHNICIAN');
        if(function_exists('set_time_limit'))set_time_limit(180);
        if($method==='GET' && isset($match[3]))json(clientPppPreview($match[1],$action,$actor));
        if($method==='POST' && !isset($match[3]))json(clientPppExecute($match[1],$action,body(),$actor));
    }
    if($method==='POST' && preg_match('#^/client-ppp-actions/([a-f0-9]{24})/(verify|continue)$#D',$route,$match)) {
        $row=clientPppFind('id',$match[1])??throw new HttpError(404,'Operación no encontrada.','NOT_FOUND');
        $actor=$row['action']==='DELETE'?permit('ADMIN'):permit('ADMIN','TECHNICIAN');
        if(body()!==[])throw new HttpError(422,'Esta operación no acepta parámetros.','VALIDATION_ERROR');
        if(function_exists('set_time_limit'))set_time_limit(180);
        $plan=json_decode($row['planJson'],true,512,JSON_THROW_ON_ERROR);
        json(apiLocks(['client:'.$row['clientId'],...array_map(static fn(array $t):string=>'router:'.$t['routerId'],$plan['targets'])],function()use($row,$match,$actor):array {
            $fresh=clientPppFind('id',$row['id']);
            audit('client.ppp.'.$match[2],'Client',$row['clientId'],$actor['id']);
            return clientPppApply($fresh,$match[2]==='continue');
        }));
    }
    return false;
}
