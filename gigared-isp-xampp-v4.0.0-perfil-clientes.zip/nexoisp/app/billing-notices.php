<?php
declare(strict_types=1);
namespace Nexo;

use DateTimeImmutable;
use DateTimeZone;
use Throwable;

function billingPolicyNotice(string $clientId,?string $invoiceId,string $kind,string $channel,string $subject,string $body,string $key): array
{
    $old=fetchOne('SELECT * FROM ClientNotice WHERE dedupeKey=?',[$key]);if($old){if($old['clientId']!==$clientId||$old['channel']!==$channel||$old['subject']!==$subject||$old['body']!==$body)throw new HttpError(409,'La referencia corresponde a otro aviso.');return $old;}
    $id=id();$stamp=now();$portal=$channel==='PORTAL';
    db()->prepare('INSERT IGNORE INTO ClientNotice(id,clientId,invoiceId,channel,kind,subject,body,status,dedupeKey,nextAttemptAt,sentAt,createdAt,updatedAt) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)')->execute([$id,$clientId,$invoiceId,$channel,$kind,$subject,$body,$portal?'DELIVERED':'QUEUED',$key,$stamp,$portal?$stamp:null,$stamp,$stamp]);
    $row=fetchOne('SELECT * FROM ClientNotice WHERE dedupeKey=?',[$key]);if($row['clientId']!==$clientId||$row['channel']!==$channel||$row['subject']!==$subject||$row['body']!==$body)throw new HttpError(409,'La referencia corresponde a otro aviso.');if($portal)clientProfileEvent($clientId,'NOTICE_DELIVERED',['noticeId'=>$row['id'],'channel'=>'PORTAL','kind'=>$kind],null,null,'BILLING','notice-delivered:'.$row['id']);return $row;
}

function billingPolicyInvoiceNotices(array $invoice,array $p,DateTimeImmutable $at): int
{
    $channels=json_decode($p['channelsJson'],true,16,JSON_THROW_ON_ERROR);$zone=new DateTimeZone(POLICY_ZONE);$settings=billingPolicySettings();$count=0;
    $due=billingDate($invoice['dueAt'])->setTimezone($zone);$issue=billingDate($invoice['issuedAt']);$events=['INVOICE'=>$issue];
    foreach([1,2,3] as $n){$offset=$p['reminder'.$n.'Days'];if($offset!==null&&$offset!==0)$events['REMINDER'.$n]=$due->modify(((int)$offset>=0?'+':'').(int)$offset.' days')->setTime(...array_map('intval',explode(':',$settings['reminder'.$n.'Hour'])));}
    foreach($events as $kind=>$when){if($when>$at)continue;foreach($channels as $channel){
        $key='invoice:'.$invoice['id'].':'.$kind.':'.$channel;if(fetchOne('SELECT id FROM ClientNotice WHERE dedupeKey=?',[$key]))continue;
        $balance=(int)$invoice['amountCents']-(int)$invoice['paidCents'];$subject=$kind==='INVOICE'?'Nueva factura '.$invoice['number']:'Recordatorio de pago '.$invoice['number'];$body=$subject.'. Saldo: '.number_format($balance/100,2).' '.$invoice['currency'].'. Vencimiento: '.$due->format('d/m/Y').'.';
        billingPolicyNotice($invoice['clientId'],$invoice['id'],$kind,$channel,$subject,$body,$key);$count++;
    }}return $count;
}

/** Gateway contract: HTTPS, HMAC, Idempotency-Key and an acknowledged provider id. */
function billingPolicyDeliverNotices(int $limit=10): int
{
    $settings=billingPolicySettings(true);if(!$settings['gatewayConfigured'])return 0;$delivered=0;
    foreach(fetchAll("SELECT * FROM ClientNotice WHERE status IN ('QUEUED','FAILED') AND attempts<5 AND nextAttemptAt<=? ORDER BY createdAt,id LIMIT ".max(1,min(20,$limit)),[now()]) as $notice){
        try{
            $client=fetchOne('SELECT email,phone,status FROM Client WHERE id=?',[$notice['clientId']]);if(!$client||$client['status']==='RETIRED')throw new \RuntimeException('Unavailable recipient.');
            $recipient=$notice['channel']==='EMAIL'?$client['email']:$client['phone'];if(!is_string($recipient)||$recipient==='')throw new \RuntimeException('Missing recipient.');
            $body=json_encode(['id'=>$notice['id'],'channel'=>$notice['channel'],'recipient'=>$recipient,'subject'=>$notice['subject'],'body'=>$notice['body']],JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE);$timestamp=(string)time();$signature=hash_hmac('sha256',$timestamp.'.'.$body,decryptSecret($settings['gatewaySecretEncrypted']));
            $ctx=stream_context_create(['http'=>['method'=>'POST','header'=>"Content-Type: application/json\r\nIdempotency-Key: ".$notice['id']."\r\nX-GIGARED-Timestamp: ".$timestamp."\r\nX-GIGARED-Signature: ".$signature."\r\n",'content'=>$body,'timeout'=>10,'ignore_errors'=>true,'follow_location'=>0,'max_redirects'=>0],'ssl'=>['verify_peer'=>true,'verify_peer_name'=>true]]);
            $reply=@file_get_contents($settings['gatewayUrl'],false,$ctx,0,65537);$headers=$http_response_header??[];$code=preg_match('~^HTTP/\S+\s+(\d{3})~',$headers[0]??'',$m)?(int)$m[1]:0;$receipt=is_string($reply)?json_decode($reply,true):null;
            if($code<200||$code>=300||!is_array($receipt)||!is_string($receipt['id']??null)||$receipt['id']===''||strlen($receipt['id'])>180)throw new \RuntimeException('Missing gateway acknowledgement.');
            db()->prepare("UPDATE ClientNotice SET status='SENT',providerId=?,attempts=attempts+1,lastError=NULL,sentAt=?,updatedAt=? WHERE id=?")->execute([$receipt['id'],now(),now(),$notice['id']]);clientProfileEvent($notice['clientId'],'NOTICE_SENT',['noticeId'=>$notice['id'],'channel'=>$notice['channel']],null,null,'BILLING','notice-sent:'.$notice['id']);$delivered++;
        }catch(Throwable){$retry=gmdate('Y-m-d H:i:s',time()+min(3600,60*(2**(int)$notice['attempts'])));db()->prepare("UPDATE ClientNotice SET status='FAILED',attempts=attempts+1,lastError=?,nextAttemptAt=?,updatedAt=? WHERE id=?")->execute(['El gateway no confirmó la entrega. Revisa su configuración y el destinatario.',$retry,now(),$notice['id']]);}
    }return $delivered;
}

function billingPolicySettingsDispatch(string $method,string $route): bool
{
    if($route==='/billing/automation/settings'){
        if($method==='GET'){permit('ADMIN','BILLING');json(billingPolicySettings());}
        if($method==='PATCH'){
            $actor=permit('ADMIN');$data=body();$allowed=['enabled','invoiceHour','cutHour','noticeHour','lateFeeHour','reminder1Hour','reminder2Hour','reminder3Hour','gatewayUrl','gatewaySecret'];if(array_diff(array_keys($data),$allowed))throw new HttpError(422,'Configuración no admitida.');$row=billingPolicySettings(true);
            if(isset($data['enabled'])){if(!is_bool($data['enabled']))throw new HttpError(422,'Activación inválida.');if($data['enabled']&&networkReadOnly()&&!$row['enabled'])throw new HttpError(409,'La red sigue en modo lectura; habilita escrituras en la configuración del servidor antes de activar cortes automáticos.','NETWORK_READ_ONLY');$row['enabled']=(int)$data['enabled'];}
            foreach(['invoiceHour','cutHour','noticeHour','lateFeeHour','reminder1Hour','reminder2Hour','reminder3Hour'] as $k)if(isset($data[$k])){if(!is_string($data[$k])||!preg_match('/^(?:[01][0-9]|2[0-3]):[0-5][0-9]$/D',$data[$k]))throw new HttpError(422,'Hora inválida.');$row[$k]=$data[$k];}
            if(array_key_exists('gatewayUrl',$data)){$url=$data['gatewayUrl'];if($url!==null&&$url!==''){if(!is_string($url)||strlen($url)>1024||!filter_var($url,FILTER_VALIDATE_URL)||parse_url($url,PHP_URL_SCHEME)!=='https'||parse_url($url,PHP_URL_USER)!==null||parse_url($url,PHP_URL_FRAGMENT)!==null)throw new HttpError(422,'El gateway requiere HTTPS sin credenciales en la URL.');}$row['gatewayUrl']=$url?:null;}
            if(array_key_exists('gatewaySecret',$data)){if(!is_string($data['gatewaySecret'])||strlen($data['gatewaySecret'])<32||strlen($data['gatewaySecret'])>255)throw new HttpError(422,'Usa una clave de gateway de 32 a 255 caracteres.');$row['gatewaySecretEncrypted']=encryptSecret($data['gatewaySecret']);}
            $keys=['enabled','invoiceHour','cutHour','noticeHour','lateFeeHour','reminder1Hour','reminder2Hour','reminder3Hour','gatewayUrl','gatewaySecretEncrypted'];$values=array_map(static fn(string $k):mixed=>$row[$k],$keys);$values[0]=(int)$values[0];
            db()->prepare("INSERT INTO BillingAutomationSetting(id,".implode(',',$keys).",updatedAt) VALUES ('primary',".implode(',',array_fill(0,count($keys),'?')).",?) ON DUPLICATE KEY UPDATE ".implode(',',array_map(static fn(string $k):string=>$k.'=VALUES('.$k.')',$keys)).',updatedAt=VALUES(updatedAt)')->execute([...$values,now()]);audit('billing.automation.settings','BillingAutomationSetting','primary',$actor['id']);json(billingPolicySettings());
        }
    }
    if($route==='/billing/automation/run'&&$method==='POST'){permit('ADMIN','BILLING');if(body()!==[])throw new HttpError(422,'No se admiten parámetros.');json(billingPolicyTick(null,true));}
    if(preg_match('#^/routers/([a-f0-9]{24})/billing-policy(?:/(prepare))?$#D',$route,$m)){
        $actor=permit('ADMIN');$router=apiRecord('Router',$m[1]);
        if($method==='GET')json(billingNetworkRouterPolicy($router['id']));
        if($method==='PATCH')json(billingNetworkRouterSave($router,body(),$actor));
        if($method==='POST'&&isset($m[2])){requireNetworkWrite();if(body()!==[])throw new HttpError(422,'No se admiten parámetros.');json(billingWithLocks(['router:'.$router['id']],function()use($router,$actor):array {$controller=new BillingNetworkController($router);try{$controller->prepare();audit('billing.firewall.prepare','Router',$router['id'],$actor['id']);return billingNetworkRouterPolicy($router['id']);}finally{$controller->close();}}));}
    }
    return false;
}
