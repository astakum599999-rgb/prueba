<?php
declare(strict_types=1);

namespace Nexo;

use PDO;
use RuntimeException;
use Throwable;

final class WorkerDeferred extends RuntimeException {}

function workerPublicError(Throwable $error): string
{
    if ($error instanceof HttpError) {
        return substr($error->getMessage(), 0, 800);
    }
    if ($error instanceof RouterError) {
        if ($error->routerCode === 'NETWORK_READ_ONLY') {
            return 'La red está en modo solo lectura. No se aplicó configuración al MikroTik.';
        }
        if ($error->routerCode === 'FASTTRACK_CONFLICT') {
            return 'Desactive FastTrack para el tráfico administrado antes de provisionar: FastTrack omite las colas y las reglas de corte.';
        }
        $code = preg_match('/^[A-Za-z0-9_-]{1,64}$/D', $error->routerCode) ? ' (' . $error->routerCode . ')' : '';
        return 'RouterOS no confirmó la operación' . $code . '. Verifique conectividad, permisos y configuración del router.';
    }
    return 'La operación no se completó. Verifique la base de datos y la configuración del servidor.';
}

function workerPayload(array $task): array
{
    $payload = $task['payload'];
    if (is_string($payload)) {
        $payload = json_decode($payload, true, 64, JSON_THROW_ON_ERROR);
    }
    if (!is_array($payload)) {
        throw new HttpError(400, 'Contenido de tarea inválido.');
    }
    return $payload;
}

/** Only a strictly scoped financial job may bypass the network-write guard. */
function workerLocalBillingTask(array $task): bool
{
    if (($task['kind'] ?? null) !== 'BILLING_RUN') return false;
    try {
        return (workerPayload($task + ['payload' => []])['scope'] ?? null) === 'LOCAL_ONLY';
    } catch (\JsonException | HttpError) {
        return false;
    }
}

function workerTouchLease(): void
{
    $active = $GLOBALS['nexo_active_task'] ?? null;
    if (!is_array($active)) {
        return;
    }
    db()->prepare("UPDATE `Task` SET lockedAt = ?, updatedAt = ? WHERE id = ? AND lockedBy = ? AND status = 'RUNNING'")
        ->execute([now(), now(), $active['id'], $active['owner']]);
}

/** A short InnoDB transaction claims one job; no network I/O holds row locks. */
function claimTask(string $owner): ?array
{
    return tx(function (PDO $pdo) use ($owner): ?array {
        $cutoff = billingNow()->modify('-5 minutes')->format('Y-m-d H:i:s.v');
        // General billing and configuration jobs remain pending in reading mode.
        // A scoped local billing job can only create financial records.
        $allowed = networkReadOnly() ? " AND (kind IN ('ROUTER_TEST','DIAGNOSTIC') OR (kind='BILLING_RUN' AND JSON_TYPE(JSON_EXTRACT(payload, '$.scope'))='STRING' AND BINARY JSON_UNQUOTE(JSON_EXTRACT(payload, '$.scope'))='LOCAL_ONLY'))" : '';
        $pdo->prepare("UPDATE `Task` SET status = 'FAILED', error = 'La tarea agotó sus intentos y su reserva expiró.', completedAt = ?, lockedAt = NULL, lockedBy = NULL, updatedAt = ? WHERE status = 'RUNNING' AND attempts >= 5 AND (lockedAt IS NULL OR lockedAt < ?)" . $allowed)
            ->execute([now(), now(), $cutoff]);
        $task = fetchOne("SELECT * FROM `Task` WHERE attempts < 5" . $allowed . " AND ((status = 'QUEUED' AND nextRunAt <= ?) OR (status = 'RUNNING' AND (lockedAt IS NULL OR lockedAt < ?))) ORDER BY CASE WHEN kind = 'SERVICE_SYNC' AND JSON_UNQUOTE(JSON_EXTRACT(payload, '$.source')) = 'payment' THEN 1 WHEN kind IN ('BILLING_RUN', 'AUTOCUT_RUN') THEN 2 WHEN kind IN ('DIAGNOSTIC', 'ROUTER_TEST') THEN 3 WHEN kind = 'SERVICE_SYNC' THEN 5 ELSE 10 END, createdAt, id LIMIT 1 FOR UPDATE", [now(), $cutoff]);
        if ($task === null) {
            return null;
        }
        $pdo->prepare("UPDATE `Task` SET status = 'RUNNING', attempts = attempts + 1, startedAt = COALESCE(startedAt, ?), lockedAt = ?, lockedBy = ?, error = NULL, updatedAt = ? WHERE id = ?")
            ->execute([now(), now(), $owner, now(), $task['id']]);
        $task['status'] = 'RUNNING';
        $task['attempts'] = (int) $task['attempts'] + 1;
        $task['lockedBy'] = $owner;
        return $task;
    });
}

function workerLoadService(string $serviceId): array
{
    billingLocalRequireNetworkService($serviceId);
    $service = billingService($serviceId);
    if ($service === null) {
        throw new HttpError(404, 'Servicio no encontrado.');
    }
    $service['router'] = fetchOne('SELECT * FROM `Router` WHERE id = ?', [$service['routerId']]);
    if ($service['router'] === null || $service['plan'] === null || $service['client'] === null) {
        throw new HttpError(409, 'El servicio no tiene todas sus referencias disponibles.');
    }
    return $service;
}

function workerWithService(string $serviceId, callable $operation): mixed
{
    // Reject financial-only and incomplete records before a router lock or I/O.
    billingLocalRequireNetworkService($serviceId);
    $initial = fetchOne('SELECT routerId FROM `Service` WHERE id = ?', [$serviceId]);
    if ($initial === null) {
        throw new HttpError(404, 'Servicio no encontrado.');
    }
    $routerKey = 'router:' . $initial['routerId'];
    if (!lock($routerKey, 0)) {
        throw new WorkerDeferred('El router está procesando otra tarea.');
    }
    $controller = null;
    try {
        $service = workerLoadService($serviceId);
        if ($service['routerId'] !== $initial['routerId']) {
            throw new HttpError(409, 'Cambió el router del servicio; vuelva a sincronizar.');
        }
        $controller = new MikroTik($service['router']);
        $result = $operation($controller, $service);
        if (!is_array($result) || ($result['routerContacted'] ?? true) !== false) {
            db()->prepare('UPDATE `Router` SET online = 1, lastSeenAt = ?, lastError = NULL, updatedAt = ? WHERE id = ?')
                ->execute([now(), now(), $service['routerId']]);
        }
        return $result;
    } catch (Throwable $error) {
        if (!$error instanceof WorkerDeferred) {
            db()->prepare('UPDATE `Router` SET online = 0, lastError = ?, updatedAt = ? WHERE id = ?')
                ->execute([workerPublicError($error), now(), $initial['routerId']]);
        }
        throw $error;
    } finally {
        if ($controller !== null) {
            $controller->close();
        }
        unlock($routerKey);
    }
}

/** Caller owns the client's named lock and a short transaction. */
function workerReconcileClient(string $clientId): void
{
    $client = fetchOne('SELECT status FROM `Client` WHERE id = ?', [$clientId]);
    if ($client === null || $client['status'] === 'RETIRED') {
        return;
    }
    $services = fetchAll('SELECT s.desiredState,s.appliedState FROM `Service` s WHERE s.clientId = ? AND s.routerId IS NOT NULL AND s.type IS NOT NULL AND s.ipAddress IS NOT NULL AND NOT EXISTS (SELECT 1 FROM `LocalBillingService` l WHERE l.serviceId=s.id)', [$clientId]);
    if ($services === []) {
        return;
    }
    $hasActive = false;
    $allKnown = true;
    $allRetired = true;
    foreach ($services as $service) {
        $hasActive = $hasActive || $service['appliedState'] === 'ACTIVE';
        $allKnown = $allKnown && $service['appliedState'] !== null;
        $allRetired = $allRetired && $service['desiredState'] === 'RETIRED' && $service['appliedState'] === 'RETIRED';
    }
    if (!$hasActive && !$allKnown) {
        return;
    }
    $status = $allRetired ? 'RETIRED' : ($hasActive ? 'ACTIVE' : 'SUSPENDED');
    db()->prepare('UPDATE `Client` SET status = ?, updatedAt = ? WHERE id = ?')->execute([$status, now(), $clientId]);
}

function workerSyncService(string $serviceId): array
{
    requireNetworkWrite();
    // New customer accounts have durable remote IDs and dedicated profile operations.
    if(function_exists(__NAMESPACE__ . '\\billingPolicySettings') && fetchOne("SELECT id FROM ClientProvisioning WHERE serviceId=? AND status='CONFIRMED'",[$serviceId]))throw new HttpError(409,'Usa las acciones del perfil para esta cuenta aprovisionada; no se recreará su recurso.','MANAGED_SERVICE_SYNC_BLOCKED');
    // A rejected local task must not mark the record as failed or mutate it.
    billingLocalRequireNetworkService($serviceId);
    $revision = null;
    try {
        return workerWithService($serviceId, function (MikroTik $controller, array $service) use (&$revision): array {
            $revision = (int) $service['revision'];
            $contacted = true;
            workerTouchLease();
            if ($service['desiredState'] === 'RETIRED') {
                // A historic address can already belong to another subscriber.
                if ($service['appliedState'] === 'RETIRED') {
                    $contacted = false;
                } else {
                    $controller->retirarServicio($service);
                }
            } else {
                $retiredIds = array_column(fetchAll("SELECT id FROM `Service` WHERE routerId = ? AND ipAddress = ? AND desiredState = 'RETIRED' AND appliedState = 'RETIRED' AND id <> ?", [$service['routerId'], $service['ipAddress'], $service['id']]), 'id');
                $controller->transferirReservasRetiradas($service, $retiredIds);
                workerTouchLease();
                $controller->crearServicio($service);
                workerTouchLease();
                if ($service['desiredState'] === 'SUSPENDED') {
                    $controller->suspenderServicio($service);
                } else {
                    $controller->reactivarServicio($service);
                }
            }
            $applied = billingWithLocks(['client:' . $service['clientId']], function () use ($service): bool {
                return tx(function (PDO $pdo) use ($service): bool {
                    $statement = $pdo->prepare("UPDATE `Service` SET appliedState = ?, syncStatus = 'SYNCED', lastSyncAt = ?, lastError = NULL, updatedAt = ? WHERE id = ? AND revision = ?");
                    $statement->execute([$service['desiredState'], now(), now(), $service['id'], $service['revision']]);
                    $changed = $statement->rowCount() > 0;
                    if ($changed) {
                        workerReconcileClient($service['clientId']);
                    }
                    return $changed;
                });
            });
            return ['serviceId' => $service['id'], 'revision' => $revision, 'state' => $service['desiredState'], 'applied' => $applied,
                'routerContacted' => $contacted, 'simulated' => $service['router']['transport'] === 'SIMULATED'];
        });
    } catch (Throwable $error) {
        if (!$error instanceof WorkerDeferred) {
            $sql = "UPDATE `Service` SET syncStatus = 'FAILED', lastError = ?, updatedAt = ? WHERE id = ?";
            $params = [workerPublicError($error), now(), $serviceId];
            if ($revision !== null) {
                $sql .= ' AND revision = ?';
                $params[] = $revision;
            }
            db()->prepare($sql)->execute($params);
        }
        throw $error;
    }
}

function workerRouterOperation(string $routerId, bool $firewall): mixed
{
    if ($firewall) requireNetworkWrite();
    $key = 'router:' . $routerId;
    if (!lock($key, 0)) {
        throw new WorkerDeferred('El router está procesando otra tarea.');
    }
    $controller = null;
    try {
        $router = fetchOne('SELECT * FROM `Router` WHERE id = ?', [$routerId]);
        if ($router === null) {
            throw new HttpError(404, 'Router no encontrado.');
        }
        $controller = new MikroTik($router);
        workerTouchLease();
        $result = $firewall ? $controller->configureFirewall() : $controller->testConnection();
        db()->prepare('UPDATE `Router` SET online = 1, lastSeenAt = ?, lastError = NULL, updatedAt = ? WHERE id = ?')
            ->execute([now(), now(), $routerId]);
        return $result;
    } catch (Throwable $error) {
        db()->prepare('UPDATE `Router` SET online = 0, lastError = ?, updatedAt = ? WHERE id = ?')
            ->execute([workerPublicError($error), now(), $routerId]);
        throw $error;
    } finally {
        if ($controller !== null) {
            $controller->close();
        }
        unlock($key);
    }
}

function executeTask(array $task): mixed
{
    $localBilling = workerLocalBillingTask($task);
    if (!$localBilling && !in_array($task['kind'] ?? '', ['ROUTER_TEST','DIAGNOSTIC'], true)) requireNetworkWrite();
    $payload = workerPayload($task);
    switch ($task['kind']) {
        case 'SERVICE_SYNC':
            if(($payload['source']??null)==='billing-policy')return billingNetworkSync(billingId($payload['serviceId']??null),(int)($payload['policyRevision']??0));
            if(($payload['source']??null)==='profile-plan-change')return billingNetworkPlanSync(billingId($payload['serviceId']??null),(int)($payload['serviceRevision']??0),$payload['planSnapshot']??[]);
            return workerSyncService(billingId($payload['serviceId'] ?? null));
        case 'DIAGNOSTIC':
            return workerWithService(billingId($payload['serviceId'] ?? null), function (MikroTik $controller, array $service): array {
                if ($service['desiredState'] === 'RETIRED' || $service['appliedState'] === 'RETIRED') {
                    throw new HttpError(409, 'No se consulta una IP liberada por un servicio retirado.');
                }
                $result = $controller->obtenerTraficoYDiagnostico($service);
                if (function_exists(__NAMESPACE__ . '\\operationsRecordTraffic')) {
                    operationsRecordTraffic($service, $result);
                }
                return $result;
            });
        case 'ROUTER_TEST':
            return workerRouterOperation(billingId($payload['routerId'] ?? null), false);
        case 'FIREWALL_SYNC':
            return workerRouterOperation(billingId($payload['routerId'] ?? null), true);
        case 'BILLING_RUN':
            // Do not forward payload fields, IDs or a supplied clock to this path.
            return $localBilling ? generateLocalInvoices() : generateInvoices();
        case 'AUTOCUT_RUN':
            return runAutocut();
        case 'BULK_SYNC':
            $ids = $payload['ids'] ?? null;
            if (!is_array($ids) || count($ids) < 1 || count($ids) > 500) {
                throw new HttpError(400, 'El lote debe contener de uno a 500 servicios.');
            }
            $ids = array_values(array_unique(array_map(__NAMESPACE__ . '\\billingId', $ids)));
            foreach ($ids as $serviceId) billingLocalRequireNetworkService($serviceId);
            return tx(function (PDO $pdo) use ($ids, $task): array {
                $taskIds = [];
                foreach ($ids as $serviceId) {
                    if (fetchOne('SELECT id FROM `Service` WHERE id = ?', [$serviceId]) === null) {
                        throw new HttpError(404, 'Un servicio del lote no existe.');
                    }
                    $child = enqueue('SERVICE_SYNC', ['serviceId' => $serviceId, 'parentTaskId' => $task['id']]);
                    $taskIds[] = $child['id'];
                }
                return ['taskIds' => $taskIds];
            });
        default:
            throw new HttpError(400, 'Tipo de tarea desconocido.');
    }
}

function scheduleTasks(): void
{
    if(function_exists(__NAMESPACE__ . '\\billingPolicyTick'))billingPolicyTick();
    // Read-only inventory refresh is independent of financial/network writes.
    // Web fallback has its own ADMIN/TECHNICIAN endpoint and durable debounce.
    if (PHP_SAPI === 'cli' && function_exists(__NAMESPACE__ . '\\secretAutoSyncTick')) secretAutoSyncTick(null, 5);
    if (function_exists(__NAMESPACE__ . '\\generateLocalInvoices') && fetchOne("SELECT s.id FROM Service s JOIN LocalBillingService l ON l.serviceId=s.id JOIN LocalBillingSchedule b ON b.serviceId=s.id JOIN Client c ON c.id=s.clientId WHERE s.desiredState<>'RETIRED' AND c.status<>'RETIRED' AND NOT EXISTS (SELECT 1 FROM FinanceDeletion d WHERE d.entityType='Service' AND d.entityId=s.id) LIMIT 1") !== null) {
        $localAt = billingNow();
        enqueue('BILLING_RUN', ['scope' => 'LOCAL_ONLY', 'scheduled' => true], 'billing-local-' . $localAt->format('Y-m-d-H-i'));
    }
    if (networkReadOnly()) return;
    $at = billingNow();
    expirePaymentPromises($at);
    enqueue('BILLING_RUN', ['scheduled' => true, 'at' => $at->format(DATE_ATOM)], 'billing-' . $at->format('Y-m-d'));
    enqueue('AUTOCUT_RUN', ['scheduled' => true, 'at' => $at->format(DATE_ATOM)], 'autocut-' . intdiv($at->getTimestamp(), 60));
}

/** Safe for CLI and the authenticated browser fallback; each claim is durable. */
function processTasks(int $maxJobs = 1): array
{
    if ($maxJobs < 1 || $maxJobs > 100) {
        throw new HttpError(400, 'El límite de tareas debe estar entre uno y 100.');
    }
    if (PHP_SAPI !== 'cli') {
        if (function_exists('set_time_limit')) {
            set_time_limit(240);
        }
        ignore_user_abort(true);
    }
    $owner = (PHP_SAPI === 'cli' ? 'cli-' : 'web-') . getmypid() . '-' . bin2hex(random_bytes(12));
    $result = ['processed' => 0, 'taskIds' => [], 'failed' => 0, 'deferred' => 0];
    for ($count = 0; $count < $maxJobs; $count++) {
        $task = claimTask($owner);
        if ($task === null) {
            break;
        }
        $GLOBALS['nexo_active_task'] = ['id' => $task['id'], 'owner' => $owner];
        try {
            $output = executeTask($task);
            $encoded = json_encode($output ?? ['ok' => true], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
            db()->prepare("UPDATE `Task` SET status = 'SUCCEEDED', result = ?, error = NULL, completedAt = ?, lockedAt = NULL, lockedBy = NULL, updatedAt = ? WHERE id = ? AND lockedBy = ? AND status = 'RUNNING'")
                ->execute([$encoded, now(), now(), $task['id'], $owner]);
            $result['processed']++;
            $result['taskIds'][] = $task['id'];
        } catch (WorkerDeferred $error) {
            $next = billingNow()->modify('+2 seconds')->format('Y-m-d H:i:s.v');
            db()->prepare("UPDATE `Task` SET status = 'QUEUED', attempts = GREATEST(attempts - 1, 0), nextRunAt = ?, lockedAt = NULL, lockedBy = NULL, updatedAt = ? WHERE id = ? AND lockedBy = ?")
                ->execute([$next, now(), $task['id'], $owner]);
            $result['deferred']++;
        } catch (Throwable $error) {
            $final = (int) $task['attempts'] >= 5;
            $delay = (int) (1500 * 2 ** max(0, (int) $task['attempts'] - 1));
            $next = billingNow()->modify('+' . $delay . ' milliseconds')->format('Y-m-d H:i:s.v');
            db()->prepare('UPDATE `Task` SET status = ?, error = ?, nextRunAt = ?, completedAt = ?, lockedAt = NULL, lockedBy = NULL, updatedAt = ? WHERE id = ? AND lockedBy = ?')
                ->execute([$final ? 'FAILED' : 'QUEUED', workerPublicError($error), $next, $final ? now() : null, now(), $task['id'], $owner]);
            $result['processed']++;
            $result['failed']++;
            $result['taskIds'][] = $task['id'];
            error_log('GIGARED ISP task ' . $task['id'] . ': ' . workerPublicError($error));
        } finally {
            unset($GLOBALS['nexo_active_task']);
        }
    }
    return $result;
}
