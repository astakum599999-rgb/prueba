# Referencia del perfil de clientes de Mikrowisp

Investigación: 4 de noviembre de 2026, America/Lima. Se inició sesión con las credenciales públicas suministradas por el usuario en https://demo.mikrosystem.net/admin/. Se recorrieron Clientes/Usuarios, un perfil con varios servicios y las ocho pestañas. Se inspeccionaron formularios y respuestas de lectura; no se guardaron clientes, ajustes, pagos ni órdenes de red en el demo. No se incluyen datos personales, cookies, capturas del demo ni código privado en la distribución.

## Lo observado y su adaptación

| Demo observado | GIGARED ISP 4.0.0 |
| --- | --- |
| Resumen: datos a la izquierda; calendario, deuda y tickets a la derecha | Perfil navegable al pulsar el nombre, datos/GPS editables, IP y conexión observada, acciones manuales existentes |
| Servicios: plan, costo, IP, router, estado, autenticación | Servicios existentes y cuentas PPPoE importadas; credenciales protegidas; cambio de plan por ID remoto confirmado |
| Facturación: Facturas, Configuración, Transacciones, Saldos | Historias del mismo cliente, PDF interno real, pagos/promesas y política individual |
| Tickets: reclamos, asignación, prioridad, seguimiento | Tablas Ticket/TicketComment existentes, formularios y notas del técnico |
| Email & SMS; Documentos | Avisos multicanal, cola con confirmación del gateway, avisos del portal y contratos existentes |
| Estadísticas: servicio, diario/mensual, consumo | Muestras reales de tráfico/bytes/ping, consulta de 24 horas, 7 o 30 días; sin datos inventados |
| Log: todos, conexión, corte/activación | Auditoría existente + eventos de sesiones/IP/facturación; filtros por fecha, tipo y texto |

La implementación es independiente y conserva marca, navegación y temas de GIGARED. Reproduce los flujos observables; no afirma igualdad del código, algoritmos privados o funciones fiscales del proveedor. Equipos/VoIP/productos recurrentes y facturación fiscal AFIP/ARCA vistos en el demo no forman parte de este módulo de Internet ni se presentan como implementados.

## Configuración y calendario observados

El demo permite prepago/postpago, día de pago 1–28, creación desactivada o 1–25 días antes, gracia, corte por 1–12 facturas vencidas, reducción de velocidad, mora, reconexión, impuestos, fechas fijas y tres recordatorios. Un caso visible mostraba pago 01/11/2026, factura 27/10/2026 03:30 y corte 06/11/2026 02:30 con cinco días de gracia. Las pruebas reproducen estas fechas en America/Lima y almacenan UTC. La documentación contiene una redacción ambigua sobre restar gracia: se usó el ejemplo observable de sumar días.

Para respetar la configuración anterior del usuario, el calendario predeterminado sigue siendo el aniversario de instalación: inicio 01/10/2026, primer pago 01/11/2026, emisión dos días antes, gracia del servicio. Consultar un perfil o actualizar no crea una política individual. Solo guardar Configuración cambia las condiciones futuras; no reescribe facturas emitidas. Los importes se calculan con enteros (céntimos y puntos básicos), separados por moneda.

## Fuentes públicas consultadas

- Demo: https://demo.mikrosystem.net/admin/ → Clientes/Usuarios → nombre → pestañas; Facturación → Configuración.
- https://docs.mikrosystem.net/docs/configurar-facturación-interna
- https://docs.mikrosystem.net/docs/crear-factura-de-servicios
- https://docs.mikrosystem.net/docs/bajar-velocidad-por-falta-de-pago
- https://docs.mikrosystem.net/docs/registrar-pago-manual
- https://docs.mikrosystem.net/docs/tareas-programadas
- https://docs.mikrosystem.net/docs/notificaciones-en-pantalla
- https://docs.mikrosystem.net/docs/configurar-router
- https://docs.mikrosystem.net/docs/configurar-firewall
- https://docs.mikrosystem.net/docs/ticket-de-soporte
- https://docs.mikrosystem.net/docs/configuración-masiva

Las guías indican reducción ante la primera deuda vencida, corte según umbral y recuperación al resolver todas las deudas; promesas de hasta 20 días; mora posterior al vencimiento. Los avisos HTTP aparecen como obsoletos en la documentación oficial: aquí son opcionales. No se intercepta ni falsifica HTTPS.

## Arquitectura integrada

Se reutilizan Client, Service, Plan, Router, Invoice/InvoiceLine, Payment, PaymentPromise, Ticket/TicketComment, ServiceContract, Audit y Task. La migración 022 añade nueve tablas: ClientBillingPolicy, BillingAutomationSetting, BillingRouterPolicy, BillingServiceState, InvoiceAutomationFee, ClientNetworkObservation, ClientActivityEvent, ClientNotice y ClientTelemetrySample. Incluyen claves foráneas, índices temporales, revisiones, estados y deduplicación. SQL001–021 permanecen idénticos.

Código: client-profile.php (agregación, historial, PDF y rutas), client-telemetry.php (medición de lectura), billing-policy.php (calendario/estados/cargos), billing-network.php (controlador REST/Socket y confirmación), billing-notices.php (avisos/gateway), worker.php y bin/worker.php (tareas). React: ClientProfile.tsx, ClientBillingConfig.tsx y BillingAutomation.tsx. Fuentes y assets compilados incluidos.

La observación de sesiones se comparte con el sondeo existente de un segundo. Solo una lectura completa y exitosa produce conexión/desconexión/cambio de IP; fallos se muestran como desconocidos. Las muestras de diagnóstico se solicitan cada cinco segundos mientras Estadísticas está visible, con caché de dos segundos y retención de treinta días; no existe una captura histórica anterior a la instalación ni muestreo de toda la red a cada segundo.

El controlador exige FastTrack desactivado: no interpreta exclusiones personalizadas como garantía de que el tráfico limitado pase por las colas. Las IP PPP dinámicas reciben listas mediante perfiles administrados; no quedan IPs de pools en listas estáticas que pudieran afectar a su siguiente titular.
