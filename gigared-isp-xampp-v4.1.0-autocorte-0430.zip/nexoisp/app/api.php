<?php
declare(strict_types=1);
namespace Nexo;

require_once __DIR__ . '/client-notes.php';
require_once __DIR__ . '/client-ip-access.php';
require_once __DIR__ . '/billing-local.php';
require_once __DIR__ . '/financial-delete.php';
require_once __DIR__ . '/client-payment-date.php';

function apiFields(string $table): array
{
    return match ($table) {
        'User' => ['id','name','email','role','active','createdAt'],
        'Client' => ['id','code','name','email','phone','document','address','latitude','longitude','zone','status','createdAt','updatedAt'],
        'Plan' => ['id','name','downloadKbps','uploadKbps','queueParent','priority','pppoeProfile','priceCents','currency','active','createdAt','updatedAt'],
        'Router' => ['id','name','host','port','transport','username','useTls','verifyTls','cutAddressList','cutProfile','paymentPortalIp','paymentPortalPort','dhcpServer','hotspotServer','online','lastSeenAt','lastError','createdAt','updatedAt'],
        'Service' => ['id','clientId','planId','routerId','type','ipAddress','macAddress','username','desiredState','appliedState','suspensionReason','syncStatus','revision','lastSyncAt','lastError','billingDay','dueDays','graceDays','createdAt','updatedAt'],
        'Ticket' => ['id','clientId','assigneeId','subject','body','priority','status','createdAt','updatedAt'],
        'Task' => ['id','kind','status','payload','result','error','attempts','createdAt','updatedAt','startedAt','completedAt'],
        'ApiKey' => ['id','label','prefix','expiresAt','revokedAt','lastUsedAt','createdAt'],
        'AuditLog' => ['id','userId','action','entityType','entityId','details','createdAt'],
        'TicketComment' => ['id','ticketId','authorName','body','createdAt'],
        default => throw new \LogicException('Entidad no soportada'),
    };
}

function apiPick(array $row, array $fields): array
{
    return array_intersect_key($row, array_flip($fields));
}

function apiRecord(string $table, string $identifier, bool $forUpdate = false): array
{
    apiFields($table);
    return fetchOne('SELECT * FROM `' . $table . '` WHERE `id`=:id' . ($forUpdate ? ' FOR UPDATE' : ''), ['id' => $identifier]) ?? throw new HttpError(404, 'Registro no encontrado', 'NOT_FOUND');
}

function apiExecute(string $sql, array $params = []): void
{
    foreach ($params as $key => $value) if (is_bool($value)) $params[$key] = (int)$value;
    db()->prepare($sql)->execute($params);
}

function apiInsert(string $table, array $data): array
{
    apiFields($table);
    $hasNotes = $table === 'Client' && array_key_exists('notes', $data);
    $notes = $hasNotes ? $data['notes'] : null;
    if ($hasNotes) unset($data['notes']);
    $data['id'] ??= id();
    $data['createdAt'] ??= now();
    if (in_array($table, ['User','Client','Plan','Router','Service','Ticket'], true)) $data['updatedAt'] ??= now();
    foreach (array_keys($data) as $field) if (!preg_match('/^[A-Za-z][A-Za-z0-9]*$/D', $field)) throw new \LogicException('Campo SQL inválido');
    $fields = array_keys($data);
    apiExecute('INSERT INTO `' . $table . '` (`' . implode('`,`', $fields) . '`) VALUES (:' . implode(',:', $fields) . ')', $data);
    if ($hasNotes) clientNotesStore($data['id'], $notes);
    return apiRecord($table, $data['id']);
}

function apiUpdate(string $table, string $identifier, array $data): array
{
    apiFields($table);
    $hasNotes = $table === 'Client' && array_key_exists('notes', $data);
    $notes = $hasNotes ? $data['notes'] : null;
    if ($hasNotes) unset($data['notes']);
    if (in_array($table, ['User','Client','Plan','Router','Service','Ticket'], true)) $data['updatedAt'] = now();
    if (!$data) return apiRecord($table, $identifier);
    $assignments = [];
    foreach (array_keys($data) as $field) {
        if (!preg_match('/^[A-Za-z][A-Za-z0-9]*$/D', $field) || $field === 'id') throw new \LogicException('Campo SQL inválido');
        $assignments[] = '`' . $field . '`=:' . $field;
    }
    $data['_recordId'] = $identifier;
    apiExecute('UPDATE `' . $table . '` SET ' . implode(',', $assignments) . ' WHERE `id`=:_recordId', $data);
    if ($hasNotes) clientNotesStore($identifier, $notes);
    return apiRecord($table, $identifier);
}

function apiRelated(string $table, string $identifier): array
{
    $cacheKey = $table . ':' . $identifier;
    return $GLOBALS['nexo_relations'][$cacheKey] ??= apiRecord($table, $identifier);
}

function apiWarmRelations(array $rows): void
{
    foreach (['Client' => 'clientId','Plan' => 'planId','Router' => 'routerId','User' => 'assigneeId'] as $table => $field) {
        $ids = array_values(array_unique(array_filter(array_column($rows, $field), 'is_string')));
        if (!$ids) continue;
        $parameters = []; $placeholders = [];
        foreach ($ids as $index => $identifier) { $parameters['rel' . $index] = $identifier; $placeholders[] = ':rel' . $index; }
        foreach (fetchAll('SELECT * FROM `' . $table . '` WHERE `id` IN (' . implode(',', $placeholders) . ')', $parameters) as $record) $GLOBALS['nexo_relations'][$table . ':' . $record['id']] = $record;
    }
}

function apiDto(string $table, array $row): array
{
    $result = apiPick($row, apiFields($table));
    if ($table === 'Plan') $result['profileImport'] = profileImportPlanInfo($row['id']);
    if ($table === 'Router' && function_exists(__NAMESPACE__ . '\\mikrotikLiveRouterInfo')) $result['live'] = mikrotikLiveRouterInfo($row['id']);
    if ($table === 'Service') {
        $result['client'] = apiPick(apiRelated('Client', $row['clientId']), ['id','code','name','status']);
        $result['plan'] = apiPick(apiRelated('Plan', $row['planId']), apiFields('Plan'));
        $result['router'] = is_string($row['routerId']) && $row['routerId'] !== '' ? apiPick(apiRelated('Router', $row['routerId']), apiFields('Router')) : null;
        $result['billingOnly'] = billingLocalIsService($row['id']);
        $result['billingStartOn'] = null;
        if ($result['billingOnly']) {
            $result = array_merge($result, billingLocalCalendarFields($row));
            if ($result['billingCycle'] === 'INSTALLATION_ANNIVERSARY') {
                $result['billingDay'] = $result['paymentDay'];
                $result['dueDays'] = 2;
            }
        }
    } elseif ($table === 'Ticket') {
        $result['client'] = apiPick(apiRelated('Client', $row['clientId']), ['id','code','name']);
        $result['assignee'] = $row['assigneeId'] ? apiPick(apiRelated('User', $row['assigneeId']), ['id','name','role']) : null;
        $result['comments'] = fetchAll('SELECT `id`,`ticketId`,`authorName`,`body`,`createdAt` FROM `TicketComment` WHERE `ticketId`=:ticket ORDER BY `createdAt` ASC,`id` ASC', ['ticket' => $row['id']]);
    } elseif ($table === 'Client') {
        $result=array_merge($result,clientPaymentDate($row['id']));
        $result['canManualPppReactivate'] = clientPppCanActivate($row);
        if (function_exists(__NAMESPACE__ . '\\provisionPublic')) $result['provisioning'] = array_map(__NAMESPACE__ . '\\provisionPublic',fetchAll('SELECT * FROM ClientProvisioning WHERE clientId=? ORDER BY createdAt DESC',[$row['id']]));
        $result['notes'] = clientNotesGet($row['id']);
        $result['ipAddresses'] = clientIpAddresses($row['id']);
        $counts = fetchOne('SELECT (SELECT COUNT(*) FROM `Service` s WHERE s.`clientId`=:serviceClient AND ' . financialDeletionClause('Service', 's') . ') AS services,(SELECT COUNT(*) FROM `Ticket` WHERE `clientId`=:ticketClient) AS tickets', ['serviceClient' => $row['id'], 'ticketClient' => $row['id']]);
        $result['_count'] = ['services' => (int)$counts['services'], 'tickets' => (int)$counts['tickets']];
        $result['routerSecrets'] = secretImportClientRows($row['id']);
    } elseif ($table === 'AuditLog') {
        $result['user'] = $row['userId'] ? apiPick(apiRelated('User', $row['userId']), ['id','name']) : null;
    }
    return $result;
}

function apiLike(string $value): string
{
    return '%' . strtr($value, ['=' => '==', '%' => '=%', '_' => '=_']) . '%';
}

function apiSearch(array $expressions, string $search, array &$where, array &$params): void
{
    if ($search === '') return;
    $parts = [];
    foreach ($expressions as $index => $expression) { $key = 'search' . $index; $parts[] = $expression . ' LIKE :' . $key . " ESCAPE '='"; $params[$key] = apiLike($search); }
    $where[] = '(' . implode(' OR ', $parts) . ')';
}

function apiList(string $table, array $p, array $where = [], array $params = [], string $order = '`createdAt` DESC,`id` DESC'): array
{
    apiFields($table);
    if ($table === 'Service') $where[] = financialDeletionClause('Service', 'Service');
    $clause = $where ? ' WHERE ' . implode(' AND ', $where) : '';
    $count = (int)fetchOne('SELECT COUNT(*) AS n FROM `' . $table . '`' . $clause, $params)['n'];
    $rows = fetchAll('SELECT * FROM `' . $table . '`' . $clause . ' ORDER BY ' . $order . ' LIMIT ' . $p['pageSize'] . ' OFFSET ' . $p['offset'], $params);
    if($table==='Client')clientPaymentDatesWarm(array_column($rows,'id'));
    apiWarmRelations($rows);
    if ($table === 'Service') billingLocalWarm(array_column($rows, 'id'));
    if ($table === 'Client') {
        secretImportWarmClients(array_column($rows, 'id'));
        clientNotesWarm(array_column($rows, 'id'));
        clientIpAddressesWarm(array_column($rows, 'id'));
    }
    return ['results' => array_map(fn(array $row): array => apiDto($table, $row), $rows), 'count' => $count, 'page' => $p['page'], 'pageSize' => $p['pageSize']];
}

function apiLocks(array $keys, callable $callback): mixed
{
    $keys = array_values(array_unique($keys)); sort($keys, SORT_STRING);
    $held = [];
    try {
        foreach ($keys as $key) {
            if (!lock($key, 10)) throw new HttpError(409, 'Recurso ocupado; vuelva a intentar la operación', 'RESOURCE_BUSY');
            $held[] = $key;
        }
        return $callback();
    } finally { foreach (array_reverse($held) as $key) unlock($key); }
}

function apiChangeServices(array $serviceIds, ?string $state, array $user): array
{
    requireNetworkWrite();
    $ids = array_values(array_unique($serviceIds)); sort($ids, SORT_STRING);
    $keys = [];
    foreach ($ids as $identifier) {
        billingLocalRequireNetworkService($identifier);
        $keys[] = 'client:' . apiRecord('Service', $identifier)['clientId'];
    }
    return apiLocks($keys, fn(): array => tx(function (\PDO $pdo) use ($ids, $state, $user): array {
        $tasks = [];
        foreach ($ids as $identifier) {
            $service = apiRecord('Service', $identifier, true);
            billingLocalRequireNetworkService($identifier);
            if ($service['desiredState'] === 'RETIRED' && $state !== null && $state !== 'RETIRED') throw new HttpError(409, 'Un servicio retirado no se puede reactivar');
            $data = ['syncStatus' => 'PENDING', 'revision' => (int)$service['revision'] + 1];
            if ($state !== null) { $data['desiredState'] = $state; $data['suspensionReason'] = $state === 'SUSPENDED' ? 'MANUAL' : null; }
            apiUpdate('Service', $identifier, $data);
            $tasks[] = enqueue('SERVICE_SYNC', ['serviceId' => $identifier]);
            audit($state ?? 'SYNC', 'Service', $identifier, $user['id']);
        }
        return $tasks;
    }));
}

function apiValidAssignee(?string $assigneeId): void
{
    if ($assigneeId === null) return;
    if (!fetchOne("SELECT `id` FROM `User` WHERE `id`=:id AND `active`=1 AND `role` IN ('ADMIN','TECHNICIAN')", ['id' => $assigneeId])) throw new HttpError(422, 'El técnico asignado no está disponible');
}

function apiDispatch(string $method, string $route): bool
{
    if ($method === 'POST' && $route === '/auth/login') json(loginUser(body()));
    if ($method === 'GET' && $route === '/auth/me') json(['user' => requireAuth(), 'capabilities' => authCapabilities()]);
    if ($method === 'POST' && $route === '/auth/logout') {
        requireAuth(); $token = $_COOKIE['nexoisp_session'] ?? null;
        if (is_string($token)) apiExecute('DELETE FROM `Session` WHERE `tokenHash`=:hash', ['hash' => hashToken($token)]);
        setcookie('nexoisp_session', '', sessionCookieOptions(time() - 3600)); json(null, 204);
    }
    if ($method === 'POST' && $route === '/worker/tick') {
        $actor = requireAuth(); scheduleTasks(); $counts = processTasks(1);
        if (in_array($actor['role'], ['ADMIN','TECHNICIAN'], true) && function_exists(__NAMESPACE__ . '\\fiberProcessJobs')) {
            if (function_exists('set_time_limit')) set_time_limit(120);
            ignore_user_abort(true);
            fiberScheduleReads();
            $fiber = fiberProcessJobs(1);
            $counts['processed'] += (int)($fiber['processed'] ?? 0);
            $counts['failed'] += (int)($fiber['failed'] ?? 0);
        }
        json(['processed' => (int)($counts['processed'] ?? 0), 'failed' => (int)($counts['failed'] ?? 0)]);
    }
    if ($route === '/keys' && $method === 'GET') {
        $user = requireAuth(); $p = pagination(); $where = ['`userId`=:owner']; $params = ['owner' => $user['id']];
        apiSearch(['`label`','`prefix`'], $p['search'], $where, $params); json(apiList('ApiKey', $p, $where, $params));
    }
    if ($route === '/keys' && $method === 'POST') {
        $user = requireAuth(); $data = validate('key', body());
        if (isset($data['expiresAt']) && strtotime($data['expiresAt']) <= time()) throw new HttpError(422, 'La fecha de expiración debe ser futura');
        $token = rtrim(strtr(base64_encode(random_bytes(32)), '+/', '-_'), '=');
        if (isset($data['expiresAt'])) $data['expiresAt'] = gmdate('Y-m-d H:i:s', strtotime($data['expiresAt']));
        $record = tx(function (\PDO $pdo) use ($data, $token, $user): array {
            $key = apiInsert('ApiKey', $data + ['userId' => $user['id'], 'prefix' => substr($token, 0, 8), 'tokenHash' => hashToken($token)]);
            audit('CREATE_API_KEY', 'ApiKey', $key['id'], $user['id']); return $key;
        });
        json(apiDto('ApiKey', $record) + ['token' => $token], 201);
    }
    if (preg_match('#^/keys/([A-Za-z0-9_-]{1,128})$#D', $route, $m) && $method === 'DELETE') {
        $user = requireAuth(); tx(function (\PDO $pdo) use ($m, $user): void {
            $key = apiRecord('ApiKey', $m[1], true);
            if ($key['userId'] !== $user['id']) throw new HttpError(404, 'Clave no encontrada');
            apiUpdate('ApiKey', $key['id'], ['revokedAt' => now()]); audit('REVOKE_API_KEY', 'ApiKey', $key['id'], $user['id']);
        }); json(null, 204);
    }
    if ($route === '/technicians' && $method === 'GET') {
        requireAuth(); $p = pagination(); $base = " FROM `User` WHERE `active`=1 AND `role` IN ('ADMIN','TECHNICIAN')";
        json(['results' => fetchAll('SELECT `id`,`name`,`role`' . $base . ' ORDER BY `name` ASC,`id` ASC LIMIT ' . $p['pageSize'] . ' OFFSET ' . $p['offset']), 'count' => (int)fetchOne('SELECT COUNT(*) AS n' . $base)['n'], 'page' => $p['page'], 'pageSize' => $p['pageSize']]);
    }
    if ($route === '/dashboard' && $method === 'GET') {
        requireAuth(); $counts = fetchOne("SELECT (SELECT COUNT(*) FROM `Client`) AS clients,(SELECT COUNT(*) FROM `Client` WHERE `status`='ACTIVE') AS activeClients,(SELECT COUNT(*) FROM `Client` WHERE `status`='SUSPENDED') AS suspendedClients,(SELECT COUNT(*) FROM `Service` s WHERE `desiredState`<>'RETIRED' AND " . financialDeletionClause('Service', 's') . ") AS services,(SELECT COUNT(*) FROM `Router`) AS routers,(SELECT COUNT(*) FROM `Router` WHERE `online`=1) AS onlineRouters,(SELECT COUNT(*) FROM `Ticket` WHERE `status` IN ('OPEN','IN_PROGRESS')) AS openTickets,(SELECT COUNT(*) FROM `Task` WHERE `status` IN ('QUEUED','RUNNING')) AS pendingTasks");
        $totals = fetchAll("SELECT `currency`,SUM(`amountCents`) AS invoicedCents,SUM(`paidCents`) AS paidCents,SUM(`amountCents`-`paidCents`) AS outstandingCents FROM `Invoice` i WHERE `status`<>'VOID' AND " . financialDeletionClause('Invoice', 'i') . " GROUP BY `currency` ORDER BY `currency` ASC");
        foreach ($totals as &$total) foreach (['invoicedCents','paidCents','outstandingCents'] as $field) $total[$field] = (int)$total[$field]; unset($total);
        $recentInvoices = fetchAll('SELECT * FROM `Invoice` i WHERE ' . financialDeletionClause('Invoice', 'i') . ' ORDER BY `createdAt` DESC,`id` DESC LIMIT 5');
        foreach ($recentInvoices as &$invoice) $invoice['client'] = apiPick(apiRelated('Client', $invoice['clientId']), ['id','name']); unset($invoice);
        $recentTasks = array_map(fn(array $row): array => apiDto('Task', $row), fetchAll('SELECT * FROM `Task` ORDER BY `createdAt` DESC,`id` DESC LIMIT 5'));
        json(['counts' => array_map('intval', $counts), 'billing' => $totals, 'recentInvoices' => $recentInvoices, 'recentTasks' => $recentTasks, 'onlinePppoe' => dashboardOnlineCount()]);
    }
    if ($route === '/audit' && $method === 'GET') {
        permit('ADMIN'); $p = pagination(); $where = []; $params = [];
        apiSearch(['`action`','`entityType`','`entityId`'], $p['search'], $where, $params); json(apiList('AuditLog', $p, $where, $params));
    }
    if ($route === '/tasks' && $method === 'GET') {
        requireAuth(); $p = pagination(); $where = []; $params = [];
        if (($status = queryEnum('status', ['QUEUED','RUNNING','SUCCEEDED','FAILED'])) !== null) { $where[] = '`status`=:status'; $params['status'] = $status; }
        apiSearch(['`id`','`error`','`kind`'], $p['search'], $where, $params); json(apiList('Task', $p, $where, $params));
    }
    if (preg_match('#^/tasks/([A-Za-z0-9_-]{1,128})(/retry)?$#D', $route, $m)) {
        $user = requireAuth();
        if ($method === 'GET' && empty($m[2])) json(apiDto('Task', apiRecord('Task', $m[1])));
        if ($method === 'POST' && ($m[2] ?? '') === '/retry') {
            $task = tx(function (\PDO $pdo) use ($m, $user): array {
                $old = apiRecord('Task', $m[1], true);
                if ($old['status'] !== 'FAILED') throw new HttpError(409, 'Sólo se reintentan tareas fallidas');
                if (!canRetryTask($user['role'], $old['kind'])) throw new HttpError(403, 'No dispone de permisos para reintentar esta tarea', 'FORBIDDEN');
                if (!in_array($old['kind'], ['ROUTER_TEST','DIAGNOSTIC'], true)) requireNetworkWrite();
                $payload = json_decode($old['payload'], true, 512, JSON_THROW_ON_ERROR);
                if (in_array($old['kind'], ['SERVICE_SYNC','DIAGNOSTIC'], true) && is_string($payload['serviceId'] ?? null)) billingLocalRequireNetworkService($payload['serviceId']);
                if ($old['kind'] === 'BULK_SYNC' && is_array($payload['ids'] ?? null)) foreach ($payload['ids'] as $serviceId) {
                    if (!is_string($serviceId)) throw new HttpError(422, 'Identificador de servicio inválido.', 'VALIDATION_ERROR');
                    billingLocalRequireNetworkService($serviceId);
                }
                $task = enqueue($old['kind'], $payload); audit('RETRY_TASK', 'Task', $task['id'], $user['id']); return $task;
            }); json(apiDto('Task', $task), 202);
        }
    }
    return apiEntityDispatch($method, $route);
}

function apiEntityDispatch(string $method, string $route): bool
{
    if (!preg_match('#^/(users|clients|plans|routers|services|tickets)(?:/([A-Za-z0-9_-]{1,128}))?(?:/(suspend|reactivate|sync|diagnostics|test|firewall|comments))?$#D', $route, $match)) return false;
    $resource = $match[1]; $identifier = $match[2] ?? null; $action = $match[3] ?? null;
    $table = ['users' => 'User','clients' => 'Client','plans' => 'Plan','routers' => 'Router','services' => 'Service','tickets' => 'Ticket'][$resource];
    $user = requireAuth();
    if ($resource === 'users') permit('ADMIN');
    if ($resource === 'services' && $identifier === 'bulk' && $method === 'POST' && $action === null) {
        permit('ADMIN','TECHNICIAN'); $input = body();
        if (array_diff(array_keys($input), ['ids','action']) || !isset($input['ids'],$input['action']) || !is_array($input['ids']) || !array_is_list($input['ids']) || count($input['ids']) < 1 || count($input['ids']) > 100 || !in_array($input['action'], ['suspend','reactivate','sync'], true)) throw new HttpError(422, 'Lote inválido');
        foreach ($input['ids'] as $id) if (!is_string($id) || preg_match('/^[A-Za-z0-9_-]{1,128}$/D', $id) !== 1) throw new HttpError(422, 'Identificador de servicio inválido');
        json(['tasks' => array_map(fn(array $row): array => apiDto('Task', $row), apiChangeServices($input['ids'], $input['action'] === 'suspend' ? 'SUSPENDED' : ($input['action'] === 'reactivate' ? 'ACTIVE' : null), $user))], 202);
    }
    if ($method === 'GET' && $action === null) {
        if ($identifier !== null) {
            $row = apiRecord($table, $identifier);
            if ($table === 'Service') financialRequirePresent('Service', $identifier);
            $result = apiDto($table, $row);
            if ($table === 'Client') {
                $rows = fetchAll('SELECT * FROM `Service` s WHERE s.`clientId`=:client AND ' . financialDeletionClause('Service', 's') . ' ORDER BY `createdAt` DESC,`id` DESC', ['client' => $identifier]);
                apiWarmRelations($rows); billingLocalWarm(array_column($rows, 'id')); $result['services'] = array_map(fn(array $service): array => apiDto('Service', $service), $rows);
            }
            json($result);
        }
        $p = pagination(); $where = []; $params = [];
        $searchFields = match ($table) {
            'User' => ['`name`','`email`'], 'Client' => ['`name`','`code`','`document`','`email`','`zone`', "(SELECT GROUP_CONCAT(CONCAT_WS(' ', s.`username`,CONVERT(CONVERT(s.`username` USING latin1) USING utf8mb4),s.`profile`,s.`remoteAddress`,r.`name`) SEPARATOR ' ') FROM `RouterSecretImport` s JOIN `Router` r ON r.`id`=s.`routerId` WHERE s.`clientId`=`Client`.`id`)"], 'Plan' => ['`name`'], 'Router' => ['`name`','`host`'],
            'Service' => ['`ipAddress`','`username`', '(SELECT c.`name` FROM `Client` c WHERE c.`id`=`Service`.`clientId`)'],
            'Ticket' => ['`subject`','(SELECT c.`name` FROM `Client` c WHERE c.`id`=`Ticket`.`clientId`)'],
        };
        apiSearch($searchFields, $p['search'], $where, $params);
        if ($table === 'Client' && ($status = queryEnum('status', ['ACTIVE','SUSPENDED','RETIRED'])) !== null) { $where[] = '`status`=:state'; $params['state'] = $status; }
        if ($table === 'Client' && queryEnum('excludeRetired', ['true','false']) === 'true') $where[] = "`status`<>'RETIRED'";
        if ($table === 'Ticket' && ($status = queryEnum('status', ['OPEN','IN_PROGRESS','RESOLVED','CLOSED'])) !== null) { $where[] = '`status`=:state'; $params['state'] = $status; }
        if ($table === 'Service') {
            $status = queryEnum(array_key_exists('status', $_GET) ? 'status' : 'desiredState', ['ACTIVE','SUSPENDED','RETIRED']);
            if ($status !== null) { $where[] = '`desiredState`=:state'; $params['state'] = $status; }
            foreach (['clientId','routerId'] as $filter) if (isset($_GET[$filter])) {
                if (!is_string($_GET[$filter]) || strlen($_GET[$filter]) > 128) throw new HttpError(422, 'Filtro inválido');
                $where[] = '`' . $filter . '`=:' . $filter; $params[$filter] = $_GET[$filter];
            }
        }
        json(apiList($table, $p, $where, $params, in_array($table, ['Plan','Router'], true) ? '`name` ASC,`id` ASC' : ($table === 'Ticket' ? '`updatedAt` DESC,`id` DESC' : '`createdAt` DESC,`id` DESC')));
    }
    if ($action !== null && $identifier !== null && $method === 'POST') return apiActionDispatch($table, $identifier, $action, $user);
    if ($method === 'POST' && $identifier === null && $action === null) return apiCreateDispatch($table, $user);
    if ($method === 'PATCH' && $identifier !== null && $action === null) return apiPatchDispatch($table, $identifier, $user);
    if ($method === 'DELETE' && $identifier !== null && $action === null) return apiDeleteDispatch($table, $identifier, $user);
    return false;
}

function apiCreateDispatch(string $table, array $user): bool
{
    match ($table) {
        'User','Plan','Router' => permit('ADMIN'),
        'Service' => permit('ADMIN','TECHNICIAN'),
        'Client','Ticket' => permit('ADMIN','BILLING','TECHNICIAN'),
    };
    if ($table === 'Service') requireNetworkWrite();
    $data = validate(strtolower($table), body());
    if ($table === 'User') { $data['passwordHash'] = hashPassword($data['password']); unset($data['password']); }
    if ($table === 'Router') {
        if ($data['transport'] === 'SIMULATED' && !config('allow_simulated_routers', false)) throw new HttpError(422, 'Los routers simulados están deshabilitados');
        $data['port'] ??= $data['transport'] === 'REST' ? ($data['useTls'] ? 443 : 80) : ($data['useTls'] ? 8729 : 8728);
        $data['passwordEncrypted'] = encryptSecret($data['password']); unset($data['password']);
    }
    if ($table === 'Service') {
        if (in_array($data['type'], ['PPPOE','HOTSPOT'], true) && (($data['username'] ?? null) === null || $data['username'] === '' || ($data['password'] ?? null) === null || $data['password'] === '')) throw new HttpError(422, 'PPPoE/Hotspot requieren usuario y contraseña');
        if (in_array($data['type'], ['IP_MAC','HOTSPOT','DHCP'], true) && empty($data['macAddress'])) throw new HttpError(422, 'Este tipo de servicio requiere MAC');
        if (isset($data['password'])) { $data['passwordEncrypted'] = encryptSecret($data['password']); unset($data['password']); }
        $record = apiLocks(['client:' . $data['clientId']], fn(): array => tx(function (\PDO $pdo) use ($data, $user): array {
            $client = apiRecord('Client', $data['clientId'], true); $plan = apiRecord('Plan', $data['planId']); apiRecord('Router', $data['routerId']);
            if ($client['status'] === 'RETIRED' || !$plan['active']) throw new HttpError(409, 'Cliente retirado o plan inactivo');
            $pendingRetirements = (int)fetchOne("SELECT COUNT(*) AS n FROM `Service` s WHERE `clientId`=:client AND `desiredState`='RETIRED' AND (`appliedState` IS NULL OR `appliedState`<>'RETIRED') AND " . financialDeletionClause('Service', 's') . "", ['client' => $client['id']])['n'];
            $liveDesired = (int)fetchOne("SELECT COUNT(*) AS n FROM `Service` WHERE `clientId`=:client AND `desiredState`<>'RETIRED'", ['client' => $client['id']])['n'];
            if ($pendingRetirements && !$liveDesired) throw new HttpError(409, 'El retiro del cliente sigue pendiente de confirmar en el router');
            $service = apiInsert('Service', $data); enqueue('SERVICE_SYNC', ['serviceId' => $service['id']]); audit('CREATE', 'Service', $service['id'], $user['id']); return $service;
        }));
        json(apiDto('Service', $record), 201);
    }
    $record = tx(function (\PDO $pdo) use ($table, $data, $user): array {
        if ($table === 'Ticket') { apiRecord('Client', $data['clientId']); apiValidAssignee($data['assigneeId'] ?? null); }
        $row = apiInsert($table, $data); audit('CREATE', $table, $row['id'], $user['id']); return $row;
    });
    json(apiDto($table, $record), 201);
}

function apiPatchDispatch(string $table, string $identifier, array $user): bool
{
    match ($table) {
        'User','Plan','Router' => permit('ADMIN'),
        'Service' => permit('ADMIN','TECHNICIAN'),
        'Client','Ticket' => permit('ADMIN','BILLING','TECHNICIAN'),
    };
    if ($table === 'Service') { requireNetworkWrite(); billingLocalRequireNetworkService($identifier); }
    $input = body();
    $nameSyncVersion = null;
    if ($table === 'Client') {
        $nameSyncVersion = $input['nameSyncVersion'] ?? null;
        unset($input['nameSyncVersion']);
    }
    $data = validate(strtolower($table), $input, true);
    if ($table === 'Client') json(clientNameSyncPatch($identifier,$data,$user,$nameSyncVersion));
    if ($table === 'User') {
        if (isset($data['password'])) { $data['passwordHash'] = hashPassword($data['password']); unset($data['password']); }
        $record = apiLocks(['admin-users'], fn(): array => tx(function (\PDO $pdo) use ($identifier, $data, $user): array {
            $old = apiRecord('User', $identifier, true);
            if ($old['role'] === 'ADMIN' && $old['active'] && (array_key_exists('active', $data) && !$data['active'] || isset($data['role']) && $data['role'] !== 'ADMIN') && (int)fetchOne("SELECT COUNT(*) AS n FROM `User` WHERE `role`='ADMIN' AND `active`=1")['n'] <= 1) throw new HttpError(409, 'Debe conservar al menos un administrador activo');
            $record = apiUpdate('User', $identifier, $data);
            if (isset($data['passwordHash']) || array_key_exists('active', $data) && !$data['active']) apiExecute('DELETE FROM `Session` WHERE `userId`=:user', ['user' => $identifier]);
            audit('UPDATE', 'User', $identifier, $user['id']); return $record;
        }));
        json(apiDto('User', $record));
    }
    if ($table === 'Router') {
        if (($data['transport'] ?? null) === 'SIMULATED' && !config('allow_simulated_routers', false)) throw new HttpError(422, 'Los routers simulados están deshabilitados');
        if (isset($data['password'])) { $data['passwordEncrypted'] = encryptSecret($data['password']); unset($data['password']); }
        $record = apiLocks(['router:' . $identifier], fn(): array => tx(function (\PDO $pdo) use ($identifier, $data, $user): array {
            $old = apiRecord('Router', $identifier, true);
            $history = (int)fetchOne('SELECT COUNT(*) AS n FROM `Service` WHERE `routerId`=:router', ['router' => $identifier])['n'];
            $snapshots = (int)fetchOne('SELECT COUNT(*) AS n FROM `RouterSecretImport` WHERE `routerId`=:router', ['router' => $identifier])['n'];
            $profiles = (int)fetchOne('SELECT COUNT(*) AS n FROM `RouterProfileImport` WHERE `routerId`=:router', ['router' => $identifier])['n'];
            if ($history || $snapshots || $profiles) foreach (['host','port','transport','cutAddressList'] as $field) if (array_key_exists($field, $data) && (string)$data[$field] !== (string)$old[$field]) throw new HttpError(409, 'Un router con servicios, secrets o perfiles importados conserva su identidad de administración');
            $row = apiUpdate('Router', $identifier, $data); audit('UPDATE', 'Router', $identifier, $user['id']); return $row;
        }));
        json(apiDto('Router', $record));
    }
    if ($table === 'Service') {
        if (isset($data['password'])) { $data['passwordEncrypted'] = encryptSecret($data['password']); unset($data['password']); }
        $initial = apiRecord('Service', $identifier);
        $record = apiLocks(['client:' . $initial['clientId']], fn(): array => tx(function (\PDO $pdo) use ($identifier, $data, $user): array {
            $old = apiRecord('Service', $identifier, true);
            foreach (['routerId','type','ipAddress','username','clientId'] as $field) if (array_key_exists($field, $data) && $data[$field] !== $old[$field]) throw new HttpError(409, $field . ' es inmutable; retire el servicio y cree uno nuevo');
            if ($old['desiredState'] === 'RETIRED') throw new HttpError(409, 'No se puede modificar un servicio retirado');
            if (isset($data['planId']) && !apiRecord('Plan', $data['planId'])['active']) throw new HttpError(409, 'El plan está inactivo');
            if (in_array($old['type'], ['IP_MAC','HOTSPOT','DHCP'], true) && array_key_exists('macAddress', $data) && $data['macAddress'] === null) throw new HttpError(422, 'La MAC es obligatoria para este servicio');
            $record = apiUpdate('Service', $identifier, $data + ['syncStatus' => 'PENDING','revision' => (int)$old['revision'] + 1]);
            enqueue('SERVICE_SYNC', ['serviceId' => $identifier]); audit('UPDATE', 'Service', $identifier, $user['id']); return $record;
        }));
        json(apiDto('Service', $record));
    }
    $save = fn(): array => tx(function (\PDO $pdo) use ($table, $identifier, $data, $user): array {
        $old = apiRecord($table, $identifier, true);
        if ($table === 'Plan') unset($GLOBALS['nexo_profile_import_plan_cache'][$identifier]);
        if ($table === 'Plan') profileImportValidatePlanPatch($old, $data);
        if ($table === 'Ticket') {
            if (isset($data['clientId'])) apiRecord('Client', $data['clientId']);
            if (array_key_exists('assigneeId', $data)) apiValidAssignee($data['assigneeId']);
        }
        $record = apiUpdate($table, $identifier, $data);
        if ($table === 'Plan') profileImportPlanPatched($identifier, $data, $user['id']);
        if ($table === 'Plan' && !networkReadOnly()) foreach (fetchAll("SELECT `id`,`revision` FROM `Service` WHERE `planId`=:plan AND `desiredState`<>'RETIRED' ORDER BY `id` ASC FOR UPDATE", ['plan' => $identifier]) as $service) {
            if (billingLocalIsService($service['id'])) continue;
            billingLocalRequireNetworkService($service['id']);
            apiUpdate('Service', $service['id'], ['syncStatus' => 'PENDING', 'revision' => (int)$service['revision'] + 1]);
            enqueue('SERVICE_SYNC', ['serviceId' => $service['id']]);
        }
        audit('UPDATE', $table, $identifier, $user['id']); return $record;
    });
    $imported = $table === 'Plan' ? profileImportPlanInfo($identifier) : null;
    $record = $imported ? apiLocks(['router:' . $imported['routerId']], $save) : $save();
    json(apiDto($table, $record));
}

function apiDeleteDispatch(string $table, string $identifier, array $user): bool
{
    if ($table === 'Service') { permit('ADMIN','TECHNICIAN'); json(apiDto('Task', apiChangeServices([$identifier], 'RETIRED', $user)[0]), 202); }
    if ($table === 'Router') {
        permit('ADMIN'); apiLocks(['router:' . $identifier], fn() => tx(function (\PDO $pdo) use ($identifier, $user): void {
            apiRecord('Router', $identifier, true);
            if ((int)fetchOne('SELECT COUNT(*) AS n FROM `Service` WHERE `routerId`=:router', ['router' => $identifier])['n']) throw new HttpError(409, 'El router conserva servicios e historial');
            if ((int)fetchOne('SELECT COUNT(*) AS n FROM `RouterSecretImport` WHERE `routerId`=:router', ['router' => $identifier])['n']) throw new HttpError(409, 'El router conserva secrets importados e historial de clientes');
            if ((int)fetchOne('SELECT COUNT(*) AS n FROM `RouterProfileImport` WHERE `routerId`=:router', ['router' => $identifier])['n']) throw new HttpError(409, 'El router conserva perfiles importados e historial de planes');
            apiExecute('DELETE FROM `Router` WHERE `id`=:id', ['id' => $identifier]); audit('DELETE', 'Router', $identifier, $user['id']);
        })); json(null, 204);
    }
    if ($table === 'Plan') {
        permit('ADMIN'); $record = tx(function (\PDO $pdo) use ($identifier, $user): array {
            apiRecord('Plan', $identifier, true); $row = apiUpdate('Plan', $identifier, ['active' => false]); audit('DEACTIVATE', 'Plan', $identifier, $user['id']); return $row;
        }); json(apiDto('Plan', $record));
    }
    if ($table === 'Client') {
        permit('ADMIN','BILLING'); requireNetworkWrite(); $record = apiLocks(['client:' . $identifier], fn(): array => tx(function (\PDO $pdo) use ($identifier, $user): array {
            $client = apiRecord('Client', $identifier, true);
            $services = fetchAll('SELECT * FROM `Service` s WHERE `clientId`=:client AND ' . financialDeletionClause('Service', 's') . ' ORDER BY `id` ASC FOR UPDATE', ['client' => $identifier]);
            foreach ($services as $service) billingLocalRequireNetworkService($service['id']);
            $allRetired = true;
            foreach ($services as $service) {
                if ($service['appliedState'] !== 'RETIRED') $allRetired = false;
                if ($service['desiredState'] === 'RETIRED') continue;
                apiUpdate('Service', $service['id'], ['desiredState' => 'RETIRED', 'suspensionReason' => null, 'syncStatus' => 'PENDING', 'revision' => (int)$service['revision'] + 1]);
                enqueue('SERVICE_SYNC', ['serviceId' => $service['id']]);
            }
            if ($allRetired) $client = apiUpdate('Client', $identifier, ['status' => 'RETIRED']);
            audit('RETIRE', 'Client', $identifier, $user['id']); return $client;
        })); json(apiDto('Client', $record));
    }
    return false;
}

function apiActionDispatch(string $table, string $identifier, string $action, array $user): bool
{
    if ($table === 'Router' && in_array($action, ['test','firewall'], true)) {
        $action === 'firewall' ? permit('ADMIN') : permit('ADMIN','TECHNICIAN');
        if ($action === 'firewall') requireNetworkWrite();
        apiRecord('Router', $identifier);
        $task = tx(function (\PDO $pdo) use ($identifier, $action, $user): array {
            $kind = $action === 'test' ? 'ROUTER_TEST' : 'FIREWALL_SYNC'; $task = enqueue($kind, ['routerId' => $identifier]); audit($kind, 'Router', $identifier, $user['id']); return $task;
        }); json(apiDto('Task', $task), 202);
    }
    if ($table === 'Service' && in_array($action, ['suspend','reactivate','sync'], true)) {
        permit('ADMIN','TECHNICIAN'); $state = $action === 'suspend' ? 'SUSPENDED' : ($action === 'reactivate' ? 'ACTIVE' : null);
        json(apiDto('Task', apiChangeServices([$identifier], $state, $user)[0]), 202);
    }
    if ($table === 'Service' && $action === 'diagnostics') {
        permit('ADMIN','TECHNICIAN'); $service = apiRecord('Service', $identifier);
        billingLocalRequireNetworkService($identifier);
        if ($service['desiredState'] === 'RETIRED') throw new HttpError(409, 'No se puede diagnosticar un servicio retirado');
        $task = tx(function (\PDO $pdo) use ($identifier, $user): array { $task = enqueue('DIAGNOSTIC', ['serviceId' => $identifier]); audit('DIAGNOSTIC', 'Service', $identifier, $user['id']); return $task; }); json(apiDto('Task', $task), 202);
    }
    if ($table === 'Ticket' && $action === 'comments') {
        permit('ADMIN','BILLING','TECHNICIAN'); $data = validate('comment', body());
        $comment = tx(function (\PDO $pdo) use ($identifier, $data, $user): array {
            apiRecord('Ticket', $identifier, true); $row = apiInsert('TicketComment', ['ticketId' => $identifier, 'authorName' => $user['name'], 'body' => $data['body']]);
            apiUpdate('Ticket', $identifier, []); audit('COMMENT', 'Ticket', $identifier, $user['id']); return $row;
        }); json(apiDto('TicketComment', $comment), 201);
    }
    return false;
}
