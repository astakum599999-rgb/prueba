<?php
declare(strict_types=1);
namespace Nexo;

use DateTimeImmutable;
use DateTimeZone;

/** A calendar date in Lima is never parsed as browser-local UTC midnight. */
function clientPaymentCalendarDue(array $service,?array $policy,?string $startOn,string $period): ?string
{
    $zone=new DateTimeZone(POLICY_ZONE);$month=new DateTimeImmutable($period.'-01 00:00:00',$zone);
    $start=$startOn!==null?new DateTimeImmutable($startOn.' 00:00:00',$zone):billingDate($service['createdAt'])->setTimezone($zone);
    if($policy&&$policy['calendarMode']==='FIXED'){
        $due=$month->setDate((int)$month->format('Y'),(int)$month->format('m'),(int)$policy['paymentDay']);
        if($due<$start||($policy['paymentType']==='POSTPAID'&&$due<$start->modify('first day of next month')->setTime(0,0)))return null;
        return $due->format('Y-m-d');
    }
    if($startOn!==null){
        if($month<$start->modify('first day of next month')->setTime(0,0))return null;
        return $month->setDate((int)$month->format('Y'),(int)$month->format('m'),min((int)$start->format('d'),(int)$month->format('t')))->format('Y-m-d');
    }
    $dates=invoiceDates($period,(int)$service['billingDay'],(int)$service['dueDays'],(int)$service['graceDays'],billingDate($service['createdAt']),$month->modify('+2 months'));
    return $dates===null?null:billingDate($dates['dueAt'])->setTimezone($zone)->format('Y-m-d');
}

/** Batch the visible page: one policy, service and invoice query, no router I/O. */
function clientPaymentDatesWarm(array $clientIds,?DateTimeImmutable $at=null): void
{
    $ids=array_values(array_unique($clientIds));if(!$ids)return;$at??=billingNow();$zone=new DateTimeZone(POLICY_ZONE);$today=$at->setTimezone($zone)->format('Y-m-d');
    $slots=implode(',',array_fill(0,count($ids),'?'));$policies=[];$reserved=[];$pending=[];$candidates=[];
    foreach(fetchAll("SELECT * FROM ClientBillingPolicy WHERE clientId IN ($slots)",$ids) as $p)$policies[$p['clientId']]=$p;
    $services=fetchAll("SELECT s.*,l.startOn FROM Service s LEFT JOIN LocalBillingSchedule l ON l.serviceId=s.id WHERE s.clientId IN ($slots) AND s.desiredState<>'RETIRED' AND ".financialDeletionClause('Service','s'),$ids);
    foreach(fetchAll("SELECT i.id,i.clientId,i.serviceId,i.period,i.status,i.dueAt,i.amountCents,i.paidCents,EXISTS(SELECT 1 FROM FinanceDeletion d WHERE d.entityType='Invoice' AND d.entityId=i.id) AS hidden FROM Invoice i WHERE i.clientId IN ($slots)",$ids) as $i){
        $reserved[$i['serviceId']][$i['period']]=true;
        if(!$i['hidden']&&$i['status']==='OPEN'&&(int)$i['amountCents']>(int)$i['paidCents']){
            $date=billingDate($i['dueAt'])->setTimezone($zone)->format('Y-m-d');$id=$i['clientId'];
            if(!isset($pending[$id])||$date<$pending[$id])$pending[$id]=$date;
        }
    }
    foreach($services as $s){
        $policy=$policies[$s['clientId']]??null;$start=$s['startOn'];$cursor=$at->setTimezone($zone)->modify('first day of this month')->setTime(0,0);
        $first=$start!==null?new DateTimeImmutable($start.' 00:00:00',$zone):billingDate($s['createdAt'])->setTimezone($zone);
        $first=$first->modify('first day of this month')->setTime(0,0);if($first>$cursor)$cursor=$first;
        // Include the previous period for legacy calendars whose dueDays cross months.
        $lookback=0;if($start===null&&(!$policy||$policy['calendarMode']!=='FIXED')){$lookback=intdiv((int)$s['dueDays'],28)+2;$cursor=$cursor->modify('-'.$lookback.' months');}
        $limit=count($reserved[$s['id']]??[])+$lookback+15;
        for($n=0;$n<$limit;$n++,$cursor=$cursor->modify('+1 month')){
            $period=$cursor->format('Y-m');if(isset($reserved[$s['id']][$period]))continue;
            $due=clientPaymentCalendarDue($s,$policy,$start,$period);if($due===null||$due<$today)continue;
            $id=$s['clientId'];if(!isset($candidates[$id])||$due<$candidates[$id])$candidates[$id]=$due;break;
        }
    }
    foreach($ids as $id){$date=$pending[$id]??$candidates[$id]??null;$GLOBALS['nexo_payment_dates'][$id]=['paymentDate'=>$date,'paymentDateSource'=>isset($pending[$id])?'UNPAID_INVOICE':($date?'CALENDAR':null),'paymentDateOverdue'=>$date!==null&&$date<$today];}
}
function clientPaymentDate(string $clientId): array
{
    if(!array_key_exists($clientId,$GLOBALS['nexo_payment_dates']??[]))clientPaymentDatesWarm([$clientId]);
    return $GLOBALS['nexo_payment_dates'][$clientId];
}
