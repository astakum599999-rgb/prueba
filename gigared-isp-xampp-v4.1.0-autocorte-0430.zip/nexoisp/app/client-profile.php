<?php
declare(strict_types=1);
namespace Nexo;

use DateTimeImmutable;
use DateTimeZone;
use PDO;

function clientProfileEvent(string $clientId,string $kind,array $details=[],?string $serviceId=null,?string $actorId=null,string $source='SYSTEM',?string $dedupe=null,?string $at=null): void
{
    // Callers supply explicit, password-free projections, never RouterOS responses.
    db()->prepare('INSERT IGNORE INTO ClientActivityEvent(id,clientId,serviceId,actorId,kind,source,detailsJson,dedupeKey,occurredAt) VALUES (?,?,?,?,?,?,?,?,?)')
        ->execute([id(),$clientId,$serviceId,$actorId,$kind,$source,json_encode($details,JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE),$dedupe,$at??now()]);
}

/** Observations only: a failed/stale read never generates a false disconnect. */
function clientProfileObserve(array $router,array $sessions,string $observed): void
{
    $clients=[];foreach(clientIpLiveAccounts([],$router['id']) as $account)$clients[$account['clientId']][bin2hex($account['username'])]=true;
    $previous=[];foreach(fetchAll('SELECT * FROM ClientNetworkObservation WHERE routerId=?',[$router['id']]) as $row)$previous[$row['clientId']]=$row;
    foreach($clients as $clientId=>$names){
        $addresses=[];foreach($sessions as $s)if($s['service']==='pppoe'&&isset($names[$s['usernameHex']]))$addresses[]=$s['address'];
        $addresses=array_values(array_unique($addresses));sort($addresses,SORT_STRING);$connected=$addresses!==[];$json=json_encode($addresses,JSON_THROW_ON_ERROR);
        $old=$previous[$clientId]??null;
        if($old && $old['observedAt']>=$observed)continue;
        if($old&&(bool)$old['connected']===$connected&&$old['addressesJson']===$json)continue;
        if($old && (bool)$old['connected']!==$connected)clientProfileEvent($clientId,$connected?'PPP_CONNECTED':'PPP_DISCONNECTED',['routerId'=>$router['id'],'addresses'=>$addresses],null,null,'OBSERVED',null,$observed);
        elseif($old && $connected && $old['addressesJson']!==$json)clientProfileEvent($clientId,'IP_CHANGED',['routerId'=>$router['id'],'before'=>json_decode($old['addressesJson'],true),'after'=>$addresses],null,null,'OBSERVED',null,$observed);
        db()->prepare('INSERT INTO ClientNetworkObservation(clientId,routerId,connected,addressesJson,observedAt) VALUES (?,?,?,?,?) ON DUPLICATE KEY UPDATE connected=VALUES(connected),addressesJson=VALUES(addressesJson),observedAt=VALUES(observedAt)')->execute([$clientId,$router['id'],(int)$connected,$json,$observed]);
    }
    foreach(array_chunk(array_keys($clients),500) as $ids){$slots=implode(',',array_fill(0,count($ids),'?'));db()->prepare("UPDATE ClientNetworkObservation SET observedAt=? WHERE routerId=? AND observedAt<? AND clientId IN ($slots)")->execute([$observed,$router['id'],$observed,...$ids]);}
}

function clientProfileConnection(string $clientId): array
{
    $accounts=clientIpLiveAccounts([$clientId]);$routers=array_unique(array_column($accounts,'routerId'));$online=false;$known=true;$observed=null;$addresses=[];
    foreach($routers as $routerId){$cache=fetchOne('SELECT * FROM RouterPppActiveCache WHERE routerId=?',[$routerId]);if(!clientIpLiveFresh($cache)){$known=false;continue;}
        $observed=$observed===null?$cache['lastSuccessAt']:min($observed,$cache['lastSuccessAt']);$names=[];foreach($accounts as $a)if($a['routerId']===$routerId)$names[bin2hex($a['username'])]=true;
        foreach(json_decode($cache['sessions'],true,64,JSON_THROW_ON_ERROR) as $s)if($s['service']==='pppoe'&&isset($names[$s['usernameHex']])){$online=true;$addresses[]=$s['address'];}
    }
    return ['status'=>$online?'ONLINE':($routers&&$known?'OFFLINE':'UNKNOWN'),'observedAt'=>$observed,'addresses'=>array_values(array_unique($addresses)),'intervalSeconds'=>1];
}

function clientProfileSummary(string $clientId): array
{
    $client=apiRecord('Client',$clientId);$services=fetchAll('SELECT * FROM Service s WHERE clientId=? AND '.financialDeletionClause('Service','s').' ORDER BY createdAt,id',[$clientId]);
    $balances=fetchAll("SELECT currency,SUM(amountCents-paidCents) AS outstandingCents,COUNT(*) AS unpaid FROM Invoice i WHERE clientId=? AND status='OPEN' AND ".financialDeletionClause('Invoice','i').' GROUP BY currency',[$clientId]);
    foreach($balances as &$balance){$balance['outstandingCents']=(int)$balance['outstandingCents'];$balance['unpaid']=(int)$balance['unpaid'];}unset($balance);
    $p=billingPolicyPublic($clientId);$calendar=[];$at=billingNow();
    foreach($services as $s){if($s['desiredState']==='RETIRED')continue;$full=billingService($s['id']);$next=null;
        $month=$at->setTimezone(new DateTimeZone(POLICY_ZONE))->modify('first day of this month')->setTime(0,0);$periods=[$month->format('Y-m'),$month->modify('+1 month')->format('Y-m'),$month->modify('+2 months')->format('Y-m')];
        foreach($periods as $period){$dates=$p['configured']?billingPolicyCalendarDates($full,$period,$at,true):billingServiceInvoiceDates($full,$period,$at->modify('+3 months'));if($dates&&$dates['dueAt']>=$at->format('Y-m-d H:i:s.v')){$next=$dates+['period'=>$period];break;}}
        if($next)$calendar[]=['serviceId'=>$s['id'],'planName'=>$full['plan']['name']]+$next;
    }
    return ['client'=>apiDto('Client',$client),'connection'=>clientProfileConnection($clientId),'services'=>array_map(static function(array $s):array{$dto=apiDto('Service',$s);$dto['billingNetwork']=fetchOne('SELECT desiredAction,appliedAction,lastError,appliedAt FROM BillingServiceState WHERE serviceId=?',[$s['id']]);return $dto;},$services),'balances'=>$balances,'calendar'=>$calendar,'policy'=>$p,'map'=>provisionSettings(),'automation'=>billingPolicySettings(),'openTickets'=>(int)fetchOne("SELECT COUNT(*) AS n FROM Ticket WHERE clientId=? AND status IN ('OPEN','IN_PROGRESS')",[$clientId])['n']];
}

function clientProfileList(string $clientId,string $kind,array $page): array
{
    apiRecord('Client',$clientId);$where='clientId=?';$params=[$clientId];$dto=null;$order='createdAt DESC,id DESC';
    switch($kind){
        case 'invoices':$table='Invoice';$where.=' AND '.financialDeletionClause('Invoice','Invoice');$dto=static function(array $r):array {$r=invoicePublic($r,true);$r['promiseUntil']=fetchOne("SELECT MAX(promisedUntil) AS untilAt FROM PaymentPromise WHERE invoiceId=? AND status='ACTIVE' AND promisedUntil>? AND currency=? AND amountCents>=?",[$r['id'],now(),$r['currency'],(int)$r['amountCents']-(int)$r['paidCents']])['untilAt'];$r['overdue']=$r['status']==='OPEN'&&billingDate($r['dueAt'])->setTimezone(new DateTimeZone(POLICY_ZONE))->format('Y-m-d')<billingNow()->setTimezone(new DateTimeZone(POLICY_ZONE))->format('Y-m-d');return $r;};break;
        case 'tickets':$table='Ticket';$dto=static fn(array $r):array=>apiDto('Ticket',$r);$order='updatedAt DESC,id DESC';break;
        case 'notices':$table='ClientNotice';break;
        case 'documents':$table='ServiceContract';$dto=static fn(array $r):array=>array_intersect_key($r,array_flip(['id','number','title','status','createdAt']));break;
        case 'payments':
            $from='Payment p JOIN Invoice i ON i.id=p.invoiceId';$clause='i.clientId=? AND '.financialDeletionClause('Payment','p').' AND '.financialDeletionClause('Invoice','i');$count=(int)fetchOne('SELECT COUNT(*) AS n FROM '.$from.' WHERE '.$clause,$params)['n'];
            $rows=fetchAll('SELECT p.*,i.number AS invoiceNumber,i.currency FROM '.$from.' WHERE '.$clause.' ORDER BY p.receivedAt DESC,p.id DESC LIMIT '.$page['pageSize'].' OFFSET '.$page['offset'],$params);return ['results'=>$rows,'count'=>$count,'page'=>$page['page'],'pageSize'=>$page['pageSize']];
        default:throw new HttpError(404,'Pestaña no encontrada.');
    }
    $search=$page['search']??'';
    if($search!==''){$field=match($table){'Invoice'=>'number','Ticket'=>'subject','ClientNotice'=>'subject',default=>'title'};$where.=' AND `'.$field.'` LIKE ?';$params[]='%'.$search.'%';}
    $count=(int)fetchOne('SELECT COUNT(*) AS n FROM '.$table.' WHERE '.$where,$params)['n'];$rows=fetchAll('SELECT * FROM '.$table.' WHERE '.$where.' ORDER BY '.$order.' LIMIT '.$page['pageSize'].' OFFSET '.$page['offset'],$params);
    if($dto)$rows=array_map($dto,$rows);return ['results'=>$rows,'count'=>$count,'page'=>$page['page'],'pageSize'=>$page['pageSize']];
}

function clientProfileLogs(string $clientId,array $p): array
{
    apiRecord('Client',$clientId);$type=$_GET['type']??'ALL';if(!in_array($type,['ALL','CONNECTION','NETWORK','BILLING'],true))throw new HttpError(422,'Filtro de eventos inválido.');
    $from=$_GET['from']??null;$to=$_GET['to']??null;if(is_string($from)&&is_string($to)&&$from>$to)throw new HttpError(422,'Rango de fechas invertido.');$where='e.clientId=?';$params=[$clientId];
    if(($p['search']??'')!==''){$where.=' AND (e.kind LIKE ? OR e.detailsJson LIKE ?)';$params[]='%'.$p['search'].'%';$params[]='%'.$p['search'].'%';}
    foreach(['from'=>[$from,'>='],'to'=>[$to,'<=']] as [$value,$op])if($value!==null){$day=billingCalculationDate($value,'fecha')->format('Y-m-d');$where.=' AND e.occurredAt '.$op.' ?';$params[]=(new DateTimeImmutable($day.($op==='<='?' 23:59:59.999':' 00:00:00'),new DateTimeZone(POLICY_ZONE)))->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s.v');}
    if($type==='CONNECTION')$where.=" AND e.source='OBSERVED'";if($type==='NETWORK')$where.=" AND (e.source='NETWORK' OR e.kind LIKE 'client.ppp.%')";if($type==='BILLING')$where.=" AND (e.source='BILLING' OR e.kind LIKE 'invoice.%' OR e.kind LIKE 'payment.%')";
    $union="SELECT id,clientId,serviceId,actorId,kind,source,detailsJson,occurredAt FROM ClientActivityEvent UNION ALL SELECT a.id,CASE WHEN a.entityType='Client' THEN a.entityId WHEN a.entityType='Service' THEN s.clientId WHEN a.entityType='Invoice' THEN i.clientId WHEN a.entityType='Ticket' THEN t.clientId WHEN a.entityType='Payment' THEN pi.clientId WHEN a.entityType='PaymentPromise' THEN pri.clientId END AS clientId,CASE WHEN a.entityType='Service' THEN a.entityId ELSE NULL END AS serviceId,a.userId AS actorId,a.action AS kind,'AUDIT' AS source,'{}' AS detailsJson,a.createdAt AS occurredAt FROM AuditLog a LEFT JOIN Service s ON a.entityType='Service' AND s.id=a.entityId LEFT JOIN Invoice i ON a.entityType='Invoice' AND i.id=a.entityId LEFT JOIN Ticket t ON a.entityType='Ticket' AND t.id=a.entityId LEFT JOIN Payment pay ON a.entityType='Payment' AND pay.id=a.entityId LEFT JOIN Invoice pi ON pi.id=pay.invoiceId LEFT JOIN PaymentPromise pr ON a.entityType='PaymentPromise' AND pr.id=a.entityId LEFT JOIN Invoice pri ON pri.id=pr.invoiceId";
    $count=(int)fetchOne('SELECT COUNT(*) AS n FROM ('.$union.') e WHERE '.$where,$params)['n'];$rows=fetchAll('SELECT e.*,u.name AS operatorName FROM ('.$union.') e LEFT JOIN User u ON u.id=e.actorId WHERE '.$where.' ORDER BY e.occurredAt DESC,e.id DESC LIMIT '.$p['pageSize'].' OFFSET '.$p['offset'],$params);
    foreach($rows as &$r){$r['details']=json_decode($r['detailsJson'],true,64,JSON_THROW_ON_ERROR);unset($r['detailsJson']);}unset($r);return ['results'=>$rows,'count'=>$count,'page'=>$p['page'],'pageSize'=>$p['pageSize']];
}

function clientProfileStatistics(string $clientId,array $p): array
{
    apiRecord('Client',$clientId);$serviceId=$_GET['serviceId']??null;$sourceId=$_GET['sourceSecretId']??null;
    if($serviceId!==null&&$serviceId!==''){provisionIdentifier($serviceId);if(!fetchOne('SELECT id FROM Service WHERE id=? AND clientId=?',[$serviceId,$clientId]))throw new HttpError(404,'Servicio ajeno al cliente.');}
    if($sourceId!==null){provisionIdentifier($sourceId);if(!fetchOne('SELECT id FROM RouterSecretImport WHERE id=? AND clientId=?',[$sourceId,$clientId]))throw new HttpError(404,'Cuenta ajena al cliente.');}
    $start=isset($_GET['from'])?operationsDate($_GET['from']):gmdate('Y-m-d H:i:s',time()-86400);$end=isset($_GET['to'])?operationsDate($_GET['to']):now();if($start>$end)throw new HttpError(422,'Rango de fechas invertido.');$start=max($start,gmdate('Y-m-d H:i:s',time()-30*86400));
    $fields='t.id,t.serviceId,t.sampledAt,t.uploadBps,t.downloadBps,t.uploadBytes,t.downloadBytes,t.averageMs,t.lossPercent';$queries=[];$params=[];
    if($sourceId===null){$old='SELECT '.$fields.',NULL AS sourceSecretId FROM TrafficSample t JOIN Service s ON s.id=t.serviceId WHERE s.clientId=? AND t.sampledAt BETWEEN ? AND ?';$params=[$clientId,$start,$end];if($serviceId){$old.=' AND t.serviceId=?';$params[]=$serviceId;}$queries[]=$old;}
    $fresh='SELECT '.$fields.',t.sourceSecretId FROM ClientTelemetrySample t WHERE t.clientId=? AND t.sampledAt BETWEEN ? AND ?';$params=[...$params,$clientId,$start,$end];if($serviceId){$fresh.=' AND t.serviceId=?';$params[]=$serviceId;}if($sourceId){$fresh.=' AND t.sourceSecretId=?';$params[]=$sourceId;}$queries[]=$fresh;
    $from='('.implode(' UNION ALL ',$queries).') t';$count=(int)fetchOne('SELECT COUNT(*) AS n FROM '.$from,$params)['n'];$rows=fetchAll('SELECT t.* FROM '.$from.' ORDER BY sampledAt DESC,id DESC LIMIT '.$p['pageSize'].' OFFSET '.$p['offset'],$params);
    $hours=(strtotime($end.' UTC')-strtotime($start.' UTC'))/3600;$bucket=$hours>48?"DATE_FORMAT(sampledAt,'%Y-%m-%d %H:00:00')":"CONCAT(DATE_FORMAT(sampledAt,'%Y-%m-%d %H:'),LPAD(FLOOR(MINUTE(sampledAt)/15)*15,2,'0'),':00')";
    $series=fetchAll('SELECT MIN(id) AS id,'.$bucket.' AS sampledAt,AVG(uploadBps) AS uploadBps,AVG(downloadBps) AS downloadBps,AVG(averageMs) AS averageMs,AVG(lossPercent) AS lossPercent,COUNT(*) AS samples FROM '.$from.' GROUP BY '.$bucket.' ORDER BY sampledAt LIMIT 1000',$params);
    $window='SELECT uploadBytes,downloadBytes,LAG(uploadBytes) OVER (PARTITION BY serviceId,sourceSecretId ORDER BY sampledAt,id) AS prevUp,LAG(downloadBytes) OVER (PARTITION BY serviceId,sourceSecretId ORDER BY sampledAt,id) AS prevDown FROM '.$from;
    $usage=fetchOne('SELECT COUNT(uploadBytes) AS upN,COUNT(downloadBytes) AS downN,SUM(CASE WHEN prevUp IS NULL OR uploadBytes IS NULL THEN 0 WHEN uploadBytes>=prevUp THEN uploadBytes-prevUp ELSE uploadBytes END) AS upBytes,SUM(CASE WHEN prevDown IS NULL OR downloadBytes IS NULL THEN 0 WHEN downloadBytes>=prevDown THEN downloadBytes-prevDown ELSE downloadBytes END) AS downBytes FROM ('.$window.') u',$params);
    return ['results'=>$rows,'series'=>$series,'usage'=>['uploadBytes'=>(int)$usage['upN']>1?$usage['upBytes']:null,'downloadBytes'=>(int)$usage['downN']>1?$usage['downBytes']:null],'count'=>$count,'page'=>$p['page'],'pageSize'=>$p['pageSize'],'connection'=>clientProfileConnection($clientId),'coverage'=>'SAMPLES','message'=>'Consumo observado entre muestras; se consideran reinicios de contador. No equivale a una captura continua NetFlow.'];
}

function clientProfileInvoicePdf(string $clientId,string $invoiceId): never
{
    $i=fetchOne('SELECT * FROM Invoice WHERE id=? AND clientId=?',[$invoiceId,$clientId])??throw new HttpError(404,'Factura no encontrada.');financialRequirePresent('Invoice',$invoiceId);
    $client=apiRecord('Client',$clientId);$company=fetchOne("SELECT * FROM CompanyProfile WHERE id='primary'")??['name'=>'GIGARED ISP'];$lines=fetchAll('SELECT * FROM InvoiceLine WHERE invoiceId=? ORDER BY position,id',[$invoiceId]);
    $text=[$company['name']??'GIGARED ISP','FACTURA '.$i['number'],'Cliente: '.$client['name'],'Documento: '.($client['document']??''),'Dirección: '.($client['address']??''),'Periodo: '.$i['period'],'Emisión: '.date('d/m/Y',strtotime($i['issuedAt'].' UTC')),'Vencimiento: '.date('d/m/Y',strtotime($i['dueAt'].' UTC')),'Estado: '.$i['status'],''];
    foreach($lines as $line)$text[]=$line['description'].' | '.$line['quantity'].' x '.number_format((int)$line['unitCents']/100,2).' = '.number_format((int)$line['totalCents']/100,2).' '.$i['currency'];
    $text[]='';$text[]='Total: '.number_format((int)$i['amountCents']/100,2).' '.$i['currency'];$text[]='Pagado: '.number_format((int)$i['paidCents']/100,2).' '.$i['currency'];$text[]='Pendiente: '.number_format(((int)$i['amountCents']-(int)$i['paidCents'])/100,2).' '.$i['currency'];
    $wrapped=[];foreach($text as $line){if($line===''){$wrapped[]='';continue;}preg_match_all('/.{1,88}/us',$line,$parts);foreach($parts[0] as $part)$wrapped[]=$part;}
    $objects=[1=>'',2=>'',3=>'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>'];$pages=[];
    foreach(array_chunk($wrapped,48) as $chunk){$page=count($objects)+1;$content=$page+1;$pages[]=$page;$stream="BT /F1 11 Tf 45 790 Td 15 TL\n";
        foreach($chunk as $line){$encoded=function_exists('iconv')?iconv('UTF-8','Windows-1252//TRANSLIT',$line):preg_replace('/[^\x20-\x7E]/','?',$line);$encoded=str_replace(['\\','(',')',"\r","\n"],['\\\\','\\(','\\)','',''],(string)$encoded);$stream.='('.$encoded.") Tj T*\n";}$stream.='ET';
        $objects[$page]='<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 3 0 R >> >> /Contents '.$content.' 0 R >>';$objects[$content]='<< /Length '.strlen($stream).">>\nstream\n".$stream."\nendstream";
    }
    $objects[1]='<< /Type /Catalog /Pages 2 0 R >>';$objects[2]='<< /Type /Pages /Kids ['.implode(' ',array_map(static fn(int $n):string=>$n.' 0 R',$pages)).'] /Count '.count($pages).' >>';ksort($objects);
    $pdf="%PDF-1.4\n";$offset=[0];foreach($objects as $id=>$object){$offset[$id]=strlen($pdf);$pdf.=$id." 0 obj\n".$object."\nendobj\n";}$xref=strlen($pdf);$pdf.='xref'."\n0 ".(count($objects)+1)."\n0000000000 65535 f \n";foreach($objects as $id=>$object)$pdf.=sprintf('%010d 00000 n ',$offset[$id])."\n";$pdf.='trailer << /Size '.(count($objects)+1).' /Root 1 0 R >>'."\nstartxref\n".$xref."\n%%EOF";
    header('Content-Type: application/pdf');header('Content-Disposition: attachment; filename="factura-'.preg_replace('/[^A-Za-z0-9_-]/','',$i['number']).'.pdf"');header('Content-Length: '.strlen($pdf));echo $pdf;exit;
}

function clientProfileDispatch(string $method,string $route): bool
{
    if(preg_match('#^/clients/([a-f0-9]{24})/profile(?:/(summary|invoices|payments|tickets|documents|notices|statistics|logs|billing-policy|diagnose|sample|plan-change))?$#D',$route,$m)){
        $actor=requireAuth();$clientId=$m[1];$section=$m[2]??'summary';apiRecord('Client',$clientId);
        if($method==='GET'){
            if($section==='summary')json(clientProfileSummary($clientId));
            if(in_array($section,['invoices','payments','tickets','documents','notices'],true))json(clientProfileList($clientId,$section,pagination()));
            if($section==='logs')json(clientProfileLogs($clientId,pagination()));if($section==='statistics')json(clientProfileStatistics($clientId,pagination()));if($section==='billing-policy')json(['policy'=>billingPolicyPublic($clientId),'settings'=>billingPolicySettings()]);
        }
        if($method==='PATCH'&&$section==='billing-policy'){permit('ADMIN','BILLING');json(billingPolicySave($clientId,body(),$actor));}
        if($method==='POST'&&$section==='sample'){permit('ADMIN','TECHNICIAN');json(clientProfileSample($clientId,body()));}
        if($method==='POST'&&$section==='diagnose'){permit('ADMIN','TECHNICIAN');$data=body();if(array_diff(array_keys($data),['serviceId']))throw new HttpError(422,'Parámetros no admitidos.');$serviceId=provisionIdentifier($data['serviceId']??null);$s=apiRecord('Service',$serviceId);if($s['clientId']!==$clientId)throw new HttpError(404,'Servicio ajeno al cliente.');billingLocalRequireNetworkService($serviceId);if($s['desiredState']==='RETIRED')throw new HttpError(409,'El servicio está retirado.');json(enqueue('DIAGNOSTIC',['serviceId'=>$serviceId,'requestedBy'=>$actor['id']]),202);}
        if($method==='POST'&&$section==='plan-change'){permit('ADMIN','TECHNICIAN');json(billingNetworkPlanRequest($clientId,body(),$actor),202);}
        if($method==='POST'&&$section==='notices'){permit('ADMIN','BILLING');$data=body();if(array_diff(array_keys($data),['channel','subject','body','requestKey']))throw new HttpError(422,'Parámetros no admitidos.');if(!in_array($data['channel']??null,['PORTAL','EMAIL','SMS','TELEGRAM'],true))throw new HttpError(422,'Canal inválido.');$subject=portalText($data['subject']??null,'asunto',180);$message=portalText($data['body']??null,'mensaje',4000);$key=$data['requestKey']??'';if(!is_string($key)||!preg_match('/^[a-f0-9-]{36}$/iD',$key))throw new HttpError(422,'Identificador de mensaje inválido.');json(billingPolicyNotice($clientId,null,'MANUAL',$data['channel'],$subject,$message,'manual:'.$clientId.':'.$key),201);}
    }
    if($method==='GET'&&preg_match('#^/clients/([a-f0-9]{24})/profile/invoices/([a-f0-9]{24})/pdf$#D',$route,$m)){requireAuth();clientProfileInvoicePdf($m[1],$m[2]);}
    return billingPolicySettingsDispatch($method,$route);
}
