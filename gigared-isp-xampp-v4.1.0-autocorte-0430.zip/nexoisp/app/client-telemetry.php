<?php
declare(strict_types=1);
namespace Nexo;

use Throwable;

function clientTelemetryNumber(mixed $value): ?float
{
    return (is_int($value)||is_float($value)||(is_string($value)&&preg_match('/^[0-9]+(?:\.[0-9]+)?$/D',$value)))&&is_finite((float)$value)&&(float)$value>=0?(float)$value:null;
}
function clientTelemetryDuration(mixed $value): ?float
{
    if(!is_string($value))return null;if(preg_match('/^([0-9.]+)(us|ms|s)$/D',$value,$m))return (float)$m[1]*match($m[2]){'us'=>0.001,'s'=>1000,default=>1};return null;
}
function clientProfileSample(string $clientId,array $input): array
{
    if(array_diff(array_keys($input),['serviceId','sourceSecretId']))throw new HttpError(422,'Parámetros de medición no admitidos.');
    $source=null;$service=null;$routerId=null;$username=null;
    if(isset($input['sourceSecretId'])){$source=fetchOne('SELECT * FROM RouterSecretImport WHERE id=? AND clientId=? AND present=1',[provisionIdentifier($input['sourceSecretId']),$clientId]);if(!$source||clientPppArchived($source['id'])!==null)throw new HttpError(404,'Cuenta no disponible.');$routerId=$source['routerId'];$username=$source['username'];}
    elseif(isset($input['serviceId'])){$service=fetchOne("SELECT * FROM Service WHERE id=? AND clientId=? AND desiredState<>'RETIRED' AND (appliedState IS NULL OR appliedState<>'RETIRED')",[provisionIdentifier($input['serviceId']),$clientId]);if(!$service||!$service['routerId']||billingLocalIsService($service['id']))throw new HttpError(422,'Selecciona una cuenta PPPoE o servicio de red.');$routerId=$service['routerId'];if($service['type']==='PPPOE')$username=$service['username'];}
    else throw new HttpError(422,'Selecciona una cuenta o servicio.');
    $client=apiRecord('Client',$clientId);if($client['status']==='RETIRED')throw new HttpError(409,'No se mide un cliente retirado.');
    return billingWithLocks(['client:'.$clientId,'router:'.$routerId],function()use($clientId,$source,$service,$routerId,$username):array {
        $last=fetchOne('SELECT * FROM ClientTelemetrySample WHERE clientId=? AND sourceSecretId<=>? AND serviceId<=>? ORDER BY sampledAt DESC,id DESC LIMIT 1',[$clientId,$source['id']??null,$service['id']??null]);
        if($last&&strtotime($last['sampledAt'].' UTC')>time()-2)return ['sample'=>$last,'cached'=>true];
        $router=fetchOne('SELECT * FROM Router WHERE id=?',[$routerId])??throw new HttpError(404,'Router no encontrado.');$transport=secretImportTransport($router);
        try{
            $ip=$service['ipAddress']??null;
            if($username!==null){
                if($source){$secret=$transport->print('/ppp/secret',['.id'=>$source['remoteId']],['.proplist'=>'.id,name,service']);if(count($secret)!==1||($secret[0]['name']??null)!==$username)throw new HttpError(409,'La identidad PPPoE cambió; sincroniza antes de medir.');}
                $active=provisionRows($transport,'/ppp/active','.id,name,service,address',true);$matched=array_values(array_filter($active,static fn(array $r):bool=>$r['name']===$username&&($r['service']??'')==='pppoe'));
                if(!$matched)return ['sample'=>null,'status'=>'OFFLINE','message'=>'No hay una sesión PPPoE activa observada.'];$ip=$matched[0]['address'];
            }
            $ip=clientIpAddress($ip);if($ip===null)throw new HttpError(422,'No hay una IP concreta para diagnosticar.');$data=['uploadBps'=>null,'downloadBps'=>null,'uploadBytes'=>null,'downloadBytes'=>null,'averageMs'=>null,'lossPercent'=>null];
            foreach(provisionRows($transport,'/queue/simple','.id,target,rate,bytes') as $queue)if(($queue['target']??'')===$ip.'/32'){
                $rates=explode('/',(string)($queue['rate']??''));$bytes=explode('/',(string)($queue['bytes']??''));$data['uploadBps']=clientTelemetryNumber($rates[0]??null);$data['downloadBps']=clientTelemetryNumber($rates[1]??null);$data['uploadBytes']=clientTelemetryNumber($bytes[0]??null);$data['downloadBytes']=clientTelemetryNumber($bytes[1]??null);break;
            }
            if($username!==null&&$data['downloadBps']===null){foreach(provisionRows($transport,'/interface','.id,name,type,running,rx-byte,tx-byte') as $interface)if(($interface['name']??'')==='<pppoe-'.$username.'>'&&($interface['type']??'')==='pppoe-in'){
                $samples=$transport->execute('/interface/monitor-traffic',['interface'=>$interface['.id'],'once'=>'']);$sample=$samples[0]??[];$data['uploadBps']=clientTelemetryNumber($sample['rx-bits-per-second']??null);$data['downloadBps']=clientTelemetryNumber($sample['tx-bits-per-second']??null);$data['uploadBytes']=clientTelemetryNumber($interface['rx-byte']??null);$data['downloadBytes']=clientTelemetryNumber($interface['tx-byte']??null);break;
            }}
            try{$packets=$transport->execute('/ping',['address'=>$ip,'count'=>'3','interval'=>'200ms']);$durations=[];$sent=count($packets);$received=0;
                foreach($packets as $packet){$duration=clientTelemetryDuration($packet['time']??null);if($duration!==null)$durations[]=$duration;if(isset($packet['sent'])){$sent=(int)$packet['sent'];$received=(int)($packet['received']??0);}elseif($duration!==null)$received++;}
                if($durations)$data['averageMs']=array_sum($durations)/count($durations);if($sent>0)$data['lossPercent']=max(0,min(100,100*($sent-$received)/$sent));
            }catch(RouterError){/* Unavailable ping is not a fabricated zero. */}
            if(count(array_filter($data,static fn(mixed $v):bool=>$v!==null))===0)return ['sample'=>null,'status'=>'NO_MEASUREMENTS','message'=>'El router no devolvió contadores ni respuestas de diagnóstico.'];
            $row=['id'=>id(),'clientId'=>$clientId,'routerId'=>$routerId,'sourceSecretId'=>$source['id']??null,'serviceId'=>$service['id']??null,'sampledAt'=>now()]+$data;$keys=array_keys($row);db()->prepare('INSERT INTO ClientTelemetrySample(`'.implode('`,`',$keys).'`) VALUES ('.implode(',',array_fill(0,count($keys),'?')).')')->execute(array_values($row));db()->exec('DELETE FROM ClientTelemetrySample WHERE sampledAt<UTC_TIMESTAMP(3)-INTERVAL 30 DAY LIMIT 2000');return ['sample'=>$row,'cached'=>false,'address'=>$ip];
        }finally{$transport->close();}
    });
}
