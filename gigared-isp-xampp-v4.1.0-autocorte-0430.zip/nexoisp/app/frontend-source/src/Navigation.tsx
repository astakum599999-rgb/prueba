import { useState } from 'react';
import { ChevronDown } from 'lucide-react';
import { pageMeta } from './pages';
import type { PageName } from './types';

const groups: { title: string; pages: PageName[] }[] = [
  { title: 'Resumen de la operación', pages: ['dashboard'] },
  { title: 'Clientes y contratos', pages: ['clients', 'services', 'portal-accounts', 'contracts'] },
  { title: 'Facturación y cobranza', pages: ['invoices', 'payments', 'payment-reports', 'payment-promises', 'service-charges', 'service-discounts', 'billing-settings'] },
  { title: 'Caja y reportes', pages: ['cash-accounts', 'cash-movements', 'reports'] },
  { title: 'Red e inventario', pages: ['plans', 'routers', 'inventory-assets', 'inventory-movements'] },
  { title: 'Red FTTH', pages: ['fiber'] },
  { title: 'Soporte y agenda', pages: ['tickets', 'installations', 'tasks'] },
  { title: 'Administración', pages: ['users', 'audit', 'keys', 'company-settings'] },
];

export default function Navigation({ visiblePages, page, go, extended }: { visiblePages: PageName[]; page: PageName; go: (name: PageName) => void; extended: boolean }) {
  const [collapsed, setCollapsed] = useState<string[]>([]);
  const navItem = (name: PageName) => {
    const Icon = pageMeta[name].icon;
    return <button key={name} className={`nav-item ${page === name ? 'active' : ''}`} aria-current={page === name ? 'page' : undefined} onClick={() => go(name)}><Icon size={18} className="nav-icon" /><span>{name === 'dashboard' ? 'Resumen general' : pageMeta[name].title}</span>{page === name && <span className="nav-dot" aria-hidden="true" />}</button>;
  };
  return <nav aria-label="Menú principal">{extended ? groups.map((group, index) => {
    const items = group.pages.filter(name => visiblePages.includes(name));
    if (!items.length) return null;
    const closed = collapsed.includes(group.title);
    return <section className="nav-group" key={group.title}><button className="nav-group-heading" aria-expanded={!closed} aria-controls={`nav-group-${index}`} onClick={() => setCollapsed(old => closed ? old.filter(name => name !== group.title) : [...old, group.title])}><span>{group.title}</span><ChevronDown size={13} style={{ transform: closed ? 'rotate(-90deg)' : undefined }} /></button><div id={`nav-group-${index}`} hidden={closed}>{items.map(navItem)}</div></section>;
  }) : visiblePages.map(navItem)}</nav>;
}
