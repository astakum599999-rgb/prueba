<?php
declare(strict_types=1);

namespace Nexo;

use PDO;
use PDOException;

// The user's local currency preference is an explicitly authorized DML addition.
// This literal does not relabel amounts, invoices, plans, payments or cash records.
const MIGRATION_PEN_COMPANY_PREFERENCE_SQL = "INSERT INTO CompanyProfile (id,currency) VALUES ('primary','PEN') ON DUPLICATE KEY UPDATE currency='PEN'";

// Authorized, idempotent nullability change: no existing value or key is removed.
const MIGRATION_LOCAL_BILLING_SERVICE_SQL = 'ALTER TABLE `Service` MODIFY COLUMN `routerId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NULL, MODIFY COLUMN `type` VARCHAR(20) NULL, MODIFY COLUMN `ipAddress` VARCHAR(45) CHARACTER SET ascii COLLATE ascii_bin NULL';

// Explicitly requested billing-only activation and Peru 04:30 schedule.
const MIGRATION_BILLING_GRANT_SQL = "INSERT INTO BillingNetworkGrant (id,enabled) VALUES ('primary',1) ON DUPLICATE KEY UPDATE enabled=1";
const MIGRATION_AUTOCUT_0430_SQL = "INSERT INTO BillingAutomationSetting (id,enabled,cutHour) VALUES ('primary',1,'04:30') ON DUPLICATE KEY UPDATE enabled=1,cutHour='04:30'";

/** Read immutable SQL bytes before comparing the database's installed prefix. */
function migrationFiles(): array
{
    $initial = APP_ROOT . '/database/schema.sql';
    $directory = APP_ROOT . '/database/migrations';
    if (!is_file($initial) || is_link($initial) || !is_dir($directory) || is_link($directory)) {
        throw new HttpError(503, 'Faltan archivos de migración. Extrae de nuevo el paquete completo sin reemplazar storage/config.php.', 'MIGRATION_FILES_MISSING');
    }
    $files = [['name' => '001_initial', 'path' => $initial, 'number' => 1]];
    $entries = scandir($directory);
    if ($entries === false) {
        throw new HttpError(503, 'No se puede leer la carpeta de migraciones.', 'MIGRATION_FILES_MISSING');
    }
    foreach ($entries as $entry) {
        if ($entry === '.' || $entry === '..' || !str_ends_with(strtolower($entry), '.sql')) {
            continue;
        }
        if (!preg_match('/^(\d{3})_[A-Za-z0-9_-]+\.sql$/D', $entry, $match) || is_link($directory . '/' . $entry) || !is_file($directory . '/' . $entry)) {
            throw new HttpError(503, 'Hay un archivo de migración no admitido. Usa la distribución completa original.', 'MIGRATION_FILES_INVALID');
        }
        $files[] = ['name' => substr($entry, 0, -4), 'path' => $directory . '/' . $entry, 'number' => (int) $match[1]];
    }
    usort($files, static fn(array $left, array $right): int => $left['number'] <=> $right['number']);
    foreach ($files as $index => &$file) {
        if ($file['number'] !== $index + 1) {
            throw new HttpError(503, 'La secuencia de migraciones está incompleta o contiene versiones duplicadas.', 'MIGRATION_FILES_INVALID');
        }
        $sql = file_get_contents($file['path']);
        if ($sql === false || trim($sql) === '' || strlen($sql) > 4194304) {
            throw new HttpError(503, 'Una migración está vacía, no se puede leer o excede el límite admitido.', 'MIGRATION_FILES_INVALID');
        }
        $file['sql'] = $sql;
        $file['checksum'] = hash('sha256', $sql);
    }
    unset($file);
    return $files;
}

function migrationInstalled(PDO $pdo): array
{
    $check = $pdo->query("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name='_nexoisp_migrations'");
    if ((int) $check->fetchColumn() === 0) {
        $existing = $pdo->query("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name IN ('User','Client','Service')");
        if ((int) $existing->fetchColumn() !== 0) {
            throw new HttpError(409, 'La base existente no tiene historial de migraciones. Restaura su historial original antes de actualizar.', 'MIGRATION_HISTORY_INVALID');
        }
        return [];
    }
    return $pdo->query('SELECT `name`,`checksum` FROM `_nexoisp_migrations` ORDER BY `name` ASC')->fetchAll(PDO::FETCH_ASSOC);
}

function migrationCheckPrefix(array $files, array $installed): void
{
    if (count($installed) > count($files)) {
        throw new HttpError(409, 'La base contiene versiones que no están en este paquete. No se permite volver a una versión anterior.', 'MIGRATION_HISTORY_INVALID');
    }
    foreach ($installed as $index => $record) {
        $expected = $files[$index] ?? null;
        if ($expected === null || $record['name'] !== $expected['name']) {
            throw new HttpError(409, 'El historial no es un prefijo de esta distribución. Faltan versiones o hay migraciones desconocidas.', 'MIGRATION_HISTORY_INVALID');
        }
        if (!is_string($record['checksum']) || !hash_equals($expected['checksum'], $record['checksum'])) {
            throw new HttpError(409, 'El checksum SHA-256 de una migración aplicada cambió. Restaura su archivo SQL original; no edites el historial.', 'MIGRATION_CHECKSUM_MISMATCH');
        }
    }
}

function migrationStatus(?PDO $pdo = null): array
{
    $pdo ??= db();
    $files = migrationFiles();
    $installed = migrationInstalled($pdo);
    migrationCheckPrefix($files, $installed);
    $applied = array_column($installed, 'name');
    $pending = array_column(array_slice($files, count($installed)), 'name');
    $versions = [];
    foreach ($files as $index => $file) {
        $versions[] = ['name' => $file['name'], 'status' => $index < count($installed) ? 'APPLIED' : 'PENDING'];
    }
    return [
        'currentVersion' => $applied === [] ? null : $applied[count($applied) - 1],
        'targetVersion' => $files[count($files) - 1]['name'],
        'needsUpgrade' => $pending !== [], 'applied' => $applied, 'pending' => $pending,
        'verified' => $applied, 'versions' => $versions,
    ];
}

function migrationNeedsUpgrade(?PDO $pdo = null): bool
{
    return migrationStatus($pdo)['needsUpgrade'];
}

/** Split SQL on statement terminators, preserving quoted text and ignoring comments. */
function migrationStatements(string $sql): array
{
    $statements = [];
    $buffer = '';
    $quote = null;
    $lineComment = false;
    $blockComment = false;
    $length = strlen($sql);
    for ($index = 0; $index < $length; $index++) {
        $char = $sql[$index];
        $next = $index + 1 < $length ? $sql[$index + 1] : '';
        if ($lineComment) {
            if ($char === "\n" || $char === "\r") {
                $lineComment = false;
                $buffer .= ' ';
            }
            continue;
        }
        if ($blockComment) {
            if ($char === '*' && $next === '/') {
                $blockComment = false;
                $buffer .= ' ';
                $index++;
            }
            continue;
        }
        if ($quote !== null) {
            $buffer .= $char;
            if ($char === '\\' && $next !== '') {
                $buffer .= $next;
                $index++;
            } elseif ($char === $quote) {
                if ($next === $quote) {
                    $buffer .= $next;
                    $index++;
                } else {
                    $quote = null;
                }
            }
            continue;
        }
        if ($char === '-' && $next === '-' && ($index + 2 >= $length || ctype_space($sql[$index + 2]))) {
            $lineComment = true;
            $index++;
        } elseif ($char === '#') {
            $lineComment = true;
        } elseif ($char === '/' && $next === '*') {
            $blockComment = true;
            $index++;
        } elseif ($char === "'" || $char === '"' || $char === '`') {
            $quote = $char;
            $buffer .= $char;
        } elseif ($char === ';') {
            if (trim($buffer) !== '') {
                $statements[] = trim($buffer);
            }
            $buffer = '';
        } else {
            $buffer .= $char;
        }
    }
    if ($quote !== null || $blockComment) {
        throw new HttpError(503, 'Una migración contiene comillas o comentarios SQL sin cerrar.', 'MIGRATION_FILES_INVALID');
    }
    if (trim($buffer) !== '') {
        $statements[] = trim($buffer);
    }
    if ($statements === []) {
        throw new HttpError(503, 'Una migración no contiene sentencias SQL.', 'MIGRATION_FILES_INVALID');
    }
    foreach ($statements as $statement) {
        $createTable = preg_match('/^CREATE\s+TABLE\s+IF\s+NOT\s+EXISTS\s+/i', $statement) === 1;
        $invoiceBackfill = preg_match('/^INSERT\s+IGNORE\s+INTO\s+`?InvoiceLine`?(?:\s|\()/i', $statement) === 1;
        $companyPenPreference = preg_replace('/\s+/', ' ', trim($statement)) === MIGRATION_PEN_COMPANY_PREFERENCE_SQL;
        $localBillingNullability = preg_replace('/\s+/', ' ', trim($statement)) === MIGRATION_LOCAL_BILLING_SERVICE_SQL;
        if (!$createTable && !$invoiceBackfill && !$companyPenPreference && !$localBillingNullability && !in_array(preg_replace('/\s+/', ' ', trim($statement)),[MIGRATION_BILLING_GRANT_SQL,MIGRATION_AUTOCUT_0430_SQL],true)) {
            throw new HttpError(503, 'La migración contiene una sentencia no admitida. Sólo se permiten tablas aditivas y las sentencias literales autorizadas de facturación local, InvoiceLine y PEN.', 'MIGRATION_FILES_INVALID');
        }
    }
    return $statements;
}

function migrationApply(?PDO $pdo = null): array
{
    $pdo ??= db();
    $database = (string) $pdo->query('SELECT DATABASE()')->fetchColumn();
    if ($database === '') {
        throw new HttpError(503, 'Selecciona la base de datos antes de aplicar migraciones.', 'DATABASE_UNAVAILABLE');
    }
    if ($pdo->inTransaction()) {
        throw new HttpError(409, 'Las migraciones DDL deben ejecutarse fuera de una transacción de negocio.', 'MIGRATION_TRANSACTION_ACTIVE');
    }
    $lockName = 'nexo-schema:' . substr(hash('sha256', $database), 0, 52);
    $statement = $pdo->prepare('SELECT GET_LOCK(?,30)');
    $statement->execute([$lockName]);
    if ((int) $statement->fetchColumn() !== 1) {
        throw new HttpError(409, 'Otra actualización del esquema está en curso. Espera y vuelve a consultar.', 'MIGRATION_BUSY');
    }
    try {
        $files = migrationFiles();
        $installed = migrationInstalled($pdo);
        migrationCheckPrefix($files, $installed);
        $verified = array_column($installed, 'name');
        $pending = array_slice($files, count($installed));
        foreach ($pending as &$file) {
            $file['statements'] = migrationStatements($file['sql']);
        }
        unset($file);
        $pdo->exec('CREATE TABLE IF NOT EXISTS `_nexoisp_migrations` (`name` VARCHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL PRIMARY KEY, `checksum` CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL, `appliedAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3)) ENGINE=InnoDB');
        $applied = [];
        foreach ($pending as $file) {
            try {
                // MariaDB commits DDL implicitly. Record only a completed file;
                // interrupted additive statements can safely be rerun on retry.
                foreach ($file['statements'] as $sql) {
                    $pdo->exec($sql);
                }
                $record = $pdo->prepare('INSERT INTO `_nexoisp_migrations` (`name`,`checksum`) VALUES (?,?)');
                $record->execute([$file['name'], $file['checksum']]);
            } catch (PDOException) {
                throw new HttpError(503, 'No se completó la migración ' . $file['name'] . '. Las tablas creadas se conservan; corrige permisos o conectividad y reintenta con el mismo SQL.', 'MIGRATION_FAILED');
            }
            $applied[] = $file['name'];
        }
        return ['applied' => $applied, 'verified' => $verified];
    } finally {
        try {
            $release = $pdo->prepare('SELECT RELEASE_LOCK(?)');
            $release->execute([$lockName]);
        } catch (PDOException) {
            // Closing a lost MariaDB connection also releases its server lock.
        }
    }
}
