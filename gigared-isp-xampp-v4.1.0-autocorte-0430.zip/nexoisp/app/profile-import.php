<?php
declare(strict_types=1);
namespace Nexo;

use PDO;

require_once __DIR__ . '/secret-import.php';

const PROFILE_IMPORT_PROPERTIES = '.id,name,rate-limit,local-address,remote-address,comment';
const PROFILE_IMPORT_LIMIT = 20000;

function profileImportInvalid(string $field, int $row = 1): never
{
    if (!in_array($field, ['.id','name','rate-limit','local-address','remote-address','comment','lista','registro'], true)) $field = 'registro';
    throw new HttpError(502, 'El router devolvió un perfil PPP no admitido en el campo ' . $field . ', fila ' . max(1, $row) . '; no se importó ningún perfil.', 'INVALID_ROUTER_RESPONSE');
}

function profileImportText(mixed $value, int $maximum, string $field, int $row, bool $multiline = false): string
{
    if (!is_string($value) || strlen($value) > $maximum * 4) profileImportInvalid($field, $row);
    $count = preg_match('//u', $value) === 1 ? preg_match_all('/./us', $value) : strlen($value);
    if ($count === false || $count > $maximum) profileImportInvalid($field, $row);
    $text = secretImportDisplayText($value, $multiline);
    if (strlen($text) > $maximum * 4 || preg_match_all('/./us', $text) > $maximum) profileImportInvalid($field, $row);
    return $text;
}

/** Return exact whole kbit/s; RouterOS unqualified numbers are bit/s. */
function profileImportRate(string $value): array
{
    if (!preg_match('/^([0-9]{1,12})(?:\.([0-9]{1,6}))?([kmg]?)$/iD', $value, $match)) return [null, 'UNSUPPORTED_RATE'];
    $fraction = $match[2] ?? '';
    $digits = ltrim($match[1] . $fraction, '0');
    if ($digits === '') return [null, 'UNLIMITED'];
    if (PHP_INT_SIZE < 8) return [null, 'UNSUPPORTED_RATE'];
    $numerator = (int)$digits;
    $denominator = 10 ** strlen($fraction);
    $multiplier = match (strtolower($match[3] ?? '')) { 'k'=>1000, 'm'=>1000000, 'g'=>1000000000, default=>1 };
    // Check before multiplying; every subsequent product fits a signed int64.
    if ($numerator > intdiv(10000000000 * $denominator, $multiplier)) return [null, 'UNSUPPORTED_RATE'];
    $scaled = $numerator * $multiplier;
    $divisor = $denominator * 1000;
    if ($scaled % $divisor !== 0) return [null, 'UNSUPPORTED_RATE'];
    $kbps = intdiv($scaled, $divisor);
    return $kbps >= 1 && $kbps <= 10000000 ? [$kbps, 'READY'] : [null, 'UNSUPPORTED_RATE'];
}

/** Only base RX/TX rates are copied; burst settings remain visible as source text. */
function profileImportParseRateLimit(string $value): array
{
    $empty = ['downloadKbps'=>null,'uploadKbps'=>null,'rateStatus'=>'NO_RATE','reason'=>'El perfil no declara una velocidad base en rate-limit.'];
    $value = trim($value);
    if ($value === '') return $empty;
    $tokens = preg_split('/\s+/u', $value);
    $invalid = ['downloadKbps'=>null,'uploadKbps'=>null,'rateStatus'=>'UNSUPPORTED_RATE','reason'=>'El formato de velocidad base del perfil está incompleto o no es compatible.'];
    if ($tokens === false || $tokens === []) return $invalid;
    $parts = explode('/', $tokens[0]);
    if (count($parts) > 2 || in_array('', $parts, true)) return $invalid;
    [$upload, $rxStatus] = profileImportRate($parts[0]);
    [$download, $txStatus] = profileImportRate($parts[1] ?? $parts[0]);
    $status = $rxStatus === 'UNSUPPORTED_RATE' || $txStatus === 'UNSUPPORTED_RATE' ? 'UNSUPPORTED_RATE' : ($rxStatus === 'UNLIMITED' || $txStatus === 'UNLIMITED' ? 'UNLIMITED' : 'READY');
    return [
        'downloadKbps'=>$download,'uploadKbps'=>$upload,'rateStatus'=>$status,
        'reason'=>match ($status) {
            'READY'=>'Velocidad base leída: RX es subida del cliente y TX es bajada. Los valores de ráfaga no se aplican.',
            'UNLIMITED'=>'Al menos una dirección no tiene límite; no se inventa una velocidad comercial.',
            default=>'La velocidad base no se puede representar exactamente en kbit/s enteros dentro del rango admitido.',
        },
    ];
}

function profileImportNormalize(array $rows, ?string $cutProfile = null): array
{
    if (!array_is_list($rows) || count($rows) > PROFILE_IMPORT_LIMIT) profileImportInvalid('lista');
    $result = []; $names = []; $remoteIds = [];
    foreach ($rows as $index => $row) {
        $position = $index + 1;
        if (!is_array($row) || array_is_list($row)) profileImportInvalid('registro', $position);
        foreach (['.id','name'] as $field) if (!array_key_exists($field, $row)) profileImportInvalid($field, $position);
        $remoteId = $row['.id'];
        if (!is_string($remoteId) || $remoteId === '' || strlen($remoteId) > 512 || preg_match('//u', $remoteId) !== 1 || preg_match('/[\x00-\x1F\x7F]/', $remoteId) || preg_match_all('/./us', $remoteId) > 128) profileImportInvalid('.id', $position);
        $name = $row['name'];
        if (!is_string($name) || $name === '' || strlen($name) > 1020) profileImportInvalid('name', $position);
        $length = preg_match('//u', $name) === 1 ? preg_match_all('/./us', $name) : strlen($name);
        if ($length === false || $length > 255) profileImportInvalid('name', $position);
        $key = bin2hex($name); $remoteKey = bin2hex($remoteId);
        if (isset($names[$key])) profileImportInvalid('name', $position);
        if (isset($remoteIds[$remoteKey])) profileImportInvalid('.id', $position);
        $names[$key] = true; $remoteIds[$remoteKey] = true;
        $displayName = secretImportDisplayText($name);
        $rateLimit = profileImportText($row['rate-limit'] ?? '', 2000, 'rate-limit', $position, true);
        $rate = profileImportParseRateLimit($rateLimit);
        if ($rate['rateStatus'] === 'READY' && ($name !== $displayName || preg_match_all('/./us', $name) > 200 || trim($name) === '')) {
            $rate['rateStatus'] = 'NAME_REVIEW';
            $rate['reason'] = 'El nombre original no cabe exactamente en el campo del perfil del plan; se conserva el perfil observado para revisión.';
        }
        if ($cutProfile !== null && $name === $cutProfile) {
            $rate['rateStatus'] = 'CUT_PROFILE';
            $rate['reason'] = 'Perfil reservado para suspensión. Se conserva como observación y no se convierte en un plan comercial.';
        }
        if(preg_match('/^gg-(?:cut|limited|warning)-([a-f0-9]{16})$/D',$name,$managed)&&($row['comment']??'')==='gigared:billing:profile:'.$managed[1]){
            $rate['rateStatus']='CUT_PROFILE';$rate['reason']='Perfil técnico de corte o reducción de GIGARED. Se observa sin crear un plan comercial.';
        }
        $entry = [
            'remoteId'=>$remoteId,'profileName'=>$name,'displayName'=>$displayName,'rateLimit'=>$rateLimit,
            ...$rate,
            'localAddress'=>profileImportText($row['local-address'] ?? '',255,'local-address',$position),
            'remoteAddress'=>profileImportText($row['remote-address'] ?? '',255,'remote-address',$position),
            'comment'=>profileImportText($row['comment'] ?? '',16000,'comment',$position,true),
        ];
        $fingerprint = $entry; $fingerprint['profileName'] = bin2hex($name);
        $entry['snapshotHash'] = hash('sha256', json_encode($fingerprint,JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
        $result[] = $entry;
    }
    return $result;
}

function profileImportRead(RouterTransport $transport, ?string $cutProfile = null): array
{
    try { return profileImportNormalize($transport->print('/ppp/profile',[],['.proplist'=>PROFILE_IMPORT_PROPERTIES]), $cutProfile); }
    finally { $transport->close(); }
}

function profileImportTruncate(string $text, int $limit): string
{
    preg_match_all('/./us',$text,$characters);
    return implode('',array_slice($characters[0],0,$limit));
}

function profileImportCreatePlan(array $router, array $entry): string
{
    $name = profileImportTruncate($entry['displayName'].' · '.$router['name'],200);
    if (fetchOne('SELECT id FROM `Plan` WHERE name=?',[$name])) {
        $name = profileImportTruncate($entry['displayName'].' · '.$router['name'],170).' · '.substr(hash('sha256',$router['id']."\0".$entry['profileName']),0,24);
        if (fetchOne('SELECT id FROM `Plan` WHERE name=?',[$name])) throw new HttpError(409,'Un plan local ya utiliza el nombre reservado para este perfil. No se fusionaron sus datos.','PROFILE_PLAN_CONFLICT');
    }
    $currency = localCurrency();
    $identifier = id();
    db()->prepare('INSERT INTO `Plan` (id,name,downloadKbps,uploadKbps,queueParent,priority,pppoeProfile,priceCents,currency,active) VALUES (?,?,?,?,?,?,?,?,?,0)')
        ->execute([$identifier,$name,$entry['downloadKbps'],$entry['uploadKbps'],'global',8,$entry['profileName'],0,$currency]);
    return $identifier;
}

function profileImportRun(string $routerId, ?string $actorId, ?RouterTransport $transport = null, bool $automatic = false, bool $alreadyLocked = false): array
{
    if (!preg_match('/^[a-f0-9]{24}$/D',$routerId)) throw new HttpError(422,'Identificador de router inválido.','VALIDATION_ERROR');
    $lock = 'router:'.$routerId;
    if (!$alreadyLocked && !lock($lock,10)) throw new HttpError(409,'El router está ocupado. Intenta la lectura de nuevo.','RESOURCE_BUSY');
    try {
        $router = fetchOne('SELECT * FROM `Router` WHERE id=?',[$routerId]) ?? throw new HttpError(404,'Router no encontrado.','NOT_FOUND');
        $rows = profileImportRead($transport ?? secretImportTransport($router), (string)($router['cutProfile'] ?? 'Perfil_Corte'));
        return tx(function(PDO $pdo) use($router,$rows,$actorId,$automatic): array {
            $previous = fetchAll('SELECT * FROM `RouterProfileImport` WHERE routerId=? FOR UPDATE',[$router['id']]);
            $existing=[]; foreach($previous as $old) $existing[bin2hex($old['profileName'])]=$old;
            $summary=['router'=>['id'=>$router['id'],'name'=>$router['name']],'total'=>count($rows),'created'=>0,'updated'=>0,'unchanged'=>0,'missing'=>0,'absencesChanged'=>0,'plansCreated'=>0,'plansUpdated'=>0,'pending'=>0,'networkReadOnly'=>true];
            $timestamp=now();
            foreach($rows as $entry) {
                $identity=bin2hex($entry['profileName']);$old=$existing[$identity]??null;unset($existing[$identity]);
                $planId=$old['planId']??null;$createdPlan=false;
                if($planId===null&&$entry['rateStatus']==='READY') {
                    $planId=profileImportCreatePlan($router,$entry);$summary['plansCreated']++;$createdPlan=true;
                } elseif($planId!==null) {
                    $plan=fetchOne('SELECT * FROM `Plan` WHERE id=? FOR UPDATE',[$planId]);
                    if($plan===null) throw new HttpError(409,'Falta el plan asociado al perfil.','PROFILE_PLAN_CONFLICT');
                    if($entry['rateStatus']==='READY') {
                        if((int)$plan['downloadKbps']!==$entry['downloadKbps']||(int)$plan['uploadKbps']!==$entry['uploadKbps']) {
                            $pdo->prepare('UPDATE `Plan` SET downloadKbps=?,uploadKbps=?,updatedAt=? WHERE id=?')->execute([$entry['downloadKbps'],$entry['uploadKbps'],$timestamp,$planId]);$summary['plansUpdated']++;
                        }
                    } elseif((bool)$plan['active']) {
                        $pdo->prepare('UPDATE `Plan` SET active=0,updatedAt=? WHERE id=?')->execute([$timestamp,$planId]);$summary['plansUpdated']++;
                    }
                }
                if($old===null) {
                    $pdo->prepare('INSERT INTO `RouterProfileImport` (id,routerId,remoteId,profileName,displayName,rateLimit,downloadKbps,uploadKbps,rateStatus,reason,localAddress,remoteAddress,comment,present,planId,priceConfigured,snapshotHash,firstSeenAt,lastSeenAt) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,1,?,0,?,?,?)')
                        ->execute([id(),$router['id'],$entry['remoteId'],$entry['profileName'],$entry['displayName'],$entry['rateLimit'],$entry['downloadKbps'],$entry['uploadKbps'],$entry['rateStatus'],$entry['reason'],$entry['localAddress'],$entry['remoteAddress'],$entry['comment'],$planId,$entry['snapshotHash'],$timestamp,$timestamp]);
                    $summary['created']++;
                } else {
                    $changed=$old['snapshotHash']!==$entry['snapshotHash']||!(bool)$old['present']||$createdPlan;
                    if ($changed) $pdo->prepare('UPDATE `RouterProfileImport` SET remoteId=?,displayName=?,rateLimit=?,downloadKbps=?,uploadKbps=?,rateStatus=?,reason=?,localAddress=?,remoteAddress=?,comment=?,present=1,planId=?,snapshotHash=?,lastSeenAt=? WHERE id=?')
                        ->execute([$entry['remoteId'],$entry['displayName'],$entry['rateLimit'],$entry['downloadKbps'],$entry['uploadKbps'],$entry['rateStatus'],$entry['reason'],$entry['localAddress'],$entry['remoteAddress'],$entry['comment'],$planId,$entry['snapshotHash'],$timestamp,$old['id']]);
                    $summary[$changed?'updated':'unchanged']++;
                }
                if($entry['rateStatus']!=='READY'||!(bool)($old['priceConfigured']??false)) $summary['pending']++;
            }
            foreach($existing as $old) {
                $summary['missing']++;
                if((bool)$old['present']) {
                    $pdo->prepare('UPDATE `RouterProfileImport` SET present=0 WHERE id=?')->execute([$old['id']]);$summary['absencesChanged']++;
                    if($old['planId']!==null) $pdo->prepare('UPDATE `Plan` SET active=0,updatedAt=? WHERE id=? AND active=1')->execute([$timestamp,$old['planId']]);
                }
            }
            $pdo->prepare('UPDATE `RouterProfileImport` SET lastSeenAt=? WHERE routerId=? AND present=1')->execute([$timestamp,$router['id']]);
            if (!$automatic || $summary['created'] || $summary['updated'] || $summary['absencesChanged'] || $summary['plansCreated'] || $summary['plansUpdated']) audit($automatic ? 'router.profiles.auto-sync' : 'router.profiles.import','Router',$router['id'],$actorId);
            unset($GLOBALS['nexo_profile_import_plan_cache']);
            return $summary;
        });
    } finally { if (!$alreadyLocked) unlock($lock); }
}

function profileImportPublic(array $row): array
{
    $present=(bool)$row['present'];$price=(bool)$row['priceConfigured'];
    $status=!$present?'ABSENT':($row['rateStatus']!=='READY'?'RATE_PENDING':(!$price?'PRICE_PENDING':'READY'));
    $reason=!$present?'El perfil no se observó en la última lectura completa; se conserva su historial.':($status==='PRICE_PENDING'?'RouterOS no contiene una tarifa comercial. Completa el precio y la moneda localmente.':$row['reason']);
    return [
        'id'=>$row['id'],'routerId'=>$row['routerId'],'routerName'=>$row['routerName'],
        'profileName'=>$row['displayName'],'rateLimit'=>$row['rateLimit'],
        'downloadKbps'=>$row['downloadKbps']===null?null:(int)$row['downloadKbps'],
        'uploadKbps'=>$row['uploadKbps']===null?null:(int)$row['uploadKbps'],
        'rateStatus'=>$row['rateStatus'],'status'=>$status,'reason'=>$reason,
        'localAddress'=>$row['localAddress'],'remoteAddress'=>$row['remoteAddress'],'comment'=>$row['comment'],
        'planId'=>$row['planId'],'priceConfigured'=>$price,'present'=>$present,
        'firstSeenAt'=>$row['firstSeenAt'],'lastSeenAt'=>$row['lastSeenAt'],'networkReadOnly'=>true,
    ];
}

function profileImportPlanInfo(string $planId): ?array
{
    if(array_key_exists($planId,$GLOBALS['nexo_profile_import_plan_cache']??[])) return $GLOBALS['nexo_profile_import_plan_cache'][$planId];
    $row=fetchOne('SELECT p.*,r.name AS routerName FROM `RouterProfileImport` p JOIN `Router` r ON r.id=p.routerId WHERE p.planId=?',[$planId]);
    return $GLOBALS['nexo_profile_import_plan_cache'][$planId]=$row===null?null:profileImportPublic($row);
}

function profileImportExplicitPrice(array $data): bool
{
    return array_key_exists('priceCents',$data)&&array_key_exists('currency',$data)&&is_int($data['priceCents'])&&$data['priceCents']>=0&&$data['priceCents']<=100000000&&is_string($data['currency'])&&preg_match('/^[A-Z]{3}$/D',$data['currency'])===1;
}

/** Called while holding the router lock, before changing the local Plan. */
function profileImportValidatePlanPatch(array $old,array $data): void
{
    unset($GLOBALS['nexo_profile_import_plan_cache'][$old['id']]);
    $info=profileImportPlanInfo($old['id']);if($info===null)return;
    foreach(['downloadKbps','uploadKbps'] as $field) {
        if(array_key_exists($field,$data)&&(int)$data[$field]!==$info[$field]) throw new HttpError(409,'La velocidad del plan importado proviene del perfil. Actualiza su observación o crea un plan local independiente.','PROFILE_RATE_PENDING');
    }
    if(array_key_exists('pppoeProfile',$data)&&$data['pppoeProfile']!==$old['pppoeProfile']) throw new HttpError(409,'El perfil de origen de un plan importado no se puede sustituir.','PROFILE_PLAN_CONFLICT');
    $willBeActive=array_key_exists('active',$data)?(bool)$data['active']:(bool)$old['active'];
    if($willBeActive&&$info['rateStatus']==='CUT_PROFILE') throw new HttpError(409,'El perfil está reservado para suspensión y no es un plan comercial.','PROFILE_RATE_PENDING');
    if($willBeActive&&(!$info['present']||$info['rateStatus']!=='READY')) throw new HttpError(409,'El perfil está ausente o necesita una velocidad válida antes de activar el plan.','PROFILE_RATE_PENDING');
    if($willBeActive&&!$info['priceConfigured']&&!profileImportExplicitPrice($data)) throw new HttpError(409,'Completa el precio y la moneda del plan antes de activarlo.','PROFILE_PRICE_PENDING');
}

function profileImportPlanPatched(string $planId,array $data,string $actorId): void
{
    if(!profileImportExplicitPrice($data))return;
    unset($GLOBALS['nexo_profile_import_plan_cache'][$planId]);
    $info=profileImportPlanInfo($planId);if($info===null)return;
    db()->prepare('UPDATE `RouterProfileImport` SET priceConfigured=1 WHERE planId=?')->execute([$planId]);
    audit('router.profile.price-configured','Plan',$planId,$actorId);
    unset($GLOBALS['nexo_profile_import_plan_cache'][$planId]);
}

function profileImportAssertBillable(string $planId): void
{
    unset($GLOBALS['nexo_profile_import_plan_cache'][$planId]);
    $info=profileImportPlanInfo($planId);if($info===null)return;
    if($info['rateStatus']==='CUT_PROFILE') throw new HttpError(409,'El perfil está reservado para suspensión y no se puede facturar como plan comercial.','PROFILE_RATE_PENDING');
    if(!$info['present']||$info['rateStatus']!=='READY') throw new HttpError(409,'El perfil del plan requiere revisión de velocidad antes de facturar.','PROFILE_RATE_PENDING');
    if(!$info['priceConfigured']) throw new HttpError(409,'El perfil no contiene una tarifa comercial. Completa el precio y la moneda del plan antes de facturar.','PROFILE_PRICE_PENDING');
}

function profileImportDispatch(string $method,string $route): bool
{
    if($method==='POST'&&preg_match('#^/routers/([a-f0-9]{24})/import-profiles$#D',$route,$match)) {
        $actor=permit('ADMIN','TECHNICIAN');
        if(body()!==[])throw new HttpError(422,'La importación no admite cambios de configuración.','VALIDATION_ERROR');
        try {json(profileImportRun($match[1],$actor['id']));}
        catch(RouterError $error){throw new HttpError(502,'No se pudo completar la lectura de perfiles PPP. Comprueba conectividad, API y permisos de lectura.',$error->routerCode);}
    }
    if($method==='GET'&&$route==='/router-profiles') {
        requireAuth();$p=pagination();$where=[];$params=[];
        if($p['search']!=='') {
            $where[]='(p.displayName LIKE ? OR r.name LIKE ? OR p.rateLimit LIKE ?)';
            foreach(range(1,3) as $_)$params[]='%'.$p['search'].'%';
        }
        if(isset($_GET['routerId'])) {
            if(!is_string($_GET['routerId'])||!preg_match('/^[a-f0-9]{24}$/D',$_GET['routerId']))throw new HttpError(422,'Filtro de router inválido.','VALIDATION_ERROR');
            $where[]='p.routerId=?';$params[]=$_GET['routerId'];
        }
        $from=' FROM `RouterProfileImport` p JOIN `Router` r ON r.id=p.routerId'.($where?' WHERE '.implode(' AND ',$where):'');
        $count=(int)fetchOne('SELECT COUNT(*) AS n'.$from,$params)['n'];
        $rows=fetchAll('SELECT p.*,r.name AS routerName'.$from.' ORDER BY r.name,p.displayName,p.id LIMIT '.$p['pageSize'].' OFFSET '.$p['offset'],$params);
        json(['results'=>array_map(__NAMESPACE__.'\\profileImportPublic',$rows),'count'=>$count,'page'=>$p['page'],'pageSize'=>$p['pageSize']]);
    }
    return false;
}
