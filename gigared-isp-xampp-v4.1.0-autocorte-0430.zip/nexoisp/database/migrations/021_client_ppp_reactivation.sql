-- Explicit staff actions only; no worker or billing job can initiate these operations.
CREATE TABLE IF NOT EXISTS `ClientPppActivation` (
  `id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `clientId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `actorId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `requestKey` CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `suspensionId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `action` VARCHAR(10) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `status` VARCHAR(16) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'PREPARED',
  `planJson` MEDIUMTEXT NOT NULL,
  `lastError` VARCHAR(500) NULL,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `activeClientId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin GENERATED ALWAYS AS (CASE WHEN `status`<>'CONFIRMED' THEN `clientId` ELSE NULL END) STORED,
  PRIMARY KEY (`id`),
  KEY `client_ppp_activation_origin_idx` (`suspensionId`),
  UNIQUE KEY `client_ppp_activation_request_unique` (`requestKey`),
  UNIQUE KEY `client_ppp_activation_pending_unique` (`activeClientId`),
  KEY `client_ppp_activation_history_idx` (`clientId`,`createdAt`),
  CONSTRAINT `client_ppp_activation_client_fk` FOREIGN KEY (`clientId`) REFERENCES `Client` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `client_ppp_activation_actor_fk` FOREIGN KEY (`actorId`) REFERENCES `User` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `client_ppp_activation_origin_fk` FOREIGN KEY (`suspensionId`) REFERENCES `ClientPppAction` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `client_ppp_activation_action_check` CHECK (`action`='REACTIVATE'),
  CONSTRAINT `client_ppp_activation_status_check` CHECK (`status` IN ('PREPARED','RUNNING','UNCERTAIN','CONFIRMED'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

