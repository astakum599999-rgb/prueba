-- Additive profile, billing policy and observed network history. Existing accounts are unchanged.
CREATE TABLE IF NOT EXISTS `ClientBillingPolicy` (
 `clientId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 `calendarMode` VARCHAR(12) NOT NULL DEFAULT 'INHERIT',
 `paymentType` VARCHAR(12) NOT NULL DEFAULT 'POSTPAID',
 `paymentDay` TINYINT UNSIGNED NOT NULL DEFAULT 1,
 `invoiceLeadDays` TINYINT UNSIGNED NOT NULL DEFAULT 2,
 `generateEnabled` TINYINT UNSIGNED NOT NULL DEFAULT 1,
 `graceDays` TINYINT UNSIGNED NOT NULL DEFAULT 3,
 `cutAfterInvoices` TINYINT UNSIGNED NOT NULL DEFAULT 0,
 `reduceEnabled` TINYINT UNSIGNED NOT NULL DEFAULT 0,
 `reducedDownloadKbps` INT UNSIGNED NOT NULL DEFAULT 0,
 `reducedUploadKbps` INT UNSIGNED NOT NULL DEFAULT 0,
 `lateFeeMode` VARCHAR(12) NOT NULL DEFAULT 'NONE',
 `lateFeeValue` INT UNSIGNED NOT NULL DEFAULT 0,
 `reconnectionFeeCents` INT UNSIGNED NOT NULL DEFAULT 0,
 `noticeLeadDays` TINYINT UNSIGNED NOT NULL DEFAULT 0,
 `taxMode` VARCHAR(12) NOT NULL DEFAULT 'INCLUDED',
 `tax1Bps` SMALLINT UNSIGNED NOT NULL DEFAULT 0,
 `tax2Bps` SMALLINT UNSIGNED NOT NULL DEFAULT 0,
 `tax3Bps` SMALLINT UNSIGNED NOT NULL DEFAULT 0,
 `reminder1Days` SMALLINT NULL DEFAULT -2,
 `reminder2Days` SMALLINT NULL,
 `reminder3Days` SMALLINT NULL,
 `channelsJson` TEXT NOT NULL,
 `fixedInvoiceOn` DATE NULL,
 `fixedCutOn` DATETIME(3) NULL,
 `fixedCutUsedAt` DATETIME(3) NULL,
 `networkServiceId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NULL,
 `networkSecretId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NULL,
 `networkBindingJson` TEXT NULL,
 `revision` INT UNSIGNED NOT NULL DEFAULT 1,
 `updatedAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
 PRIMARY KEY (`clientId`),
 CONSTRAINT `client_policy_client_fk` FOREIGN KEY (`clientId`) REFERENCES `Client` (`id`) ON DELETE RESTRICT,
 CONSTRAINT `client_policy_network_service_fk` FOREIGN KEY (`networkServiceId`) REFERENCES `Service` (`id`) ON DELETE RESTRICT,
 CONSTRAINT `client_policy_network_secret_fk` FOREIGN KEY (`networkSecretId`) REFERENCES `RouterSecretImport` (`id`) ON DELETE RESTRICT,
 CONSTRAINT `client_policy_calendar_check` CHECK (`calendarMode` IN ('INHERIT','FIXED') AND `paymentType` IN ('PREPAID','POSTPAID')),
 CONSTRAINT `client_policy_days_check` CHECK (`paymentDay` BETWEEN 1 AND 28 AND `invoiceLeadDays`<=25 AND `graceDays`<=90 AND `noticeLeadDays`<=25 AND `cutAfterInvoices`<=12),
 CONSTRAINT `client_policy_boolean_check` CHECK (`generateEnabled` IN (0,1) AND `reduceEnabled` IN (0,1)),
 CONSTRAINT `client_policy_fee_check` CHECK (`lateFeeMode` IN ('NONE','FIXED','PERCENT') AND `lateFeeValue`<=2147483647 AND `reconnectionFeeCents`<=2147483647),
 CONSTRAINT `client_policy_tax_check` CHECK (`taxMode` IN ('INCLUDED','ADD','NONE') AND `tax1Bps`<=10000 AND `tax2Bps`<=10000 AND `tax3Bps`<=10000),
 CONSTRAINT `client_policy_reminder_check` CHECK ((`reminder1Days` IS NULL OR `reminder1Days` BETWEEN -25 AND 25) AND (`reminder2Days` IS NULL OR `reminder2Days` BETWEEN -25 AND 25) AND (`reminder3Days` IS NULL OR `reminder3Days` BETWEEN -25 AND 25))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `BillingAutomationSetting` (
 `id` VARCHAR(20) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 `enabled` TINYINT UNSIGNED NOT NULL DEFAULT 0,
 `invoiceHour` CHAR(5) NOT NULL DEFAULT '03:30',
 `cutHour` CHAR(5) NOT NULL DEFAULT '02:30',
 `noticeHour` CHAR(5) NOT NULL DEFAULT '04:30',
 `lateFeeHour` CHAR(5) NOT NULL DEFAULT '00:00',
 `reminder1Hour` CHAR(5) NOT NULL DEFAULT '08:30',
 `reminder2Hour` CHAR(5) NOT NULL DEFAULT '13:30',
 `reminder3Hour` CHAR(5) NOT NULL DEFAULT '17:00',
 `gatewayUrl` VARCHAR(1024) NULL,
 `gatewaySecretEncrypted` TEXT NULL,
 `nextRunAt` DATETIME(3) NULL,
 `lastRunAt` DATETIME(3) NULL,
 `lastSummary` TEXT NULL,
 `updatedAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
 PRIMARY KEY (`id`),
 CONSTRAINT `billing_automation_id_check` CHECK (`id`='primary' AND `enabled` IN (0,1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `BillingRouterPolicy` (
 `routerId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 `warningList` VARCHAR(63) NOT NULL DEFAULT 'AVISO_MOROSO',
 `cutList` VARCHAR(63) NOT NULL DEFAULT 'MOROSOS',
 `portalIp` VARCHAR(45) CHARACTER SET ascii COLLATE ascii_bin NULL,
 `portalPort` SMALLINT UNSIGNED NOT NULL DEFAULT 80,
 `preparedHash` CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NULL,
 `preparedAt` DATETIME(3) NULL,
 `updatedAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
 PRIMARY KEY (`routerId`),
 CONSTRAINT `billing_router_policy_fk` FOREIGN KEY (`routerId`) REFERENCES `Router` (`id`) ON DELETE RESTRICT,
 CONSTRAINT `billing_router_policy_port_check` CHECK (`portalPort` BETWEEN 1 AND 65535 AND `warningList`<>`cutList`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `BillingServiceState` (
 `serviceId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 `desiredAction` VARCHAR(12) NOT NULL DEFAULT 'ACTIVE',
 `appliedAction` VARCHAR(12) NULL,
 `revision` INT UNSIGNED NOT NULL DEFAULT 1,
 `appliedIp` VARCHAR(45) CHARACTER SET ascii COLLATE ascii_bin NULL,
 `originalJson` MEDIUMTEXT NULL,
 `lastError` VARCHAR(500) NULL,
 `appliedAt` DATETIME(3) NULL,
 `updatedAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
 PRIMARY KEY (`serviceId`),
 CONSTRAINT `billing_state_service_fk` FOREIGN KEY (`serviceId`) REFERENCES `Service` (`id`) ON DELETE RESTRICT,
 CONSTRAINT `billing_state_desired_check` CHECK (`desiredAction` IN ('ACTIVE','WARNING','LIMITED','CUT')),
 CONSTRAINT `billing_state_applied_check` CHECK (`appliedAction` IS NULL OR `appliedAction` IN ('ACTIVE','WARNING','LIMITED','CUT'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `InvoiceAutomationFee` (
 `id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 `invoiceId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 `lineId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 `kind` VARCHAR(16) NOT NULL,
 `amountCents` INT UNSIGNED NOT NULL,
 `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
 PRIMARY KEY (`id`), UNIQUE KEY `invoice_automation_fee_once` (`invoiceId`,`kind`),
 CONSTRAINT `invoice_auto_fee_invoice_fk` FOREIGN KEY (`invoiceId`) REFERENCES `Invoice` (`id`) ON DELETE RESTRICT,
 CONSTRAINT `invoice_auto_fee_line_fk` FOREIGN KEY (`lineId`) REFERENCES `InvoiceLine` (`id`) ON DELETE RESTRICT,
 CONSTRAINT `invoice_auto_fee_kind_check` CHECK (`kind` IN ('LATE','RECONNECTION') AND `amountCents` BETWEEN 1 AND 2147483647)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `ClientNetworkObservation` (
 `clientId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 `routerId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 `connected` TINYINT UNSIGNED NOT NULL,
 `addressesJson` TEXT NOT NULL,
 `observedAt` DATETIME(3) NOT NULL,
 PRIMARY KEY (`clientId`,`routerId`),
 CONSTRAINT `client_observation_client_fk` FOREIGN KEY (`clientId`) REFERENCES `Client` (`id`) ON DELETE RESTRICT,
 CONSTRAINT `client_observation_router_fk` FOREIGN KEY (`routerId`) REFERENCES `Router` (`id`) ON DELETE RESTRICT,
 CONSTRAINT `client_observation_connected_check` CHECK (`connected` IN (0,1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `ClientActivityEvent` (
 `id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 `clientId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 `serviceId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NULL,
 `actorId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NULL,
 `kind` VARCHAR(40) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 `source` VARCHAR(24) NOT NULL,
 `detailsJson` TEXT NOT NULL,
 `dedupeKey` VARCHAR(191) CHARACTER SET ascii COLLATE ascii_bin NULL,
 `occurredAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
 PRIMARY KEY (`id`), UNIQUE KEY `client_event_once` (`dedupeKey`),
 KEY `client_event_time_idx` (`clientId`,`occurredAt`,`id`), KEY `client_event_kind_idx` (`clientId`,`kind`,`occurredAt`),
 CONSTRAINT `client_event_client_fk` FOREIGN KEY (`clientId`) REFERENCES `Client` (`id`) ON DELETE RESTRICT,
 CONSTRAINT `client_event_service_fk` FOREIGN KEY (`serviceId`) REFERENCES `Service` (`id`) ON DELETE RESTRICT,
 CONSTRAINT `client_event_actor_fk` FOREIGN KEY (`actorId`) REFERENCES `User` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `ClientNotice` (
 `id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 `clientId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 `invoiceId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NULL,
 `channel` VARCHAR(12) NOT NULL,
 `kind` VARCHAR(24) NOT NULL,
 `subject` VARCHAR(180) NOT NULL,
 `body` TEXT NOT NULL,
 `status` VARCHAR(12) NOT NULL,
 `dedupeKey` VARCHAR(191) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 `providerId` VARCHAR(180) NULL,
 `attempts` INT UNSIGNED NOT NULL DEFAULT 0,
 `nextAttemptAt` DATETIME(3) NULL,
 `lastError` VARCHAR(500) NULL,
 `sentAt` DATETIME(3) NULL,
 `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
 `updatedAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
 PRIMARY KEY (`id`), UNIQUE KEY `client_notice_once` (`dedupeKey`),
 KEY `client_notice_queue_idx` (`status`,`nextAttemptAt`), KEY `client_notice_history_idx` (`clientId`,`createdAt`,`id`),
 CONSTRAINT `client_notice_client_fk` FOREIGN KEY (`clientId`) REFERENCES `Client` (`id`) ON DELETE RESTRICT,
 CONSTRAINT `client_notice_invoice_fk` FOREIGN KEY (`invoiceId`) REFERENCES `Invoice` (`id`) ON DELETE RESTRICT,
 CONSTRAINT `client_notice_channel_check` CHECK (`channel` IN ('PORTAL','EMAIL','SMS','TELEGRAM')),
 CONSTRAINT `client_notice_status_check` CHECK (`status` IN ('QUEUED','SENT','FAILED','DELIVERED'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `ClientTelemetrySample` (
 `id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 `clientId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 `routerId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 `sourceSecretId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NULL,
 `serviceId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NULL,
 `sampledAt` DATETIME(3) NOT NULL,
 `uploadBps` DECIMAL(20,3) NULL, `downloadBps` DECIMAL(20,3) NULL,
 `uploadBytes` DECIMAL(24,0) NULL, `downloadBytes` DECIMAL(24,0) NULL,
 `averageMs` DECIMAL(14,3) NULL, `lossPercent` DECIMAL(7,4) NULL,
 PRIMARY KEY (`id`), KEY `client_telemetry_time_idx` (`clientId`,`sampledAt`,`id`),
 KEY `client_telemetry_retention_idx` (`sampledAt`),
 CONSTRAINT `client_telemetry_client_fk` FOREIGN KEY (`clientId`) REFERENCES `Client` (`id`) ON DELETE RESTRICT,
 CONSTRAINT `client_telemetry_router_fk` FOREIGN KEY (`routerId`) REFERENCES `Router` (`id`) ON DELETE RESTRICT,
 CONSTRAINT `client_telemetry_source_fk` FOREIGN KEY (`sourceSecretId`) REFERENCES `RouterSecretImport` (`id`) ON DELETE RESTRICT,
 CONSTRAINT `client_telemetry_service_fk` FOREIGN KEY (`serviceId`) REFERENCES `Service` (`id`) ON DELETE RESTRICT,
 CONSTRAINT `client_telemetry_loss_check` CHECK (`lossPercent` IS NULL OR `lossPercent` BETWEEN 0 AND 100)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
