-- Authorized billing-only automation. No client policy is created or changed.
CREATE TABLE IF NOT EXISTS `BillingNetworkGrant` (
 `id` VARCHAR(16) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 `enabled` TINYINT UNSIGNED NOT NULL DEFAULT 1,
 `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
 PRIMARY KEY (`id`),
 CONSTRAINT `billing_grant_check` CHECK (`id`='primary' AND `enabled` IN (0,1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO BillingNetworkGrant (id,enabled) VALUES ('primary',1) ON DUPLICATE KEY UPDATE enabled=1;
INSERT INTO BillingAutomationSetting (id,enabled,cutHour) VALUES ('primary',1,'04:30') ON DUPLICATE KEY UPDATE enabled=1,cutHour='04:30';
