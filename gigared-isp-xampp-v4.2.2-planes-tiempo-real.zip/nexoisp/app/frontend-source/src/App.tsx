import { lazy, Suspense, useCallback, useEffect, useState, type FormEvent } from 'react';
import { Activity, ArrowRight, CheckCircle2, ChevronDown, Globe2, KeyRound, LogOut, Menu, Moon, Network, ShieldCheck, Sun, Wifi, X } from 'lucide-react';
import { api, apiBase, post, remove } from './api';
import PortalApp from './PortalApp';
import Navigation from './Navigation';
import TrafficHistory from './TrafficHistory';
import SecretImportDialog from './SecretImportDialog';
import ProfileImportDialog from './ProfileImportDialog';
import FiberPage from './FiberPage';
import BillingServiceDialog from './BillingServiceDialog';
import ClientRegistration from './ClientRegistration';
const ClientProfile = lazy(() => import('./ClientProfile'));
const BillingAutomation = lazy(() => import('./BillingAutomation'));
import ClientPppActions from './ClientPppActions';
import { SecretAutoSyncStatus, useSecretAutoSync } from './SecretAutoSync';
import { ExtensionsPage, ExtensionFormDialog, extensionCanRead, extensionNames, isExtensionPage } from './Extensions';
import { ConfirmDialog, DetailDialog, DiagnosticDialog, FormDialog, TaskDialog } from './dialogs';
import type { Row } from './forms';
import { DashboardPage, pageMeta, ResourcePage, type PageActions } from './pages';
import type { Capabilities, PageName, Task, User } from './types';
import { errorMessage, labels, Loading } from './ui';
import { setDefaultCurrency } from './currency';

type Dialog = { type: 'client-ppp-action'; clientId: string; action: 'suspend' | 'delete' | 'reactivate' } | { type: 'profile-import' } | { type: 'secret-import' } | { type: 'form'; kind: string; row?: Row } | { type: 'detail'; kind: PageName; row: Row } | { type: 'task'; id: string } | { type: 'diagnostic'; service: Row } | { type: 'prorate' } | { type: 'traffic'; service: Row } | { type: 'confirm'; title: string; description: string; confirm: () => Promise<void> };
interface Toast { id: number; message: string; error: boolean }

function defaultTheme(): 'dark' | 'light' {
  try { const saved = localStorage.getItem('nexoisp-theme'); if (saved === 'dark' || saved === 'light') return saved; }
  catch { /* The interface also works when storage is unavailable. */ }
  return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
}
function route(): PageName { const value = window.location.hash.replace(/^#\/?/, ''); if (/^clients\/[a-f0-9]{24}$/.test(value)) return 'clients'; return Object.hasOwn(pageMeta, value) ? value as PageName : 'dashboard'; }

function Login({ authenticated, theme, toggleTheme }: { authenticated: (user: User, capabilities: Capabilities) => void; theme: string; toggleTheme: () => void }) {
  const [email, setEmail] = useState(''), [password, setPassword] = useState(''), [busy, setBusy] = useState(false), [error, setError] = useState('');
  const submit = async (event: FormEvent) => {
    event.preventDefault(); setBusy(true); setError('');
    try { const response = await post<{ user: User; capabilities: Capabilities }>('/auth/login', { email, password }); setPassword(''); setDefaultCurrency(response.capabilities.defaultCurrency); authenticated(response.user, response.capabilities); }
    catch (err) { setError(errorMessage(err)); }
    finally { setBusy(false); }
  };
  return <div className="login-page"><section className="login-art"><div className="login-brand"><div className="brand-mark"><Network size={28} /></div><span>GIGARED <span style={{ color: '#36d6c0' }}>ISP</span></span></div><div><p className="login-kicker">CONECTA. CONTROLA. CRECE.</p><h1>Tu red conecta<br />personas.<br /><span>Tu operación,<br />en un solo lugar.</span></h1><p>Clientes, facturación y control MikroTik. Una plataforma para acompañar cada conexión.</p><div className="login-visual" aria-hidden="true"><svg viewBox="0 0 460 230"><defs><linearGradient id="network-line"><stop stopColor="#36d6c0" /><stop offset="1" stopColor="#6d86f4" /></linearGradient></defs><g stroke="url(#network-line)" strokeWidth="1.5" fill="none" opacity=".7"><path d="M60 70 190 115 330 55M190 115 350 170M190 115 80 190M190 115 230 205M330 55 415 100M350 170 415 100" /></g>{[[60,70],[190,115],[330,55],[350,170],[80,190],[230,205],[415,100]].map(([cx,cy], index) => <g key={index}><circle cx={cx} cy={cy} r={index === 1 ? 27 : 16} fill="#152c43" stroke="#36d6c0" strokeOpacity=".7" /><circle cx={cx} cy={cy} r={index === 1 ? 7 : 4} fill="#36d6c0" /></g>)}</svg></div></div><div className="inline-gap" style={{ color: '#9fb8cc' }}><ShieldCheck size={17} /><span>Accesos por rol · Operaciones con trazabilidad</span></div></section><section className="login-form"><button className="icon-button" style={{ position: 'absolute', top: 28, right: 28 }} aria-label={theme === 'dark' ? 'Cambiar a tema claro' : 'Cambiar a tema oscuro'} onClick={toggleTheme}>{theme === 'dark' ? <Sun size={20} /> : <Moon size={20} />}</button><div className="login-card"><div className="login-kicker">BIENVENIDO A GIGARED ISP</div><h2>Conecta con tu operación</h2><p className="subtle">Ingresa con la cuenta de tu equipo.</p><form onSubmit={event => void submit(event)}>{error && <div className="alert error" role="alert">{error}</div>}<label className="field"><span className="field-label">Correo electrónico</span><input autoComplete="username" type="email" required value={email} onChange={event => setEmail(event.target.value)} disabled={busy} /></label><label className="field"><span className="field-label">Contraseña</span><input autoComplete="current-password" type="password" required value={password} onChange={event => setPassword(event.target.value)} disabled={busy} /></label><button className="button primary" style={{ width: '100%', marginTop: 10, justifyContent: 'center' }} type="submit" disabled={busy}>{busy ? 'Verificando acceso…' : 'Entrar al panel'}<ArrowRight size={18} /></button></form><div className="alert info" style={{ marginTop: 26 }}><KeyRound size={18} /><span>Si necesitas acceso, contacta al administrador de tu ISP. Las cuentas y permisos se administran de forma centralizada.</span></div><p className="subtle" style={{ textAlign: 'center', marginTop: 28 }}>Al cerrar o recargar esta página, vuelve a iniciar sesión.</p></div></section></div>;
}

function AdminApp() {
  const [user, setUser] = useState<User | null>(null), [capabilities, setCapabilities] = useState<Capabilities>({ simulatedRouters: false }), [initializing, setInitializing] = useState(true);
  const [page, setPage] = useState<PageName>(route), [theme, setTheme] = useState(defaultTheme), [sidebar, setSidebar] = useState(false);
  const [profileId, setProfileId] = useState<string | null>(() => /^#\/clients\/([a-f0-9]{24})$/.exec(window.location.hash)?.[1] || null);
  const [dialog, setDialog] = useState<Dialog | null>(null), [refresh, setRefresh] = useState(0), [toasts, setToasts] = useState<Toast[]>([]);
  const close = useCallback(() => setDialog(null), []);
  const saved = useCallback(() => setRefresh(value => value + 1), []);
  const autoSecrets = useSecretAutoSync({ enabled: !!user && capabilities.secretAutoSync === true, userId: user?.id, canRun: user?.role === 'ADMIN' || user?.role === 'TECHNICIAN', paused: dialog !== null, refreshed: saved });
  const notify = useCallback((message: string, error = false) => { const id = Date.now() + Math.random(); setToasts(old => [...old.slice(-3), { id, message, error }]); window.setTimeout(() => setToasts(old => old.filter(toast => toast.id !== id)), 6500); }, []);
  useEffect(() => { document.documentElement.dataset.theme = theme; try { localStorage.setItem('nexoisp-theme', theme); } catch { /* Session authentication never depends on browser storage. */ } }, [theme]);
  useEffect(() => {
    let active = true;
    const listener = () => { setUser(null); setDialog(null); };
    window.addEventListener('nexoisp:unauthorized', listener);
    api<{ user: User; capabilities: Capabilities }>('/auth/me').then(response => { if (active) { setDefaultCurrency(response.capabilities.defaultCurrency); setUser(response.user); setCapabilities(response.capabilities); } }).catch(() => undefined).finally(() => { if (active) setInitializing(false); });
    return () => { active = false; window.removeEventListener('nexoisp:unauthorized', listener); };
  }, []);
  useEffect(() => {
    if (!user || capabilities.browserWorker !== true) return;
    let stopped = false;
    let schedule: number | undefined;
    let deadline: number | undefined;
    let pending: AbortController | undefined;
    const tick = async () => {
      if (stopped || pending) return;
      pending = new AbortController();
      deadline = window.setTimeout(() => pending?.abort(), 120000);
      try {
        await api('/worker/tick', { method: 'POST', body: '{}', signal: pending.signal });
      } catch {
        // Persistent task results remain available in Operations; session expiry is handled by api().
      } finally {
        window.clearTimeout(deadline);
        pending = undefined;
        if (!stopped) schedule = window.setTimeout(() => void tick(), 5000);
      }
    };
    schedule = window.setTimeout(() => void tick(), 250);
    return () => { stopped = true; window.clearTimeout(schedule); window.clearTimeout(deadline); pending?.abort(); };
  }, [user?.id, capabilities.browserWorker]);
  useEffect(() => { const listener = () => { setPage(route()); setProfileId(/^#\/clients\/([a-f0-9]{24})$/.exec(window.location.hash)?.[1] || null); setSidebar(false); }; window.addEventListener('hashchange', listener); return () => window.removeEventListener('hashchange', listener); }, []);
  useEffect(() => { if (user && user.role !== 'ADMIN' && ['users', 'audit'].includes(page)) { window.location.hash = '/dashboard'; setPage('dashboard'); } }, [user, page]);
  useEffect(() => { if (user && isExtensionPage(page) && (!capabilities.extensions || !extensionCanRead(page, user.role))) { window.location.hash = '/dashboard'; setPage('dashboard'); } }, [user, page, capabilities.extensions]);
  const go = (next: PageName) => { setProfileId(null); window.location.hash = `/${next}`; setPage(next); setSidebar(false); };
  const toggleTheme = () => setTheme(value => value === 'dark' ? 'light' : 'dark');
  const logout = async () => {
    try { await post('/auth/logout'); setUser(null); setDialog(null); }
    catch (err) { notify(errorMessage(err), true); }
  };
  const queued = (response: Task | { tasks: Task[] }, message = 'Operación encolada.') => {
    saved();
    if ('tasks' in response) { notify(`${response.tasks.length} operaciones encoladas. Consulta su progreso en Operaciones de red.`); if (response.tasks[0]) setDialog({ type: 'task', id: response.tasks[0].id }); }
    else { notify(message); setDialog({ type: 'task', id: response.id }); }
  };
  const execute = async (action: string, row?: Row, ids?: string[]) => {
    if (action === 'bulk:diagnostics') { queued(await post<{ tasks: Task[] }>('/network/bulk-diagnostics', { ids })); return; }
    if (action.startsWith('bulk:')) { queued(await post<{ tasks: Task[] }>('/services/bulk', { ids, action: action.split(':')[1] })); return; }
    if (action === 'billing' || action === 'autocut') { queued(await post<Task>(action === 'billing' ? '/billing/run' : '/billing/autocut')); return; }
    if (!row) return;
    if (action === 'sync' || action === 'suspend' || action === 'reactivate') queued(await post<Task>(`/services/${row.id}/${action}`));
    else if (action === 'router-test' || action === 'firewall') queued(await post<Task>(`/routers/${row.id}/${action === 'router-test' ? 'test' : 'firewall'}`));
    else if (action === 'retry-task') queued(await post<Task>(`/tasks/${row.id}/retry`));
    else if (action === 'revoke-key') { await remove(`/keys/${row.id}`); saved(); notify('La clave de API fue revocada.'); }
    else if (['delete-invoice', 'delete-payment', 'delete-billing-service'].includes(action)) {
      const path = action === 'delete-invoice' ? `/invoices/${row.id}` : action === 'delete-payment' ? `/payments/${row.id}` : `/billing-services/${row.id}`;
      await remove(path); saved();
      notify(action === 'delete-payment' ? 'Pago eliminado. El saldo de la factura se actualizó.' : action === 'delete-invoice' ? 'Factura eliminada del listado. Su historial se conserva.' : 'Servicio eliminado del listado sin modificar MikroTik.');
    }
    else if (action === 'void-invoice') { await post(`/invoices/${row.id}/void`); saved(); notify('La factura fue anulada.'); }
    else if (action.startsWith('delete:')) { const resource = action.split(':')[1]; await remove(`/${resource}/${row.id}`); saved(); notify(resource === 'routers' ? 'Router eliminado.' : resource === 'plans' ? 'Plan desactivado.' : 'Retiro registrado. Los cambios de red se procesarán en segundo plano.'); }
  };
  const onAction = (action: string, row?: Row, ids?: string[]) => {
    if (['client-ppp-suspend','client-ppp-delete','client-ppp-reactivate'].includes(action) && row) {
      if (capabilities.clientPppActions !== true || !(action === 'client-ppp-delete' ? user?.role === 'ADMIN' : ['ADMIN','TECHNICIAN'].includes(user?.role || ''))) { notify('No dispone de permisos para esta acción.', true); return; }
      setDialog({ type: 'client-ppp-action', clientId: String(row.id), action: action === 'client-ppp-delete' ? 'delete' : action === 'client-ppp-reactivate' ? 'reactivate' : 'suspend' }); return;
    }
    if (['delete-invoice', 'delete-payment', 'delete-billing-service'].includes(action) && (capabilities.financialDeletion !== true || !['ADMIN', 'BILLING'].includes(user?.role || ''))) { notify('No dispone de permisos para eliminar estos registros.', true); return; }
    const mutation = ['sync', 'suspend', 'reactivate', 'firewall', 'billing', 'autocut', 'bulk:sync', 'bulk:suspend', 'bulk:reactivate', 'delete:clients', 'delete:services'].includes(action) || action === 'retry-task' && !['DIAGNOSTIC', 'ROUTER_TEST'].includes(String(row?.kind));
    if (capabilities.networkReadOnly === true && mutation) { notify('Modo solo lectura: la configuración del MikroTik permanece protegida.', true); return; }
    if (row?.billingOnly === true && ['sync', 'suspend', 'reactivate', 'diagnostics', 'traffic', 'delete:services'].includes(action)) { notify('Este servicio es solo para facturación y no admite operaciones de red.', true); return; }
    if (action === 'traffic' && row) { setDialog({ type: 'traffic', service: row }); return; }
    if (action === 'diagnostics' && row) { setDialog({ type: 'diagnostic', service: row }); return; }
    const confirmations: Record<string, { title: string; description: string }> = {
      suspend: { title: 'Suspender servicio', description: 'Se aplicará el corte en el router asignado. El cliente perderá conectividad cuando se confirme la sincronización.' },
      'bulk:suspend': { title: `Suspender ${ids?.length || 0} servicios`, description: 'Se encolará una suspensión por cada servicio seleccionado. Revisa la selección antes de continuar.' },
      'bulk:reactivate': { title: `Reactivar ${ids?.length || 0} servicios`, description: 'Se solicitará la reconexión de los servicios seleccionados. Los servicios retirados no pueden reactivarse. La solicitud puede sustituir una suspensión manual.' },
      firewall: { title: 'Configurar firewall de corte', description: 'Se crearán o actualizarán reglas administradas por GIGARED ISP para el corte y el portal HTTP configurado. Verifica el portal, la Address List y la política de tu red antes de continuar. HTTPS no admite redirección transparente.' },
      'revoke-key': { title: 'Revocar clave de API', description: 'Las integraciones que utilicen esta clave perderán acceso inmediatamente. Esta acción no puede deshacerse.' },
      'delete-invoice': { title: 'Eliminar factura', description: `La factura ${String(row?.number || '')} desaparecerá de los listados y conservará su historial. Primero elimina sus pagos y resuelve los reportes pendientes. El periodo y los cargos únicos de esta factura permanecerán reservados; no podrás emitir otra para este mismo servicio y periodo. No se enviarán órdenes a MikroTik.` },
      'delete-payment': { title: 'Eliminar pago', description: `El pago ${String(row?.externalReference || '')} desaparecerá de los listados y su importe volverá al saldo pendiente de la factura. Si está vinculado a Caja, primero revierte el movimiento allí. La referencia del pago seguirá reservada y el historial se conservará. No se realizarán cortes ni reconexiones.` },
      'delete-billing-service': { title: 'Eliminar servicio', description: 'El servicio de facturación local desaparecerá del listado. Primero elimina sus facturas y resuelve los contratos activos asociados. El historial se conservará y no se modificará el MikroTik ni se eliminará el cliente.' },
      'void-invoice': { title: 'Anular factura', description: 'La factura dejará de formar parte del saldo pendiente. El historial se conservará y no se borrarán pagos.' },
      'delete:clients': { title: 'Retirar cliente', description: 'Se retirarán todos los servicios del cliente y se solicitará la eliminación de sus recursos administrados en RouterOS. Se conservará su historial de facturación y soporte.' },
      'delete:services': { title: 'Retirar servicio', description: 'Se eliminarán los recursos de este servicio administrados por GIGARED ISP en el router. Su historial se conservará y no se generarán nuevas facturas.' },
      'delete:plans': { title: 'Desactivar plan', description: 'El plan dejará de estar disponible para nuevas altas. Los servicios que ya lo utilizan conservarán su asignación.' },
      'delete:routers': { title: 'Eliminar router', description: 'Se eliminará la configuración de acceso al router. Solo se permite si no tiene servicios asignados; no se modificarán reglas en el equipo.' },
      autocut: { title: 'Revisar facturas para autocorte', description: 'Se revisarán las facturas abiertas cuyo periodo de gracia haya terminado. Los servicios con deuda vencida serán suspendidos en segundo plano.' },
    };
    const confirmation = confirmations[action];
    if (confirmation) setDialog({ type: 'confirm', ...confirmation, confirm: () => execute(action, row, ids) });
    else void execute(action, row, ids).catch(err => notify(errorMessage(err), true));
  };
  const actions: PageActions = {
    form: (kind, row) => {
      if (kind === 'billing-service' || kind === 'services' && row?.billingOnly === true) {
        if (capabilities.localBillingServices !== true || !['ADMIN', 'BILLING'].includes(user?.role || '')) { notify('No dispone de permisos para administrar la facturación del servicio.', true); return; }
        setDialog({ type: 'form', kind: 'billing-service', row }); return;
      }
      if (kind === 'profile-import') { if (capabilities.profileImport === true && ['ADMIN', 'TECHNICIAN'].includes(user?.role || '')) setDialog({ type: 'profile-import' }); return; }
      if (kind === 'secret-import') { if (capabilities.secretImport === true && ['ADMIN', 'TECHNICIAN'].includes(user?.role || '')) setDialog({ type: 'secret-import' }); return; }
      if (kind === 'services' && capabilities.networkReadOnly === true) { notify('El alta y la edición de servicios de red están bloqueadas en modo solo lectura.', true); return; }
      setDialog(kind === 'prorate' ? { type: 'prorate' } : { type: 'form', kind, row });
    },
    details: (kind, row) => { if (kind === 'clients' && capabilities.clientProfile === true) { setProfileId(row.id); window.location.hash = `/clients/${row.id}`; return; } if (kind === 'tasks') setDialog({ type: 'task', id: row.id }); else setDialog({ type: 'detail', kind, row }); },
    action: onAction,
  };
  if (initializing) return <div style={{ minHeight: '100vh', display: 'grid', placeItems: 'center' }}><Loading label="Abriendo tu centro de operaciones…" /></div>;
  if (!user) return <Login authenticated={(next, caps) => { setUser(next); setCapabilities(caps); setRefresh(value => value + 1); }} theme={theme} toggleTheme={toggleTheme} />;
  const visiblePages: PageName[] = [...(capabilities.fiber ? ['fiber'] as PageName[] : []), 'dashboard', 'clients', 'services', 'plans', 'routers', 'invoices', 'payments', ...(capabilities.billingPolicies && ['ADMIN','BILLING'].includes(user.role) ? ['billing-settings'] as PageName[] : []), 'tickets', 'tasks', ...(user.role === 'ADMIN' ? ['users', 'audit'] as PageName[] : []), 'keys', ...(capabilities.extensions ? extensionNames.filter(name => extensionCanRead(name, user.role)) : [])];
  const meta = pageMeta[page];
  return <div className="app-shell">{sidebar && <button className="menu-backdrop" aria-label="Cerrar menú" onClick={() => setSidebar(false)} />}<aside className={`sidebar ${sidebar ? 'open' : ''}`}><button className="brand" onClick={() => go('dashboard')} aria-label="GIGARED ISP, inicio"><div className="brand-mark"><Network size={27} /></div><span>GIGARED <span style={{ color: 'var(--sidebar-accent)' }}>ISP</span><small>Centro de operaciones</small></span></button><div className="section-label" style={{ color: 'var(--sidebar-heading)', padding: '0 16px' }}>GESTIÓN DE TU ISP</div><Navigation visiblePages={visiblePages} page={page} go={go} extended={capabilities.extensions === true} /><div className="sidebar-bottom"><div className="inline-gap" style={{ color: 'var(--sidebar-accent)' }}><Wifi size={17} /><strong>Conexiones que importan</strong></div><p>Control y visibilidad para tu red.</p><span>GIGARED ISP · v4.2.2</span></div></aside><div className="workspace"><header className="topbar"><div className="inline-gap"><button className="icon-button mobile-menu" aria-label="Abrir menú de navegación" onClick={() => setSidebar(true)}><Menu size={22} /></button><div className="topbar-title"><Globe2 size={16} /><span>Mi operación</span><span className="subtle">/</span><strong>{meta.title === 'Centro de operaciones' ? 'Resumen general' : meta.title}</strong></div></div><div className="inline-gap"><button className="icon-button" aria-label={theme === 'dark' ? 'Activar tema claro' : 'Activar tema oscuro'} onClick={toggleTheme}>{theme === 'dark' ? <Sun size={19} /> : <Moon size={19} />}</button><div className="user-avatar" aria-hidden="true">{user.name.split(' ').slice(0, 2).map(part => part[0]).join('').toUpperCase()}</div><div className="user-meta"><strong>{user.name}</strong><span>{labels[user.role]}</span></div><ChevronDown size={14} className="subtle" /><button className="icon-button" title="Cerrar sesión" aria-label="Cerrar sesión" onClick={() => void logout()}><LogOut size={18} /></button></div></header><main className={`content${page === 'clients' ? ' content-clients' : ''}`}>{capabilities.networkReadOnly === true && <div className="alert info network-readonly-banner" role="status"><ShieldCheck size={21} /><div><strong>{capabilities.manualPppoeEditing === true ? 'Edición PPPoE manual habilitada' : 'MikroTik en modo solo lectura'}</strong><span>{capabilities.manualPppoeEditing === true ? 'Las acciones manuales confirmadas de clientes están habilitadas. Los cortes de facturación siguen las condiciones de cada cliente y el horario del sistema.' : 'La importación consulta usuarios y perfiles y guarda una copia local. Los cambios de configuración, cortes y reconexiones están bloqueados.'}</span></div></div>}{capabilities.secretAutoSync === true && ['clients', 'routers', 'plans'].includes(page) && <SecretAutoSyncStatus state={autoSecrets.state} error={autoSecrets.error} paused={dialog !== null} liveSessionPolling={page === 'clients' && capabilities.clientIpLive === true && ['ADMIN', 'TECHNICIAN'].includes(user.role)} />}{!profileId && page !== 'billing-settings' && (<div className="page-heading"><div><div className="login-kicker" style={{ marginBottom: 7 }}>{page === 'dashboard' ? 'TU RED, DE UN VISTAZO' : 'GESTIÓN Y SEGUIMIENTO'}</div><h1 className="page-title">{page === 'dashboard' ? `Hola, ${user.name.split(' ')[0]}` : meta.title}{page === 'dashboard' && <span className="welcome-wave" aria-hidden="true"> ✦</span>}</h1><p className="page-description">{meta.description}</p></div><div className="date-chip"><Activity size={15} /><span>{new Intl.DateTimeFormat('es', { day: 'numeric', month: 'long', year: 'numeric' }).format(new Date())}</span></div></div>)}{page === 'billing-settings' && capabilities.billingPolicies === true ? <Suspense fallback={<Loading />}><BillingAutomation user={user} readOnly={capabilities.networkReadOnly === true} /></Suspense> : page === 'clients' && profileId && capabilities.clientProfile === true ? <Suspense fallback={<Loading />}><ClientProfile key={profileId} clientId={profileId} user={user} capabilities={capabilities} refresh={refresh} actions={actions} saved={saved} back={() => go('clients')} /></Suspense> : page === 'dashboard' ? <DashboardPage refresh={refresh} actions={actions} networkReadOnly={capabilities.networkReadOnly === true} onlineEnabled={capabilities.dashboardOnline === true} /> : page === 'fiber' ? <FiberPage user={user} notify={notify} /> : isExtensionPage(page) ? <ExtensionsPage key={page} page={page} user={user} notify={notify} /> : <ResourcePage key={page} page={page} user={user} refresh={refresh} actions={actions} extensions={capabilities.extensions === true} capabilities={capabilities} />}</main><footer className="workspace-footer"><span>GIGARED ISP</span><span>Gestión de redes y servicios de Internet</span>{capabilities.profileImport === true && <a className="text-link demo-link" href={`${apiBase.replace(/\/api\/v1$/, '')}/demo/`} target="_blank" rel="noreferrer">Ver demostración</a>}</footer></div><div className="toast-stack" aria-live="polite">{toasts.map(toast => <div className={`toast ${toast.error ? 'error' : 'success'}`} key={toast.id} role={toast.error ? 'alert' : 'status'}>{toast.error ? <ShieldCheck size={20} /> : <CheckCircle2 size={20} />}<span>{toast.message}</span><button className="icon-button" aria-label="Cerrar notificación" onClick={() => setToasts(old => old.filter(item => item.id !== toast.id))}><X size={15} /></button></div>)}</div>{dialog?.type === 'client-ppp-action' && <ClientPppActions clientId={dialog.clientId} action={dialog.action} close={close} saved={saved} />}{dialog?.type === 'profile-import' && <ProfileImportDialog close={close} saved={saved} />}{dialog?.type === 'secret-import' && <SecretImportDialog close={close} saved={saved} />}{dialog?.type === 'traffic' && <TrafficHistory service={dialog.service} close={close} />}{dialog?.type === 'prorate' && <ExtensionFormDialog kind="prorate" close={close} onSaved={saved} notify={notify} />}{dialog?.type === 'form' && (dialog.kind === 'payment-promises' ? <ExtensionFormDialog kind={dialog.kind} row={dialog.row} close={close} onSaved={saved} notify={notify} /> : dialog.kind === 'billing-service' ? <BillingServiceDialog key={`billing-${dialog.row?.id || dialog.row?.clientId || 'new'}`} row={dialog.row} close={close} saved={saved} notify={notify} /> : dialog.kind === 'clients' && !dialog.row?.id && capabilities.clientProvisioning === true && ['ADMIN','TECHNICIAN'].includes(user.role) ? <ClientRegistration user={user} close={close} saved={saved} notify={notify} /> : <FormDialog key={`${dialog.kind}-${dialog.row?.id || 'new'}`} kind={dialog.kind} row={dialog.row} capabilities={capabilities} close={close} saved={saved} notify={notify} billingService={() => actions.form('billing-service')} />)}{dialog?.type === 'detail' && <DetailDialog key={`${dialog.kind}-${dialog.row.id}`} kind={dialog.kind} row={dialog.row} user={user} fiber={capabilities.fiber === true} localBillingServices={capabilities.localBillingServices === true} financialDeletion={capabilities.financialDeletion === true} close={close} actions={actions} notify={notify} saved={saved} extensions={capabilities.extensions === true} networkReadOnly={capabilities.networkReadOnly === true} />}{dialog?.type === 'task' && <TaskDialog key={dialog.id} id={dialog.id} close={close} onComplete={saved} />}{dialog?.type === 'diagnostic' && <DiagnosticDialog key={dialog.service.id} service={dialog.service} close={close} />}{dialog?.type === 'confirm' && <ConfirmDialog title={dialog.title} description={dialog.description} confirm={dialog.confirm} close={() => setDialog(current => current?.type === 'confirm' ? null : current)} />}</div>;
}

export default function App() {
  const clientMode = document.querySelector<HTMLMetaElement>('meta[name="nexoisp-mode"]')?.content === 'client';
  useEffect(() => { document.title = clientMode ? 'GIGARED ISP · Portal del cliente' : 'GIGARED ISP · Centro de operaciones'; }, [clientMode]);
  return clientMode ? <PortalApp /> : <AdminApp />;
}
