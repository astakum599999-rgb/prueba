import { useEffect, useState } from 'react';
import { Activity, ArrowDown, ArrowUp } from 'lucide-react';
import { api } from './api';
import { EmptyState, errorMessage, Loading } from './ui';

type Period = 'day' | 'week' | 'month' | 'year';
interface Point { at: string; downloadBps: number | null; uploadBps: number | null; samples: number }
interface History {
  period: Period; serverTime: string; firstObservedAt: string | null; bucketSeconds: number;
  points: Point[]; current: { status: string; downloadBps: number | null; uploadBps: number | null; observedAt: string | null; coveredRouters: number; totalRouters: number; message: string | null };
}
const stamp = (value: string, period: Period, full = false) => new Intl.DateTimeFormat('es-PE', { timeZone: 'America/Lima', ...(period === 'day' && !full ? {} : { day: '2-digit', month: 'short' }), ...(period === 'year' && !full ? {} : { hour: '2-digit', minute: '2-digit', hour12: false }), ...(full ? { year: 'numeric' } : {}) }).format(new Date(value));
const rate = (value: number | null) => value === null ? '—' : `${new Intl.NumberFormat('es-PE', { maximumFractionDigits: 2 }).format(value / 1_000_000)} Mbps`;

function Graph({ points, period }: { points: Point[]; period: Period }) {
  const [compact, setCompact] = useState(() => window.matchMedia('(max-width: 767px)').matches);
  useEffect(() => { const media = window.matchMedia('(max-width: 767px)'); const update = () => setCompact(media.matches); media.addEventListener('change', update); return () => media.removeEventListener('change', update); }, []);
  const width = compact ? 640 : 960, height = compact ? 290 : 270, left = 66, right = 20, top = 28, bottom = 42;
  const valid = points.filter(point => point.downloadBps !== null && point.uploadBps !== null);
  const maximum = Math.max(1_000_000, ...valid.flatMap(point => [point.downloadBps!, point.uploadBps!]));
  const unit = maximum >= 1_000_000_000 ? 1_000_000_000 : 1_000_000;
  const x = (index: number) => left + index / Math.max(1, points.length - 1) * (width - left - right);
  const y = (value: number) => height - bottom - value / maximum * (height - top - bottom);
  const line = (key: 'downloadBps' | 'uploadBps') => { let started = false; return points.map((point, index) => { const value = point[key]; if (value === null) { started = false; return ''; } const move = started ? 'L' : 'M'; started = true; return `${move}${x(index).toFixed(2)},${y(value).toFixed(2)}`; }).join(' '); };
  const ticks = [...new Set(compact ? [0, Math.floor((points.length - 1) / 2), points.length - 1] : [0, Math.floor((points.length - 1) / 4), Math.floor((points.length - 1) / 2), Math.floor((points.length - 1) * .75), points.length - 1])];
  return <div className="global-traffic-chart"><svg viewBox={`0 0 ${width} ${height}`} role="img" aria-label="Tráfico global de descarga y subida en Mbps"><title>Tráfico global de clientes</title><desc>Dos series en la misma escala. Los intervalos sin mediciones dejan huecos. Pasa el puntero por un intervalo para ver sus valores.</desc>
    {[0, .25, .5, .75, 1].map(ratio => <g key={ratio}><line x1={left} x2={width - right} y1={y(maximum * ratio)} y2={y(maximum * ratio)} className="chart-grid" /><text x={left - 9} y={y(maximum * ratio) + 4} textAnchor="end">{(maximum * ratio / unit).toLocaleString('es-PE', { maximumFractionDigits: 1 })}</text></g>)}
    <text x={left} y="18">{unit === 1_000_000_000 ? 'Gbps' : 'Mbps'}</text><path d={line('downloadBps')} className="traffic-download-line" /><path d={line('uploadBps')} className="traffic-upload-line" />
    {valid.length === 1 && points.map((point, index) => point.downloadBps !== null && point.uploadBps !== null ? <g key={point.at}><circle cx={x(index)} cy={y(point.downloadBps)} r="4" fill="var(--traffic-download)" /><circle cx={x(index)} cy={y(point.uploadBps)} r="4" fill="var(--traffic-upload)" /></g> : null)}
    {ticks.map(index => points[index] && <text key={index} x={x(index)} y={height - 12} textAnchor={index === 0 ? 'start' : index === points.length - 1 ? 'end' : 'middle'}>{stamp(points[index]!.at, period)}</text>)}
    {points.map((point, index) => <rect key={point.at} x={x(index) - 3} y={top} width={Math.max(6, (width - left - right) / points.length)} height={height - top - bottom} fill="transparent"><title>{stamp(point.at, period, true)}{point.samples ? ` · Descarga: ${rate(point.downloadBps)} · Subida: ${rate(point.uploadBps)}` : ' · Sin medición'}</title></rect>)}
  </svg></div>;
}

export default function DashboardTraffic() {
  const [period, setPeriod] = useState<Period>('day'), [observation, setObservation] = useState<{ value: History; receivedAt: number; requestMs: number } | null>(null), [error, setError] = useState(''), [clock, setClock] = useState(() => performance.now());
  useEffect(() => {
    let stopped = false, pending: AbortController | undefined, timer: number | undefined, deadline: number | undefined;
    setObservation(null); setError('');
    const tick = async () => {
      if (stopped || pending || document.hidden) return;
      const controller = new AbortController(); pending = controller; const started = performance.now();
      deadline = window.setTimeout(() => controller.abort(), 90_000);
      try { const value = await api<History>('/dashboard/traffic/refresh', { method: 'POST', body: JSON.stringify({ period }), signal: controller.signal, cache: 'no-store' }); if (!stopped && !controller.signal.aborted) { setObservation({ value, receivedAt: performance.now(), requestMs: performance.now() - started }); setError(''); } }
      catch (reason) { if (!stopped && !document.hidden) setError(errorMessage(reason)); }
      finally { window.clearTimeout(deadline); pending = undefined; if (!stopped && !document.hidden) timer = window.setTimeout(() => void tick(), Math.max(0, 1000 - (performance.now() - started))); }
    };
    const visibility = () => { window.clearTimeout(timer); if (document.hidden) pending?.abort(); else void tick(); };
    const expiry = window.setInterval(() => setClock(performance.now()), 1000);
    document.addEventListener('visibilitychange', visibility); void tick();
    return () => { stopped = true; window.clearTimeout(timer); window.clearTimeout(deadline); window.clearInterval(expiry); pending?.abort(); document.removeEventListener('visibilitychange', visibility); };
  }, [period]);
  const data = observation?.value, current = data?.current;
  const age = current?.observedAt && data ? Date.parse(data.serverTime) - Date.parse(current.observedAt) + (observation?.requestMs || 0) + Math.max(0, clock - (observation?.receivedAt || 0)) : Infinity;
  const fresh = !error && current?.status === 'FRESH' && Number.isFinite(age) && age >= 0 && age < 5000;
  const measured = data?.points.some(point => point.samples > 0);
  return <section className="panel dashboard-traffic" data-testid="dashboard-global-traffic"><header className="panel-heading"><div><h2 className="panel-title">Tráfico global de clientes</h2><p className="subtle">Descarga y subida · Promedio por intervalo · Hora de Perú</p></div><label className="traffic-period"><span>Período</span><select aria-label="Período del tráfico global" value={period} onChange={event => setPeriod(event.target.value as Period)}><option value="day">Diario</option><option value="week">Últimos 7 días</option><option value="month">Último mes</option><option value="year">Último año</option></select></label></header>
    <div className="traffic-summary"><div className="traffic-download"><ArrowDown size={18} /><span>Descarga <strong>{rate(fresh ? current?.downloadBps ?? null : null)}</strong></span></div><div className="traffic-upload"><ArrowUp size={18} /><span>Subida <strong>{rate(fresh ? current?.uploadBps ?? null : null)}</strong></span></div><span className="subtle">{fresh ? 'Lectura actualizada · 1 s' : current?.status === 'WARMING' ? 'Tomando las primeras muestras…' : current?.status === 'EMPTY' ? 'Sin servicios de red asociados' : 'Sin lectura completa reciente'}</span></div>
    {error && <div className="alert warning" role="status">No se pudo actualizar el tráfico: {error}</div>}{current?.message && <div className="alert warning" role="status">{current.message}</div>}
    {!data ? <Loading label="Consultando el tráfico global…" /> : measured ? <Graph points={data.points} period={period} /> : <EmptyState icon={<Activity size={25} />} title="Todavía no hay mediciones para este período" description="El historial se construye con las lecturas reales. Mantén el worker activo para seguir recopilando datos con el panel cerrado." />}
    {data?.firstObservedAt && <p className="traffic-history-start subtle">Historial disponible desde {stamp(data.firstObservedAt, period, true)}.</p>}
  </section>;
}
