<?php
declare(strict_types=1);
namespace Nexo;

use PDO;

enum ClientPurgeRemoved { case VALUE; }

/** Permanent local erasure. No router/OLT transport is used by this module. */
function clientPurgeIn(string $column,array $ids): array
{
    return $ids?[$column.' IN ('.implode(',',array_fill(0,count($ids),'?')).')',array_values($ids)]:['0=1',[]];
}

function clientPurgeSpecs(string $clientId): array
{
    $specs=['Client'=>['id=?',[$clientId]]];
    foreach(['Service','Invoice','Ticket','PortalAccount','PaymentReport','ServiceContract','Installation','InventoryMovement','RouterSecretImport','PppoeAccountEdit','ClientNameSync','ClientNote','FinanceDeletion','ClientProvisioning','ClientPppAction','ClientPppActivation','ClientBillingPolicy','DashboardConnection','DashboardTrafficCounter','ClientNetworkObservation','ClientActivityEvent','ClientNotice','ClientTelemetrySample'] as $table)$specs[$table]=['clientId=?',[$clientId]];
    $specs['FiberOnu']=['client_id=?',[$clientId]];
    foreach(['Payment'=>'invoiceId','PaymentPromise'=>'invoiceId','InvoiceLine'=>'invoiceId','InvoiceAutomationFee'=>'invoiceId'] as $table=>$field)$specs[$table]=[$field.' IN (SELECT id FROM Invoice WHERE clientId=?)',[$clientId]];
    foreach(['ServiceCharge','ServiceDiscount','TrafficSample','LocalBillingService','LocalBillingSchedule','BillingServiceState'] as $table)$specs[$table]=['serviceId IN (SELECT id FROM Service WHERE clientId=?)',[$clientId]];
    $specs['PortalSession']=['accountId IN (SELECT id FROM PortalAccount WHERE clientId=?)',[$clientId]];
    $specs['TicketComment']=['ticketId IN (SELECT id FROM Ticket WHERE clientId=?)',[$clientId]];
    $specs['ClientPppRetiredSecret']=['actionId IN (SELECT id FROM ClientPppAction WHERE clientId=?)',[$clientId]];
    foreach(['FiberSample','FiberDraft','FiberJob'] as $table)$specs[$table]=['onu_id IN (SELECT id FROM FiberOnu WHERE client_id=?)',[$clientId]];
    $cash=array_column(fetchAll('SELECT id FROM CashMovement WHERE paymentId IN (SELECT p.id FROM Payment p JOIN Invoice i ON i.id=p.invoiceId WHERE i.clientId=?)',[$clientId]),'id');
    $seen=array_fill_keys($cash,true);$next=$cash;
    while($next){$found=[];foreach(array_chunk($next,500) as $chunk){[$where,$params]=clientPurgeIn('reversalOf',$chunk);foreach(fetchAll('SELECT id FROM CashMovement WHERE '.$where,$params) as $row)if(!isset($seen[$row['id']])){$seen[$row['id']]=true;$found[]=$row['id'];}}$next=$found;}
    $specs['CashMovement']=clientPurgeIn('id',array_keys($seen));
    return $specs;
}

function clientPurgeLocks(string $clientId): array
{
    $routers=fetchAll('SELECT routerId FROM Service WHERE clientId=? AND routerId IS NOT NULL UNION SELECT routerId FROM RouterSecretImport WHERE clientId=? UNION SELECT routerId FROM ClientProvisioning WHERE clientId=? UNION SELECT routerId FROM PppoeAccountEdit WHERE clientId=? UNION SELECT routerId FROM ClientNameSync WHERE clientId=? UNION SELECT routerId FROM DashboardConnection WHERE clientId=? UNION SELECT routerId FROM DashboardTrafficCounter WHERE clientId=? UNION SELECT routerId FROM ClientNetworkObservation WHERE clientId=?',array_fill(0,8,$clientId));
    $olts=fetchAll('SELECT DISTINCT olt_id FROM FiberOnu WHERE client_id=?',[$clientId]);
    $locks=['billing-policy-tick','dashboard-traffic','client:'.$clientId];
    foreach($routers as $r)$locks[]='router:'.$r['routerId'];foreach($olts as $r)$locks[]='fiber:olt:'.$r['olt_id'];
    sort($locks,SORT_STRING);return array_values(array_unique($locks));
}

function clientPurgeGuard(string $clientId): array
{
    $client=fetchOne('SELECT * FROM Client WHERE id=? FOR UPDATE',[$clientId])??throw new HttpError(404,'Cliente no encontrado.','NOT_FOUND');
    if($client['status']!=='RETIRED')throw new HttpError(409,'Solo se pueden eliminar definitivamente clientes retirados.','CLIENT_NOT_RETIRED');
    if(fetchOne("SELECT id FROM Service WHERE clientId=? AND routerId IS NOT NULL AND (desiredState<>'RETIRED' OR appliedState IS NULL OR appliedState<>'RETIRED') LIMIT 1",[$clientId]))throw new HttpError(409,'Completa primero el retiro de sus servicios de red.','CLIENT_PURGE_PENDING');
    foreach(['PppoeAccountEdit','ClientNameSync'] as $table)if(fetchOne("SELECT id FROM $table WHERE clientId=? AND status IN ('PREPARED','UNCERTAIN') LIMIT 1",[$clientId]))throw new HttpError(409,'Confirma primero las ediciones de MikroTik pendientes.','CLIENT_PURGE_PENDING');
    if(fetchOne("SELECT id FROM ClientProvisioning WHERE clientId=? AND status IN ('PREPARED','APPLYING','UNCERTAIN') LIMIT 1",[$clientId])||fetchOne('SELECT id FROM ClientPppAction WHERE activeClientId=? LIMIT 1',[$clientId])||fetchOne('SELECT id FROM ClientPppActivation WHERE activeClientId=? LIMIT 1',[$clientId]))throw new HttpError(409,'Hay una operación de red pendiente de verificar.','CLIENT_PURGE_PENDING');
    if(fetchOne('SELECT id FROM RouterSecretImport WHERE clientId=? AND present=1 LIMIT 1',[$clientId]))throw new HttpError(409,'Todavía hay cuentas importadas presentes. Completa su retiro en MikroTik antes de borrar el historial.','CLIENT_PURGE_PENDING');
    if(fetchOne("SELECT b.serviceId FROM BillingServiceState b JOIN Service s ON s.id=b.serviceId WHERE s.clientId=? AND (COALESCE(b.appliedAction,'ACTIVE')<>'ACTIVE' OR b.desiredAction<>COALESCE(b.appliedAction,'ACTIVE')) LIMIT 1",[$clientId]))throw new HttpError(409,'Hay efectos de facturación de red pendientes de restaurar.','CLIENT_PURGE_PENDING');
    if(fetchOne("SELECT j.id FROM FiberJob j JOIN FiberOnu o ON o.id=j.onu_id WHERE o.client_id=? AND j.status='RUNNING' LIMIT 1",[$clientId]))throw new HttpError(409,'Espera a que termine la consulta de la ONU.','CLIENT_PURGE_PENDING');
    return $client;
}

/** Fingerprint rows incrementally: telemetry history never needs to fit in PHP memory. */
function clientPurgeSnapshot(array $specs): array
{
    $pk=[];foreach(fetchAll("SELECT TABLE_NAME AS t,COLUMN_NAME AS c FROM information_schema.KEY_COLUMN_USAGE WHERE CONSTRAINT_SCHEMA=DATABASE() AND CONSTRAINT_NAME='PRIMARY' ORDER BY TABLE_NAME,ORDINAL_POSITION") as $row)$pk[strtolower($row['t'])][]=$row['c'];
    $hash=hash_init('sha256');$counts=[];$ids=[];
    foreach($specs+['InventoryAsset'=>['clientId=?',$specs['Client'][1]]] as $table=>[$where,$params]){
        $columns=$pk[strtolower($table)]??throw new HttpError(503,'No se pudo verificar el esquema para el borrado.');
        $order=implode(',',array_map(static fn(string $c):string=>'`'.$c.'`',$columns));
        hash_update($hash,$table."\0");$count=0;$pdo=db();$pdo->setAttribute(PDO::MYSQL_ATTR_USE_BUFFERED_QUERY,false);
        try{
            $query=$pdo->prepare('SELECT * FROM `'.$table.'` WHERE '.$where.' ORDER BY '.$order);$query->execute($params);
            while($row=$query->fetch()){
                hash_update($hash,serialize($row));$count++;
                if($table!=='InventoryAsset'&&!in_array($table,['TrafficSample','ClientTelemetrySample','FiberSample','PortalSession'],true)&&isset($row['id']))$ids[$row['id']]=true;
            }
            $query->closeCursor();
        }finally{$pdo->setAttribute(PDO::MYSQL_ATTR_USE_BUFFERED_QUERY,true);}
        $counts[$table]=$count;
    }
    return ['hash'=>hash_final($hash),'counts'=>$counts,'ids'=>$ids];
}

/** Protect unrelated owners even if legacy data contains a cross-client foreign key. */
function clientPurgeForeignKeys(array $specs): array
{
    $edges=fetchAll('SELECT TABLE_NAME AS child,COLUMN_NAME AS columnName,REFERENCED_TABLE_NAME AS parent,REFERENCED_COLUMN_NAME AS parentColumn FROM information_schema.KEY_COLUMN_USAGE WHERE CONSTRAINT_SCHEMA=DATABASE() AND REFERENCED_TABLE_NAME IS NOT NULL');
    $canonical=[];foreach([...array_keys($specs),'InventoryAsset'] as $table)$canonical[strtolower($table)]=$table;
    foreach($edges as &$edge){
        foreach(['child','parent'] as $field)$edge[$field]=$canonical[strtolower($edge[$field])]??$edge[$field];
    }unset($edge);
    foreach($edges as $edge){
        foreach($edge as $name)if(!preg_match('/^[A-Za-z_][A-Za-z0-9_]*$/D',$name))throw new HttpError(503,'El esquema contiene identificadores no admitidos para esta operación.');
        if(!isset($specs[$edge['parent']])||$edge['child']==='InventoryAsset')continue;
        [$parentWhere,$parentParams]=$specs[$edge['parent']];[$childWhere,$childParams]=$specs[$edge['child']]??['0=1',[]];
        $sql='SELECT 1 FROM `'.$edge['child'].'` WHERE `'.$edge['columnName'].'` IN (SELECT `'.$edge['parentColumn'].'` FROM `'.$edge['parent'].'` WHERE '.$parentWhere.') AND NOT ('.$childWhere.') LIMIT 1';
        if(fetchOne($sql,[...$parentParams,...$childParams]))throw new HttpError(409,'Hay registros compartidos o relaciones de otro cliente. Revisa sus vínculos antes de borrar.','CLIENT_PURGE_SHARED');
        if(isset($specs[$edge['child']])){
            $sql='SELECT 1 FROM `'.$edge['child'].'` WHERE ('.$childWhere.') AND `'.$edge['columnName'].'` IS NOT NULL AND `'.$edge['columnName'].'` NOT IN (SELECT `'.$edge['parentColumn'].'` FROM `'.$edge['parent'].'` WHERE '.$parentWhere.') LIMIT 1';
            if(fetchOne($sql,[...$childParams,...$parentParams]))throw new HttpError(409,'Un registro del cliente está vinculado al historial de otro cliente. Revisa ese vínculo antes de borrar.','CLIENT_PURGE_SHARED');
        }
    }
    return $edges;
}

/** Remove complete owned objects, retaining the other customers in batch results. */
function clientPurgeRedact(mixed $value,array $ids): mixed
{
    if(is_string($value))return isset($ids[$value])?ClientPurgeRemoved::VALUE:str_replace(array_keys($ids),'[eliminado]',$value);
    if(!is_array($value))return $value;
    if(!array_is_list($value))foreach(['id','clientId','client_id','serviceId','invoiceId','paymentId','sourceSecretId','operationId'] as $key)if(is_string($value[$key]??null)&&isset($ids[$value[$key]]))return ClientPurgeRemoved::VALUE;
    $out=[];foreach($value as $key=>$item){if(is_string($key)&&isset($ids[$key]))continue;$clean=clientPurgeRedact($item,$ids);if($clean!==ClientPurgeRemoved::VALUE){if(array_is_list($value))$out[]=$clean;else $out[$key]=$clean;}}
    return $out;
}

function clientPurgeRelatedRows(string $table,array $columns,array $ids): array
{
    $rows=[];
    foreach(array_chunk(array_keys($ids),100) as $chunk){$parts=[];$params=[];foreach($columns as $column)foreach($chunk as $id){$parts[]='LOCATE(?,`'.$column.'`)>0';$params[]=$id;}
        foreach(fetchAll('SELECT * FROM `'.$table.'` WHERE '.implode(' OR ',$parts),$params) as $row){
            // Indexed current reads serialize a purge with worker claims and audit edits.
            $fresh=fetchOne('SELECT * FROM `'.$table.'` WHERE id=? FOR UPDATE',[$row['id']]);
            if($fresh!==null)$rows[$fresh['id']]=$fresh;
        }
    }
    ksort($rows,SORT_STRING);return $rows;
}

function clientPurgeJobs(array $ids): array
{
    $delete=[];$update=[];
    do{
        $changed=false;
        foreach(clientPurgeRelatedRows('Task',['payload','result','dedupeKey','error'],$ids) as $id=>$row){
            if(isset($delete[$id]))continue;
            $payload=json_decode($row['payload'],true,512,JSON_THROW_ON_ERROR);$owned=false;
            foreach(['clientId','serviceId','invoiceId','paymentId','operationId'] as $key)if(is_string($payload[$key]??null)&&isset($ids[$payload[$key]]))$owned=true;
            if(isset($payload['ids'])&&is_array($payload['ids'])&&$payload['ids']&&count(array_filter($payload['ids'],static fn(mixed $v):bool=>is_string($v)&&isset($ids[$v])))===count($payload['ids']))$owned=true;
            if($row['status']==='RUNNING')throw new HttpError(409,'Espera a que terminen las tareas que incluyen este cliente.','CLIENT_PURGE_PENDING');
            if($owned){$delete[$id]=$row;unset($update[$id]);$ids[$id]=true;$changed=true;continue;}
            $clean=clientPurgeRedact($payload,$ids);if($clean===ClientPurgeRemoved::VALUE)$clean=[];
            $result=$row['result']===null?null:clientPurgeRedact(json_decode($row['result'],true,512,JSON_THROW_ON_ERROR),$ids);if($result===ClientPurgeRemoved::VALUE)$result=null;
            $error=$row['error'];$dedupe=$row['dedupeKey'];foreach(array_keys($ids) as $known){if(is_string($error))$error=str_replace($known,'[eliminado]',$error);if(is_string($dedupe)&&str_contains($dedupe,$known))$dedupe=null;}
            $update[$id]=['original'=>$row,'payload'=>json_encode($clean,JSON_THROW_ON_ERROR),'result'=>$result===null?null:json_encode($result,JSON_THROW_ON_ERROR),'error'=>$error,'dedupeKey'=>$dedupe];
        }
    }while($changed);
    return ['delete'=>$delete,'update'=>$update,'ids'=>$ids];
}

/** Erase stale session observations while preserving accounts now owned by somebody else. */
function clientPurgeCacheEdits(string $clientId): array
{
    $accounts=fetchAll("SELECT routerId,username FROM Service WHERE clientId=? AND type='PPPOE' AND routerId IS NOT NULL AND username IS NOT NULL UNION SELECT s.routerId,COALESCE(a.username,s.username) AS username FROM RouterSecretImport s LEFT JOIN ClientPppRetiredSecret a ON a.secretId=s.id WHERE s.clientId=?",[$clientId,$clientId]);
    $names=[];foreach($accounts as $account){
        if(fetchOne("SELECT id FROM RouterSecretImport WHERE routerId=? AND username=? AND clientId<>? AND present=1 UNION SELECT id FROM Service WHERE routerId=? AND username=? AND clientId<>? AND desiredState<>'RETIRED' LIMIT 1",[$account['routerId'],$account['username'],$clientId,$account['routerId'],$account['username'],$clientId]))continue;
        $names[$account['routerId']][bin2hex($account['username'])]=true;
    }
    $edits=[];foreach($names as $routerId=>$usernames){
        $cache=fetchOne('SELECT * FROM RouterPppActiveCache WHERE routerId=? FOR UPDATE',[$routerId]);if($cache===null||!is_string($cache['sessions']))continue;
        $rows=json_decode($cache['sessions'],true,64,JSON_THROW_ON_ERROR);if(!is_array($rows)||!array_is_list($rows))continue;$kept=[];$removed=0;
        foreach($rows as $row){if(($row['service']??null)==='pppoe'&&isset($usernames[$row['usernameHex']??''])){$removed++;continue;}$kept[]=$row;}
        if($removed)$edits[$routerId]=['original'=>$cache,'sessions'=>json_encode($kept,JSON_THROW_ON_ERROR),'removed'=>$removed,'count'=>fetchOne('SELECT * FROM RouterPppOnlineCount WHERE routerId=? FOR UPDATE',[$routerId])];
    }
    return $edits;
}

function clientPurgePlan(string $clientId): array
{
    $client=clientPurgeGuard($clientId);$specs=clientPurgeSpecs($clientId);$edges=clientPurgeForeignKeys($specs);$snapshot=clientPurgeSnapshot($specs);$jobs=clientPurgeJobs($snapshot['ids']);
    $audits=clientPurgeRelatedRows('AuditLog',['entityId','details'],$jobs['ids']);$cash=$specs['CashMovement'];
    if(fetchOne('SELECT id FROM CashMovement WHERE '.$cash[0].' AND transferId IS NOT NULL LIMIT 1',$cash[1]))throw new HttpError(409,'Un pago está asociado a una transferencia compartida. Revisa caja antes de borrar.','CLIENT_PURGE_SHARED');
    $cashWhere=preg_replace('/^id\b/','m.id',$cash[0]);
    $effects=fetchAll("SELECT a.id,a.name,a.currency,SUM(CASE WHEN m.type='INCOME' THEN -m.amountCents ELSE m.amountCents END) AS deltaCents FROM CashMovement m JOIN CashAccount a ON a.id=m.accountId WHERE ".$cashWhere.' GROUP BY a.id,a.name,a.currency ORDER BY a.id',$cash[1]);
    foreach($effects as &$effect)$effect['deltaCents']=(int)$effect['deltaCents'];unset($effect);
    $caches=clientPurgeCacheEdits($clientId);
    $hash=hash('sha256',$snapshot['hash'].serialize([$jobs['delete'],$jobs['update'],$audits,$caches]));
    return compact('client','specs','edges','snapshot','jobs','audits','effects','caches','hash');
}

function clientPurgeWithPlan(string $clientId,callable $callback): mixed
{
    $locks=clientPurgeLocks($clientId);
    return apiLocks($locks,static function()use($clientId,$callback,$locks):mixed{
        return tx(static function(PDO $pdo)use($clientId,$callback,$locks):mixed{
            $plan=clientPurgePlan($clientId);
            if(clientPurgeLocks($clientId)!==$locks)throw new HttpError(409,'Los vínculos cambiaron. Actualiza la vista previa.','CLIENT_PURGE_CHANGED');
            return $callback($plan,$pdo);
        });
    });
}

function clientPurgePreview(string $clientId,array $actor): array
{
    return clientPurgeWithPlan($clientId,static function(array $plan)use($actor,$clientId):array{
        $expires=time()+180;$payload=base64urlEncode(json_encode(['clientId'=>$clientId,'actorId'=>$actor['id'],'hash'=>$plan['hash'],'expires'=>$expires],JSON_THROW_ON_ERROR));
        return ['client'=>array_intersect_key($plan['client'],array_flip(['id','name','code'])),'counts'=>$plan['snapshot']['counts'],'tasksDeleted'=>count($plan['jobs']['delete']),'tasksUpdated'=>count($plan['jobs']['update']),'auditsAffected'=>count($plan['audits']),'cashEffects'=>$plan['effects'],'expiresAt'=>gmdate('c',$expires),'token'=>$payload.'.'.hash_hmac('sha256','client-purge:'.$payload,encryptionKey())];
    });
}

function clientPurgeExecute(string $clientId,array $input,array $actor): array
{
    if(array_diff(array_keys($input),['token','confirmation'])||($input['confirmation']??null)!==true)throw new HttpError(422,'Confirma el borrado definitivo antes de continuar.','VALIDATION_ERROR');
    $token=$input['token']??null;
    if(!is_string($token)||strlen($token)>2000||count($parts=explode('.',$token))!==2||!hash_equals(hash_hmac('sha256','client-purge:'.$parts[0],encryptionKey()),$parts[1]))throw new HttpError(409,'Actualiza la vista previa antes de borrar.','CLIENT_PURGE_CHANGED');
    $proof=json_decode(base64_decode(strtr($parts[0],'-_','+/'),true)?:'',true);
    if(!is_array($proof)||($proof['clientId']??null)!==$clientId||($proof['actorId']??null)!==$actor['id']||($proof['expires']??0)<time())throw new HttpError(409,'La confirmación expiró. Actualiza la vista previa.','CLIENT_PURGE_CHANGED');
    return clientPurgeWithPlan($clientId,static function(array $plan,PDO $pdo)use($proof,$clientId,$actor):array{
        if(!hash_equals($plan['hash'],(string)($proof['hash']??'')))throw new HttpError(409,'Los registros cambiaron. Revisa una vista previa nueva antes de borrar.','CLIENT_PURGE_CHANGED');
        foreach($plan['jobs']['delete'] as $id=>$row)$pdo->prepare('DELETE FROM Task WHERE id=?')->execute([$id]);
        foreach($plan['jobs']['update'] as $id=>$row)$pdo->prepare('UPDATE Task SET payload=?,result=?,error=?,dedupeKey=? WHERE id=?')->execute([$row['payload'],$row['result'],$row['error'],$row['dedupeKey'],$id]);
        foreach($plan['audits'] as $id=>$row){
            if(isset($plan['jobs']['ids'][$row['entityId']??'']))$pdo->prepare('DELETE FROM AuditLog WHERE id=?')->execute([$id]);
            else{$details=$row['details']===null?null:clientPurgeRedact(json_decode($row['details'],true,512,JSON_THROW_ON_ERROR),$plan['jobs']['ids']);if($details===ClientPurgeRemoved::VALUE)$details=null;$entityId=is_string($row['entityId'])?str_replace(array_keys($plan['jobs']['ids']),'[eliminado]',$row['entityId']):null;$pdo->prepare('UPDATE AuditLog SET entityId=?,details=? WHERE id=?')->execute([$entityId,$details===null?null:json_encode($details,JSON_THROW_ON_ERROR),$id]);}
        }
        foreach($plan['caches'] as $routerId=>$cache){$pdo->prepare('UPDATE RouterPppActiveCache SET sessions=? WHERE routerId=?')->execute([$cache['sessions'],$routerId]);if($cache['count']!==null)$pdo->prepare('UPDATE RouterPppOnlineCount SET pppoeCount=? WHERE routerId=?')->execute([max(0,(int)$cache['count']['pppoeCount']-$cache['removed']),$routerId]);}
        $pdo->prepare("UPDATE InventoryAsset SET clientId=NULL,state='AVAILABLE',location=NULL WHERE clientId=?")->execute([$clientId]);
        $remaining=$plan['specs'];$deleted=[];
        while($remaining){$progress=false;
            foreach($remaining as $table=>[$where,$params]){
                $blocked=false;foreach($plan['edges'] as $edge)if($edge['parent']===$table&&$edge['child']!==$table&&isset($remaining[$edge['child']])){$blocked=true;break;}
                if($blocked)continue;
                if($table==='CashMovement'){
                    $removed=0;do{$statement=$pdo->prepare('DELETE m FROM CashMovement m LEFT JOIN CashMovement child ON child.reversalOf=m.id WHERE ('.preg_replace('/^id\b/','m.id',$where).') AND child.id IS NULL');$statement->execute($params);$n=$statement->rowCount();$removed+=$n;}while($n>0);$deleted[$table]=$removed;
                }else{$statement=$pdo->prepare('DELETE FROM `'.$table.'` WHERE '.$where);$statement->execute($params);$deleted[$table]=$statement->rowCount();}
                unset($remaining[$table]);$progress=true;
            }
            if(!$progress)throw new HttpError(409,'Hay un ciclo de relaciones que requiere revisión. No se borró ningún registro.','CLIENT_PURGE_SHARED');
        }
        unset($GLOBALS['nexo_ppp_archived'],$GLOBALS['nexo_client_notes'],$GLOBALS['nexo_client_ip_cache']);
        // Operational audit has no client ID, code, name or recoverable customer snapshot.
        audit('client.purge','System',null,$actor['id']);
        return ['deleted'=>true,'counts'=>$deleted,'cashEffects'=>$plan['effects']];
    });
}

function clientPurgeDispatch(string $method,string $route): bool
{
    if(!preg_match('#^/clients/([a-f0-9]{24})/purge(/preview)?$#D',$route,$match))return false;
    $actor=permit('ADMIN');
    if(function_exists('set_time_limit'))set_time_limit(180);
    if($method==='GET'&&!empty($match[2]))json(clientPurgePreview($match[1],$actor));
    if($method==='POST'&&empty($match[2])){ignore_user_abort(true);json(clientPurgeExecute($match[1],body(),$actor));}
    throw new HttpError(405,'Método no permitido.');
}
