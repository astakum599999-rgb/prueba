# API propia de GIGARED ISP para XAMPP v3.1.0

Base local: `http://localhost/nexoisp/api/v1`. Los cuerpos son JSON. Los importes se expresan como enteros en centavos y cada moneda usa tres letras mayúsculas. Las fechas de calendario usan `YYYY-MM-DD`; los instantes recibidos requieren zona horaria (`Z` o desplazamiento). La persistencia y los informes usan UTC.

El administrador crea claves personales desde **Claves de API**. Una integración envía `Authorization: Api-Key <TOKEN>`; hereda el rol de su propietario y puede revocarse. El inicio web utiliza cookies HttpOnly; las escrituras con sesión requieren un `Origin` autorizado: el configurado, uno de `allowed_web_origins` o la IP privada exacta del socket Apache con protocolo, Host y puerto coincidentes. No se confía en DNS ni en encabezados reenviados para ampliar esa excepción local. Consulta `RED-LOCAL.txt`. El portal de clientes tiene su propia sesión y sus rutas no aceptan una clave administrativa como identidad de cliente.

Los listados usan `page`, `pageSize` (máximo 100) y, donde corresponde, `search`. Responden `{results, count, page, pageSize}`. Los errores contienen `{error:{code,message}}`. Es un contrato propio; no ofrece compatibilidad completa con las rutas ni los JSON de WispHub.

## Servicios de facturación local

La capacidad `localBillingServices` se habilita tras aplicar `015_local_billing`. ADMIN y BILLING pueden crear una asociación mediante `POST /billing-services` con `{clientId,planId,billingDay:1,dueDays:10,graceDays:3}`. Los días admiten 1–28 y los plazos 0–90. Requiere cliente no retirado, plan activo y tarifa válida/configurada. Repetir la misma asociación activa cliente/plan/calendario devuelve200 y su mismo ID; un calendario distinto requiere editarla, con409 `BILLING_SERVICE_EXISTS`.

`PATCH /billing-services/:id` admite sólo `planId,billingDay,dueDays,graceDays`. No acepta cliente, IP, router, tipo, credenciales o estado técnico. Los campos de red se guardan nulos; `LocalBillingService` marca permanentemente el registro. El DTO de `/services`, facturas y portal expone `billingOnly:true`; el router es`null`. No se encolan trabajos ni se abre una conexión al equipo.

Los servicios locales participan en la emisión manual existente `POST /invoices {serviceId,period}` y en pagos/promesas. No se reconectan ni suspenden por esos registros aun cuando la configuración global permitiera escrituras. API y worker rechazan sus operaciones de red con409 `BILLING_ONLY_SERVICE`, y el autocorte los excluye. No se convierte una asociación local en un servicio MikroTik mediante la edición genérica. Las facturas emitidas mantienen sus importes y moneda. Consulta `FACTURACION-LOCAL.txt`.

## Modo de red solo lectura

`/auth/me` anuncia las capacidades `networkReadOnly: true`, `secretImport: true` y `profileImport: true`. El valor predeterminado también protege instalaciones anteriores sin esa opción en su configuración. No hay un control en el panel para activar escrituras.

Las acciones que crean, editan, retiran, sincronizan, suspenden o reactivan servicios de red, configuran firewall o reintentan trabajos mutantes se rechazan con **409 `NETWORK_READ_ONLY`** antes de aplicarse. El controlador y los transportes bloquean además los comandos de modificación. Los datos administrativos locales y las consultas siguen disponibles. Registrar o probar un router no aplica configuración al equipo.

El worker nuevo sólo reclama los tipos de trabajo permitidos de lectura. No procesa los trabajos antiguos que modificarían la red ni programa facturación automática/autocorte. Los endpoints manuales `/billing/run` y `/billing/autocut` también rechazan con 409. Los pagos, anulaciones y promesas conservan su efecto financiero local sin generar reconexiones ni modificar estados de servicios.

## IPs PPP activas y acceso en nueva pestaña

La capacidad `clientIpLive` anuncia el módulo. `POST /clients/ip-addresses/active` acepta únicamente `{clientIds:[id,...]}` (máximo100) para ADMIN/TECHNICIAN, con origen válido en sesiones y límite120 solicitudes/minuto. No es una modificación RouterOS. Agrupa las cuentas de esos clientes, lee `/ppp/active` una vez por router con propiedades `.id,name,address,service` y comparte un caché15s entre pestañas. Procesa hasta5 routers vencidos por llamada.

Devuelve `{intervalSeconds:15,expiresAfterSeconds:30,serverTime,processed,results:[{clientId,addresses,status,stale,observedAt,message}],routers,errors}`. Los estados son `FRESH`, `NO_SESSION`, `NO_ACCOUNT`, `PENDING` y `STALE`. Las identidades se comparan por bytes exactos y las cuentas ambiguas no se asocian a otro cliente. No se solicitan contraseñas. Los fallos conservan la observación interna y devuelven IPs activas vacías/caducadas; el navegador también retira observaciones vencidas a los30s. Una cuenta sin sesión no recibe una IP inventada.

El listado normal de clientes sigue sirviendo IPs configuradas sin consultar RouterOS. El panel visible consulta el lote cada15s; no hay botón Consultar IP actual. El endpoint individual anterior `GET /clients/:id/ip-addresses/active` permanece para compatibilidad y conserva sus permisos y límite30/minuto; la interfaz nueva no lo llama por cada fila.

Pulsar una IP abre directamente HTTP:80 en una pestaña nueva mediante un enlace con `target="_blank"`, `noopener noreferrer` y política `no-referrer`. El listado permanece abierto; no hay iframe ni diálogo de acceso. Para HTTPS u otro puerto se ajusta la barra de esa pestaña. Es navegación directa desde el PC, sin proxy ni contraseñas en URLs. La conectividad, autenticación y certificados del dispositivo siguen siendo necesarios. Consulta IP-CLIENTES.txt e IP-AUTOMATICA.txt.

## Actualización automática de secrets

La capacidad `secretAutoSync` identifica este módulo nativo. `GET /routers/secrets/auto-sync` requiere una sesión administrativa o clave de personal válida y devuelve `{intervalSeconds:30,mode:"worker-or-open-panel",networkReadOnly:true,serverTime,routers:[{routerId,routerName,enabled,status,lastStartedAt,lastSuccessAt,nextRunAt,lastErrorCode,lastError,consecutiveFailures,lastSummary}]}` sin consultar el router ni incluir credenciales.

`POST` a la misma ruta con `{}` requiere ADMIN o TECHNICIAN y el origen permitido para sesiones. Procesa como máximo un router vencido y agrega `{processed,changed,failed,deferred}` al estado. Una reserva persistida y los bloqueos del router impiden lecturas duplicadas entre pestañas y worker. El límite es120 solicitudes/minuto por actor; no permite modificar la frecuencia mediante parámetros. Los routers sin importación previa no se consultan.

El worker PHP hace la misma lectura incluso en modo de red solo lectura. El panel visible impulsa el proceso sin worker y refresca la tabla al detectar observaciones nuevas; pausa mientras se editan formularios. Para sincronización con el navegador cerrado utiliza `INICIAR-WORKER.bat`. El intervalo normal es30 segundos tras cada lectura; errores aumentan la espera hasta300 segundos. Los cambios manuales pendientes de reconciliar aplazan la importación. No se ejecutan comandos de configuración ni se piden contraseñas masivamente. Consulta `ACTUALIZACION-AUTOMATICA.txt`.

## Importar secrets a Clientes

**ADMIN o TECHNICIAN** puede ejecutar `POST /routers/:id/import-secrets` con cuerpo `{}`. Es una importación a la base local; todas las operaciones hacia MikroTik son lecturas.

La respuesta 200 contiene:

```json
{
  "router": { "id": "identificador del router", "name": "nombre del router" },
  "total": 12,
  "created": 9,
  "updated": 1,
  "unchanged": 2,
  "missing": 0,
  "namesUpdated": 1,
  "networkReadOnly": true
}
```

El ejemplo ilustra la forma del contrato, no datos incluidos en el ZIP. `total` cuenta las entradas de la lectura actual; `missing` cuenta las identidades anteriores ausentes de una lectura completa. No se eliminan sus clientes.

La consulta es `/ppp/secret/print` con lista explícita `.id,name,service,profile,remote-address,local-address,caller-id,disabled,comment`. Se incluyen los secrets locales de cualquier tipo PPP, incluso deshabilitados. No se solicita `password`; una respuesta que agregue propiedades no autorizadas tampoco las conserva. REST puede usar POST `/ppp/secret/print` para esa selección de propiedades: es una consulta, no una creación.

Se admiten hasta 20 000 entradas por router, sujetas a los límites de transporte. Una respuesta inválida, incompleta o superior al límite se rechaza sin guardar un inventario parcial. No se crean servicios gestionados, planes, facturas ni tareas de red. El nombre se toma del comentario no vacío del secret, normalizando espacios y limitándolo a 200 caracteres; el comentario completo permanece en la observación. Cada cliente conserva un código local `MT-` derivado de su identidad binaria original.

La identidad es router+usuario exacto, con distinción de mayúsculas y espacios. Repetir la misma lectura actualiza observaciones sin duplicar; el mismo usuario en routers diferentes representa clientes separados. No se fusionan clientes manuales por nombre. Al reimportar, el comentario no vacío es autoritativo para `Client.name`: reemplaza también nombres anteriores o editados localmente aunque no cambie el snapshot. Se conservan correo, teléfono, documento, dirección y los demás datos administrativos. Un comentario vacío conserva el nombre existente; para altas nuevas se usa el usuario como alternativa. `namesUpdated` cuenta renombres de clientes existentes y se incluyen en `updated`. Un nombre idéntico no actualiza `Client.updatedAt` por sí solo. Renombrar el usuario PPP representa una identidad nueva. El router con historial importado no puede reasignarse silenciosamente a otro equipo.

Los DTO de `/clients` y `/clients/:id` agregan `routerSecrets`, con `routerId`, `routerName`, `username`, `remoteId`, `pppService`, `profile`, `remoteAddress`, `localAddress`, `callerId`, `disabled`, `comment`, `present`, `firstSeenAt` y `lastSeenAt`, sin contraseña PPP. También existe `GET /clients/:id/router-secrets` para consultar esas observaciones, sujeto a autenticación. La búsqueda de clientes incluye usuario, perfil, dirección remota y nombre del router.

`disabled` expresa la habilitación del secret, no si tiene una sesión activa. La dirección puede estar vacía o contener un pool: no se convierte en una IP de sesión supuesta. La fuente no incluye RADIUS externo ni usuarios exclusivos de Hotspot. En el panel, **Clientes → Importar secrets de MikroTik** permite elegir uno o todos los routers registrados; consulta cada equipo secuencialmente e informa sus resultados por separado, sin reintentos automáticos.

## Importar perfiles PPP a Planes de Internet

**ADMIN o TECHNICIAN** puede ejecutar `POST /routers/:id/import-profiles` con cuerpo `{}`. Sólo consulta `/ppp/profile/print` con `.id,name,rate-limit,local-address,remote-address,comment`; no configura perfiles o servidores PPPoE.

La respuesta 200 incluye `{router,total,created,updated,unchanged,missing,plansCreated,plansUpdated,pending,networkReadOnly:true}`. Los primeros contadores describen observaciones; `plansCreated` y `plansUpdated` describen planes locales vinculados. `pending` cuenta perfiles que necesitan velocidad/nombre utilizable o tarifa explícita. Una lectura admite hasta 20 000 perfiles por router dentro de los límites del transporte y valida la lista completa antes de persistir.

`GET /router-profiles` lista las observaciones con paginación y búsqueda; admite filtro `routerId`. Sus DTO incluyen `id`, `routerId`, `routerName`, `profileName`, `rateLimit`, `downloadKbps`, `uploadKbps`, `rateStatus`, `status`, `reason`, `localAddress`, `remoteAddress`, `comment`, `planId`, `priceConfigured`, `present`, `firstSeenAt` y `lastSeenAt`. Las velocidades pueden ser `null` cuando no se conocen; `planId` puede ser `null` cuando no se puede generar un plan válido. Los planes vinculados exponen la observación como `Plan.profileImport`.

La identidad conserva router+nombre original binario exacto. Para la velocidad base sólo se interpreta el primer componente de `rate-limit`: Rx es **subida** del cliente y Tx es **bajada**. Una tasa sin barra es simétrica. K/M/G son unidades decimales y las tasas se convierten a kbps únicamente si el resultado entero y su rango son representables. Vacío, cero, ilimitado, tasa no interpretable o nombre que requiere revisión quedan señalados, sin inventar velocidades ni sustituir el perfil original.

Un perfil utilizable crea un plan local **inactivo**, con `priceConfigured:false` y presentación **Precio pendiente**. El valor provisional `Plan.priceCents=0` no es una tarifa comercial. Para configurarla se deben enviar explícitamente `priceCents` y `currency` en el `PATCH /plans/:id`; cero es admisible como precio gratuito sólo cuando se especifica deliberadamente junto con la moneda. Se rechaza activar o facturar un plan pendiente. Los códigos incluyen `PROFILE_PRICE_PENDING`, `PROFILE_RATE_PENDING` y `PROFILE_PLAN_CONFLICT` cuando se intenta sustituir su perfil de origen.

Los precios, moneda, nombre comercial y activación locales se conservan al reimportar; las velocidades base se actualizan desde el perfil. Si una observación desaparece o deja de ser utilizable, el plan vinculado se desactiva localmente. Las velocidades y `pppoeProfile` del plan importado no se sustituyen por valores manuales; para otra regla se crea un plan local independiente.

El `status` público distingue `PRICE_PENDING`, `RATE_PENDING`, `READY` y `ABSENT`. `READY` indica observación utilizable y tarifa configurada; no implica un plan activo, servicios facturables ni cambios en MikroTik. `rateStatus` detalla casos como `NO_RATE`, `UNLIMITED`, `UNSUPPORTED_RATE` y `NAME_REVIEW`. No se crean servicios, facturas ni tareas de red al importar perfiles.

## Recursos administrativos

| Ruta | Operaciones y propósito |
| --- | --- |
| `/auth/login`, `/auth/me`, `/auth/logout` | Entrar con correo y contraseña, consultar sesión y salir. |
| `/clients`, `/plans`, `/routers`, `/services` | Listar, crear y consultar recursos; `PATCH /:id` para edición permitida. Las operaciones de red mutantes están bloqueadas; se conserva el historial anterior. |
| `/routers/:id/test` | Encolar prueba de conexión. No devuelve contraseñas guardadas. |
| `/services/:id/diagnostics` | Diagnóstico desde el router mediante tarea. |
| `/services/:id/traffic` | Leer muestras reales guardadas y sus fechas. La ausencia de muestras no se rellena con tráfico simulado. |
| `/network/bulk-diagnostics` | `POST {ids:[serviceId,...]}`: diagnóstico por servicio, hasta 100 identificadores únicos. |
| `/tasks`, `/tasks/:id` | Consultar cola y resultados; las operaciones continúan en el worker. |
| `/invoices`, `/payments`, `/tickets` | Facturación, registro validado de pagos y soporte. El pago conserva su registro local sin reconexión en modo lectura. |
| `/users`, `/keys`, `/audit` | Personal y roles, claves revocables y auditoría, según permisos. |

Las pruebas de conexión y los diagnósticos permitidos son asíncronos y se consultan en **Operaciones de red**. Un trabajo aceptado no demuestra que terminó correctamente. La importación de secrets se realiza en la solicitud web y sólo guarda datos locales; no encola aprovisionamiento. Las acciones mutantes de versiones anteriores están bloqueadas en este modo.

## Ampliaciones de facturación

Administración y facturación pueden escribir estos recursos; los usuarios técnicos y de lectura conservan únicamente los permisos de consulta definidos por cada módulo.

| Ruta | Cuerpo de creación o comportamiento |
| --- | --- |
| `/service-charges` | `{serviceId,name,quantity,unitCents,recurrence}`; frecuencia `MONTHLY` o `ONE_TIME`. Los cargos únicos se consumen junto con su factura en una transacción. |
| `/service-discounts` | `{serviceId,name,kind,value,startOn,endOn}`. `FIXED` usa centavos; `PERCENT` usa puntos básicos (1000 = 10 %). Un descuento activo por servicio; no vuelve negativa la base del plan. |
| `/payment-promises` | `{invoiceId,amountCents,currency,promisedUntil}`. La fecha es inclusiva en UTC y el importe debe cubrir el saldo de esa factura. Las demás facturas vencidas siguen contando para el corte. |
| `/payment-promises/:id/cancel` | Cancelar un compromiso activo y conservar su historial; en lectura `autocutTaskId` es `null`, sin programar corte. |
| `/billing/prorate-preview` | `{serviceId,period,startOn,endOn}`; obtener líneas y total de la primera factura proporcional sin emitirla. |
| `/billing/prorate` | Mismo cuerpo; emitir únicamente si el servicio no tiene una factura anterior. Días inclusivos del mes real, cargos adicionales completos, descuento sobre la base proporcional. |

Las líneas de facturas emitidas son instantáneas: editar un plan, un cargo o un descuento no recalcula una factura existente. Las facturas antiguas reciben una línea `LEGACY` con su importe original al actualizar.

## Clientes, contratos y pagos informados

| Ruta del personal | Comportamiento |
| --- | --- |
| `/portal-accounts` | Administración/facturación crea `{clientId,username,password}`; contraseña propia de al menos 12 caracteres. `PATCH /:id` permite cambiar usuario, contraseña o activación. |
| `/contracts` | Crear `{serviceId,title,terms}`. Guardar condiciones y datos del servicio; las condiciones de un contrato aceptado no se editan. |
| `/payment-reports` | Consultar pagos pendientes de revisión. `POST /:id/approve` registra el pago una sola vez; `POST /:id/reject {reason}` conserva el motivo. |

Portal web: `http://localhost/nexoisp/portal/`. Sus rutas son `/portal/auth/login` con `{username,password}`, `/portal/auth/me`, `/portal/auth/logout`, `/portal/summary`, `/portal/invoices`, `/portal/payments`, `/portal/tickets`, `/portal/contracts` y `/portal/payment-reports`. Todas las consultas filtran por el cliente autenticado.

El cliente puede crear tickets, comentar los suyos, informar un pago con `{invoiceId,amountCents,currency,reference,note}` y aceptar un contrato mediante `POST /portal/contracts/:id/accept {name}`. Informar un pago no lo acredita: requiere aprobación del personal. La aceptación con nombre escrito registra una constancia, sin firma certificada.

Impresión: `/nexoisp/portal/documento.php?type=invoice|receipt|contract&id=...`, con la sesión correspondiente y control de propiedad. El navegador permite imprimir o guardar PDF. Las facturas y recibos son documentos administrativos, sin timbrado fiscal ni conexión bancaria.

## Caja, inventario, agenda e informes

| Ruta | Contrato principal |
| --- | --- |
| `/company-settings` | Perfil comercial del ISP; solo ADMIN lo modifica. |
| `/cash-accounts` | `{name,currency,openingCents}`; moneda y saldo inicial no se reescriben. |
| `/cash-movements` | `{accountId,type,amountCents,category,description,occurredAt?,paymentId?}`; `INCOME` o `EXPENSE`. Vincular un pago requiere importe y moneda exactos. |
| `/cash-movements/:id/reverse` | `POST {reason}`: contrapartida inmutable; no borra ni altera el movimiento inicial. |
| `/cash-transfers` | `{fromAccountId,toAccountId,amountCents,description,externalReference}`; dos asientos atómicos de igual moneda y referencia idempotente. |
| `/inventory-assets` | `{name,category,serialNumber?,macAddress?,brand?,model?,location?,costCents,currency}`; equipos individuales con historial de estados. |
| `/inventory-assets/:id/assign` | `{clientId,note?}`; acciones `/return`, `/repair`, `/retire` conservan movimientos y validan transiciones. |
| `/inventory-movements` | Historial de entrega, devolución y estados del equipo. |
| `/installations` | Cliente o prospecto, dirección, zona/GPS, técnico, fecha, plan/router previsto, estimado y notas. Estados `REQUESTED`, `SCHEDULED`, `IN_PROGRESS`, `COMPLETED`, `CANCELLED`. Una visita completada no provisiona automáticamente un servicio. |
| `/reports?from=...&to=...` | Facturación y cobros del intervalo, agrupados por moneda; cartera pendiente y vencida actual, cuentas y zonas. No reconstruye saldos históricos. |
| `/exports/clients.csv`, `/services.csv`, `/invoices.csv`, `/payments.csv`, `/tickets.csv`, `/cash.csv`, `/inventory.csv` | Prefijo común `/exports/` en cada nombre; columnas autorizadas, hasta 50 000 filas, sin contraseñas y con protección de fórmulas de hoja de cálculo. |

Los roles ADMIN/BILLING operan caja; VIEWER puede consultarla y TECHNICIAN no accede a sus recursos financieros. Inventario e instalaciones admiten trabajo de técnicos. El control se verifica en el servidor, independientemente de los botones visibles.

El código completo de cada contrato está en `app/api.php`, `secret-import.php`, `profile-import.php`, `portal.php`, `billing.php`, `finance.php` y `operations.php`. No se incluyen adaptadores ficticios para proveedores externos. El alcance comparado y las fuentes consultadas están en `MATRIZ-WISPHUB.md` y `REFERENCIAS-WISPHUB.md`.

## Corrección de texto PPP en 2.1.1

El importador conserva la identidad binaria exacta del usuario en la base local. Sus DTO y el nombre inicial del cliente usan presentación UTF-8; los bytes heredados de Socket se interpretan como Windows-1252 cuando no son UTF-8. Los controles quedan visibles, sin borrar ni fusionar identidades. El UTF-8 imprimible anterior conserva sus fingerprints. Una respuesta rechazada devuelve `INVALID_ROUTER_RESPONSE` con el campo y la posición de la fila, sin valores privados. No se modifican los SQL aplicados ni la política de red en lectura.

## Demostración aislada

`/nexoisp/demo/` sirve una página estática con datos ficticios y reloj virtual; también puede abrirse directamente `demo/index.html`. No utiliza esta API, credenciales, base real ni conexión a MikroTik. Permite explorar factura, suspensión, promesa y pago mediante estados simulados. No habilita acciones mutantes del panel; la suspensión real sigue bloqueada por `NETWORK_READ_ONLY`. El recorrido se documenta en `DEMOSTRACION.txt`.

## Moneda local en 2.2.1

`capabilities.defaultCurrency` refleja la moneda de Mi empresa; PEN es el valor predeterminado de esta entrega y se presenta como S/. La migración `008_currency_pen` actualiza sólo esa preferencia. Las monedas explícitas de registros anteriores permanecen intactas. Los importes siguen expresados en centavos y no se realiza conversión de divisas. Los planes importados pendientes de tarifa usan la preferencia vigente al completar su precio; los planes ya configurados conservan su moneda al editar.


## Fibra óptica nativa

El módulo se anuncia mediante `capabilities.fiber:true` y conserva `Authorization: Api-Key <TOKEN>` o la sesión de personal y el control Origin existentes. No se afirma compatibilidad binaria con una API privada de AdminOLT. La investigación pública y diferencias se documentan en `INVESTIGACION-ADMINOLT.md` y `FTTH.txt`.

| Ruta propia | Comportamiento |
| --- | --- |
| GET `/fiber/summary`, `/fiber/map`, `/fiber/capabilities` | Contadores numéricos, topología y capacidades efectivas; sin conectar a dispositivos. |
| GET `/fiber/{olts,onus,pons,vlans,profiles,zones,naps,splitters,links,queries,jobs,drafts}` | Listados `{results,count,page,pageSize}`, búsqueda y filtros por relaciones/estado. |
| POST/PATCH `/fiber/{olts,pons,vlans,profiles,zones,naps,splitters,links,queries}` | Metadatos locales validados, sin aplicar configuración en equipos. OLT/consultas/enlaces requieren ADMIN; el resto permite ADMIN/TECHNICIAN. |
| PATCH `/fiber/onus/:id` | Nombre, cliente, zona, NAP/puerto, notas y coordenadas locales. No modifica estado observado, SN ni hardware. |
| POST `/fiber/olts/:id/import` | `{pons:[],onus:[],complete:false}`: validación completa y persistencia atómica por OLT+SN o posición PON. Fuente USER_IMPORT diferenciada de DEVICE. |
| POST `/fiber/olts/:id/{test,sync,discover}` | `{}` encola consulta real, responde202 y devuelve la tarea durable. Se deduplican tareas pendientes. |
| POST `/fiber/onus/:id/{signal,diagnostic}` | Encola lectura de una ONU usando una consulta del modelo y su contexto físico. |
| POST `/fiber/tick` | ADMIN/TECHNICIAN procesa como máximo una tarea de lectura. El panel y worker comparten la cola. |
| GET `/fiber/onus/:id`, `/fiber/onus/:id/samples` | Detalle y muestras de potencia/tráfico con fechas UTC y procedencia. |
| GET `/fiber/clients/:id/onus` | ONUs vinculadas explícitamente al cliente. |
| POST `/fiber/onus/:id/preview` | `{action,configuration}` crea una preparación local cifrada. Acciones AUTHORIZE, REBOOT, WIFI, SUSPEND, REACTIVATE, DELETE. |
| POST `/fiber/drafts/:id/cancel` | Cancela una preparación local; no modifica la ONU. |
| POST `/fiber/drafts/:id/commit` y endpoints directos de acciones |409 NETWORK_READ_ONLY antes de conectar. El módulo no habilita un escritor universal al desactivar la protección. |

### Campos principales

- OLT: `name,vendor,model,software_version,host,transport,port,username,password,snmp_community,ssh_fingerprint,zone_id,latitude,longitude,poll_enabled,poll_interval`. Fabricantes HUAWEI/ZTE/FIBERHOME/VSOL/GENERIC. Transporte SSH/TELNET/SNMP. Credenciales omitidas en DTO; `has_password` y `has_snmp_community` indican presencia.
- ONU: `sn,mac,onu_type,frame,slot,pon_port,onu_index,pon_id,olt_id,status,authorization,mode,wan_mode,vlan,profile_id,rx_power,tx_power,temperature,distance,client_id,zone_id,nap_id,nap_port,latitude,longitude,notes,source,present,last_seen_at`. ONLINE/OFFLINE/LOS/UNKNOWN son observaciones, no efectos de guardar una preparación. `fresh` exige lectura DEVICE reciente.
- Perfil: `olt_id,name,kind,profile_index,tcont,gem_port,download_kbps,upload_kbps,fixed_kbps,assured_kbps,maximum_kbps,priority`. Un registro administrativo no crea esos perfiles en la OLT.
- NAP: `name,zone_id,capacity,latitude,longitude,description`. Un puerto ocupado no puede asignarse otra vez. Splitters validan jerarquías sin ciclos; enlaces validan extremos y ocupación física.
- Consulta: `olt_id,name,kind,command,pattern,oid,enabled`. Sólo show/display de una línea; se rechazan configuración, operadores y consultas de credenciales. Variables numéricas `{frame}`, `{slot}`, `{port}`, `{onu_index}` también admiten doble llave. Parsers PCRE con capturas nombradas, texto normalizado a LF, sin ANSI y límites de tamaño/tiempo.

SSH verifica una huella SHA256 antes de autenticar. SNMPv2c sólo GET/GETNEXT, sin SET; conserva enteros negativos y Counter64 sin pérdida de precisión. La prueba de conexión usa MIB-II estándar; las tablas ópticas necesitan OIDs del firmware y parsers configurados. No se inventan valores de potencia ni datos de tráfico.

Las preparaciones aceptan VLAN, perfiles y configuración Bridge/Router, WAN DHCP/PPPoE/STATIC, usuario/contraseña PPP, SSID/clave WiFi, cliente/NAP y ubicación. Las claves sólo se guardan cifradas; el resumen no las muestra. Una preparación no reserva ni autoriza físicamente una ONU y su estado sigue sin aplicar.

El modelo VSOL V1600GS-F anuncia en su DTO `model_capabilities`: Single-PON GPON, un PON, Telnet/SNMP documentados, consultas vendor requeridas y perfiles de velocidad informativos. La versión real de firmware no se conoce todavía y no se certificaron comandos de inventario ni SSH para ese equipo.

## Eliminación financiera (3.2.0)

Requiere migración016 y rol ADMIN/BILLING. Sesiones con CSRF; API keys conservan su autorización. Sin cuerpo de solicitud.

| Método y ruta | Operación |
| --- | --- |
| `DELETE /invoices/:id` | Eliminar factura sin pagos activos ni reportes pendientes. Cancela sus promesas activas. |
| `DELETE /payments/:id` | Eliminar pago y recalcular saldo. Requiere reversión previa de ingresos de Caja relacionados. |
| `DELETE /billing-services/:id` | Eliminar servicio local sin facturas ni contratos vigentes. |
| `DELETE /services/:id` | Mismo flujo para servicios marcados como locales; los de red mantienen su flujo anterior. |

HTTP204 en éxito, incluidas repeticiones; HTTP409 ante relaciones que impiden eliminar; HTTP410 al consultar registros eliminados. Los listados, totales, CSV y portal los excluyen. Los registros y su marcador de auditoría se conservan. La combinación servicio/período y los cargos únicos de facturas eliminadas siguen reservados (`INVOICE_PERIOD_DELETED`); una referencia de pago eliminada no puede acreditarse de nuevo (`PAYMENT_DELETED`). Ninguna de estas eliminaciones locales crea tareas de red ni modifica equipos.

## Búsqueda e inicio local (3.3.0)

`GET /clients?q=<texto>&excludeRetired=true&page=1&pageSize=10` devuelve coincidencias por nombre/código/documento/correo y omite retirados antes de paginar. `excludeRetired` admite únicamente `true` o `false`; omitirlo conserva el listado anterior. El formulario espera2 caracteres y hace una consulta tras250ms sin teclear.

`POST /billing-services` y `PATCH /billing-services/:id` admiten `billingStartOn: "2026-10-15"` opcional (fecha real2000–2100). `billingDay` conserva su rango1–28 y define el día mensual; `dueDays` y `graceDays` no cambian. Omitir la fecha mantiene el inicio existente; cadena vacía/null son inválidos. Los DTOs de Service devuelven `billingStartOn` como fechaISO o null para calendario anterior.

El inicio explícito reemplaza la fecha de alta únicamente al calcular el calendario local. Permite fechas anteriores al alta sin reescribir Service.createdAt ni facturas emitidas; no permite emitir meses anteriores ni anticipar una fecha futura. La primera emisión usa la mayor entre el inicio y el día mensual programado. Las asociaciones existentes sin inicio conservan su cálculo anterior. Requiere017_local_billing_start. Sin tareas de red ni cambios a equipos.

## Calendario por instalación (3.4.0; sustituye el calendario explícito de3.3)

POST/PATCH `/billing-services`: `clientId` sólo al crear, `planId`, `billingStartOn` (fecha instalada) y `graceDays`0–90. Con fecha explícita se rechazan overrides `billingDay`/`dueDays`422 (`AUTOMATIC_BILLING_CALENDAR`); el panel nuevo los omite. Servicios legacy sin fecha siguen aceptando su calendario anterior por compatibilidad.

DTOService: `billingCycle=INSTALLATION_ANNIVERSARY`, `paymentDay` díaoriginal1–31, `invoiceLeadDays=2`. `billingDay` es alias derivado; no configura el calendario. `billingStartOn` se reutiliza, sin SQLnuevo. Primer período: mesposterior ainstalación, identifica mesdevencimiento. Nuevo vencimiento=aniversario mensual con clamp al último día; emitido2díasantes; `graceUntil` es límiteEXCLUSIVO traseldía de pago y los días adicionales. En America/Lima, instalación2026-10-01/gracia3 produce emisión2026-10-30T05:00:00Z, vencimiento2026-11-01T05:00:00Z y límite2026-11-05T05:00:00Z.

No se emite antes de la fecha programada ni durante el mes de instalación. Prorrateo anterior rechazado409 (`ANNIVERSARY_PRORATION_UNSUPPORTED`). Las facturas emitidas se devuelven sin recalcular al repetir POST; las eliminadas mantienen reserva409. El worker agenda cada minuto `BILLING_RUN` con payload`{scope:"LOCAL_ONLY",scheduled:true}` y deduplicación; sólo ese alcance financiero es procesable en lectura. Ignora IDs/fechas inyectados en payload y selecciona únicamente asociaciones locales con instalación. Las tareas generales de red siguen bloqueadas.

## Conteo PPPoE online (3.5.0)

GET `/dashboard` incluye `onlinePppoe` desde caché, sin I/O de router. GET `/dashboard/pppoe-online` devuelve el mismo agregado; POST a esa ruta con cuerpo vacío `{}` actualiza las lecturas vencidas (hasta5routers por solicitud). Todos los roles de personal autenticado pueden ver este agregado; las sesiones conservan CSRF/origen y el acceso detallado a IP mantiene sus permisos anteriores.

Respuesta: `count` entero o null, `status` FRESH/PARTIAL/STALE/EMPTY/PENDING, `stale`, `observedAt`/`serverTime` ISO UTC, `intervalSeconds=15`, `expiresAfterSeconds=30`, `coveredRouters`, `totalRouters`, `processed`. Sólo hay count cuando TODOS los routers reales configurados tienen observación válida. Cero confirmado es válido; falta de lectura no equivale a cero. No devuelve nombres, IPs ni credenciales.

Fuente: todas las filas `service=pppoe` de `/ppp/active`, antes de filtrar cuentas importadas o direcciones. Otras clases PPP y routers simulados no se suman. Caché agregada atómica con el inventario y fecha de observación exacta. Requiere018_pppoe_online; SQL001–017 inmutables.

## Cadencia de sesiones (3.5.1)

Los DTOs de `/dashboard/pppoe-online` y `/clients/ip-addresses/active` devuelven `intervalSeconds:1` y `expiresAfterSeconds:5`. Comparten reserva/bloqueo por router y una sola lectura de `/ppp/active`. El intervalo se calcula desde el inicio de lectura; las rutas comprueban la elegibilidad dentro del bloqueo, adaptando reservas antiguas sin migrar datos. Los endpoints live admiten600 solicitudes/minuto por usuario; el límite global de API no cambia. Errores de conexión usan backoff2/4/8/16/30s y no se presentan como cero ni datos recientes. Frontendprograma1segundo entre comienzos de solicitudes sin solapar, resta la latencia para la caducidad y rechaza respuestas antiguas. No cambia la autorización ni envía configuraciones al router. SQL001–018 inmutables.


## Dashboard de tráfico y conexiones (4.4.0)

Requiere aplicar `024_dashboard_insights`. Lectura permitida a ADMIN, TECHNICIAN, BILLING y VIEWER con la autenticación existente.

| Método | Ruta | Resultado |
| --- | --- | --- |
| GET | `/api/v1/dashboard/traffic?period=day` | Histórico y última medición, sin consultar equipos. |
| POST | `/api/v1/dashboard/traffic/refresh` | Solicita una lectura compartida y devuelve el histórico. JSON: `{"period":"week"}`. |
| GET | `/api/v1/dashboard/connections` | Hasta 10 clientes con su última conexión PPPoE detectada. |

`period` admite `day`, `week`, `month` y `year`. Los límites siguen America/Lima y abarcan hoy, 7, 30 o 365 días naturales incluyendo hoy. `downloadBps` y `uploadBps` están en bits por segundo. Las series incluyen `null` donde no hay observaciones; los puntos son promedios ponderados por la cantidad de muestras. `current.status=FRESH` indica total completo reciente; los totales incompletos o caducados devuelven tasas nulas.

El contador `/dashboard/pppoe-online` mantiene su proyección sin identidades. El endpoint de conexiones devuelve nombre local, IP, router y hora de detección; excluye retirados y no devuelve credenciales. Los contadores base individuales y sus conexiones se eliminan al borrar definitivamente al cliente; las series históricas globales no contienen identificadores de clientes.

Todas las consultas a equipos son de lectura. No se crean colas ni reglas de red para producir estadísticas. El worker recoge datos cuando no tiene un trabajo financiero o de red por procesar. Lee `DASHBOARD-TRAFICO.txt`.
