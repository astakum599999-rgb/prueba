<?php
declare(strict_types=1);
namespace Nexo;

ini_set('display_errors', '0');
date_default_timezone_set('UTC');
header('Content-Type: text/html; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
$upgradeNonce=base64_encode(random_bytes(18));
header("Content-Security-Policy: default-src 'none'; style-src 'unsafe-inline'; script-src 'nonce-{$upgradeNonce}'; form-action 'self'; frame-ancestors 'none'; base-uri 'none'");

if (!is_file(__DIR__ . '/storage/config.php')) {
    header('Location: install.php', true, 302);
    exit;
}

require_once __DIR__ . '/app/bootstrap.php';
require_once __DIR__ . '/app/validation.php';
require_once __DIR__ . '/app/auth.php';
require_once __DIR__ . '/app/migrations.php';

function upgradeEscape(mixed $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

$user = null;
$error = null;
$upgradeStatus = null;
$flash = null;
$csrf = '';
$basePath = '';
try {
    $basePath = (string) config('base_path', '');
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    session_name('nexoisp_updater');
    session_set_cookie_params(['lifetime'=>0,'httponly' => true, 'secure' => (bool) config('cookie_secure', false), 'samesite' => 'Strict', 'path' => $basePath !== '' ? $basePath : '/']);
    session_start();
    if (!isset($_SESSION['upgrade_csrf']) || !is_string($_SESSION['upgrade_csrf'])) {
        $_SESSION['upgrade_csrf'] = bin2hex(random_bytes(32));
    }
    $csrf = $_SESSION['upgrade_csrf'];
    // The updater authenticates explicitly and uses a short-lived, one-use form ticket.
    // A browser cookie alone never restores an authenticated updater page.
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
        if ((int) ($_SERVER['CONTENT_LENGTH'] ?? 0) > 16384) {
            throw new HttpError(413, 'La solicitud de actualización es demasiado grande.');
        }
        if (!trustedOrigin(headerValue('Origin'))) {
            throw new HttpError(403, 'Origen no autorizado. Abre la dirección habitual configurada de GIGARED ISP.', 'CSRF_REJECTED');
        }
        if (!isset($_POST['csrf']) || !is_string($_POST['csrf']) || !hash_equals($csrf, $_POST['csrf'])) {
            throw new HttpError(403, 'La sesión de actualización expiró. Recarga la página antes de continuar.', 'CSRF_REJECTED');
        }
        $action = $_POST['action'] ?? '';
        if ($action === 'login') {
            if (!is_string($_POST['email'] ?? null) || !is_string($_POST['password'] ?? null)) {
                throw new HttpError(422, 'Escribe el email y la contraseña de un administrador.');
            }
            $user = authenticateUser(['email' => $_POST['email'], 'password' => $_POST['password']]);
            if ($user['role'] !== 'ADMIN') {
                throw new HttpError(403, 'La cuenta inició sesión, pero sólo un administrador puede actualizar el esquema.', 'FORBIDDEN');
            }
            session_regenerate_id(true);
            $_SESSION['upgrade_csrf']=bin2hex(random_bytes(32));$csrf=$_SESSION['upgrade_csrf'];
            foreach(($_SESSION['upgrade_authorizations']??[]) as $key=>$grant)if($grant['expires']<time())unset($_SESSION['upgrade_authorizations'][$key]);
            $upgradeTicket=base64urlEncode(random_bytes(32));
            $_SESSION['upgrade_authorizations'][hashToken($upgradeTicket)]=['userId'=>$user['id'],'expires'=>time()+300];
            audit('UPDATER_LOGIN','User',$user['id'],$user['id']);
        } elseif ($action !== 'apply') {
            throw new HttpError(422, 'Acción de actualización no admitida.');
        }
        if($action==='apply'){
        $ticket=$_POST['upgrade_ticket']??null;
        $grant=is_string($ticket)?($_SESSION['upgrade_authorizations'][hashToken($ticket)]??null):null;
        if(!$grant||$grant['expires']<time())throw new HttpError(401,'Vuelve a identificarte para aplicar la actualización.');
        $user=fetchOne("SELECT id,name,email,role,active FROM User WHERE id=?",[$grant['userId']]);
        if(!$user||!$user['active']||$user['role']!=='ADMIN')throw new HttpError(403,'La cuenta ya no tiene permiso de administrador.');
        if (($_POST['backup_confirm'] ?? '') !== '1') {
            throw new HttpError(422, 'Confirma primero que guardaste un respaldo de la base de datos y de storage/config.php.');
        }
        unset($_SESSION['upgrade_authorizations'][hashToken($ticket)]);
        $result = migrationApply();
        $upgradeStatus = migrationStatus();
        if ($result['applied'] !== []) {
            audit('SCHEMA_UPGRADE', 'Schema', $upgradeStatus['targetVersion'], $user['id']);
        }
        $flash=$result;
        $_SESSION['upgrade_csrf'] = bin2hex(random_bytes(32));
        $csrf=$_SESSION['upgrade_csrf'];
        }
    }
    if ($user !== null && $user['role'] === 'ADMIN') {
        $upgradeStatus = migrationStatus();
        $flash = $flash ?? null;
    } elseif ($user !== null) {
        http_response_code(403);
    }
} catch (HttpError $failure) {
    http_response_code($failure->status);
    $error = $failure->getMessage();$user=null;
} catch (\Throwable) {
    http_response_code(503);
    $user=null;$error = 'No se pudo verificar o actualizar el esquema. Revisa MySQL, permisos y los archivos SQL originales de esta distribución.';
}
$administrator = $user !== null && $user['role'] === 'ADMIN';
?>
<!doctype html>
<html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Actualizar GIGARED ISP</title>
<style>
*{box-sizing:border-box}body{margin:0;background:#0b1120;color:#dbe5f2;font:15px/1.6 system-ui,-apple-system,Segoe UI,sans-serif}main{max-width:900px;margin:48px auto;padding:0 22px}.brand{color:#89e1c7;letter-spacing:.17em;font-size:13px;font-weight:750}h1{font-size:34px;line-height:1.2;letter-spacing:-.035em;margin:12px 0}h2{font-size:19px;margin:0 0 12px}p{color:#a2b1c7}.panel{background:#121d2d;border:1px solid #293b52;border-radius:18px;padding:27px;margin:23px 0}.notice{border:1px solid #3d586d;border-radius:12px;background:#172a3a;padding:16px 18px;margin:20px 0}.error{border-color:#844958;background:#341f2b;color:#ffd0d9}.success{border-color:#306f5b;background:#12342c;color:#afead0}label{display:block;font-size:13px;font-weight:650;margin:17px 0}input{display:block;width:100%;background:#0b1523;border:1px solid #3a4d65;color:#f0f4f9;border-radius:9px;padding:12px;margin-top:7px;font:inherit}input:focus{outline:2px solid #65dbb6;outline-offset:2px}.action{display:inline-block;background:#7be4c2;color:#092b26;font-size:15px;font-weight:750;border:0;border-radius:10px;padding:12px 21px;text-decoration:none;cursor:pointer}.secondary{background:#273a50;color:#dce8f3}.actions{display:flex;align-items:center;gap:13px;flex-wrap:wrap;margin-top:22px}.check{display:flex;align-items:flex-start;gap:12px;max-width:670px}.check input{width:18px;height:18px;flex:0 0 18px;margin:3px 0}.fine{font-size:12px;color:#8da1ba}.versions{width:100%;border-collapse:collapse;font-size:13px}.versions td,.versions th{padding:12px 8px;text-align:left;border-bottom:1px solid #2a3a50}.versions th{color:#8da5bf}.done{color:#91e7c4}.pending{color:#f1d18d}.badge{display:inline-block;border-radius:99px;background:#203347;color:#aacbe3;font-size:12px;padding:4px 10px}code{background:#0b1523;border-radius:4px;padding:2px 5px;font-size:12px}ul,ol{padding-left:22px;color:#a9b9ce}li{margin:7px 0}@media(max-width:600px){main{margin:28px auto;padding:0 15px}h1{font-size:29px}.panel{padding:21px}}
</style></head><body><main>
<div class="brand">GIGARED ISP · ACTUALIZACIÓN SEGURA</div><h1>Conserva tus datos, amplía tu sistema</h1><p>Actualizador de la base de datos para instalaciones existentes de XAMPP.</p>
<?php if ($error !== null): ?><div class="notice error" role="alert"><?= upgradeEscape($error) ?></div><?php endif; ?>
<?php if (!$administrator): ?>
<section class="panel"><h2>Acceso de administrador</h2><p><?= $user !== null ? 'La cuenta actual no tiene permisos para aplicar migraciones. Entra con un administrador existente.' : 'Usa tu cuenta actual de GIGARED ISP. No se crean usuarios ni se restablecen contraseñas en esta página.' ?></p>
<form method="post" action="actualizar.php" autocomplete="on"><input type="hidden" name="csrf" value="<?= upgradeEscape($csrf) ?>"><input type="hidden" name="action" value="login">
<label>Email<input name="email" type="email" required maxlength="254" autocomplete="username" value="<?= upgradeEscape(is_string($_POST['email'] ?? null) ? $_POST['email'] : '') ?>"></label>
<label>Contraseña<input name="password" type="password" required maxlength="128" autocomplete="current-password"></label><button class="action" type="submit">Entrar como administrador</button></form></section>
<p class="fine">La dirección y el origen del navegador deben coincidir con los configurados para esta instalación.</p>
<?php elseif ($upgradeStatus !== null): ?>
<?php if (is_array($flash)): ?><div class="notice success"><?= $flash['applied'] !== [] ? 'Actualización completada. Se aplicaron ' . count($flash['applied']) . ' versiones y se conservaron la configuración y las cuentas existentes.' : 'La base ya estaba actualizada; se verificó su historial sin volver a aplicar SQL.' ?></div><?php endif; ?>
<section class="panel"><h2>Versiones del esquema</h2><p>Los archivos ya aplicados se verificaron mediante SHA-256. No se muestran ni modifican credenciales de tu instalación.</p><table class="versions"><thead><tr><th>Versión</th><th>Estado</th></tr></thead><tbody><?php foreach ($upgradeStatus['versions'] as $version): ?><tr><td><?= upgradeEscape($version['name']) ?></td><td class="<?= $version['status'] === 'APPLIED' ? 'done' : 'pending' ?>"><?= $version['status'] === 'APPLIED' ? 'Aplicada · checksum verificado' : 'Pendiente' ?></td></tr><?php endforeach; ?></tbody></table></section>
<?php if ($upgradeStatus['needsUpgrade']): ?>
<section class="panel"><h2>Antes de aplicar</h2><ol><li>Detén el worker y evita escrituras de otras integraciones.</li><li>Exporta estructura y datos de la base desde phpMyAdmin.</li><li>Guarda una copia privada de <code>storage/config.php</code> y de la aplicación anterior.</li></ol><div class="notice">MariaDB confirma DDL por sentencia. Si hay una interrupción, las tablas creadas permanecen y las operaciones idempotentes pendientes pueden reintentarse. No existe un rollback global del esquema.</div>
<form method="post" action="actualizar.php"><input type="hidden" name="csrf" value="<?= upgradeEscape($csrf) ?>"><input type="hidden" name="action" value="apply"><input type="hidden" name="upgrade_ticket" value="<?= upgradeEscape($upgradeTicket ?? '') ?>"><label class="check"><input name="backup_confirm" type="checkbox" value="1" required><span>Confirmo que guardé un respaldo completo de la base y de su configuración original, y que detuve el worker.</span></label><button class="action" type="submit">Aplicar actualización</button></form></section>
<?php else: ?><section class="panel"><h2>Tu base está actualizada</h2><p>No quedan versiones pendientes. Puedes abrir el panel y volver a iniciar <code>INICIAR-WORKER.bat</code>.</p><a class="action" href="<?= upgradeEscape($basePath . '/') ?>">Abrir GIGARED ISP</a></section><?php endif; ?>
<?php endif; ?>
<div class="actions"><a class="action secondary" href="actualizar.php">Volver a comprobar</a></div><p class="fine">Si falta un archivo o cambió el SQL aplicado, restaura la distribución original. Nunca edites checksums para omitir una comprobación. La configuración y la clave AES permanecen intactas.</p>
</main><script nonce="<?= upgradeEscape($upgradeNonce) ?>">window.addEventListener('pagehide',function(){document.body.replaceChildren()});window.addEventListener('pageshow',function(e){if(e.persisted)window.location.replace('actualizar.php')});</script></body></html>
