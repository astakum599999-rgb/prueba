<?php
declare(strict_types=1);
namespace Nexo;

use PDO;
use Throwable;

function billingNetworkRouterPolicy(string $routerId): array
{
    return fetchOne('SELECT * FROM BillingRouterPolicy WHERE routerId=?',[$routerId])??['routerId'=>$routerId,'warningList'=>'AVISO_MOROSO','cutList'=>'MOROSOS','portalIp'=>null,'portalPort'=>80,'preparedHash'=>null,'preparedAt'=>null];
}

function billingNetworkRouterSave(array $router,array $data,array $actor): array
{
    if(array_diff(array_keys($data),['warningList','cutList','portalIp','portalPort']))throw new HttpError(422,'Campo de router no admitido.');$row=array_merge(billingNetworkRouterPolicy($router['id']),$data);
    foreach(['warningList','cutList'] as $k)if(!is_string($row[$k])||!preg_match('/^[A-Za-z0-9_.-]{1,63}$/D',$row[$k]))throw new HttpError(422,'Nombre de lista inválido.');
    if($row['warningList']===$row['cutList'])throw new HttpError(422,'Las listas de aviso y corte deben ser distintas.');
    if($row['portalIp']!==null&&(!is_string($row['portalIp'])||clientIpAddress($row['portalIp'])===null||filter_var($row['portalIp'],FILTER_VALIDATE_IP,FILTER_FLAG_IPV4)===false))throw new HttpError(422,'El portal requiere una IPv4 unicast.');
    $row['portalPort']=billingInteger($row['portalPort'],1,65535,'portalPort');
    return billingWithLocks(['router:'.$router['id']],function()use($router,$row,$actor):array {
        if(fetchOne("SELECT b.serviceId FROM BillingServiceState b JOIN Service s ON s.id=b.serviceId LEFT JOIN ClientBillingPolicy p ON p.networkServiceId=s.id WHERE (s.routerId=? OR JSON_UNQUOTE(JSON_EXTRACT(p.networkBindingJson,'$.routerId'))=?) AND COALESCE(b.appliedAction,'ACTIVE')<>'ACTIVE' LIMIT 1",[$router['id'],$router['id']]))throw new HttpError(409,'Restablece los clientes limitados/cortados antes de cambiar las reglas del router.');
        db()->prepare('INSERT INTO BillingRouterPolicy(routerId,warningList,cutList,portalIp,portalPort,updatedAt) VALUES (?,?,?,?,?,?) ON DUPLICATE KEY UPDATE warningList=VALUES(warningList),cutList=VALUES(cutList),portalIp=VALUES(portalIp),portalPort=VALUES(portalPort),preparedHash=NULL,preparedAt=NULL,updatedAt=VALUES(updatedAt)')->execute([$router['id'],$row['warningList'],$row['cutList'],$row['portalIp'],$row['portalPort'],now()]);audit('billing.router-policy.update','Router',$router['id'],$actor['id']);return billingNetworkRouterPolicy($router['id']);
    });
}

final class BillingNetworkController
{
    private RouterTransport $transport;
    private array $policy;
    private bool $billingScoped=false;
    public function __construct(private readonly array $router,?RouterTransport $transport=null,bool $billingActions=false)
    {
        $this->billingScoped=$billingActions&&billingNetworkGranted()&&billingPolicySettings()['enabled'];
        $native=$transport??match($router['transport']){'REST'=>new RouterRestTransport($router,decryptSecret($router['passwordEncrypted']),15.0,false,false,false,false,$this->billingScoped),'SOCKET'=>new RouterSocketTransport($router,decryptSecret($router['passwordEncrypted']),15.0,false,false,false,false,$this->billingScoped),default=>throw new HttpError(422,'Selecciona un router real.')};
        $this->transport=new RouterGuardedTransport($native,$this->billingScoped);$this->policy=billingNetworkRouterPolicy($router['id']);
    }
    private function write(): void {if($this->billingScoped)billingRequireNetworkWrite();else requireNetworkWrite();}
    public function close(): void {$this->transport->close();}
    private function rows(string $path,string $props): array {return provisionRows($this->transport,$path,$props);}
    private function own(string $path,string $comment): ?array {
        $rows=$this->transport->print($path,['comment'=>$comment]);if(count($rows)>1)throw new RouterError('Recurso administrado duplicado.','RESOURCE_CONFLICT');return $rows[0]??null;
    }
    private function upsert(string $path,string $comment,array $values): string {
        $old=$this->own($path,$comment);if($old){$this->transport->set($path,$old['.id'],$values+['comment'=>$comment]);return $old['.id'];}return $this->transport->add($path,$values+['comment'=>$comment]);
    }
    private function fasttrack(): void {
        foreach($this->rows('/ip/firewall/filter','.id,action,disabled') as $r)if(($r['action']??'')==='fasttrack-connection'&&!RouterTransportUtil::truthy($r['disabled']??false))throw new RouterError('FastTrack activo impide garantizar el corte o la velocidad. Esta versión requiere desactivarlo antes de automatizar.','FASTTRACK_CONFLICT');
    }
    private function configHash(): string {return hash('sha256',json_encode([$this->router['id'],$this->policy['warningList'],$this->policy['cutList'],$this->policy['portalIp'],$this->policy['portalPort']],JSON_THROW_ON_ERROR));}
    public function prepare(): void {
        $this->write();$this->fasttrack();db()->prepare('INSERT IGNORE INTO BillingRouterPolicy(routerId) VALUES (?)')->execute([$this->router['id']]);$base='gigared:billing:router:'.$this->router['id'];$cut=$this->policy['cutList'];
        $drop=$this->upsert('/ip/firewall/filter',$base.':drop',['chain'=>'forward','src-address-list'=>$cut,'action'=>'drop','disabled'=>'false']);$this->transport->execute('/ip/firewall/filter/move',['numbers'=>$drop,'destination'=>'0']);
        if($this->policy['portalIp']!==null){
            $allow=$this->upsert('/ip/firewall/filter',$base.':portal',['chain'=>'forward','src-address-list'=>$cut,'dst-address'=>$this->policy['portalIp'],'protocol'=>'tcp','dst-port'=>(string)$this->policy['portalPort'],'action'=>'accept','disabled'=>'false']);$this->transport->execute('/ip/firewall/filter/move',['numbers'=>$allow,'destination'=>'0']);
            foreach(['warning'=>$this->policy['warningList'],'cut'=>$cut] as $suffix=>$list){$rule=$this->upsert('/ip/firewall/nat',$base.':'.$suffix,['chain'=>'dstnat','src-address-list'=>$list,'protocol'=>'tcp','dst-port'=>'80','action'=>'dst-nat','to-addresses'=>$this->policy['portalIp'],'to-ports'=>(string)$this->policy['portalPort'],'disabled'=>'false']);$this->transport->execute('/ip/firewall/nat/move',['numbers'=>$rule,'destination'=>'0']);}
        }else foreach(['warning','cut'] as $suffix)if($r=$this->own('/ip/firewall/nat',$base.':'.$suffix))$this->transport->remove('/ip/firewall/nat',$r['.id']);
        db()->prepare('UPDATE BillingRouterPolicy SET preparedHash=?,preparedAt=?,updatedAt=? WHERE routerId=?')->execute([$this->configHash(),now(),now(),$this->router['id']]);$this->policy=billingNetworkRouterPolicy($this->router['id']);
    }
    private function prepared(): void {
        if(($this->policy['preparedHash']??null)!==$this->configHash())throw new RouterError('Prepara expresamente las reglas de facturación de este router antes de aplicar cortes.','BILLING_FIREWALL_UNPREPARED');$this->fasttrack();
        $drop=$this->own('/ip/firewall/filter','gigared:billing:router:'.$this->router['id'].':drop');if(!$drop||RouterTransportUtil::truthy($drop['disabled']??false)||($drop['src-address-list']??'')!==$this->policy['cutList']||($drop['action']??'')!=='drop')throw new RouterError('La regla de corte fue modificada. Revisa la configuración.','BILLING_FIREWALL_CHANGED');
    }
    public function resolve(array $service,array $p,?array $original=null): array {
        $type=$service['type'];$username=$service['username']??'';$remoteId=null;
        if(in_array($type,['DHCP','IP_MAC'],true)){
            $matches=array_filter($this->rows('/ip/dhcp-server/lease','.id,address,mac-address'),static fn(array $r):bool=>strtolower($r['mac-address']??'')===strtolower($service['macAddress']??'')&&($r['address']??null)===$service['ipAddress']);
            if(count($matches)!==1)throw new RouterError('La IP ya no corresponde a la MAC del cliente.','IDENTITY_CONFLICT');
        }
        if(($p['networkServiceId']??null)===$service['id']&&!empty($p['networkBindingJson'])){$binding=json_decode($p['networkBindingJson'],true,64,JSON_THROW_ON_ERROR);if($binding['routerId']!==$this->router['id'])throw new RouterError('Cambió el router vinculado.','IDENTITY_CONFLICT');$type='PPPOE';$username=hex2bin($binding['usernameHex']);$remoteId=$binding['remoteId'];}
        $path=$type==='PPPOE'?'/ppp/secret':($type==='HOTSPOT'?'/ip/hotspot/user':'/queue/simple');
        if($original){if($original['path']!==$path)throw new RouterError('Cambió el tipo del servicio.','IDENTITY_CONFLICT');$remoteId=$original['remoteId'];}
        if($remoteId===null){$provision=fetchOne("SELECT remoteId FROM ClientProvisioning WHERE serviceId=? AND status='CONFIRMED'",[$service['id']]);$remoteId=$provision['remoteId']??null;}
        if($remoteId===null&&$type==='PPPOE'){$source=fetchOne('SELECT remoteId FROM RouterSecretImport WHERE clientId=? AND routerId=? AND username=? AND present=1',[$service['clientId'],$this->router['id'],$username]);$remoteId=$source['remoteId']??null;}
        $props='.id,name,service,profile,disabled,comment,remote-address,address,target,max-limit,priority';$found=null;
        foreach($this->rows($path,$props) as $r){
            $match=$remoteId!==null?($r['.id']??null)===$remoteId:($r['comment']??'')==='nexoisp:'.$service['id'].($type==='PPPOE'?':pppoe':($type==='HOTSPOT'?':hotspot':':queue'));
            if(!$match)continue;if($found)throw new RouterError('Identidad duplicada.','IDENTITY_CONFLICT');
            if(in_array($type,['PPPOE','HOTSPOT'],true)&&($r['name']??null)!==$username)throw new RouterError('La cuenta ya no pertenece al usuario esperado.','IDENTITY_CONFLICT');
            if($type==='PPPOE'&&!in_array($r['service']??'', ['pppoe','any'],true))throw new RouterError('La cuenta no corresponde a PPPoE.','IDENTITY_CONFLICT');
            if(!in_array($type,['PPPOE','HOTSPOT'],true)&&($r['target']??'')!==$service['ipAddress'].'/32')throw new RouterError('La cola no corresponde a la IP del servicio.','IDENTITY_CONFLICT');$found=$r;
        }
        if(!$found)throw new RouterError('No se encontró el recurso exacto. No se crearon cuentas.','RESOURCE_NOT_FOUND');
        $baseline=$original??['path'=>$path,'remoteId'=>$found['.id'],'usernameHex'=>bin2hex($username),'profile'=>$found['profile']??null,'max-limit'=>$found['max-limit']??null,'priority'=>$found['priority']??null,'disabled'=>$found['disabled']??'false'];
        return ['type'=>$type,'path'=>$path,'record'=>$found,'original'=>$baseline,'username'=>$username];
    }
    private function profile(array $resolved,array $p,string $action): string {
        $base=$resolved['original']['profile'];if(!is_string($base)||$base==='')throw new RouterError('No hay un perfil original confirmado.','PROFILE_NOT_FOUND');if(!in_array($action,['CUT','LIMITED','WARNING'],true))return $base;
        $path=$resolved['type']==='PPPOE'?'/ppp/profile':'/ip/hotspot/user/profile';$profile=$this->transport->print($path,['name'=>$base])[0]??null;if(!$profile)throw new RouterError('El perfil original ya no existe.','PROFILE_NOT_FOUND');
        $speed=$action==='WARNING'?(string)($profile['rate-limit']??''):($action==='CUT'?'64k/64k':$p['reducedUploadKbps'].'k/'.$p['reducedDownloadKbps'].'k');$hash=substr(hash('sha256',$this->router['id'].'|'.$base.'|'.$action.'|'.$speed),0,16);$name='gg-'.strtolower($action).'-'.$hash;$tag='gigared:billing:profile:'.$hash;
        $fields=$resolved['type']==='PPPOE'?['local-address','remote-address','dns-server','only-one','use-compression','use-encryption','change-tcp-mss','session-timeout','idle-timeout','queue-type','parent-queue','address-list','routes','use-ipv6','use-mpls','use-upnp','bridge','bridge-horizon','bridge-learning','interface-list','on-up','on-down']:['shared-users','session-timeout','idle-timeout','keepalive-timeout','address-pool'];$values=[];
        foreach($fields as $key)if(isset($profile[$key])&&is_scalar($profile[$key])&&$profile[$key]!=='')$values[$key]=(string)$profile[$key];$values['name']=$name;if($speed!=='')$values['rate-limit']=$speed;if(in_array($action,['CUT','WARNING'],true)&&$resolved['type']==='PPPOE')$values['address-list']=$this->policy[$action==='CUT'?'cutList':'warningList'];
        $existing=$this->transport->print($path,['name'=>$name]);if(count($existing)>1||($existing&&($existing[0]['comment']??'')!==$tag))throw new RouterError('El nombre del perfil administrado está ocupado.','PROFILE_CONFLICT');$this->upsert($path,$tag,$values);return $name;
    }
    private function sessions(array $resolved): array {
        if($resolved['type']!=='PPPOE')return [];$rows=$this->rows('/ppp/active','.id,name,service,address');return array_values(array_filter($rows,static fn(array $r):bool=>($r['name']??null)===$resolved['username']&&($r['service']??'')==='pppoe'));
    }
    private function disconnect(array $resolved): void {
        foreach($this->sessions($resolved) as $r){$fresh=$this->sessions($resolved);foreach($fresh as $current)if($current['.id']===$r['.id']){$this->transport->remove('/ppp/active',$current['.id']);break;}}
        if($resolved['type']==='HOTSPOT')foreach($this->rows('/ip/hotspot/active','.id,user') as $r)if(($r['user']??null)===$resolved['username'])$this->transport->remove('/ip/hotspot/active',$r['.id']);
    }
    public function apply(array $service,array $p,string $action,?array $original,bool $forceReconnect=false): array {
        $this->write();$this->prepared();$r=$this->resolve($service,$p,$original);$addresses=[];
        if($action==='WARNING'&&$this->policy['portalIp']===null)throw new RouterError('Configura el portal HTTP antes de aplicar avisos en pantalla.','PORTAL_REQUIRED');
        if(RouterTransportUtil::truthy($r['record']['disabled']??false)&&($r['type']==='PPPOE'||($r['type']==='HOTSPOT'&&RouterTransportUtil::truthy($r['original']['disabled']))))throw new RouterError('La cuenta fue deshabilitada fuera de la automatización. Revisa su suspensión manual.','MANUAL_EXTERNAL');
        foreach($this->sessions($r) as $s)if($ip=clientIpAddress($s['address']??null))$addresses[]=$ip;
        $fixed=$r['type']==='PPPOE'?($r['record']['remote-address']??null):$service['ipAddress'];if($ip=clientIpAddress($fixed))$addresses[]=$ip;$addresses=array_values(array_unique($addresses));
        if($r['type']!=='PPPOE'&&!$addresses)throw new RouterError('El servicio no tiene una IP concreta confirmada.','INVALID_SERVICE');
        $listAddresses=$r['type']==='PPPOE'?(clientIpAddress($fixed)!==null?[clientIpAddress($fixed)]:[]):$addresses;
        $tag='gigared:billing:service:'.$service['id'];$list=$action==='CUT'?$this->policy['cutList']:($action==='WARNING'?$this->policy['warningList']:null);
        foreach($this->transport->print('/ip/firewall/address-list',['comment'=>$tag]) as $entry){if($list===null||!in_array($entry['address']??'', $listAddresses,true)||($entry['list']??'')!==$list)$this->transport->remove('/ip/firewall/address-list',$entry['.id']);}
        if($list!==null)foreach($listAddresses as $address){$existing=$this->transport->print('/ip/firewall/address-list',['comment'=>$tag,'list'=>$list,'address'=>$address]);if(!$existing)$this->transport->add('/ip/firewall/address-list',['comment'=>$tag,'list'=>$list,'address'=>$address,'disabled'=>'false']);}
        $values=[];$restart=false;
        if($r['type']==='PPPOE'){$profile=$this->profile($r,$p,$action);$values=['profile'=>$profile];$restart=$forceReconnect||($r['record']['profile']??'')!==$profile;}
        elseif($r['type']==='HOTSPOT'){$values=['disabled'=>$action==='CUT'?'true':$r['original']['disabled'],'profile'=>$this->profile($r,$p,$action==='CUT'?'ACTIVE':$action)];$restart=$action==='CUT'||$values['profile']!==($r['record']['profile']??'');}
        elseif(in_array($action,['LIMITED','ACTIVE','WARNING'],true))$values=['max-limit'=>$action==='LIMITED'?$p['reducedUploadKbps'].'k/'.$p['reducedDownloadKbps'].'k':$r['original']['max-limit']];
        if($values){$this->transport->set($r['path'],$r['record']['.id'],$values);$check=$this->resolve($service,$p,$r['original']);foreach($values as $k=>$v)if((string)($check['record'][$k]??'')!==(string)$v)throw new RouterError('No se confirmó el cambio en MikroTik.','UNCONFIRMED');}
        if($restart)$this->disconnect($r);
        if($list!==null)foreach($listAddresses as $address)if(!$this->transport->print('/ip/firewall/address-list',['comment'=>$tag,'list'=>$list,'address'=>$address]))throw new RouterError('No se confirmó la lista de control.','UNCONFIRMED');
        return ['original'=>$r['original'],'addresses'=>$addresses,'action'=>$action];
    }
    public function changePlan(array $service,array $p,array $plan): array {
        requireNetworkWrite();$this->fasttrack();$r=$this->resolve($service,$p);$values=[];
        if(in_array($r['type'],['PPPOE','HOTSPOT'],true)){$path=$r['type']==='PPPOE'?'/ppp/profile':'/ip/hotspot/user/profile';if(!$this->transport->print($path,['name'=>$plan['pppoeProfile']]))throw new RouterError('El perfil del nuevo plan no existe.','PROFILE_NOT_FOUND');$values=['profile'=>$plan['pppoeProfile']];}
        else $values=['max-limit'=>$plan['uploadKbps'].'k/'.$plan['downloadKbps'].'k','priority'=>$plan['priority'].'/'.$plan['priority']];
        $this->transport->set($r['path'],$r['record']['.id'],$values);$check=$this->resolve($service,$p,$r['original']);foreach($values as $k=>$v)if(($check['record'][$k]??null)!==$v)throw new RouterError('El plan no fue confirmado.','UNCONFIRMED');$this->disconnect($r);return ['planId'=>$plan['id'],'remoteId'=>$r['record']['.id']];
    }
    public function original(array $service,array $p): array {return $this->resolve($service,$p)['original'];}
}

function billingNetworkContext(array $service,array $p): array
{
    if(($p['networkServiceId']??null)===$service['id']&&!empty($p['networkBindingJson'])){$b=json_decode($p['networkBindingJson'],true,64,JSON_THROW_ON_ERROR);$routerId=$b['routerId'];}
    else {if(billingLocalIsService($service['id'])||!$service['routerId'])throw new HttpError(409,'El servicio de facturación no tiene una cuenta de red vinculada.');$routerId=$service['routerId'];}
    return fetchOne('SELECT * FROM Router WHERE id=?',[$routerId])??throw new HttpError(404,'Router no encontrado.');
}

function billingNetworkReconcileClient(string $clientId): void
{
    $p=billingPolicy($clientId);$rows=fetchAll("SELECT s.*,b.appliedAction FROM Service s LEFT JOIN BillingServiceState b ON b.serviceId=s.id WHERE s.clientId=? AND s.desiredState<>'RETIRED'",[$clientId]);$states=[];
    foreach($rows as $row){if(billingLocalIsService($row['id'])&&($p['networkServiceId']??null)!==$row['id'])continue;$states[]=$row['appliedAction']??$row['appliedState'];}
    if(!$states||in_array(null,$states,true))return;$active=(bool)array_intersect($states,['ACTIVE','WARNING','LIMITED']);
    db()->prepare("UPDATE Client SET status=?,updatedAt=? WHERE id=? AND status<>'RETIRED'")->execute([$active?'ACTIVE':'SUSPENDED',now(),$clientId]);
}

function billingNetworkSync(string $serviceId,int $revision): array
{
    billingRequireNetworkWrite();$initial=billingService($serviceId)??throw new HttpError(404,'Servicio no encontrado.');$policy=billingPolicy($initial['clientId']);if(!$policy)return ['skipped'=>true];$router=billingNetworkContext($initial,$policy);
    return billingWithLocks(['client:'.$initial['clientId'],'router:'.$router['id']],function()use($serviceId,$revision,$router):array {
        $service=billingService($serviceId);$p=billingPolicy($service['clientId']);$state=fetchOne('SELECT * FROM BillingServiceState WHERE serviceId=?',[$serviceId]);
        if(!$state||(int)$state['revision']!==$revision||!billingPolicySettings()['effectiveEnabled']||$service['client']['status']==='RETIRED')return ['skipped'=>true];
        if($state['desiredAction']===$state['appliedAction']&&$state['lastError']===null)return ['serviceId'=>$serviceId,'action'=>$state['appliedAction'],'confirmed'=>true,'replayed'=>true];
        if(clientPppPending($service['clientId'])||clientPppManualSuspension($service['clientId'])||$service['suspensionReason']==='MANUAL')return ['skipped'=>true,'reason'=>'MANUAL'];
        // Recompute after queued payments/promises; never cut based on stale work.
        $invoices=fetchAll('SELECT * FROM Invoice i WHERE serviceId=? AND '.financialDeletionClause('Invoice','i'),[$serviceId]);$promises=fetchAll('SELECT p.* FROM PaymentPromise p JOIN Invoice i ON i.id=p.invoiceId WHERE i.serviceId=?',[$serviceId]);$decision=billingPolicyDecision($p,$invoices,$promises,billingNow(),false,billingPolicySettings(),$state['appliedAction']);
        if($decision['state']!==$state['desiredAction']){billingPolicyStage($service,$p,$decision);return ['skipped'=>true,'reason'=>'STALE'];}
        $controller=new BillingNetworkController($router,null,true);
        try{
            if($decision['state']==='CUT'&&$state['appliedAction']!=='CUT'&&!billingPolicyCutWindow($p,billingNow(),billingPolicySettings()))return ['deferred'=>true,'reason'=>'CUT_SCHEDULE'];
            if(!billingNetworkRouterPolicy($router['id'])['preparedAt']&&billingNetworkGranted()&&$decision['state']!=='ACTIVE')$controller->prepare();
            $original=$state['originalJson']?json_decode($state['originalJson'],true,64,JSON_THROW_ON_ERROR):$controller->original($service,$p);
            // Freeze restoration data before the first possible remote write.
            if(!$state['originalJson'])db()->prepare('UPDATE BillingServiceState SET originalJson=? WHERE serviceId=?')->execute([json_encode($original,JSON_THROW_ON_ERROR),$serviceId]);
            $forceReconnect=$state['lastError']!==null||in_array($state['appliedAction'],['LIMITED','CUT'],true)||in_array($decision['state'],['LIMITED','CUT'],true);
            $result=$controller->apply($service,$p,$decision['state'],$original,$forceReconnect);
            tx(function(PDO $pdo)use($service,$p,$state,$decision,$result,$invoices,$router):void {
                $cut=$decision['state']==='CUT';$pdo->prepare('UPDATE BillingServiceState SET appliedAction=?,appliedIp=?,lastError=NULL,appliedAt=?,updatedAt=? WHERE serviceId=?')->execute([$decision['state'],$result['addresses'][0]??null,now(),now(),$service['id']]);
                if(!billingLocalIsService($service['id']))$pdo->prepare("UPDATE Service SET desiredState=?,appliedState=?,suspensionReason=?,syncStatus='SYNCED',lastSyncAt=?,lastError=NULL,updatedAt=? WHERE id=?")->execute([$cut?'SUSPENDED':'ACTIVE',$cut?'SUSPENDED':'ACTIVE',$cut?'BILLING':null,now(),now(),$service['id']]);
                billingNetworkReconcileClient($service['clientId']);
                if($cut){if(!empty($p['fixedCutOn']))$pdo->prepare('UPDATE ClientBillingPolicy SET fixedCutUsedAt=COALESCE(fixedCutUsedAt,?) WHERE clientId=?')->execute([now(),$service['clientId']]);if((int)$p['reconnectionFeeCents']>0)foreach($invoices as $invoice)if($invoice['status']==='OPEN'){billingPolicyFee($invoice,'RECONNECTION',(int)$p['reconnectionFeeCents']);break;}}
                clientProfileEvent($service['clientId'],'NETWORK_'.$decision['state'],['routerId'=>$router['id'],'addresses'=>$result['addresses']],$service['id'],null,'NETWORK','billing-state:'.$service['id'].':'.$state['revision']);
                foreach(json_decode($p['channelsJson'],true,16,JSON_THROW_ON_ERROR) as $channel){$subject=$cut?'Servicio suspendido por deuda':($decision['state']==='LIMITED'?'Velocidad reducida por deuda':'Actualización del estado de servicio');billingPolicyNotice($service['clientId'],null,$decision['state'],$channel,$subject,'Estado confirmado del servicio: '.$decision['state'].'. Consulta tus facturas y pagos en el portal.','network:'.$service['id'].':'.$state['revision'].':'.$channel);}
            });return ['serviceId'=>$serviceId,'action'=>$decision['state'],'confirmed'=>true];
        }catch(Throwable $error){db()->prepare('UPDATE BillingServiceState SET lastError=?,updatedAt=? WHERE serviceId=?')->execute([workerPublicError($error),now(),$serviceId]);throw $error;}finally{$controller->close();}
    });
}

function billingNetworkPlanRequest(string $clientId,array $input,array $actor): array
{
    requireNetworkWrite();if(array_diff(array_keys($input),['serviceId','planId','revision']))throw new HttpError(422,'Parámetros no admitidos.');$serviceId=provisionIdentifier($input['serviceId']??null);$planId=provisionIdentifier($input['planId']??null);
    return billingWithLocks(['client:'.$clientId],function()use($serviceId,$clientId,$planId,$input,$actor):array {
        $s=billingService($serviceId);if(!$s||$s['clientId']!==$clientId)throw new HttpError(404,'Servicio no encontrado.');if($s['desiredState']!=='ACTIVE'||$s['client']['status']==='RETIRED'||(int)$s['revision']!==($input['revision']??null))throw new HttpError(409,'El servicio cambió o no está activo.');clientPppRequireSettled($clientId);if(clientPppManualSuspension($clientId)!==null)throw new HttpError(409,'Activa primero la suspensión manual del cliente.');$p=billingPolicy($clientId)??billingPolicyDefaults($clientId);billingNetworkContext($s,$p);
        $state=fetchOne('SELECT * FROM BillingServiceState WHERE serviceId=?',[$serviceId]);if($state&&($state['desiredAction']!=='ACTIVE'||($state['appliedAction']??'ACTIVE')!=='ACTIVE'))throw new HttpError(409,'Restablece primero el servicio limitado o cortado.');
        $plan=fetchOne('SELECT * FROM Plan WHERE id=? AND active=1',[$planId])??throw new HttpError(422,'Plan no disponible.');profileImportAssertBillable($plan['id']);
        return tx(function(PDO $pdo)use($s,$plan,$actor):array {$pdo->prepare("UPDATE Service SET revision=revision+1,syncStatus='PENDING',updatedAt=? WHERE id=?")->execute([now(),$s['id']]);$task=enqueue('SERVICE_SYNC',['serviceId'=>$s['id'],'source'=>'profile-plan-change','serviceRevision'=>(int)$s['revision']+1,'planSnapshot'=>billingNetworkPlanSnapshot($plan)]);audit('service.plan.change.request','Service',$s['id'],$actor['id']);return $task;});
    });
}

function billingNetworkPlanSnapshot(array $plan): array
{
    $snapshot=['id'=>$plan['id'],'pppoeProfile'=>$plan['pppoeProfile'],'currency'=>$plan['currency']];foreach(['uploadKbps','downloadKbps','priority','priceCents'] as $key)$snapshot[$key]=(int)$plan[$key];return $snapshot;
}

function billingNetworkPlanSync(string $serviceId,int $revision,array $snapshot): array
{
    requireNetworkWrite();
    $initial=billingService($serviceId)??throw new HttpError(404,'Servicio no encontrado.');
    $policy=billingPolicy($initial['clientId'])??billingPolicyDefaults($initial['clientId']);
    $router=billingNetworkContext($initial,$policy);
    return billingWithLocks(['client:'.$initial['clientId'],'router:'.$router['id']],function()use($serviceId,$revision,$router,$snapshot):array {
        $service=billingService($serviceId);
        if((int)$service['revision']!==$revision||$service['desiredState']!=='ACTIVE')return ['skipped'=>true];
        if($service['syncStatus']==='SYNCED')return ['confirmed'=>true,'replayed'=>true];
        $controller=null;
        try {
            clientPppRequireSettled($service['clientId']);
            if(clientPppManualSuspension($service['clientId'])!==null)throw new HttpError(409,'Activa primero la suspensión manual del cliente.');
            $plan=fetchOne('SELECT * FROM Plan WHERE id=? AND active=1',[$snapshot['id']??'']);
            if(!$plan||billingNetworkPlanSnapshot($plan)!==$snapshot)throw new HttpError(409,'El plan cambió después de solicitarlo. Revisa precio y velocidad antes de repetir el cambio.');
            $policy=billingPolicy($service['clientId'])??billingPolicyDefaults($service['clientId']);
            $state=fetchOne('SELECT * FROM BillingServiceState WHERE serviceId=?',[$serviceId]);
            if($state&&($state['desiredAction']!=='ACTIVE'||($state['appliedAction']??'ACTIVE')!=='ACTIVE'))throw new HttpError(409,'Restablece primero el servicio limitado o cortado.');
            $controller=new BillingNetworkController($router);
            $result=$controller->changePlan($service,$policy,$plan);
            tx(function(PDO $pdo)use($plan,$serviceId,$service,$result):void {
                $pdo->prepare("UPDATE Service SET planId=?,syncStatus='SYNCED',lastError=NULL,lastSyncAt=?,updatedAt=? WHERE id=?")->execute([$plan['id'],now(),now(),$serviceId]);
                $pdo->prepare('UPDATE BillingServiceState SET originalJson=NULL WHERE serviceId=?')->execute([$serviceId]);
                clientProfileEvent($service['clientId'],'PLAN_CHANGED',$result,$serviceId,null,'NETWORK');
            });
            return $result;
        }catch(Throwable $error){
            db()->prepare("UPDATE Service SET syncStatus='FAILED',lastError=?,updatedAt=? WHERE id=?")->execute([workerPublicError($error),now(),$serviceId]);
            throw $error;
        }finally{$controller?->close();}
    });
}
