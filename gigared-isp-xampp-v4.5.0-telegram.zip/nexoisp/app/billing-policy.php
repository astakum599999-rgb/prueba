<?php
declare(strict_types=1);
namespace Nexo;

use DateTimeImmutable;
use DateTimeZone;
use PDO;
use Throwable;

const POLICY_ZONE='America/Lima';

function billingPolicy(string $clientId): ?array
{
    return fetchOne('SELECT * FROM ClientBillingPolicy WHERE clientId=?',[$clientId]);
}

/** Billing authorization is independent of the general network-write setting. */
function billingNetworkGranted(): bool
{
    try{return (int)(fetchOne("SELECT enabled FROM BillingNetworkGrant WHERE id='primary'")['enabled']??0)===1;}catch(Throwable){return false;}
}
function billingRequireNetworkWrite(): void
{
    if(!networkReadOnly())return;
    if(!billingNetworkGranted()||!billingPolicySettings()['enabled'])throw new HttpError(409,'La automatización de facturación está desactivada.','NETWORK_READ_ONLY');
}
/** Preserve the stored grace DATE; execute at the currently configured local hour. */
function billingPolicyCutAt(string $date,array $settings): DateTimeImmutable
{
    return billingDate($date)->setTimezone(new DateTimeZone(POLICY_ZONE))->setTime(...array_map('intval',explode(':',$settings['cutHour']??'04:30')));
}
/** The configured fixed day is the base; grace postpones this one-use cut too. */
function billingPolicyFixedCutAt(array $policy,array $settings): ?DateTimeImmutable
{
    if(empty($policy['fixedCutOn'])||!empty($policy['fixedCutUsedAt']))return null;
    return billingPolicyCutAt($policy['fixedCutOn'],$settings)->modify('+'.(int)($policy['graceDays']??0).' days');
}
function billingPolicyCutWindow(array $policy,DateTimeImmutable $at,array $settings): bool
{
    $local=$at->setTimezone(new DateTimeZone(POLICY_ZONE));$run=$local->setTime(...array_map('intval',explode(':',$settings['cutHour'])));
    // Past-due cuts catch up in the next worker cycle, including policies saved today.
    // Debt, grace, promises and the requested cut date are checked by the decision engine.
    return $local>=$run;
}

function billingPolicySettings(bool $private=false): array
{
    $row=fetchOne("SELECT * FROM BillingAutomationSetting WHERE id='primary'")??['id'=>'primary','enabled'=>0,'invoiceHour'=>'03:30','cutHour'=>'04:30','noticeHour'=>'04:30','lateFeeHour'=>'00:00','reminder1Hour'=>'08:30','reminder2Hour'=>'13:30','reminder3Hour'=>'17:00','gatewayUrl'=>null,'gatewaySecretEncrypted'=>null,'lastRunAt'=>null,'lastSummary'=>null];
    $row['enabled']=(bool)$row['enabled'];$row['billingWriteAuthorized']=billingNetworkGranted();$row['effectiveEnabled']=$row['enabled']&&(!networkReadOnly()||$row['billingWriteAuthorized']);$row['timezone']=POLICY_ZONE;$row['gatewayConfigured']=!empty($row['gatewayUrl'])&&!empty($row['gatewaySecretEncrypted']);
    if(!$private)unset($row['gatewaySecretEncrypted']);
    return $row;
}

function billingPolicyDefaults(string $clientId): array
{
    $service=fetchOne("SELECT * FROM Service WHERE clientId=? AND desiredState<>'RETIRED' ORDER BY createdAt,id LIMIT 1",[$clientId]);
    return ['clientId'=>$clientId,'calendarMode'=>'INHERIT','paymentType'=>'POSTPAID','paymentDay'=>(int)($service['billingDay']??1),'invoiceLeadDays'=>2,'generateEnabled'=>true,'graceDays'=>(int)($service['graceDays']??3),'cutAfterInvoices'=>0,'reduceEnabled'=>false,'reducedDownloadKbps'=>0,'reducedUploadKbps'=>0,'lateFeeMode'=>'NONE','lateFeeValue'=>0,'reconnectionFeeCents'=>0,'noticeLeadDays'=>0,'taxMode'=>'INCLUDED','tax1Bps'=>0,'tax2Bps'=>0,'tax3Bps'=>0,'reminder1Days'=>-2,'reminder2Days'=>null,'reminder3Days'=>null,'channelsJson'=>'["PORTAL"]','fixedInvoiceOn'=>null,'fixedCutOn'=>null,'fixedCutUsedAt'=>null,'networkServiceId'=>null,'networkSecretId'=>null,'revision'=>0];
}

function billingPolicyPublic(string $clientId): array
{
    $saved=billingPolicy($clientId);$row=$saved??billingPolicyDefaults($clientId);
    foreach(['paymentDay','invoiceLeadDays','graceDays','cutAfterInvoices','reducedDownloadKbps','reducedUploadKbps','lateFeeValue','reconnectionFeeCents','noticeLeadDays','tax1Bps','tax2Bps','tax3Bps','revision'] as $k)$row[$k]=(int)$row[$k];
    foreach(['generateEnabled','reduceEnabled'] as $k)$row[$k]=(bool)$row[$k];
    foreach(['reminder1Days','reminder2Days','reminder3Days'] as $k)$row[$k]=$row[$k]===null?null:(int)$row[$k];
    $row['configured']=$saved!==null;if(!empty($row['fixedCutOn']))$row['fixedCutOn']=billingDate($row['fixedCutOn'])->setTimezone(new DateTimeZone(POLICY_ZONE))->format('Y-m-d');$row['channels']=json_decode($row['channelsJson'],true,16,JSON_THROW_ON_ERROR);unset($row['channelsJson'],$row['networkBindingJson']);
    return $row;
}

function billingPolicySave(string $clientId,array $input,array $actor): array
{
    return apiLocks(['client:'.$clientId],function()use($clientId,$input,$actor):array {
        $client=apiRecord('Client',$clientId);if($client['status']==='RETIRED')throw new HttpError(409,'No se configura facturación automática de un cliente retirado.');
        $old=billingPolicy($clientId);$row=$old??billingPolicyDefaults($clientId);$allowed=['calendarMode','paymentType','paymentDay','invoiceLeadDays','generateEnabled','graceDays','cutAfterInvoices','reduceEnabled','reducedDownloadKbps','reducedUploadKbps','lateFeeMode','lateFeeValue','reconnectionFeeCents','noticeLeadDays','taxMode','tax1Bps','tax2Bps','tax3Bps','reminder1Days','reminder2Days','reminder3Days','channels','fixedInvoiceOn','fixedCutOn','networkServiceId','networkSecretId','revision'];
        if(array_diff(array_keys($input),$allowed))throw new HttpError(422,'Campo de configuración no admitido.');
        if(!isset($input['revision']) || $input['revision']!==(int)$row['revision'])throw new HttpError(409,'La configuración cambió; recarga antes de guardar.','POLICY_CONFLICT');
        foreach(['calendarMode'=>['INHERIT','FIXED'],'paymentType'=>['PREPAID','POSTPAID'],'lateFeeMode'=>['NONE','FIXED','PERCENT'],'taxMode'=>['INCLUDED','ADD','NONE']] as $key=>$options)if(isset($input[$key])){if(!in_array($input[$key],$options,true))throw new HttpError(422,'Opción inválida: '.$key);$row[$key]=$input[$key];}
        foreach(['paymentDay'=>[1,28],'invoiceLeadDays'=>[0,25],'graceDays'=>[0,90],'cutAfterInvoices'=>[0,12],'noticeLeadDays'=>[0,25],'reducedDownloadKbps'=>[0,10000000],'reducedUploadKbps'=>[0,10000000],'lateFeeValue'=>[0,BILLING_MAX_CENTS],'reconnectionFeeCents'=>[0,BILLING_MAX_CENTS],'tax1Bps'=>[0,10000],'tax2Bps'=>[0,10000],'tax3Bps'=>[0,10000]] as $key=>[$min,$max])if(array_key_exists($key,$input))$row[$key]=billingInteger($input[$key],$min,$max,$key);
        foreach(['generateEnabled','reduceEnabled'] as $key)if(array_key_exists($key,$input)){if(!is_bool($input[$key]))throw new HttpError(422,'Se requiere un valor booleano.');$row[$key]=(int)$input[$key];}
        if($row['lateFeeMode']==='PERCENT' && $row['lateFeeValue']>10000)throw new HttpError(422,'La mora porcentual no puede superar el 100%.');
        foreach(['reminder1Days','reminder2Days','reminder3Days'] as $key)if(array_key_exists($key,$input))$row[$key]=$input[$key]===null?null:billingInteger($input[$key],-25,25,$key);
        if(isset($input['channels'])){if(!is_array($input['channels']) || !array_is_list($input['channels']) || count($input['channels'])>4 || array_diff($input['channels'],['PORTAL','EMAIL','SMS','TELEGRAM']))throw new HttpError(422,'Canales inválidos.');$row['channelsJson']=json_encode(array_values(array_unique($input['channels'])),JSON_THROW_ON_ERROR);}
        foreach(['fixedInvoiceOn','fixedCutOn'] as $key)if(array_key_exists($key,$input)) {
            $value=$input[$key];if($value!==null){if(!is_string($value)||!preg_match('/^20[0-9]{2}-[0-9]{2}-[0-9]{2}$/D',$value))throw new HttpError(422,'Fecha fija inválida.');billingCalculationDate($value,$key);}
            if($key==='fixedCutOn'){$oldDay=empty($row[$key])?null:billingDate($row[$key])->setTimezone(new DateTimeZone(POLICY_ZONE))->format('Y-m-d');if($value===$oldDay)$value=$row[$key];else{$row['fixedCutUsedAt']=null;if($value!==null)$value=(new DateTimeImmutable($value.' '.billingPolicySettings()['cutHour'],new DateTimeZone(POLICY_ZONE)))->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s.v');}}
            $row[$key]=$value;
        }
        $bindingChanged=false;
        foreach(['networkServiceId','networkSecretId'] as $key)if(array_key_exists($key,$input)){if($input[$key]!==null)provisionIdentifier($input[$key]);$bindingChanged=$bindingChanged||$input[$key]!==($row[$key]??null);$row[$key]=$input[$key];}
        if(($row['networkServiceId']===null)!==($row['networkSecretId']===null))throw new HttpError(422,'Selecciona conjuntamente el servicio de cobro y su cuenta PPPoE, o deja ambos vacíos.');
        if($bindingChanged){
            if(fetchOne("SELECT b.serviceId FROM BillingServiceState b JOIN Service s ON s.id=b.serviceId WHERE s.clientId=? AND (COALESCE(b.appliedAction,'ACTIVE')<>'ACTIVE' OR b.desiredAction<>COALESCE(b.appliedAction,'ACTIVE')) LIMIT 1",[$clientId]))throw new HttpError(409,'Restablece primero los efectos de red antes de cambiar la vinculación.');
            $row['networkBindingJson']=null;
            if($row['networkServiceId']!==null){
                $service=fetchOne("SELECT * FROM Service WHERE id=? AND clientId=? AND desiredState<>'RETIRED'",[$row['networkServiceId'],$clientId]);
                $secret=fetchOne("SELECT * FROM RouterSecretImport WHERE id=? AND clientId=? AND present=1 AND pppService IN ('pppoe','any')",[$row['networkSecretId'],$clientId]);
                if(!$service||!$secret||clientPppArchived($secret['id'])!==null)throw new HttpError(422,'El servicio o cuenta no pertenece al cliente o ya no está disponible.');
                $row['networkBindingJson']=json_encode(['sourceId'=>$secret['id'],'routerId'=>$secret['routerId'],'remoteId'=>$secret['remoteId'],'usernameHex'=>bin2hex($secret['username'])],JSON_THROW_ON_ERROR);
            }
        }
        if(((int)$row['cutAfterInvoices']>0||(bool)$row['reduceEnabled']||(int)$row['noticeLeadDays']>0||(!empty($row['fixedCutOn'])&&empty($row['fixedCutUsedAt'])))&&$row['networkServiceId']===null&&!fetchOne("SELECT s.id FROM Service s WHERE s.clientId=? AND s.routerId IS NOT NULL AND s.desiredState<>'RETIRED' AND NOT EXISTS(SELECT 1 FROM LocalBillingService l WHERE l.serviceId=s.id) AND ".financialDeletionClause('Service','s').' LIMIT 1',[$clientId]))throw new HttpError(422,'Para activar cortes, reducción o avisos, registra un servicio de red o vincula el servicio de facturación con su cuenta PPPoE.');
        foreach(['generateEnabled','reduceEnabled'] as $flag)$row[$flag]=(int)$row[$flag];
        unset($row['configured'],$row['channels'],$row['updatedAt']);$row['revision']=(int)$row['revision']+1;$row['updatedAt']=now();
        tx(function(PDO $pdo)use($row,$clientId,$actor):void {
            $keys=array_keys($row);$updates=implode(',',array_map(static fn(string $k):string=>'`'.$k.'`=VALUES(`'.$k.'`)',$keys));
            $pdo->prepare('INSERT INTO ClientBillingPolicy (`'.implode('`,`',$keys).'`) VALUES ('.implode(',',array_fill(0,count($keys),'?')).') ON DUPLICATE KEY UPDATE '.$updates)->execute(array_values($row));
            audit('client.billing-policy.update','Client',$clientId,$actor['id']);
        });
        return billingPolicyPublic($clientId);
    });
}

/** No policy row means the original installation/legacy calendar remains exact. */
function billingPolicyDates(array $service,string $period,DateTimeImmutable $at,bool $preview=false): ?array
{
    $p=billingPolicy($service['clientId']);if(!$p||$p['calendarMode']!=='FIXED')return null;
    billingCalculationDate($period.'-01','period');$zone=new DateTimeZone(POLICY_ZONE);$settings=billingPolicySettings();
    $due=new DateTimeImmutable($period.'-'.str_pad((string)$p['paymentDay'],2,'0',STR_PAD_LEFT).' 00:00:00',$zone);
    $installation=billingLocalStartOn($service['id']);$start=$installation!==null?new DateTimeImmutable($installation.' 00:00:00',$zone):billingServiceStart($service)->setTimezone($zone);
    if($due<$start || ($p['paymentType']==='POSTPAID' && $due<$start->modify('first day of next month')->setTime(0,0)))return null;
    $issue=$due->modify('-'.(int)$p['invoiceLeadDays'].' days')->setTime(...array_map('intval',explode(':',$settings['invoiceHour'])));
    if(!empty($p['fixedInvoiceOn']) && substr($p['fixedInvoiceOn'],0,7)===$period)$issue=new DateTimeImmutable($p['fixedInvoiceOn'].' '.$settings['invoiceHour'],$zone);
    if($issue>$due)$issue=$due;
    if(!$preview && $issue>$at)return null;
    $cut=$due->modify('+'.(int)$p['graceDays'].' days')->setTime(...array_map('intval',explode(':',$settings['cutHour'])));
    return ['issuedAt'=>$issue->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s.v'),'dueAt'=>$due->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s.v'),'graceUntil'=>$cut->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s.v')];
}

function billingPolicyPeriods(array $service,DateTimeImmutable $at): array
{
    $zone=new DateTimeZone(POLICY_ZONE);$installation=billingLocalStartOn($service['id']);$start=$installation!==null?new DateTimeImmutable($installation.' 00:00:00',$zone):billingServiceStart($service)->setTimezone($zone);$cursor=$start->modify('first day of this month')->setTime(0,0);$last=$at->setTimezone($zone)->modify('first day of next month')->setTime(0,0);$out=[];
    while($cursor<=$last){$out[]=$cursor->format('Y-m');$cursor=$cursor->modify('+1 month');}return $out;
}

function billingPolicyCalendarDates(array $service,string $period,DateTimeImmutable $at,bool $preview=false): ?array
{
    $p=billingPolicy($service['clientId']);if(!$p)return null;if($p['calendarMode']==='FIXED')return billingPolicyDates($service,$period,$at,$preview);
    $start=billingLocalStartOn($service['id']);$future=billingDate($period.'-01')->modify('+2 months');
    $dates=$start!==null?billingAnniversaryDates($start,$period,(int)$p['graceDays'],$future):invoiceDates($period,(int)$service['billingDay'],(int)$service['dueDays'],(int)$p['graceDays'],billingDate($service['createdAt']),$future);
    if(!$dates)return null;$settings=billingPolicySettings();$due=billingDate($dates['dueAt'])->setTimezone(new DateTimeZone(POLICY_ZONE));$issue=$due->modify('-'.(int)$p['invoiceLeadDays'].' days')->setTime(...array_map('intval',explode(':',$settings['invoiceHour'])));
    if(!empty($p['fixedInvoiceOn'])&&substr($p['fixedInvoiceOn'],0,7)===$period)$issue=new DateTimeImmutable($p['fixedInvoiceOn'].' '.$settings['invoiceHour'],new DateTimeZone(POLICY_ZONE));if($issue>$due)$issue=$due;if(!$preview&&$issue>$at)return null;$dates['issuedAt']=$issue->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s.v');$dates['graceUntil']=billingPolicyCutAt($dates['graceUntil'],$settings)->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s.v');return $dates;
}

function billingPolicyTax(array $service,array $calculation): array
{
    $p=billingPolicy($service['clientId']);if(!$p||$p['taxMode']!=='ADD')return $calculation;$base=(int)$calculation['amountCents'];
    foreach(['tax1Bps','tax2Bps','tax3Bps'] as $i=>$key)if((int)$p[$key]>0){$amount=intdiv($base*(int)$p[$key]+5000,10000);if(!$amount)continue;
        if($calculation['amountCents']>BILLING_MAX_CENTS-$amount)throw new HttpError(422,'El importe con impuestos excede el límite admitido.');
        $calculation['lines'][]=['type'=>'CHARGE','chargeId'=>null,'discountId'=>null,'description'=>'Impuesto #'.($i+1).' ('.number_format((int)$p[$key]/100,2).'%)','quantity'=>1,'unitCents'=>$amount,'totalCents'=>$amount];$calculation['amountCents']+=$amount;
    }return $calculation;
}

function billingPolicyFee(array $invoice,string $kind,int $amount): bool
{
    if($amount<=0||$invoice['status']!=='OPEN'||(int)$invoice['paidCents']>=(int)$invoice['amountCents']||financialDeleted('Invoice',$invoice['id'])||fetchOne('SELECT id FROM InvoiceAutomationFee WHERE invoiceId=? AND kind=?',[$invoice['id'],$kind]))return false;
    if($amount>BILLING_MAX_CENTS-(int)$invoice['amountCents'])throw new HttpError(422,'El recargo excede el límite de la factura.');
    $line=id();$position=(int)fetchOne('SELECT COALESCE(MAX(position),-1)+1 AS n FROM InvoiceLine WHERE invoiceId=?',[$invoice['id']])['n'];
    db()->prepare("INSERT INTO InvoiceLine(id,invoiceId,type,position,description,quantity,unitCents,totalCents,currency,createdAt) VALUES (?,?,'CHARGE',?,?,1,?,?,?,?)")->execute([$line,$invoice['id'],$position,$kind==='LATE'?'Recargo por mora':'Cargo de reconexión',$amount,$amount,$invoice['currency'],now()]);
    db()->prepare('INSERT INTO InvoiceAutomationFee(id,invoiceId,lineId,kind,amountCents) VALUES (?,?,?,?,?)')->execute([id(),$invoice['id'],$line,$kind,$amount]);
    db()->prepare('UPDATE Invoice SET amountCents=amountCents+?,updatedAt=? WHERE id=?')->execute([$amount,now(),$invoice['id']]);
    clientProfileEvent($invoice['clientId'],'FEE_'.$kind,['invoiceId'=>$invoice['id'],'amountCents'=>$amount,'currency'=>$invoice['currency']],$invoice['serviceId'],null,'BILLING');return true;
}

/** Pure decision: promises cover only their invoice, manual suspension wins. */
function billingPolicyDecision(array $p,array $invoices,array $promises,DateTimeImmutable $at,bool $manual=false,?array $settings=null,?string $previous=null): array
{
    if($manual)return ['state'=>'MANUAL','overdue'=>0,'outstanding'=>count($invoices)];
    $unpaid=[];$overdue=[];$protected=[];$warning=false;$fixedDebt=false;$stamp=$at->format('Y-m-d H:i:s.v');$settings??=['noticeHour'=>'04:30'];
    foreach($invoices as $i){if($i['status']!=='OPEN'||(int)$i['paidCents']>=(int)$i['amountCents'])continue;$unpaid[]=$i;
        $covered=false;foreach($promises as $pr)if($pr['invoiceId']===$i['id']&&$pr['status']==='ACTIVE'&&$pr['promisedUntil']>$stamp&&$pr['currency']===$i['currency']&&(int)$pr['amountCents']>=(int)$i['amountCents']-(int)$i['paidCents']){$covered=true;break;}
        if($covered){$protected[]=$i;continue;}
        // A consumed fixed trigger keeps controlling only the debt that existed when it cut.
        // Later invoices cannot re-arm it; a covering promise can temporarily protect old debt.
        if(!empty($p['fixedCutOn'])&&!empty($p['fixedCutUsedAt'])&&isset($i['createdAt'])&&billingDate($i['createdAt'])<=billingDate($p['fixedCutUsedAt']))$fixedDebt=true;
        if(billingPolicyCutAt($i['graceUntil'],$settings)<=$at)$overdue[]=$i;
        $due=billingDate($i['dueAt'])->setTimezone(new DateTimeZone(POLICY_ZONE));$notice=$due->modify('-'.(int)$p['noticeLeadDays'].' days')->setTime(...array_map('intval',explode(':',$settings['noticeHour'])));
        if((int)$p['noticeLeadDays']>0&&$at>=$notice)$warning=true;
    }
    $cut=$fixedDebt||((int)$p['cutAfterInvoices']>0&&count($overdue)>=(int)$p['cutAfterInvoices']);
    $fixed=billingPolicyFixedCutAt($p,$settings);
    if($unpaid&&$fixed!==null&&$fixed<=$at&&count($protected)!==count($unpaid))$cut=true;
    $keepLimited=in_array($previous,['LIMITED','CUT'],true)&&$unpaid&&count($protected)<count($unpaid);
    $state=$cut?'CUT':(($overdue||$keepLimited)&&(bool)$p['reduceEnabled']&&(int)$p['reducedDownloadKbps']>0&&(int)$p['reducedUploadKbps']>0?'LIMITED':($warning?'WARNING':'ACTIVE'));
    return ['state'=>$state,'overdue'=>count($overdue),'outstanding'=>count($unpaid),'promised'=>count($protected)];
}

function billingPolicyStage(array $service,array $p,array $decision): ?string
{
    if(!billingPolicySettings()['effectiveEnabled']||$decision['state']==='MANUAL'||$service['desiredState']==='RETIRED')return null;
    if(billingLocalIsService($service['id']) && ($p['networkServiceId']??null)!==$service['id'])return null;
    if(clientPppPending($service['clientId'])||provisionPending($service['clientId']))return null;
    if(fetchOne("SELECT id FROM Task WHERE status IN ('QUEUED','RUNNING') AND kind='SERVICE_SYNC' AND JSON_UNQUOTE(JSON_EXTRACT(payload,'$.source'))='profile-plan-change' AND JSON_UNQUOTE(JSON_EXTRACT(payload,'$.serviceId'))=? LIMIT 1",[$service['id']]))return null;
    $state=fetchOne('SELECT * FROM BillingServiceState WHERE serviceId=?',[$service['id']]);$action=$decision['state'];
    if($action==='CUT'&&($state['appliedAction']??null)!=='CUT'&&!billingPolicyCutWindow($p,billingNow(),billingPolicySettings()))return null;
    if(!$state&&$action==='ACTIVE')return null;
    $revision=(int)($state['revision']??0)+1;
    if($state && $state['desiredAction']===$action && $state['appliedAction']===$action && !$state['lastError'])return null;
    if($state && $state['desiredAction']===$action){$pending=fetchOne("SELECT id FROM Task WHERE kind='SERVICE_SYNC' AND status IN ('QUEUED','RUNNING') AND JSON_UNQUOTE(JSON_EXTRACT(payload,'$.source'))='billing-policy' AND JSON_UNQUOTE(JSON_EXTRACT(payload,'$.serviceId'))=? LIMIT 1",[$service['id']]);if($pending)return $pending['id'];}
    db()->prepare('INSERT INTO BillingServiceState(serviceId,desiredAction,revision,updatedAt) VALUES (?,?,?,?) ON DUPLICATE KEY UPDATE desiredAction=VALUES(desiredAction),revision=VALUES(revision),updatedAt=VALUES(updatedAt)')->execute([$service['id'],$action,$revision,now()]);
    $task=enqueue('SERVICE_SYNC',['serviceId'=>$service['id'],'source'=>'billing-policy','policyRevision'=>$revision,'desiredAction'=>$action],'billing-policy-'.$service['id'].'-'.$revision);return $task['id'];
}

function billingPolicyReconcile(string $serviceId,?DateTimeImmutable $at=null): array
{
    $service=billingService($serviceId);if(!$service||$service['client']['status']==='RETIRED')return [];$p=billingPolicy($service['clientId']);if(!$p)return [];
    $invoices=fetchAll('SELECT * FROM Invoice i WHERE serviceId=? AND '.financialDeletionClause('Invoice','i'),[$serviceId]);$promises=fetchAll('SELECT p.* FROM PaymentPromise p JOIN Invoice i ON i.id=p.invoiceId WHERE i.serviceId=?',[$serviceId]);
    $manual=clientPppManualSuspension($service['clientId'])!==null||($service['suspensionReason']==='MANUAL');
    $previous=fetchOne('SELECT appliedAction FROM BillingServiceState WHERE serviceId=?',[$serviceId])['appliedAction']??null;
    $decision=billingPolicyDecision($p,$invoices,$promises,$at??billingNow(),$manual,billingPolicySettings(),$previous);$task=billingPolicyStage($service,$p,$decision);return $task?[$task]:[];
}

function billingPolicyTick(?DateTimeImmutable $at=null,bool $force=false): array
{
    $at??=billingNow();$summary=['clients'=>0,'created'=>0,'fees'=>0,'tasks'=>0,'notices'=>0,'failed'=>0];
    if(!fetchOne('SELECT clientId FROM ClientBillingPolicy LIMIT 1')||!lock('billing-policy-tick',0))return $summary;
    try{
        db()->prepare("INSERT IGNORE INTO BillingAutomationSetting(id) VALUES ('primary')")->execute();$setting=billingPolicySettings(true);
        $reserved=fetchOne("SELECT nextRunAt FROM BillingAutomationSetting WHERE id='primary'");if(!$force&&!empty($reserved['nextRunAt'])&&$reserved['nextRunAt']>$at->format('Y-m-d H:i:s.v'))return $summary;
        db()->prepare("UPDATE BillingAutomationSetting SET nextRunAt=?,lastRunAt=? WHERE id='primary'")->execute([$at->modify('+1 minute')->format('Y-m-d H:i:s.v'),$at->format('Y-m-d H:i:s.v')]);
        foreach(fetchAll("SELECT p.* FROM ClientBillingPolicy p JOIN Client c ON c.id=p.clientId WHERE c.status<>'RETIRED' ORDER BY p.clientId") as $p){
            try{billingWithLocks(['client:'.$p['clientId']],function()use($p,$at,&$summary):void {
                foreach(fetchAll("SELECT * FROM Service s WHERE clientId=? AND desiredState<>'RETIRED' AND ".financialDeletionClause('Service','s'),[$p['clientId']]) as $raw){
                    $service=billingService($raw['id']);
                    if((bool)$p['generateEnabled'])foreach(billingServicePeriods($service,$at) as $period){if(fetchOne('SELECT id FROM Invoice WHERE serviceId=? AND period=?',[$service['id'],$period]))continue;
                        tx(function(PDO $pdo)use($service,$period,$at,&$summary):void {$made=makeInvoice($service,$period,$at);if($made&&$made['created']){$summary['created']++;clientProfileEvent($service['clientId'],'INVOICE_CREATED',['invoiceId'=>$made['invoice']['id']],$service['id'],null,'BILLING');}});
                    }
                    foreach(fetchAll("SELECT * FROM Invoice i WHERE serviceId=? AND status='OPEN' AND ".financialDeletionClause('Invoice','i'),[$service['id']]) as $invoice){
                        tx(fn(PDO $pdo):int=>resolveInvoicePromises($invoice['id'],false,$at));
                        $late=billingDate($invoice['dueAt'])->setTimezone(new DateTimeZone(POLICY_ZONE))->modify('+1 day')->setTime(...array_map('intval',explode(':',billingPolicySettings()['lateFeeHour'])));
                        if($p['lateFeeMode']!=='NONE'&&$at>=$late){$amount=$p['lateFeeMode']==='PERCENT'?intdiv(((int)$invoice['amountCents']-(int)$invoice['paidCents'])*(int)$p['lateFeeValue']+5000,10000):(int)$p['lateFeeValue'];$summary['fees']+=tx(fn(PDO $pdo):int=>(int)billingPolicyFee($invoice,'LATE',$amount));}
                        $invoice=fetchOne('SELECT * FROM Invoice WHERE id=?',[$invoice['id']]);$summary['notices']+=billingPolicyInvoiceNotices($invoice,$p,$at);
                    }
                    $summary['tasks']+=count(billingPolicyReconcile($service['id'],$at));
                }$summary['clients']++;
            });}catch(Throwable $error){$summary['failed']++;try{clientProfileEvent($p['clientId'],'BILLING_ERROR',['message'=>workerPublicError($error)],null,null,'BILLING','billing-error:'.$p['clientId'].':'.$at->format('Y-m-d-H-i'));}catch(Throwable){}}
        }
        billingPolicyDeliverNotices(10);db()->prepare("UPDATE BillingAutomationSetting SET lastSummary=?,updatedAt=? WHERE id='primary'")->execute([json_encode($summary,JSON_THROW_ON_ERROR),now()]);return $summary;
    }finally{unlock('billing-policy-tick');}
}
