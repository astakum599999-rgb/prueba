<?php
declare(strict_types=1);
namespace Nexo;

/** Called inside the validated PPP snapshot transaction; no network I/O. */
function dashboardConnectionsObserve(array $router,array $sessions,string $observed): void
{
    $clients=[];$owners=[];
    foreach(clientIpLiveAccounts([],$router['id']) as $account){$hex=bin2hex($account['username']);$clients[$account['clientId']][$hex]=true;$owners[$hex][$account['clientId']]=true;}
    foreach($owners as $ids)if(count($ids)!==1)foreach($ids as $clientId=>$unused)unset($clients[$clientId]);
    $previous=[];foreach(fetchAll('SELECT * FROM DashboardConnection WHERE routerId=?',[$router['id']]) as $row)$previous[$row['clientId']]=$row;
    $grouped=[];
    foreach($sessions as $session){$hex=$session['usernameHex'];if($session['service']!=='pppoe'||count($owners[$hex]??[])!==1)continue;$clientId=array_key_first($owners[$hex]);$grouped[$clientId][]=$session;}
    foreach($clients as $clientId=>$names){
        $old=$previous[$clientId]??null;if($old&&$old['observedAt']>=$observed)continue;
        $rows=$grouped[$clientId]??[];$addresses=[];$keys=[];
        foreach($rows as $row){$addresses[]=$row['address'];$keys[]=($row['remoteId']??$row['usernameHex']).':'.$row['address'];}
        $addresses=array_values(array_unique($addresses));sort($addresses,SORT_STRING);sort($keys,SORT_STRING);
        $connected=$rows!==[];$hash=$connected?hash('sha256',json_encode($keys,JSON_THROW_ON_ERROR)):null;
        if($old&&(bool)$old['connected']===$connected&&$old['sessionHash']===$hash)continue;
        $connectedAt=$connected?$observed:($old['connectedAt']??null);
        db()->prepare('INSERT INTO DashboardConnection(clientId,routerId,connected,sessionHash,connectedAt,observedAt,addressesJson) VALUES (?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE connected=VALUES(connected),sessionHash=VALUES(sessionHash),connectedAt=VALUES(connectedAt),observedAt=VALUES(observedAt),addressesJson=VALUES(addressesJson)')
            ->execute([$clientId,$router['id'],(int)$connected,$hash,$connectedAt,$observed,json_encode($addresses,JSON_THROW_ON_ERROR)]);
    }
    foreach(array_chunk(array_keys($clients),500) as $ids){$slots=implode(',',array_fill(0,count($ids),'?'));db()->prepare("UPDATE DashboardConnection SET observedAt=? WHERE routerId=? AND observedAt<? AND clientId IN ($slots)")->execute([$observed,$router['id'],$observed,...$ids]);}
}

function dashboardConnectionsRecent(): array
{
    $rows=fetchAll("SELECT d.*,c.name,c.code,r.name AS routerName,p.status AS cacheStatus,p.lastSuccessAt,p.failures FROM DashboardConnection d JOIN Client c ON c.id=d.clientId JOIN Router r ON r.id=d.routerId LEFT JOIN RouterPppActiveCache p ON p.routerId=d.routerId WHERE d.connectedAt IS NOT NULL AND c.status<>'RETIRED' AND NOT EXISTS (SELECT 1 FROM DashboardConnection newer WHERE newer.clientId=d.clientId AND (newer.connectedAt>d.connectedAt OR (newer.connectedAt=d.connectedAt AND newer.routerId>d.routerId))) ORDER BY d.connectedAt DESC,d.clientId LIMIT 10");
    return array_map(static function(array $row):array{
        $fresh=$row['observedAt']===$row['lastSuccessAt']&&clientIpLiveFresh(['status'=>$row['cacheStatus'],'lastSuccessAt'=>$row['lastSuccessAt'],'failures'=>$row['failures']]);
        return ['clientId'=>$row['clientId'],'name'=>$row['name'],'code'=>$row['code'],'routerName'=>$row['routerName'],'addresses'=>json_decode($row['addressesJson'],true,32,JSON_THROW_ON_ERROR),'connectedAt'=>dashboardOnlineIso($row['connectedAt']),'observedAt'=>dashboardOnlineIso($row['observedAt']),'status'=>$fresh?((bool)$row['connected']?'ONLINE':'OFFLINE'):'UNKNOWN'];
    },$rows);
}
