<?php
declare(strict_types=1);
namespace Nexo;

use DateTimeImmutable;
use DateTimeZone;
use PDO;
use Throwable;

const DASHBOARD_TRAFFIC_INTERVAL = 1;

function dashboardTrafficTransport(array $router): RouterTransport
{
    $password=decryptSecret($router['passwordEncrypted']);
    return match($router['transport']){'REST'=>new RouterRestTransport($router,$password,2.0),'SOCKET'=>new RouterSocketTransport($router,$password,2.0),default=>throw new HttpError(422,'Se necesita un router real.')};
}

function dashboardTrafficUnsigned(mixed $value): string
{
    if(is_int($value))$value=(string)$value;
    if(!is_string($value)||!preg_match('/^[0-9]{1,20}$/D',$value))throw new HttpError(502,'El equipo no devolvió contadores de tráfico válidos.','INVALID_TRAFFIC_COUNTER');
    $value=ltrim($value,'0');$value=$value===''?'0':$value;
    if(strlen($value)===20&&strcmp($value,'18446744073709551615')>0)throw new HttpError(502,'Contador fuera de rango.','INVALID_TRAFFIC_COUNTER');
    return $value;
}

/** Subtract UInt64 decimal strings before converting the small delta to float. */
function dashboardTrafficDelta(string $current,string $previous): ?float
{
    if(strlen($current)<strlen($previous)||(strlen($current)===strlen($previous)&&strcmp($current,$previous)<0))return null;
    $previous=str_pad($previous,strlen($current),'0',STR_PAD_LEFT);$result='';$borrow=0;
    for($i=strlen($current)-1;$i>=0;$i--){$digit=(int)$current[$i]-(int)$previous[$i]-$borrow;$borrow=$digit<0?1:0;$result=(string)($digit<0?$digit+10:$digit).$result;}
    return (float)$result;
}

function dashboardTrafficRows(RouterTransport $transport,string $path,string $fields): array
{
    $options=['.proplist'=>$fields];if(in_array($path,['/interface','/queue/simple'],true))$options['stats']='';$rows=$transport->print($path,[],$options);
    if(!array_is_list($rows)||count($rows)>CLIENT_IP_LIVE_LIMIT)throw new HttpError(502,'La lista de contadores no es válida.','INVALID_TRAFFIC_COUNTER');
    $seen=[];foreach($rows as $row){if(!is_array($row)||!is_string($row['.id']??null)||!preg_match('/^\*[a-z0-9]{1,32}$/iD',$row['.id'])||isset($seen[$row['.id']]))throw new HttpError(502,'La lista de contadores no es válida.','INVALID_TRAFFIC_COUNTER');$seen[$row['.id']]=true;}
    return $rows;
}

function dashboardTrafficMetric(string $source,mixed $upload,mixed $download,string $clientId): array
{
    return ['clientId'=>$clientId,'sourceKey'=>hash_hmac('sha256','dashboard-counter:'.$clientId.':'.$source,encryptionKey()),'uploadBytes'=>dashboardTrafficUnsigned($upload),'downloadBytes'=>dashboardTrafficUnsigned($download)];
}

/** One bounded counter print, not one monitor-traffic operation per subscriber. */
function dashboardTrafficReadRouter(array $router,array $accounts,array $services): array
{
    $transport=dashboardTrafficTransport($router);
    try{
        if($transport->isSimulated())throw new HttpError(422,'Los equipos simulados no generan tráfico real.');
        $metrics=[];$active=[];$activeIps=[];
        if($accounts){
            $cache=fetchOne('SELECT * FROM RouterPppActiveCache WHERE routerId=?',[$router['id']]);
            if(!clientIpLiveFresh($cache))throw new HttpError(502,'Falta una lectura PPP reciente para medir el tráfico.');
            $owners=[];foreach($accounts as $account)$owners[bin2hex($account['username'])][$account['clientId']]=true;
            foreach(json_decode($cache['sessions'],true,64,JSON_THROW_ON_ERROR) as $session){
                if($session['service']!=='pppoe'||!isset($owners[$session['usernameHex']]))continue;
                if(count($owners[$session['usernameHex']])!==1)throw new HttpError(409,'Hay una cuenta de red asociada a más de un cliente.');
                $active[$session['usernameHex']][]=$session;$activeIps[$session['address']]=true;
            }
        }
        if($active){
            $interfaces=dashboardTrafficRows($transport,'/interface','.id,name,type,running,rx-byte,tx-byte');$byName=[];
            foreach($interfaces as $row)if(($row['type']??null)==='pppoe-in'&&is_string($row['name']??null))$byName[$row['name']][]=$row;
            $selected=[];$missing=false;
            foreach($active as $hex=>$sessions){$selected[$hex]=$byName['<pppoe-'.hex2bin((string)$hex).'>']??[];if(count($selected[$hex])!==count($sessions))$missing=true;}
            if($missing){
                $bindings=dashboardTrafficRows($transport,'/interface/pppoe-server','.id,name,user');$selected=array_fill_keys(array_keys($active),[]);
                foreach($bindings as $binding){if(!is_string($binding['user']??null)||!is_string($binding['name']??null))continue;$hex=bin2hex($binding['user']);if(!isset($active[$hex]))continue;foreach($byName[$binding['name']]??[] as $row)$selected[$hex][$row['.id']??'']=$row;}
            }
            foreach($active as $hex=>$sessions){
                $rows=array_values($selected[$hex]??[]);if(count($rows)!==count($sessions))throw new HttpError(502,'No se identificaron todas las interfaces PPPoE activas.');
                $identities=array_map(static fn(array $s):string=>$s['remoteId']??$s['address'],$sessions);sort($identities,SORT_STRING);
                foreach($rows as $row){
                    if(!is_string($row['.id']??null)||!preg_match('/^\*[a-z0-9]{1,32}$/iD',$row['.id'])||!in_array($row['running']??null,[true,'true','yes','1'],true))throw new HttpError(502,'La interfaz PPPoE cambió durante la lectura.');
                    $metric=dashboardTrafficMetric('pppoe:'.$row['.id'].':'.$hex.':'.implode(',',$identities),$row['rx-byte']??null,$row['tx-byte']??null,array_key_first($owners[$hex]));$metrics[$metric['sourceKey']]=$metric;
                }
            }
        }
        if($services){
            $queues=dashboardTrafficRows($transport,'/queue/simple','.id,name,target,bytes,disabled,comment');$hotspot=null;
            foreach($services as $service){
                $ip=$service['ipAddress'];if(!is_string($ip)||filter_var($ip,FILTER_VALIDATE_IP)===false)throw new HttpError(422,'Un servicio de red no tiene una IP medible.');
                if(isset($activeIps[$ip]))throw new HttpError(409,'Una IP aparece en servicios PPPoE y de cola simple; revisa su asignación.');
                $matches=[];
                foreach($queues as $queue){$target=$queue['target']??null;if(!in_array($target,[$ip,$ip.'/32',$ip.'/128'],true))continue;$matches[]=$queue;}
                if(!$matches&&$service['type']==='HOTSPOT'){
                    $hotspot??=dashboardTrafficRows($transport,'/ip/hotspot/active','.id,user,address');$online=false;foreach($hotspot as $session)if(($session['address']??null)===$ip)$online=true;if(!$online)continue;
                }
                if(count($matches)!==1)throw new HttpError(502,'Se necesita una cola individual con contadores para cada servicio IP/Hotspot.');
                $queue=$matches[0];if(in_array($queue['disabled']??null,[true,'true','yes','1'],true))continue;
                if(!is_string($queue['.id']??null)||!preg_match('/^\*[a-z0-9]{1,32}$/iD',$queue['.id']))throw new HttpError(502,'La cola no tiene un identificador válido.');
                $pair=is_string($queue['bytes']??null)?explode('/',$queue['bytes']):($queue['bytes']??null);if(!is_array($pair)||!array_is_list($pair)||count($pair)!==2)throw new HttpError(502,'La cola no devolvió sus contadores de bytes.');
                $metric=dashboardTrafficMetric('queue:'.$queue['.id'].':'.$ip,$pair[0],$pair[1],$service['clientId']);$metrics[$metric['sourceKey']]=$metric;
            }
        }
        return array_values($metrics);
    }finally{$transport->close();}
}

function dashboardTrafficBucket(float $download,float $upload,string $observed): void
{
    foreach(['MINUTE'=>substr($observed,0,16).':00','HOUR'=>substr($observed,0,13).':00:00'] as $resolution=>$bucket){
        db()->prepare('INSERT INTO DashboardTrafficBucket(resolution,bucketAt,sampleCount,downloadSum,uploadSum,downloadPeak,uploadPeak,firstSampleAt,lastSampleAt) VALUES (?,?,1,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE sampleCount=sampleCount+1,downloadSum=downloadSum+VALUES(downloadSum),uploadSum=uploadSum+VALUES(uploadSum),downloadPeak=GREATEST(downloadPeak,VALUES(downloadPeak)),uploadPeak=GREATEST(uploadPeak,VALUES(uploadPeak)),lastSampleAt=VALUES(lastSampleAt)')->execute([$resolution,$bucket,$download,$upload,$download,$upload,$observed,$observed]);
    }
}

/** One shared reservation for worker, dashboard and concurrent browsers. */
function dashboardTrafficTick(): void
{
    if(!lock('dashboard-traffic',0))return;
    try{
        db()->exec("INSERT IGNORE INTO DashboardTrafficState(id) VALUES ('primary')");$state=fetchOne("SELECT * FROM DashboardTrafficState WHERE id='primary'");$started=now();
        if($state['nextRunAt']!==null&&$state['nextRunAt']>$started)return;
        db()->prepare("UPDATE DashboardTrafficState SET nextRunAt=? WHERE id='primary'")->execute([clientIpLiveAfter(90,$started)]);
        $deadline=microtime(true)+6;
        $clients=array_fill_keys(array_column(fetchAll("SELECT id FROM Client WHERE status<>'RETIRED'"),'id'),true);
        $routers=fetchAll("SELECT * FROM Router WHERE transport IN ('REST','SOCKET') ORDER BY id");$sets=[];$total=0;$covered=0;$ready=true;$download=0.0;$upload=0.0;$observed=null;$errors=[];$busy=false;$hardError=false;
        foreach($routers as $router){
            $accounts=array_values(array_filter(clientIpLiveAccounts([],$router['id']),static fn(array $a):bool=>isset($clients[$a['clientId']])));
            $services=fetchAll("SELECT s.* FROM Service s LEFT JOIN LocalBillingService l ON l.serviceId=s.id JOIN Client c ON c.id=s.clientId WHERE s.routerId=? AND s.type<>'PPPOE' AND s.desiredState<>'RETIRED' AND (s.appliedState IS NULL OR s.appliedState<>'RETIRED') AND c.status<>'RETIRED' AND l.serviceId IS NULL",[$router['id']]);
            if(!$accounts&&!$services)continue;$total++;
            if(microtime(true)>$deadline){$errors[]='La lectura de algunos routers se reintentará en el próximo ciclo.';$hardError=true;continue;}
            if(!lock('router:'.$router['id'],1)){$busy=true;continue;}
            try{
                if(microtime(true)>$deadline)throw new HttpError(503,'La lectura de algunos routers se reintentará en el próximo ciclo.');
                if(function_exists(__NAMESPACE__.'\\clientPppoeEditPending')&&clientPppoeEditPending($router['id']))throw new HttpError(409,'La medición espera la confirmación de una edición PPPoE.');
                if($accounts){
                    $cache=fetchOne('SELECT * FROM RouterPppActiveCache WHERE routerId=?',[$router['id']]);
                    if(!clientIpLiveFresh($cache)){
                        if($cache!==null&&clientIpLiveNextQueryAt($cache)>now())throw new HttpError(503,'La lectura PPP está esperando su reintento.');
                        $pppStarted=now();$count=null;
                        try{$sessions=clientIpLiveRead(dashboardTrafficTransport($router),$count);clientIpLiveStore($router,$sessions,$count,$pppStarted,now());}
                        catch(Throwable $error){clientIpLiveStoreFailure($router['id'],$error);throw $error;}
                    }
                }
                $metrics=dashboardTrafficReadRouter($router,$accounts,$services);$at=now();$previous=[];foreach(fetchAll('SELECT * FROM DashboardTrafficCounter WHERE routerId=?',[$router['id']]) as $row)$previous[$row['sourceKey']]=$row;
                foreach($metrics as $metric){
                    $old=$previous[$metric['sourceKey']]??null;
                    if(!$old){$ready=false;continue;}
                    $elapsed=(float)(new DateTimeImmutable($at,new DateTimeZone('UTC')))->format('U.u')-(float)(new DateTimeImmutable($old['observedAt'],new DateTimeZone('UTC')))->format('U.u');
                    $down=dashboardTrafficDelta($metric['downloadBytes'],$old['downloadBytes']);$up=dashboardTrafficDelta($metric['uploadBytes'],$old['uploadBytes']);
                    if($elapsed<0.2||$elapsed>15||$down===null||$up===null){$ready=false;continue;}
                    $download+=$down*8/$elapsed;$upload+=$up*8/$elapsed;
                }
                $sets[]=['routerId'=>$router['id'],'metrics'=>$metrics,'at'=>$at];$covered++;$observed=$observed===null?$at:min($observed,$at);
            }catch(Throwable $error){$hardError=true;$errors[]=$error instanceof HttpError?$error->getMessage():'No se pudo leer el tráfico de un router.';}
            finally{unlock('router:'.$router['id']);}
        }
        $status=$total===0?'EMPTY':($covered!==$total?($covered?'PARTIAL':($hardError?'ERROR':'PENDING')):($ready?'SUCCESS':'WARMING'));
        $stateAge=$state['observedAt']===null?INF:microtime(true)-(float)(new DateTimeImmutable($state['observedAt'],new DateTimeZone('UTC')))->format('U.u');
        $keepLast=$busy&&!$hardError&&($state['status']??null)==='SUCCESS'&&$stateAge>=0&&$stateAge<5;
        $failures=$status==='ERROR'?min(10,(int)$state['failures']+1):0;$delay=$failures?clientIpLiveRetrySeconds($failures):DASHBOARD_TRAFFIC_INTERVAL;
        $message=$errors?substr(implode(' ',array_unique($errors)),0,480):null;while($message!==null&&preg_match('//u',$message)!==1)$message=substr($message,0,-1);
        $next=clientIpLiveAfter($delay,$status==='SUCCESS'?$started:now());
        tx(static function(PDO $pdo)use($sets,$status,$covered,$total,$ready,$download,$upload,$observed,$message,$failures,$next,$keepLast):void{
            foreach($sets as $set){
                foreach(array_chunk($set['metrics'],500) as $chunk){$values=[];foreach($chunk as $metric)array_push($values,$set['routerId'],$metric['clientId'],$metric['sourceKey'],$metric['uploadBytes'],$metric['downloadBytes'],$set['at']);$sql='INSERT INTO DashboardTrafficCounter(routerId,clientId,sourceKey,uploadBytes,downloadBytes,observedAt) VALUES '.implode(',',array_fill(0,count($chunk),'(?,?,?,?,?,?)')).' ON DUPLICATE KEY UPDATE uploadBytes=VALUES(uploadBytes),downloadBytes=VALUES(downloadBytes),observedAt=VALUES(observedAt)';$pdo->prepare($sql)->execute($values);}
                $pdo->prepare('DELETE FROM DashboardTrafficCounter WHERE routerId=? AND observedAt<>?')->execute([$set['routerId'],$set['at']]);
            }
            if($keepLast){$pdo->prepare("UPDATE DashboardTrafficState SET nextRunAt=?,lastError=NULL,failures=0 WHERE id='primary'")->execute([$next]);return;}
            $success=$status==='SUCCESS';if($success)dashboardTrafficBucket($download,$upload,$observed);
            $pdo->prepare("UPDATE DashboardTrafficState SET status=?,nextRunAt=?,observedAt=IF(?=1,?,observedAt),downloadBps=?,uploadBps=?,coveredRouters=?,totalRouters=?,lastError=?,failures=? WHERE id='primary'")->execute([$status,$next,(int)$success,$observed,$success?$download:null,$success?$upload:null,$covered,$total,$message,$failures]);
            if((int)gmdate('s')<2){$pdo->exec("DELETE FROM DashboardTrafficCounter WHERE observedAt<UTC_TIMESTAMP()-INTERVAL 1 DAY LIMIT 2000");$pdo->exec("DELETE FROM DashboardTrafficBucket WHERE resolution='MINUTE' AND bucketAt<UTC_TIMESTAMP()-INTERVAL 32 DAY LIMIT 2000");$pdo->exec("DELETE FROM DashboardTrafficBucket WHERE resolution='HOUR' AND bucketAt<UTC_TIMESTAMP()-INTERVAL 400 DAY LIMIT 2000");}
        });
    }catch(Throwable){
        db()->prepare("UPDATE DashboardTrafficState SET status='ERROR',nextRunAt=?,downloadBps=NULL,uploadBps=NULL,lastError='No se pudo completar la medición de tráfico.' WHERE id='primary'")->execute([clientIpLiveAfter(5)]);
    }finally{unlock('dashboard-traffic');}
}

function dashboardTrafficHistory(string $period): array
{
    $days=match($period){'day'=>0,'week'=>6,'month'=>29,'year'=>364,default=>throw new HttpError(422,'Elige diario, últimos 7 días, último mes o último año.','VALIDATION_ERROR')};
    $step=match($period){'day'=>300,'week'=>3600,'month'=>21600,default=>86400};$local=new DateTimeImmutable('now',new DateTimeZone('America/Lima'));$from=$local->setTime(0,0)->modify('-'.$days.' days')->setTimezone(new DateTimeZone('UTC'));$to=$local->setTimezone(new DateTimeZone('UTC'));$epoch=$from->getTimestamp();
    $resolution=$period==='year'?'HOUR':'MINUTE';
    $rows=fetchAll("SELECT FLOOR((TIMESTAMPDIFF(SECOND,'1970-01-01',bucketAt)-?)/?) AS slot,SUM(downloadSum)/SUM(sampleCount) AS downloadBps,SUM(uploadSum)/SUM(sampleCount) AS uploadBps,SUM(sampleCount) AS samples,MAX(downloadPeak) AS downloadPeak,MAX(uploadPeak) AS uploadPeak FROM DashboardTrafficBucket WHERE resolution=? AND bucketAt>=? AND bucketAt<=? GROUP BY slot ORDER BY slot",[$epoch,$step,$resolution,$from->format('Y-m-d H:i:s'),$to->format('Y-m-d H:i:s')]);
    $slots=[];foreach($rows as $row)$slots[(int)$row['slot']]=$row;$points=[];
    for($slot=0;$slot<=(int)floor(($to->getTimestamp()-$epoch)/$step);$slot++){$row=$slots[$slot]??null;$points[]=['at'=>gmdate('Y-m-d\TH:i:s\Z',$epoch+$slot*$step),'downloadBps'=>$row===null?null:(float)$row['downloadBps'],'uploadBps'=>$row===null?null:(float)$row['uploadBps'],'samples'=>$row===null?0:(int)$row['samples']];}
    $state=fetchOne("SELECT * FROM DashboardTrafficState WHERE id='primary'");$age=$state&&$state['observedAt']!==null?microtime(true)-(float)(new DateTimeImmutable($state['observedAt'],new DateTimeZone('UTC')))->format('U.u'):INF;$fresh=$state&&$state['status']==='SUCCESS'&&$age>=0&&$age<5;
    $first=fetchOne("SELECT MIN(firstSampleAt) AS firstAt FROM DashboardTrafficBucket WHERE resolution='HOUR'");
    return ['serverTime'=>dashboardOnlineIso(now()),'period'=>$period,'timezone'=>'America/Lima','from'=>$from->format('c'),'to'=>$to->format('c'),'bucketSeconds'=>$step,'intervalSeconds'=>DASHBOARD_TRAFFIC_INTERVAL,'points'=>$points,'firstObservedAt'=>dashboardOnlineIso($first['firstAt']??null),'current'=>['status'=>$fresh?'FRESH':(($state['status']??'PENDING')==='SUCCESS'?'STALE':($state['status']??'PENDING')),'downloadBps'=>$fresh?(float)$state['downloadBps']:null,'uploadBps'=>$fresh?(float)$state['uploadBps']:null,'observedAt'=>dashboardOnlineIso($state['observedAt']??null),'coveredRouters'=>(int)($state['coveredRouters']??0),'totalRouters'=>(int)($state['totalRouters']??0),'message'=>$state['lastError']??null]];
}

function dashboardTrafficDispatch(string $method,string $route): bool
{
    if(!in_array($route,['/dashboard/traffic','/dashboard/traffic/refresh','/dashboard/connections'],true))return false;
    $actor=permit('ADMIN','TECHNICIAN','BILLING','VIEWER');
    if($method==='GET'&&$route==='/dashboard/connections')json(['results'=>dashboardConnectionsRecent(),'serverTime'=>dashboardOnlineIso(now())]);
    if($method==='GET'&&$route==='/dashboard/traffic')json(dashboardTrafficHistory(is_string($_GET['period']??'day')?($_GET['period']??'day'):''));
    if($method==='POST'&&$route==='/dashboard/traffic/refresh'){
        $input=body();if(array_diff(array_keys($input),['period'])||!is_string($input['period']??'day')||!in_array($input['period']??'day',['day','week','month','year'],true))throw new HttpError(422,'Período de tráfico inválido.','VALIDATION_ERROR');
        rateLimit('dashboard-traffic:'.$actor['id'],600,60);if(function_exists('set_time_limit'))set_time_limit(90);ignore_user_abort(true);dashboardTrafficTick();json(dashboardTrafficHistory($input['period']??'day'));
    }
    throw new HttpError(405,'Método no permitido.','METHOD_NOT_ALLOWED');
}
