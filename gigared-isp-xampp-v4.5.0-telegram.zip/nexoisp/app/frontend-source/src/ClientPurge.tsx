import { useEffect, useRef, useState } from 'react';
import { Trash2 } from 'lucide-react';
import { api, post } from './api';
import { errorMessage, Loading, Modal, money } from './ui';

interface Preview {
  client: { id: string; name: string; code: string }; token: string;
  counts: Record<string, number>; tasksDeleted: number; tasksUpdated: number;
  auditsAffected: number; cashEffects: { name: string; currency: string; deltaCents: number }[];
}
export default function ClientPurge({ clientId, close, saved }: { clientId: string; close: () => void; saved: () => void }) {
  const [preview, setPreview] = useState<Preview | null>(null), [loading, setLoading] = useState(true), [busy, setBusy] = useState(false), [error, setError] = useState('');
  const alive = useRef(true), running = useRef(false);
  const load = async () => {
    setLoading(true); setError('');
    try { const value = await api<Preview>(`/clients/${clientId}/purge/preview`, { cache: 'no-store' }); if (alive.current) setPreview(value); }
    catch (reason) { if (alive.current) { setPreview(null); setError(errorMessage(reason)); } }
    finally { if (alive.current) setLoading(false); }
  };
  useEffect(() => { alive.current = true; void load(); return () => { alive.current = false; }; }, [clientId]);
  const erase = async () => {
    if (!preview || loading || error || running.current) return;
    running.current = true; setBusy(true); setError('');
    try { await post(`/clients/${clientId}/purge`, { token: preview.token, confirmation: true }); saved(); close(); }
    catch (reason) {
      // Lost responses are resolved by checking presence; deletion is never blindly retried.
      try { await api(`/clients/${clientId}`, { cache: 'no-store' }); }
      catch (check) { if (check && typeof check === 'object' && 'status' in check && check.status === 404) { saved(); close(); return; } }
      if (alive.current) setError(errorMessage(reason));
    } finally { running.current = false; if (alive.current) setBusy(false); }
  };
  const sum = (...tables: string[]) => tables.reduce((n, table) => n + (preview?.counts[table] || 0), 0);
  return <Modal title="Eliminar definitivamente" description={preview ? `${preview.client.name} · ${preview.client.code}` : 'Borrado completo de un cliente retirado.'} close={() => { if (!busy) close(); }} footer={<><button className="button" disabled={busy} onClick={close}>Cancelar</button>{error && <button className="button" disabled={busy || loading} onClick={() => void load()}>Actualizar vista previa</button>}<button className="button danger" disabled={busy || loading || !preview || !!error} onClick={() => void erase()}><Trash2 size={16} />{busy ? 'Eliminando…' : 'Sí, eliminar definitivamente'}</button></>}>
    {loading && <Loading label="Revisando los registros del retirado…" />}{error && <div className="alert error" role="alert">{error}</div>}
    {!loading && preview && <><p><strong>¿Estás seguro de eliminar definitivamente a este cliente?</strong></p><div className="alert warning">Se borrarán permanentemente el cliente y sus registros asociados, incluidas facturas y pagos. Esta operación no se puede deshacer.</div>
      <div className="details-list"><div><span>Servicios</span><strong>{sum('Service')}</strong></div><div><span>Facturas y pagos</span><strong>{sum('Invoice', 'Payment')}</strong></div><div><span>Movimientos de caja vinculados</span><strong>{sum('CashMovement')}</strong></div><div><span>Tickets y comentarios</span><strong>{sum('Ticket', 'TicketComment')}</strong></div><div><span>Contratos y acceso al portal</span><strong>{sum('ServiceContract', 'PortalAccount', 'PortalSession')}</strong></div><div><span>Notas, avisos e historial</span><strong>{sum('ClientNote', 'ClientNotice', 'ClientActivityEvent') + preview.auditsAffected}</strong></div><div><span>Registros locales de ONUs vinculadas</span><strong>{sum('FiberOnu')}</strong></div><div><span>Equipos de inventario que quedan disponibles</span><strong>{sum('InventoryAsset')}</strong></div><div><span>Tareas eliminadas / depuradas</span><strong>{preview.tasksDeleted} / {preview.tasksUpdated}</strong></div></div>
      {preview.cashEffects.length > 0 && <><p>Al eliminar sus movimientos vinculados a pagos, los saldos de caja cambiarán:</p>{preview.cashEffects.map((effect, index) => <p key={index}>{effect.name}: {money(effect.deltaCents, effect.currency)}</p>)}</>}
      <p>Los planes, routers, cuentas de caja y equipos de inventario compartidos se conservan. La operación borra registros locales del sistema.</p>
    </>}
  </Modal>;
}
