import { Users } from 'lucide-react';
import { useEffect, useState } from 'react';
import { api } from './api';
import type { RecentConnection } from './types';
import { EmptyState } from './ui';

export default function DashboardConnections({ enabled }: { enabled: boolean }) {
  const [rows, setRows] = useState<RecentConnection[]>([]), [receivedAt, setReceivedAt] = useState(0), [clock, setClock] = useState(0), [serverTime, setServerTime] = useState(0), [requestMs, setRequestMs] = useState(0);
  useEffect(() => {
    if (!enabled) return;
    let stopped = false, pending: AbortController | undefined, timer: number | undefined;
    const tick = async () => {
      if (stopped || document.hidden || pending) return;
      pending = new AbortController(); const started = performance.now();
      const deadline = window.setTimeout(() => pending?.abort(), 10_000);
      try { const result = await api<{ results: RecentConnection[]; serverTime: string }>('/dashboard/connections', { cache: 'no-store', signal: pending.signal }); if (!stopped) { setRows(result.results); setReceivedAt(performance.now()); setServerTime(Date.parse(result.serverTime)); setRequestMs(performance.now() - started); } }
      catch { if (!stopped) setReceivedAt(0); }
      finally { window.clearTimeout(deadline); pending = undefined; if (!stopped && !document.hidden) timer = window.setTimeout(() => void tick(), Math.max(0, 1000 - (performance.now() - started))); }
    };
    const visibility = () => { window.clearTimeout(timer); if (document.hidden) pending?.abort(); else void tick(); };
    const expiry = window.setInterval(() => setClock(performance.now()), 1000);
    document.addEventListener('visibilitychange', visibility); void tick();
    return () => { stopped = true; window.clearTimeout(timer); window.clearInterval(expiry); pending?.abort(); document.removeEventListener('visibilitychange', visibility); };
  }, [enabled]);
  const currentRows = rows.map(row => { const age = serverTime - Date.parse(row.observedAt) + requestMs + Math.max(0, clock - receivedAt); return { ...row, status: receivedAt > 0 && Number.isFinite(age) && age >= 0 && age < 5000 ? row.status : 'UNKNOWN' as const }; });
  return <section className="panel dashboard-connections" data-testid="dashboard-recent-connections"><header className="panel-heading"><div><h2 className="panel-title">Últimos conectados</h2><p className="subtle">Últimas conexiones PPPoE detectadas.</p></div><Users size={20} /></header>{currentRows.length ? <div className="table-wrap"><table className="data-table"><thead><tr><th>Cliente / IP</th><th>Conexión detectada</th><th>Estado</th></tr></thead><tbody>{currentRows.map(row => <tr key={row.clientId}><td><button className="table-primary text-link" onClick={() => { window.location.hash = `/clients/${row.clientId}`; }}>{row.name}</button><div className="table-secondary">{row.addresses.join(', ') || 'Sin IP actual'}</div></td><td>{new Intl.DateTimeFormat('es-PE', { timeZone: 'America/Lima', day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false }).format(new Date(row.connectedAt))}</td><td><span className={`badge ${row.status === 'ONLINE' ? 'active' : row.status === 'OFFLINE' ? 'neutral' : 'pending'}`}>{row.status === 'ONLINE' ? 'Online' : row.status === 'OFFLINE' ? 'Offline' : 'Sin lectura reciente'}</span></td></tr>)}</tbody></table></div> : <EmptyState icon={<Users size={25} />} title="Todavía no hay conexiones detectadas" description="Las cuentas PPPoE de tus clientes aparecerán al recibir una lectura válida del MikroTik." />}</section>;
}
