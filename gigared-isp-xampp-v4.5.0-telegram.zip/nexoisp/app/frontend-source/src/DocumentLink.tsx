import { useState, type AnchorHTMLAttributes } from 'react';
import { authenticatedFetch } from './api';
import { errorMessage } from './ui';

export default function DocumentLink({ children, ...props }: AnchorHTMLAttributes<HTMLAnchorElement>) {
  const [busy, setBusy] = useState(false), [error, setError] = useState('');
  const open = async () => {
    if (busy || !props.href) return;
    const pdf = new URL(props.href, window.location.origin).pathname.endsWith('/pdf');
    const popup = pdf ? null : window.open('about:blank', '_blank');
    if (popup) popup.opener = null;
    setBusy(true); setError('');
    try {
      if (!pdf && !popup) throw new Error('Permite abrir ventanas para consultar el documento.');
      const response = await authenticatedFetch(props.href);
      if (!response.ok) throw new Error(response.status === 401 ? 'Vuelve a iniciar sesión para abrir el documento.' : 'El documento no está disponible.');
      const blob = await response.blob(), url = URL.createObjectURL(blob);
      if (pdf) {
        const filename = /filename="([^"]+)"/.exec(response.headers.get('Content-Disposition') || '')?.[1] || 'documento.pdf';
        const anchor = document.createElement('a'); anchor.href = url; anchor.download = filename.replace(/[^a-zA-Z0-9_.-]/g, '_'); document.body.appendChild(anchor); anchor.click(); anchor.remove();
      } else popup!.location.replace(url);
      window.setTimeout(() => URL.revokeObjectURL(url), 60000);
    } catch (reason) { popup?.close(); setError(errorMessage(reason)); }
    finally { setBusy(false); }
  };
  return <><a {...props} aria-disabled={busy || undefined} onClick={event => { event.preventDefault(); void open(); }}>{children}</a>{error && <small role="alert" className="field-hint">{error}</small>}</>;
}
