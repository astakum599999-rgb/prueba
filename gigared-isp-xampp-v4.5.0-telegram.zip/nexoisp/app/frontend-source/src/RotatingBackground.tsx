import { useEffect, useState } from 'react';

const images = ['fiber-1.jpg', 'fiber-2.jpg', 'fiber-3.jpg'].map(name => new URL(`${import.meta.env.BASE_URL}backgrounds/${name}`, document.baseURI).href);
const intervalMs = 20_000;

export default function RotatingBackground() {
  const [ready, setReady] = useState<string[]>([]);
  const [current, setCurrent] = useState<string>();
  useEffect(() => {
    document.body.classList.add('login-screen');
    let active = true;
    const pending = images.map(src => {
      const image = new Image();
      image.onload = () => {
        if (!active) return;
        setReady(previous => images.filter(url => url === src || previous.includes(url)));
        setCurrent(previous => previous ?? src);
      };
      image.src = src;
      return image;
    });
    return () => { active = false; pending.forEach(image => { image.onload = null; }); document.body.classList.remove('login-screen'); };
  }, []);
  useEffect(() => {
    if (ready.length < 2) return;
    let timer: number | undefined;
    const schedule = () => {
      window.clearTimeout(timer);
      if (document.hidden) return;
      timer = window.setTimeout(() => {
        setCurrent(previous => ready[(ready.indexOf(previous ?? '') + 1) % ready.length]);
        schedule();
      }, intervalMs);
    };
    schedule();
    document.addEventListener('visibilitychange', schedule);
    return () => { window.clearTimeout(timer); document.removeEventListener('visibilitychange', schedule); };
  }, [ready]);
  return <div className="rotating-background" aria-hidden="true">{ready.map(src => <img key={src} src={src} alt="" draggable={false} className={src === current ? 'is-current' : ''} />)}</div>;
}
