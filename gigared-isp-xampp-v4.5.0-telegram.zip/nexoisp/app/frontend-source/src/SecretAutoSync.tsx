import { useEffect, useRef, useState } from 'react';
import { RefreshCw } from 'lucide-react';
import { api } from './api';
import { date, errorMessage } from './ui';

interface AutoRouter {
  routerId: string;
  routerName: string;
  enabled: boolean;
  status: string;
  lastSuccessAt: string | null;
  nextRunAt: string | null;
  lastError: string | null;
  lastSummary?: { observedAt?: string; errors?: Record<string, string>; accounts?: {total:number}; profiles?: {total:number}; sessions?: {pppoeCount:number} } | null;
}
interface AutoState {
  intervalSeconds: number;
  serverTime: string;
  routers: AutoRouter[];
  processed?: number;
  changed?: boolean;
}

export function useSecretAutoSync({ enabled, userId, canRun, paused, refreshed }: {
  enabled: boolean; userId?: string; canRun: boolean; paused: boolean; refreshed: () => void;
}) {
  const [state, setState] = useState<AutoState | null>(null);
  const [error, setError] = useState('');
  const observed = useRef<string | null>(null);
  useEffect(() => { observed.current = null; setState(null); setError(''); }, [userId, enabled]);
  useEffect(() => {
    if (!enabled || !userId) return;
    let stopped = false;
    const isVisible = () => document.visibilityState !== 'hidden';
    let timer: number | undefined;
    let pending: AbortController | undefined;
    let deadline: number | undefined;
    const tick = async () => {
      window.clearTimeout(timer);
      if (stopped || pending || !isVisible()) return;
      const started = performance.now();
      const controller = new AbortController();
      pending = controller;
      deadline = window.setTimeout(() => controller.abort(), 90000);
      try {
        const result = await api<AutoState>('/routers/secrets/auto-sync', {
          method: canRun ? 'POST' : 'GET', ...(canRun ? { body: '{}' } : {}),
          cache: 'no-store', signal: pending.signal,
        });
        if (stopped || controller.signal.aborted || pending !== controller) return;
        setState(result); setError('');
        const stamp = JSON.stringify(result.routers.map(router => [router.routerId, router.lastSuccessAt, router.lastSummary?.observedAt, router.status, router.lastError]).sort());
        if (!paused && (result.changed || (observed.current !== null && observed.current !== stamp))) refreshed();
        observed.current = stamp;
      } catch (err) {
        if (!stopped && !controller.signal.aborted && isVisible()) setError(errorMessage(err));
      } finally {
        window.clearTimeout(deadline);
        if (pending === controller) pending = undefined;
        if (!stopped && isVisible()) timer = window.setTimeout(() => void tick(), Math.max(0, 1000 - (performance.now() - started)));
      }
    };
    const visible = () => { if (isVisible()) void tick(); else { window.clearTimeout(timer); pending?.abort(); } };
    document.addEventListener('visibilitychange', visible);
    timer = window.setTimeout(() => void tick(), 0);
    return () => { stopped = true; window.clearTimeout(timer); window.clearTimeout(deadline); pending?.abort(); document.removeEventListener('visibilitychange', visible); };
  }, [enabled, userId, canRun, paused, refreshed]);
  return { state, error };
}

export function SecretAutoSyncStatus({ state, error, paused, liveSessionPolling = false }: { state: AutoState | null; error: string; paused: boolean; liveSessionPolling?: boolean }) {
  const routers = state?.routers || [];
  const delayed = routers.filter(router => router.lastError).length;
  return <section className="secret-auto-status" aria-label="Estado de sincronización de MikroTik">
    <div className="inline-gap"><RefreshCw size={15} /><strong>MikroTik · sincronización automática</strong><span className="subtle">Lecturas cada {state?.intervalSeconds || 1} s</span></div>
    <p className="subtle secret-auto-help">{liveSessionPolling ? 'Cuentas PPPoE, perfiles, IP, sesiones activas y estado del router.' : 'Cuentas PPPoE, perfiles, sesiones activas y estado del router.'} Una lectura compartida por ciclo.</p>
    {delayed > 0 && <p className="secret-auto-warning">{delayed} {delayed === 1 ? 'router tiene' : 'routers tienen'} lecturas pendientes de reintento.</p>}
    {error ? <p className="secret-auto-warning" role="status">No se pudo completar la sincronización: {error}.</p> : !state ? <p className="subtle">Consultando el estado de MikroTik…</p> : !routers.length ? <p className="subtle">Importa las cuentas o perfiles de tu router una vez para activar su actualización.</p> : <details><summary>Última lectura de {routers.length} {routers.length === 1 ? 'router' : 'routers'}</summary><ul>{routers.map(router => <li key={router.routerId}><strong>{router.routerName}</strong><span>{router.lastSuccessAt ? `Último ciclo correcto: ${date(router.lastSuccessAt, true)}` : 'Primera sincronización pendiente'}</span>{router.lastSummary?.accounts && <span>Cuentas PPPoE: {router.lastSummary.accounts.total}</span>}{router.lastSummary?.profiles && <span>Perfiles PPPoE: {router.lastSummary.profiles.total}</span>}{router.lastSummary?.sessions && <span>Sesiones PPPoE: {router.lastSummary.sessions.pppoeCount}</span>}{router.lastError && <span className="secret-auto-warning">{router.lastError}</span>}{Object.entries(router.lastSummary?.errors || {}).map(([scope, message]) => <span className="secret-auto-warning" key={scope}>{({accounts:'Cuentas',profiles:'Perfiles',sessions:'Sesiones'} as Record<string,string>)[scope] || scope}: {message}</span>)}</li>)}</ul></details>}
    {paused && <p className="subtle secret-auto-help">La lectura continúa mientras editas; los valores de tu formulario se conservan.</p>}
    <p className="subtle secret-auto-help">Mantén INICIAR-WORKER.bat activo para sincronizar también con el navegador cerrado. Si el router no responde, se reintenta sin superponer consultas.</p>
  </section>;
}
