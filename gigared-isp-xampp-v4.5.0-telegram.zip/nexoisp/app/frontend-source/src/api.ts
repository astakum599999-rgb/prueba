import { acceptPageSession, forgetPageSession, pageSessionGeneration, pageSessionToken } from './browserSession';
import type { PageResult } from './types';
import { setDefaultCurrency } from './currency';

export class ApiError extends Error {
  constructor(public status: number, message: string, public code?: string) { super(message); }
}

function resolveApiBase(): string {
  const configured = document.querySelector<HTMLMetaElement>('meta[name="nexoisp-api-base"]')?.content.trim();
  if (!configured) return '/api/v1';
  const resolved = new URL(configured, window.location.origin);
  if (resolved.origin !== window.location.origin || resolved.search || resolved.hash) throw new Error('La ruta de API debe pertenecer al mismo sitio y no contener parámetros.');
  return resolved.pathname.replace(/\/+$/, '');
}

export const apiBase = resolveApiBase();

export async function authenticatedFetch(url: string, options: RequestInit = {}): Promise<Response> {
  const target = new URL(url, window.location.origin);
  if (target.origin !== window.location.origin) throw new Error('La solicitud debe pertenecer al mismo sitio.');
  const token = pageSessionToken(), headers = new Headers(options.headers);
  if (options.body && !headers.has('Content-Type')) headers.set('Content-Type', 'application/json');
  if (token) headers.set('X-NexoISP-Page', token);
  const response = await fetch(target.href, { ...options, credentials: 'same-origin', redirect: 'error', headers });
  if (response.status === 401 && pageSessionToken() === token) forgetPageSession(token);
  return response;
}
export async function api<T>(path: string, options: RequestInit = {}): Promise<T> {
  const route = path.split('?')[0], generation = pageSessionGeneration(), token = pageSessionToken();
  const logout = ['/auth/logout', '/portal/auth/logout'].includes(route);
  try {
    const response = await authenticatedFetch(`${apiBase}${path}`, options);
    const value = response.status === 204 ? undefined : await response.json().catch(() => undefined);
    if (!response.ok) {
      const message = typeof value?.error === 'string' ? value.error : value?.error?.message || value?.message || `La solicitud falló (${response.status}).`;
      throw new ApiError(response.status, message, value?.error?.code || value?.code);
    }
    if (route === '/auth/login' || route === '/portal/auth/login') acceptPageSession(value?.browserSession, `${apiBase}${route.replace(/login$/, 'logout')}`, generation);
    if (value && typeof value === 'object') {
      if (value.capabilities && Object.hasOwn(value.capabilities, 'defaultCurrency')) setDefaultCurrency(value.capabilities.defaultCurrency);
      if (route === '/company-settings' && typeof value.currency === 'string') setDefaultCurrency(value.currency);
    }
    return value as T;
  } finally { if (logout && pageSessionToken() === token) forgetPageSession(token); }
}

export const post = <T>(path: string, data: unknown = {}) => api<T>(path, { method: 'POST', body: JSON.stringify(data) });
export const patch = <T>(path: string, data: unknown) => api<T>(path, { method: 'PATCH', body: JSON.stringify(data) });
export const remove = <T>(path: string) => api<T>(path, { method: 'DELETE' });

export async function choices<T>(path: string): Promise<T[]> {
  const result: T[] = [];
  let page = 1;
  while (true) {
    const response = await api<PageResult<T>>(`${path}?page=${page}&pageSize=100`);
    result.push(...response.results);
    if (result.length >= response.count || response.results.length === 0) return result;
    page += 1;
  }
}
