type PageSession = { token: string; logoutPath: string };
let session: PageSession | null = null;
let generation = 0;
let closed = false;
export const pageSessionToken = () => session?.token;
export const pageSessionGeneration = () => generation;

export function forgetPageSession(expected?: string) {
  if (expected !== undefined && session?.token !== expected) return;
  session = null; generation++;
  window.dispatchEvent(new Event('nexoisp:unauthorized'));
}
export function acceptPageSession(value: unknown, logoutPath: string, requestGeneration: number) {
  if (closed || requestGeneration !== generation) throw new Error('La página se cerró. Vuelve a iniciar sesión.');
  const candidate = value as { mode?: string; token?: string } | undefined;
  if (candidate?.mode !== 'page' || typeof candidate.token !== 'string' || !/^[A-Za-z0-9_-]{43}$/.test(candidate.token)) throw new Error('Actualiza los archivos completos del sistema para iniciar sesión.');
  session = { token: candidate.token, logoutPath }; generation++;
}
function closePage() {
  closed = true;
  const previous = session; session = null; generation++;
  document.documentElement.classList.add('nexoisp-session-closed');
  window.dispatchEvent(new Event('nexoisp:unauthorized'));
  if (previous) void fetch(previous.logoutPath, { method: 'POST', credentials: 'same-origin', redirect: 'error', keepalive: true, headers: { 'Content-Type': 'application/json', 'X-NexoISP-Page': previous.token }, body: '{}' }).catch(() => undefined);
}
window.addEventListener('pagehide', closePage);
window.addEventListener('pageshow', event => {
  if (event.persisted) { closePage(); closed = false; window.requestAnimationFrame(() => document.documentElement.classList.remove('nexoisp-session-closed')); }
  else { closed = false; document.documentElement.classList.remove('nexoisp-session-closed'); }
});
