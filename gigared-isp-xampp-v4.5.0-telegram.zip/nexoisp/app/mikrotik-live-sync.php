<?php
declare(strict_types=1);
namespace Nexo;

use PDO;
use Throwable;

require_once __DIR__ . '/profile-import.php';
require_once __DIR__ . '/client-ip-live.php';

/** Replay a real, bounded observation during persistence; never perform I/O in a transaction. */
final class MikroTikObservedTransport implements RouterTransport
{
    public function __construct(private array $rows) {}
    public function isSimulated(): bool { return false; }
    public function print(string $resource, array $filters = [], array $options = []): array
    {
        if ($filters !== [] || !array_key_exists($resource, $this->rows)) throw new \LogicException('Recurso no observado en este ciclo.');
        return $this->rows[$resource];
    }
    public function add(string $resource, array $values): string { throw new HttpError(409, 'La sincronización automática sólo admite lecturas.', 'NETWORK_READ_ONLY'); }
    public function set(string $resource, string $id, array $values): void { throw new HttpError(409, 'La sincronización automática sólo admite lecturas.', 'NETWORK_READ_ONLY'); }
    public function remove(string $resource, string $id): void { throw new HttpError(409, 'La sincronización automática sólo admite lecturas.', 'NETWORK_READ_ONLY'); }
    public function execute(string $command, array $values = []): array { throw new HttpError(409, 'La sincronización automática sólo admite lecturas.', 'NETWORK_READ_ONLY'); }
    public function close(): void {}
}

function secretAutoSyncNextRunAt(array $state): string
{
    $scheduled = $state['nextRunAt'] ?? '1970-01-01 00:00:00.000';
    $error = ($state['status'] ?? '') === 'ERROR';
    $anchor = $error || ($state['status'] ?? '') === 'DEFERRED'
        ? ($state['updatedAt'] ?? $state['lastSuccessAt'] ?? null)
        : ($state['lastStartedAt'] ?? $state['lastSuccessAt'] ?? $state['updatedAt'] ?? null);
    if (!is_string($anchor)) return $scheduled;
    $delay = $error ? clientIpLiveRetrySeconds((int)($state['consecutiveFailures'] ?? 1)) : SECRET_AUTO_SYNC_INTERVAL;
    $deadline = secretAutoSyncAfter($delay, $anchor);
    return $scheduled < $deadline ? $scheduled : $deadline;
}

function mikrotikLiveError(Throwable $error): string
{
    return $error instanceof HttpError && $error->errorCode === 'INVALID_ROUTER_RESPONSE'
        ? 'El inventario recibido no es válido; se conserva la última información correcta.'
        : 'No se pudo completar la lectura; se reintentará automáticamente.';
}

/** Read all supported management data through one connection, then release it. */
function mikrotikLiveObserve(array $router): array
{
    $transport = secretImportTransport($router);
    $raw = []; $errors = []; $sessions = null; $count = null; $activeAt = null; $metrics = [];
    try {
        $cached = fetchOne('SELECT c.*,n.pppoeCount,n.observedAt FROM RouterPppActiveCache c LEFT JOIN RouterPppOnlineCount n ON n.routerId=c.routerId WHERE c.routerId=?', [$router['id']]);
        $reuseSessions = $cached !== null && clientIpLiveFresh($cached) && $cached['observedAt'] === $cached['lastSuccessAt'] && $cached['pppoeCount'] !== null && clientIpLiveNextQueryAt($cached) > now();
        if ($reuseSessions) { $count = (int)$cached['pppoeCount']; $activeAt = $cached['lastSuccessAt']; }
        foreach ([
            'sessions' => ['/ppp/active', '.id,name,address,service'],
            'accounts' => ['/ppp/secret', SECRET_IMPORT_PROPERTIES],
            'profiles' => ['/ppp/profile', PROFILE_IMPORT_PROPERTIES],
        ] as $scope => [$path, $properties]) {
            if ($scope === 'sessions' && $reuseSessions) continue;
            if ($scope === 'sessions' && $cached !== null && $cached['status'] === 'ERROR' && clientIpLiveNextQueryAt($cached) > now()) {
                $errors[$scope] = 'La lectura de sesiones está pendiente de reintento.';
                continue;
            }
            try {
                $rows = $transport->print($path, [], ['.proplist' => $properties]);
                $snapshot = new MikroTikObservedTransport([$path => $rows]);
                if ($scope === 'sessions') { $sessions = clientIpLiveRead($snapshot, $count); $activeAt = now(); }
                elseif ($scope === 'accounts') secretImportRead($snapshot);
                else profileImportRead($snapshot, (string)($router['cutProfile'] ?? 'Perfil_Corte'));
                $raw[$path] = $rows;
            } catch (Throwable $error) {
                $errors[$scope] = mikrotikLiveError($error);
                if ($scope === 'sessions') clientIpLiveStoreFailure($router['id'], $error);
                // A disconnected/failed gateway must not receive repeated connection attempts in one cycle.
                if ($raw === [] && $error instanceof RouterError && ($error->httpStatus === null || $error->httpStatus >= 500)) throw $error;
            }
        }
        foreach ([
            '/system/identity' => ['name'],
            '/system/resource' => ['uptime','version','cpu-load','free-memory','total-memory','board-name','platform'],
        ] as $path => $fields) {
            try {
                $rows = $transport->print($path, [], ['.proplist' => implode(',', $fields)]);
                if (!array_is_list($rows) || count($rows) !== 1 || !is_array($rows[0])) throw new \RuntimeException('Inventario de sistema inválido.');
                foreach ($fields as $field) {
                    $value = $rows[0][$field] ?? null;
                    if (!is_string($value) && !is_int($value)) continue;
                    if (strlen((string)$value) > 1024) continue;
                    if ($field === 'name') $metrics['identity'] = secretImportDisplayText((string)$value);
                    elseif (in_array($field, ['cpu-load','free-memory','total-memory'], true)) {
                        if (preg_match('/^[0-9]{1,18}$/D', (string)$value)) $metrics[$field] = (int)$value;
                    } else $metrics[$field] = secretImportDisplayText((string)$value);
                }
            } catch (Throwable) { /* System read permissions may be narrower than PPP permissions. */ }
        }
    } finally { $transport->close(); }
    return ['raw' => $raw, 'errors' => $errors, 'sessions' => $sessions, 'pppoeCount' => $count, 'activeAt' => $activeAt, 'metrics' => $metrics];
}

function mikrotikLiveSyncTick(?string $actorId = null, int $maximum = 5, ?array $refreshRouterIds = null): array
{
    secretAutoSyncEnrollImported();
    $maximum = max(1, min(5, $maximum));
    $result = ['processed'=>0,'changed'=>false,'failed'=>0,'deferred'=>0];
    if($refreshRouterIds===[])return $result;
    $forced=$refreshRouterIds!==null;
    $filter=$forced?' AND s.routerId IN ('.implode(',',array_fill(0,count($refreshRouterIds),'?')).')':'';
    $candidates = fetchAll("SELECT s.* FROM RouterSecretAutoSync s JOIN Router r ON r.id=s.routerId WHERE s.enabled=1 AND r.transport IN ('REST','SOCKET')".$filter." ORDER BY s.nextRunAt,s.routerId LIMIT 1000",$refreshRouterIds??[]);
    if($forced)$result['deferred']=count($refreshRouterIds)-count($candidates);
    foreach ($candidates as $candidate) {
        if ($result['processed'] >= $maximum) break;
        if (!$forced && secretAutoSyncNextRunAt($candidate) > now()) continue;
        $scheduler = 'secret-auto:' . $candidate['routerId']; $routerLock = 'router:' . $candidate['routerId'];
        if (!lock($scheduler, 0)) {if($forced)$result['deferred']++;continue;}
        $locked = false;
        try {
            $locked = lock($routerLock, 0);
            if (!$locked) { $result['deferred']++; continue; }
            $state = fetchOne('SELECT * FROM RouterSecretAutoSync WHERE routerId=?', [$candidate['routerId']]);
            if ($state === null || !(bool)$state['enabled'] || (!$forced && secretAutoSyncNextRunAt($state) > now())) {if($forced)$result['deferred']++;continue;}
            $router = fetchOne('SELECT * FROM Router WHERE id=?', [$candidate['routerId']]);
            if ($router === null) continue;
            if ((function_exists(__NAMESPACE__ . '\\clientPppoeEditPending') && clientPppoeEditPending($router['id'])) || (function_exists(__NAMESPACE__ . '\\clientNameSyncPending') && clientNameSyncPending($router['id']))) { $result['deferred']++; continue; }
            $started = now();
            db()->prepare("UPDATE RouterSecretAutoSync SET status='RUNNING',lastStartedAt=?,nextRunAt=?,updatedAt=? WHERE routerId=?")
                ->execute([$started, secretAutoSyncAfter(120), $started, $router['id']]);
            try {
                $snapshot = mikrotikLiveObserve($router);
                $observed = now();
                $summary = tx(function (PDO $pdo) use ($router,$snapshot,$actorId,$started,$observed): array {
                    $summary = ['accounts'=>null,'profiles'=>null,'sessions'=>null,'metrics'=>$snapshot['metrics'],'errors'=>$snapshot['errors'],'observedAt'=>$observed,'changed'=>false];
                    $replay = new MikroTikObservedTransport($snapshot['raw']);
                    if (isset($snapshot['raw']['/ppp/secret'])) {
                        $summary['accounts'] = secretImportRun($router['id'], $actorId, $replay, 0, true, true);
                        $summary['changed'] = secretAutoSyncChanged($summary['accounts']);
                    }
                    if (isset($snapshot['raw']['/ppp/profile'])) {
                        $summary['profiles'] = profileImportRun($router['id'], $actorId, $replay, true, true);
                        foreach (['created','updated','plansCreated','plansUpdated','absencesChanged'] as $field) if ($summary['profiles'][$field] > 0) $summary['changed'] = true;
                    }
                    if ($snapshot['sessions'] !== null && $snapshot['pppoeCount'] !== null) {
                        clientIpLiveStore($router, $snapshot['sessions'], $snapshot['pppoeCount'], $started, $snapshot['activeAt']);
                    }
                    if ($snapshot['pppoeCount'] !== null) $summary['sessions'] = ['pppoeCount'=>$snapshot['pppoeCount'],'observedAt'=>$snapshot['activeAt']];
                    $pdo->prepare('UPDATE Router SET online=?,lastSeenAt=?,lastError=?,updatedAt=? WHERE id=?')
                        ->execute([$snapshot['raw'] !== [] ? 1 : 0, $snapshot['raw'] !== [] ? $observed : $router['lastSeenAt'], $snapshot['errors'] ? 'Hay lecturas pendientes en la sincronización de MikroTik.' : null, $observed, $router['id']]);
                    return $summary;
                });
                $failed = $snapshot['errors'] !== [];
                $failures = $failed ? (int)$state['consecutiveFailures'] + 1 : 0;
                $next = $failed ? secretAutoSyncAfter(clientIpLiveRetrySeconds($failures)) : secretAutoSyncAfter(1, $started);
                db()->prepare('UPDATE RouterSecretAutoSync SET status=?,lastSuccessAt=?,nextRunAt=?,lastErrorCode=?,lastError=?,consecutiveFailures=?,lastSummary=?,updatedAt=? WHERE routerId=?')
                    ->execute([$failed?'ERROR':'SUCCESS', $failed?$state['lastSuccessAt']:$observed, $next, $failed?'PARTIAL_READ':null, $failed?'Hay lecturas pendientes. Consulta el detalle de la sincronización.':null, $failures, json_encode($summary, JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE), $observed, $router['id']]);
                $result['processed']++; $result['changed'] = $result['changed'] || $summary['changed'];
                if ($failed) $result['failed']++;
            } catch (Throwable $error) {
                $failures = (int)$state['consecutiveFailures'] + 1;
                db()->prepare("UPDATE RouterSecretAutoSync SET status='ERROR',nextRunAt=?,lastErrorCode='ROUTER_UNAVAILABLE',lastError=?,consecutiveFailures=?,updatedAt=? WHERE routerId=?")
                    ->execute([secretAutoSyncAfter(clientIpLiveRetrySeconds($failures)), mikrotikLiveError($error), $failures, now(), $router['id']]);
                if ($error instanceof RouterError) db()->prepare('UPDATE Router SET online=0,lastError=?,updatedAt=? WHERE id=?')->execute(['No se pudo completar la lectura del router.',now(),$router['id']]);
                $result['processed']++; $result['failed']++;
            }
        } finally { if ($locked) unlock($routerLock); unlock($scheduler); }
    }
    return $result;
}

/** Safe cached router information for authenticated dashboard/detail views. */
function mikrotikLiveRouterInfo(string $routerId): ?array
{
    $row = fetchOne('SELECT status,lastSuccessAt,lastSummary,lastError FROM RouterSecretAutoSync WHERE routerId=?', [$routerId]);
    if ($row === null) return null;
    $summary = is_string($row['lastSummary']) ? json_decode($row['lastSummary'], true, 16, JSON_THROW_ON_ERROR) : [];
    $observed = $summary['observedAt'] ?? $row['lastSuccessAt'];
    $age = is_string($observed) ? microtime(true) - (float)(new \DateTimeImmutable($observed, new \DateTimeZone('UTC')))->format('U.u') : -1;
    $fresh = $row['status'] === 'SUCCESS' && $age >= 0 && $age < CLIENT_IP_LIVE_MAX_AGE;
    return ['status'=>$row['status'], 'stale'=>!$fresh, 'observedAt'=>$observed, 'intervalSeconds'=>1,
        'metrics'=>$fresh ? ($summary['metrics'] ?? []) : null, 'message'=>$row['lastError']];
}
