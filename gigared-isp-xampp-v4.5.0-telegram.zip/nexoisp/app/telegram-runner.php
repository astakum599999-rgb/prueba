<?php
declare(strict_types=1);
namespace Nexo;

/** The existing CLI worker starts and owns a separate long-polling process. */
function telegramSupervise(): void
{
    static $process=null,$lastAttempt=0,$registered=false;
    if(PHP_SAPI!=='cli')return;
    if(!$registered){register_shutdown_function(static function()use(&$process):void{if(is_resource($process)){@proc_terminate($process);@proc_close($process);}});$registered=true;}
    $s=telegramSettings();$enabled=(bool)$s['enabled']&&$s['verifiedAt']!==null;
    if(is_resource($process)){
        $state=proc_get_status($process);
        if($state['running']){if(!$enabled){@proc_terminate($process);@proc_close($process);$process=null;}return;}
        @proc_close($process);$process=null;
    }
    if(!$enabled||time()-$lastAttempt<15)return;$lastAttempt=time();
    if(!function_exists('proc_open')){db()->prepare("UPDATE TelegramSetting SET lastError=? WHERE id='primary'")->execute(['PHP tiene proc_open deshabilitado. Habilítalo o programa bin/telegram-worker.php como proceso independiente.']);return;}
    $script=APP_ROOT.'/bin/telegram-worker.php';$log=APP_ROOT.'/storage/telegram-worker.log';
    $pipes=[];$process=@proc_open([PHP_BINARY,$script], [['pipe','r'],['file',$log,'a'],['file',$log,'a']],$pipes,APP_ROOT,null,['bypass_shell'=>true]);
    foreach($pipes as $pipe)if(is_resource($pipe))fclose($pipe);
    if(!is_resource($process)){db()->prepare("UPDATE TelegramSetting SET lastError=? WHERE id='primary'")->execute(['No se pudo iniciar el bot. Revisa los permisos de PHP y de storage, y reinicia el worker.']);$process=null;}
}
