<?php
declare(strict_types=1);
namespace Nexo;

/** Fixed HTTPS origin; neither a request nor stored settings can select a host. */
function telegramCall(string $token,string $method,array $data=[]): mixed
{
    if(!preg_match('/^[0-9]{5,20}:[A-Za-z0-9_-]{30,100}$/D',$token) || !in_array($method,['getMe','getWebhookInfo','getUpdates','sendMessage','answerCallbackQuery'],true))throw new HttpError(422,'Configuración de Telegram inválida.');
    $url='https://api.telegram.org/bot'.$token.'/'.$method;
    $body=json_encode((object)$data,JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE);
    $status=0;$raw=false;$timeout=$method==='getUpdates'?15:6;
    if(function_exists('curl_init')) {
        $curl=curl_init($url);$buffer='';
        curl_setopt_array($curl,[CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>$body,CURLOPT_HTTPHEADER=>['Content-Type: application/json'],CURLOPT_CONNECTTIMEOUT=>3,CURLOPT_TIMEOUT=>$timeout,CURLOPT_FOLLOWLOCATION=>false,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2,CURLOPT_PROTOCOLS=>CURLPROTO_HTTPS,CURLOPT_WRITEFUNCTION=>static function($handle,string $part)use(&$buffer):int{if(strlen($buffer)+strlen($part)>1048576)return 0;$buffer.=$part;return strlen($part);}]);
        $success=curl_exec($curl);$status=(int)curl_getinfo($curl,CURLINFO_RESPONSE_CODE);curl_close($curl);
        if($success!==false)$raw=$buffer;
    } elseif(filter_var(ini_get('allow_url_fopen'),FILTER_VALIDATE_BOOLEAN)) {
        $context=stream_context_create(['http'=>['method'=>'POST','header'=>"Content-Type: application/json\r\nConnection: close\r\n",'content'=>$body,'timeout'=>$timeout,'ignore_errors'=>true,'follow_location'=>0],'ssl'=>['verify_peer'=>true,'verify_peer_name'=>true,'allow_self_signed'=>false]]);
        // Suppress transport warnings: PHP's raw errors include the secret in the URL.
        $stream=@fopen($url,'rb',false,$context);
        if($stream!==false){$raw=@stream_get_contents($stream,1048577);$meta=stream_get_meta_data($stream);fclose($stream);foreach($meta['wrapper_data']??[] as $line)if(preg_match('#^HTTP/\S+ (\d{3})#',$line,$match))$status=(int)$match[1];}
    } else throw new HttpError(503,'Habilita cURL de PHP para conectar con Telegram.');
    if(!is_string($raw)||strlen($raw)>1048576)throw new HttpError(503,'No se pudo conectar con Telegram. Revisa Internet y los certificados CA de PHP.');
    try{$response=json_decode($raw,true,64,JSON_THROW_ON_ERROR);}catch(\JsonException){throw new HttpError(503,'Telegram devolvió una respuesta inválida.');}
    // An expired button notification must not delay durable payment/result messages.
    if($method==='answerCallbackQuery'&&$status===400)return false;
    if($status===429)throw new HttpError(429,'Telegram limitó las solicitudes. El worker reintentará más adelante.');
    if($status===409)throw new HttpError(409,'Otro proceso o un webhook utiliza este bot. Usa un bot dedicado y un solo lector.');
    if($status===401)throw new HttpError(422,'Telegram rechazó el token del bot. Revisa el token de BotFather.');
    if($status<200||$status>=300||!is_array($response)||($response['ok']??false)!==true)throw new HttpError(503,'Telegram no confirmó la solicitud. Revisa el bot y el permiso de conversación.');
    return $response['result']??null;
}
