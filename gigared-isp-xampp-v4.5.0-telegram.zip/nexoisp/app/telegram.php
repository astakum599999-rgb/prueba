<?php
declare(strict_types=1);
namespace Nexo;

use PDO;
use Throwable;

function telegramAfter(int $seconds): string { return gmdate('Y-m-d H:i:s',time()+$seconds).'.000'; }
function telegramJson(array $value): string { return json_encode($value,JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); }
function telegramId(mixed $value): ?string
{
    if(!is_int($value)&&!is_string($value))return null;
    $value=(string)$value;
    return preg_match('/^[1-9][0-9]{0,15}$/D',$value)&&(int)$value<=4503599627370495?$value:null;
}
function telegramSettings(): array
{
    return fetchOne("SELECT * FROM TelegramSetting WHERE id='primary'")??['enabled'=>0,'tokenEncrypted'=>null,'botId'=>null,'botUsername'=>null,'verifiedAt'=>null,'nextOffset'=>0,'revision'=>0,'lastPollAt'=>null,'nextPollAt'=>null,'lastError'=>null,'failures'=>0];
}
function telegramPublic(): array
{
    $s=telegramSettings();
    return ['enabled'=>(bool)$s['enabled'],'tokenConfigured'=>$s['tokenEncrypted']!==null,'botUsername'=>$s['botUsername'],'verifiedAt'=>$s['verifiedAt'],'revision'=>(int)$s['revision'],'lastPollAt'=>$s['lastPollAt'],'lastError'=>$s['lastError'],
        'operators'=>fetchAll('SELECT t.telegramId,t.userId,t.label,t.canPayments,t.canActivate,u.name AS userName,u.role,u.active FROM TelegramOperator t JOIN User u ON u.id=t.userId ORDER BY t.label,t.telegramId'),
        'users'=>fetchAll("SELECT id,name,role FROM User WHERE active=1 AND role IN ('ADMIN','BILLING','TECHNICIAN') ORDER BY name"),
        'pendingMessages'=>(int)fetchOne('SELECT COUNT(*) AS n FROM TelegramOutbox')['n']];
}
function telegramActor(string $telegramId,string $permission='read'): array
{
    $row=fetchOne('SELECT t.*,u.name,u.role,u.active FROM TelegramOperator t JOIN User u ON u.id=t.userId WHERE t.telegramId=?',[$telegramId]);
    if(!$row||!(bool)$row['active']||!in_array($row['role'],['ADMIN','BILLING','TECHNICIAN'],true))throw new HttpError(403,'Tu cuenta de Telegram no tiene autorización.');
    if($permission==='payment'&&(!(bool)$row['canPayments']||!in_array($row['role'],['ADMIN','BILLING'],true)))throw new HttpError(403,'Tu usuario no tiene permiso para registrar pagos.');
    if($permission==='activate'&&(!(bool)$row['canActivate']||!in_array($row['role'],['ADMIN','TECHNICIAN'],true)))throw new HttpError(403,'Tu usuario no tiene permiso para activar manualmente.');
    $row['id']=$row['userId'];return $row;
}
function telegramSave(array $input,array $actor): array
{
    billingInput($input,['enabled','revision'],['enabled','revision','token']);
    if(!is_bool($input['enabled'])||!is_int($input['revision']))throw new HttpError(422,'Configuración inválida.');
    return apiLocks(['telegram-bot'],function()use($input,$actor):array{
        $s=telegramSettings();if((int)$s['revision']!==$input['revision'])throw new HttpError(409,'La configuración cambió. Actualiza la página.');
        $token=$input['token']??'';
        if(!is_string($token)||($token!==''&&!preg_match('/^[0-9]{5,20}:[A-Za-z0-9_-]{30,100}$/D',$token)))throw new HttpError(422,'El token de BotFather tiene un formato inválido.');
        $encrypted=$s['tokenEncrypted'];$botId=$s['botId'];$verified=$s['verifiedAt'];$username=$s['botUsername'];$offset=$s['nextOffset'];
        if($token!==''){
            $different=$encrypted===null||!hash_equals(decryptSecret($encrypted),$token);
            if($different){$newId=explode(':',$token,2)[0];if($botId!==$newId)$offset=0;$encrypted=encryptSecret($token);$botId=$newId;$verified=null;$username=null;}
        }
        if($input['enabled']&&($encrypted===null||$verified===null))throw new HttpError(409,'Guarda el token con el bot desactivado, pulsa Probar conexión y después actívalo.');
        tx(function(PDO $pdo)use($input,$actor,$s,$encrypted,$botId,$verified,$username,$offset):void{
            $pdo->prepare("INSERT INTO TelegramSetting(id,enabled,tokenEncrypted,botId,botUsername,verifiedAt,nextOffset,revision,lastError,nextPollAt,updatedAt) VALUES ('primary',?,?,?,?,?,?,?,?,NULL,?) ON DUPLICATE KEY UPDATE enabled=VALUES(enabled),tokenEncrypted=VALUES(tokenEncrypted),botId=VALUES(botId),botUsername=VALUES(botUsername),verifiedAt=VALUES(verifiedAt),nextOffset=VALUES(nextOffset),revision=VALUES(revision),lastError=NULL,nextPollAt=NULL,updatedAt=VALUES(updatedAt)")->execute([(int)$input['enabled'],$encrypted,$botId,$username,$verified,$offset,(int)$s['revision']+1,null,now()]);
            $pdo->exec('DELETE FROM TelegramSession');$pdo->exec("UPDATE TelegramAction SET status='CANCELLED' WHERE status='PENDING'");$pdo->exec('DELETE FROM TelegramOutbox');
            audit('telegram.settings.save','System',null,$actor['id']);
        });return telegramPublic();
    });
}
function telegramTest(array $actor): array
{
    return apiLocks(['telegram-bot'],function()use($actor):array{
        $s=telegramSettings();if(!$s['tokenEncrypted'])throw new HttpError(409,'Primero guarda el token del bot.');
        $token=decryptSecret($s['tokenEncrypted']);$bot=telegramCall($token,'getMe');$hook=telegramCall($token,'getWebhookInfo');
        if(!is_array($bot)||($bot['is_bot']??false)!==true||(string)($bot['id']??'')!==$s['botId'])throw new HttpError(409,'La identidad del bot no coincide con su token.');
        if(!is_array($hook)||($hook['url']??'')!=='')throw new HttpError(409,'Este bot tiene un webhook configurado. Usa un bot nuevo dedicado a GIGARED ISP.');
        $username=is_string($bot['username']??null)?substr($bot['username'],0,100):null;
        db()->prepare("UPDATE TelegramSetting SET botUsername=?,verifiedAt=?,lastError=NULL,updatedAt=? WHERE id='primary'")->execute([$username,now(),now()]);
        audit('telegram.connection.test','System',null,$actor['id']);return telegramPublic();
    });
}
function telegramOperatorSave(array $input,array $actor): array
{
    billingInput($input,['telegramId','userId','label','canPayments','canActivate'],['telegramId','userId','label','canPayments','canActivate']);
    $tg=telegramId($input['telegramId']);$userId=billingId($input['userId']);$label=$input['label'];
    if(!$tg||!is_string($label)||trim($label)===''||strlen($label)>100||!is_bool($input['canPayments'])||!is_bool($input['canActivate']))throw new HttpError(422,'Datos del operador inválidos.');
    return apiLocks(['telegram-bot'],function()use($input,$actor,$tg,$userId,$label):array{
        $user=fetchOne('SELECT * FROM User WHERE id=? AND active=1',[$userId]);
        if(!$user||!in_array($user['role'],['ADMIN','BILLING','TECHNICIAN'],true))throw new HttpError(422,'Selecciona un usuario activo de administración, cobranza o técnico.');
        if($input['canPayments']&&!in_array($user['role'],['ADMIN','BILLING'],true)||$input['canActivate']&&!in_array($user['role'],['ADMIN','TECHNICIAN'],true))throw new HttpError(422,'Los permisos deben corresponder al rol del usuario.');
        tx(function(PDO $pdo)use($tg,$userId,$label,$input,$actor):void{
            $pdo->prepare('INSERT INTO TelegramOperator(telegramId,userId,label,canPayments,canActivate,createdAt) VALUES (?,?,?,?,?,?) ON DUPLICATE KEY UPDATE userId=VALUES(userId),label=VALUES(label),canPayments=VALUES(canPayments),canActivate=VALUES(canActivate)')->execute([$tg,$userId,trim($label),(int)$input['canPayments'],(int)$input['canActivate'],now()]);
            $pdo->prepare('DELETE FROM TelegramSession WHERE telegramId=?')->execute([$tg]);$pdo->prepare("UPDATE TelegramAction SET status='CANCELLED' WHERE telegramId=? AND status='PENDING'")->execute([$tg]);$pdo->prepare('DELETE FROM TelegramOutbox WHERE telegramId=?')->execute([$tg]);audit('telegram.operator.save','TelegramOperator',$tg,$actor['id']);
        });return telegramPublic();
    });
}
function telegramQueue(string $tg,string $text,array $buttons=[],?string $clientId=null): void
{
    $data=['chat_id'=>$tg,'text'=>implode('',array_slice(preg_split('//u',$text,-1,PREG_SPLIT_NO_EMPTY)?:[],0,3900)),'link_preview_options'=>['is_disabled'=>true]];
    if($buttons)$data['reply_markup']=['inline_keyboard'=>$buttons];
    telegramQueueRequest($tg,'sendMessage',$data,$clientId);
}
function telegramQueueRequest(string $tg,string $method,array $data,?string $clientId=null): void
{
    db()->prepare('INSERT INTO TelegramOutbox(id,telegramId,clientId,configRevision,method,payloadJson,nextAttemptAt,createdAt) VALUES (?,?,?,?,?,?,?,?)')->execute([id(),$tg,$clientId,telegramSettings()['revision'],$method,telegramJson($data),now(),now()]);
}
function telegramButton(string $label,string $data): array { return ['text'=>$label,'callback_data'=>$data]; }
function telegramSession(string $tg,string $state,array $data=[],?string $clientId=null): void
{
    db()->prepare('INSERT INTO TelegramSession(telegramId,clientId,state,payloadJson,expiresAt) VALUES (?,?,?,?,?) ON DUPLICATE KEY UPDATE clientId=VALUES(clientId),state=VALUES(state),payloadJson=VALUES(payloadJson),expiresAt=VALUES(expiresAt)')->execute([$tg,$clientId,$state,telegramJson($data),telegramAfter(600)]);
}
function telegramCancel(string $tg): void
{
    db()->prepare('DELETE FROM TelegramSession WHERE telegramId=?')->execute([$tg]);db()->prepare("UPDATE TelegramAction SET status='CANCELLED' WHERE telegramId=? AND status='PENDING'")->execute([$tg]);
}
function telegramMenu(string $tg): void
{
    telegramQueue($tg,"GIGARED ISP\nBusca un cliente por nombre, documento o usuario PPPoE.\nComandos: /buscar nombre, /id y /cancelar.",[[telegramButton('Buscar cliente','nav:search')]]);
}
function telegramClient(string $id): array
{
    if(!preg_match('/^[a-f0-9]{24}$/D',$id))throw new HttpError(404,'Cliente no encontrado.');
    return fetchOne("SELECT * FROM Client WHERE id=? AND status<>'RETIRED'",[$id])??throw new HttpError(404,'El cliente ya no está disponible.');
}
function telegramMoney(int $cents,string $currency): string { return ($currency==='PEN'?'S/ ':$currency.' ').number_format($cents/100,2,'.',','); }
function telegramInvoices(string $tg,string $clientId): void
{
    $client=telegramClient($clientId);$operator=telegramActor($tg);telegramCancel($tg);
    $invoices=fetchAll("SELECT i.* FROM Invoice i WHERE i.clientId=? AND i.status='OPEN' AND ".financialDeletionClause('Invoice','i').' ORDER BY dueAt,id LIMIT 10',[$clientId]);
    telegramQueue($tg,$client['name'].' · '.$client['code']."\nEstado: ".$client['status'],[],$clientId);
    foreach($invoices as $invoice){$buttons=[];if((bool)$operator['canPayments']&&in_array($operator['role'],['ADMIN','BILLING'],true))$buttons=[[telegramButton('Registrar pago','invoice:'.$invoice['id'])]];telegramQueue($tg,$invoice['number'].' · Saldo '.telegramMoney((int)$invoice['amountCents']-(int)$invoice['paidCents'],$invoice['currency']).' · Vence '.billingDate($invoice['dueAt'])->setTimezone(new \DateTimeZone('America/Lima'))->format('d/m/Y'),$buttons,$clientId);}
    if(!$invoices)telegramQueue($tg,'El cliente no tiene facturas pendientes.',[],$clientId);
    if((bool)$operator['canActivate']&&in_array($operator['role'],['ADMIN','TECHNICIAN'],true))telegramQueue($tg,'Activación independiente para una suspensión manual. Los cortes por facturación se revisan al registrar el pago.',[[telegramButton('Activar manualmente','activate:'.$clientId)]],$clientId);
    telegramQueue($tg,'Para otro cliente, pulsa Buscar.',[[telegramButton('Buscar cliente','nav:search')]]);
}
function telegramSearch(string $tg,string $query): void
{
    $query=trim($query);if(preg_match_all('/./us',$query)<2||preg_match_all('/./us',$query)>80)throw new HttpError(422,'Escribe entre 2 y 80 caracteres para buscar.');
    $q=strtolower($query);$rows=fetchAll("SELECT c.id,c.name,c.code FROM Client c WHERE c.status<>'RETIRED' AND (LOCATE(?,LOWER(c.name))>0 OR LOCATE(?,LOWER(c.code))>0 OR LOCATE(?,LOWER(COALESCE(c.document,'')))>0 OR EXISTS(SELECT 1 FROM RouterSecretImport r WHERE r.clientId=c.id AND r.present=1 AND LOCATE(?,LOWER(r.username))>0) OR EXISTS(SELECT 1 FROM Service s WHERE s.clientId=c.id AND s.desiredState<>'RETIRED' AND LOCATE(?,LOWER(COALESCE(s.username,'')))>0)) ORDER BY c.name,c.id LIMIT 6",array_fill(0,5,$q));
    if(!$rows){telegramQueue($tg,'Sin coincidencias. Escribe otro nombre, DNI o usuario PPPoE.');return;}
    foreach(array_slice($rows,0,5) as $row)telegramQueue($tg,$row['name'].' · '.$row['code'],[[telegramButton('Ver cliente','client:'.$row['id'])]],$row['id']);
    if(count($rows)>5)telegramQueue($tg,'Hay más coincidencias. Escribe un nombre más específico.');
}
function telegramAction(string $tg,string $clientId,string $kind,array $payload,int $seconds=300): string
{
    $operator=telegramActor($tg,$kind==='PAYMENT'?'payment':'activate');$id=bin2hex(random_bytes(16));
    db()->prepare('INSERT INTO TelegramAction(id,telegramId,clientId,actorId,kind,configRevision,payloadJson,expiresAt,createdAt) VALUES (?,?,?,?,?,?,?,?,?)')->execute([$id,$tg,$clientId,$operator['id'],$kind,telegramSettings()['revision'],telegramJson($payload),telegramAfter($seconds),now()]);return $id;
}
function telegramAmount(string $text): int
{
    $text=trim($text);if(!preg_match('/^(0|[1-9][0-9]{0,7})(?:[.,]([0-9]{1,2}))?$/D',$text,$m))throw new HttpError(422,'Escribe el importe, por ejemplo 40.00, sin símbolos ni separadores de miles.');
    $value=(int)$m[1]*100+(int)str_pad($m[2]??'',2,'0');if($value<1||$value>2147483647)throw new HttpError(422,'El importe debe ser positivo y válido.');return $value;
}
function telegramPaymentStep(string $tg,array $session,string $text): void
{
    telegramActor($tg,'payment');$p=json_decode($session['payloadJson'],true,32,JSON_THROW_ON_ERROR);$client=telegramClient($session['clientId']);
    $invoice=fetchOne('SELECT * FROM Invoice WHERE id=? AND clientId=?',[$p['invoiceId'],$client['id']])??throw new HttpError(404,'Factura no encontrada.');financialRequirePresent('Invoice',$invoice['id']);
    if($invoice['status']!=='OPEN')throw new HttpError(409,'La factura ya no está pendiente. Selecciona nuevamente el cliente.');
    $balance=(int)$invoice['amountCents']-(int)$invoice['paidCents'];
    if($session['state']==='AMOUNT'){
        $p['amountCents']=telegramAmount($text);if($p['amountCents']>$balance)throw new HttpError(422,'El importe supera el saldo '.telegramMoney($balance,$invoice['currency']).'.');
        telegramSession($tg,'METHOD',$p,$client['id']);telegramQueue($tg,'Escribe el método: YAPE, PLIN, TRANSFERENCIA, EFECTIVO o TARJETA.',[],$client['id']);return;
    }
    if($session['state']==='METHOD'){
        $method=strtoupper(trim($text));if(!in_array($method,['YAPE','PLIN','TRANSFERENCIA','EFECTIVO','TARJETA'],true))throw new HttpError(422,'Método válido: YAPE, PLIN, TRANSFERENCIA, EFECTIVO o TARJETA.');
        $p['provider']=$method;telegramSession($tg,'REFERENCE',$p,$client['id']);telegramQueue($tg,'Escribe el número de operación. Para efectivo usa una referencia única de tu recibo.',[],$client['id']);return;
    }
    $reference=trim($text);if($reference===''||strlen($reference)>180||preg_match('/[\x00-\x1F\x7F]/',$reference))throw new HttpError(422,'Escribe una referencia de operación válida, de hasta 180 bytes.');
    $p+=['externalReference'=>$reference,'currency'=>$invoice['currency']];$p['expectedPaidCents']=(int)$invoice['paidCents'];$p['expectedAmountCents']=(int)$invoice['amountCents'];
    if($p['amountCents']>$balance)throw new HttpError(409,'El saldo cambió. Selecciona nuevamente el cliente.');
    $action=telegramAction($tg,$client['id'],'PAYMENT',$p);db()->prepare('DELETE FROM TelegramSession WHERE telegramId=?')->execute([$tg]);
    telegramQueue($tg,"CONFIRMAR PAGO\n".$client['name']."\nFactura: ".$invoice['number']."\nImporte: ".telegramMoney($p['amountCents'],$p['currency'])."\nMétodo: ".$p['provider']."\nOperación: ".$reference."\nConfirma después de verificar el abono. Se aplicarán las reglas de deuda y reconexión del sistema.",[[telegramButton('Confirmar pago','confirm:'.$action),telegramButton('Cancelar','cancel:'.$action)]],$client['id']);
}
function telegramActionOwned(string $tg,string $id,bool $confirm=false): array
{
    if(!preg_match('/^[a-f0-9]{32}$/D',$id))throw new HttpError(404,'Acción no encontrada.');
    $row=fetchOne('SELECT * FROM TelegramAction WHERE id=? AND telegramId=?',[$id,$tg])??throw new HttpError(404,'Acción no encontrada.');
    $actor=telegramActor($tg,$row['kind']==='PAYMENT'?'payment':'activate');$s=telegramSettings();
    if(!(bool)$s['enabled']||(int)$s['revision']!==(int)$row['configRevision']||$actor['id']!==$row['actorId'])throw new HttpError(409,'La autorización cambió. Inicia nuevamente la operación.');
    telegramClient($row['clientId']);
    if($confirm&&$row['status']==='PENDING'&&$row['expiresAt']<now())throw new HttpError(409,'La confirmación venció. Inicia nuevamente la operación.');return $row;
}
function telegramPaymentConfirm(string $tg,array $row): void
{
    if($row['status']==='DONE'){telegramQueue($tg,'Este pago ya fue procesado.',[[telegramButton('Consultar resultado','status:'.$row['id'])]],$row['clientId']);return;}
    if($row['status']!=='PENDING')throw new HttpError(409,'La operación ya fue cancelada o requiere revisión.');
    $p=json_decode($row['payloadJson'],true,32,JSON_THROW_ON_ERROR);
    $result=billingWithLocks(['client:'.$row['clientId']],function()use($row,$p):array{
        $invoice=fetchOne('SELECT * FROM Invoice WHERE id=? AND clientId=? FOR UPDATE',[$p['invoiceId'],$row['clientId']])??throw new HttpError(404,'Factura no encontrada.');
        if((int)$invoice['paidCents']!==$p['expectedPaidCents']||(int)$invoice['amountCents']!==$p['expectedAmountCents'])throw new HttpError(409,'El saldo o importe de la factura cambió. Selecciona nuevamente el cliente antes de confirmar.');
        return registerPayment(paymentInput(array_intersect_key($p,array_flip(['invoiceId','amountCents','currency','provider','externalReference']))),$row['actorId']);
    });
    $stored=['paymentId'=>$result['payment']['id'],'invoiceId'=>$result['invoice']['id'],'taskIds'=>$result['reconnectionTaskIds'],'replayed'=>$result['replayed']];
    db()->prepare("UPDATE TelegramAction SET status='DONE',resultJson=?,payloadJson='{}',notifiedAt=? WHERE id=?")->execute([telegramJson($stored),$stored['taskIds']?null:now(),$row['id']]);
    audit('telegram.payment.confirm','Payment',$stored['paymentId'],$row['actorId']);
    telegramQueue($tg,($result['replayed']?'Pago existente reconocido; no se duplicó.':'Pago registrado.').' Saldo: '.telegramMoney((int)$result['invoice']['amountCents']-(int)$result['invoice']['paidCents'],$result['invoice']['currency']).($stored['taskIds']?"\nReconexión/revisión de red en cola. Se informará el resultado confirmado.":"\nNo se generó una orden de reconexión. Puede quedar deuda, existir suspensión manual o faltar una vinculación/permiso de red."),[[telegramButton('Consultar resultado','status:'.$row['id'])]],$row['clientId']);
}
/** Explicit human callback; uses the same signed preview and durable journal as the panel. */
function telegramActivationConfirm(string $tg,array $row): void
{
    if($row['status']==='DONE'){telegramQueue($tg,'La activación ya fue procesada.',[[telegramButton('Consultar resultado','status:'.$row['id'])]],$row['clientId']);return;}
    if(!in_array($row['status'],['PENDING','RUNNING'],true))throw new HttpError(409,'La activación fue cancelada.');
    $payload=json_decode($row['payloadJson'],true,32,JSON_THROW_ON_ERROR);$actor=telegramActor($tg,'activate');
    db()->prepare("UPDATE TelegramAction SET status='RUNNING' WHERE id=?")->execute([$row['id']]);
    $result=clientPppExecute($row['clientId'],'REACTIVATE',$payload,$actor);
    tx(function(PDO $pdo)use($row,$result,$tg):void{
        $pdo->prepare("UPDATE TelegramAction SET status='DONE',resultJson=?,payloadJson='{}',notifiedAt=? WHERE id=?")->execute([telegramJson(['operationId'=>$result['id'],'status'=>$result['status']]),now(),$row['id']]);
        audit('telegram.activation.confirm','Client',$row['clientId'],$row['actorId']);
        telegramQueue($tg,$result['status']==='CONFIRMED'?'Activación manual confirmada en MikroTik. El equipo del cliente iniciará su conexión.':'La activación necesita verificación. Revisa la operación en Clientes antes de continuar.',[[telegramButton('Consultar resultado','status:'.$row['id'])]],$row['clientId']);
    });
}
function telegramStatus(string $tg,array $row,bool $automatic=false): bool
{
    $r=$row['resultJson']?json_decode($row['resultJson'],true,32,JSON_THROW_ON_ERROR):[];$terminal=true;
    if($row['kind']==='ACTIVATE'){
        $operation=isset($r['operationId'])?fetchOne('SELECT status FROM ClientPppActivation WHERE id=? AND clientId=?',[$r['operationId'],$row['clientId']]):null;
        $text=$operation&&$operation['status']==='CONFIRMED'?'Activación manual confirmada en MikroTik.':'Activación sin confirmar. Revisa Clientes → Activar manual → Verificar.';
    }else{
        $payment=isset($r['paymentId'])?fetchOne('SELECT * FROM Payment WHERE id=?',[$r['paymentId']]):null;
        $text=$payment&&!financialDeleted('Payment',$payment['id'])?'Pago registrado.':'El pago ya no está disponible en el listado.';
        $ids=$r['taskIds']??[];
        if(!$ids)$text.=' No hay una orden de reconexión asociada; consulta la deuda y la configuración del cliente.';
        foreach($ids as $id){$task=fetchOne('SELECT * FROM Task WHERE id=?',[$id]);
            if(!$task){$text.="\nNo se encuentra la tarea de red; revisa el cliente.";continue;}
            if(in_array($task['status'],['QUEUED','RUNNING'],true)){$terminal=false;$text.="\nReconexión/revisión de red pendiente del worker.";continue;}
            $result=$task['result']?json_decode($task['result'],true,32,JSON_THROW_ON_ERROR):[];
            $confirmed=$task['status']==='SUCCEEDED'&&(($result['confirmed']??false)===true&&($result['action']??'')==='ACTIVE'||($result['applied']??false)===true&&($result['state']??'')==='ACTIVE');
            $text.=$confirmed?"\nReactivación confirmada por MikroTik. La sesión PPPoE puede tardar en establecerse.":"\nLa tarea terminó sin confirmar una reactivación. Revisa la deuda y Operaciones de red en el panel.";
        }
    }
    if(!$automatic||$terminal)telegramQueue($tg,$text,[],$row['clientId']);return $terminal;
}
function telegramHandle(string $tg,string $text,?string $callback): void
{
    if($callback!==null){
        if($callback==='nav:search'){telegramCancel($tg);telegramSession($tg,'SEARCH');telegramQueue($tg,'Escribe el nombre, DNI o usuario PPPoE del cliente.');return;}
        if(preg_match('/^client:([a-f0-9]{24})$/D',$callback,$m)){telegramInvoices($tg,$m[1]);return;}
        if(preg_match('/^invoice:([a-f0-9]{24})$/D',$callback,$m)){
            telegramActor($tg,'payment');$invoice=fetchOne("SELECT * FROM Invoice WHERE id=? AND status='OPEN'",[$m[1]])??throw new HttpError(404,'Factura pendiente no encontrada.');financialRequirePresent('Invoice',$invoice['id']);$client=telegramClient($invoice['clientId']);telegramCancel($tg);
            telegramSession($tg,'AMOUNT',['invoiceId'=>$invoice['id']],$client['id']);telegramQueue($tg,$client['name'].' · '.$invoice['number']."\nSaldo: ".telegramMoney((int)$invoice['amountCents']-(int)$invoice['paidCents'],$invoice['currency'])."\nEscribe el monto a registrar, por ejemplo 40.00. /cancelar para salir.",[],$client['id']);return;
        }
        if(preg_match('/^activate:([a-f0-9]{24})$/D',$callback,$m)){
            $actor=telegramActor($tg,'activate');$client=telegramClient($m[1]);telegramCancel($tg);$preview=clientPppPreview($client['id'],'REACTIVATE',$actor);
            if(isset($preview['pending']))throw new HttpError(409,'Hay una operación de red pendiente. Verifícala desde el panel.');
            $hex=bin2hex(random_bytes(16));$uuid=substr($hex,0,8).'-'.substr($hex,8,4).'-'.substr($hex,12,4).'-'.substr($hex,16,4).'-'.substr($hex,20,12);
            $id=telegramAction($tg,$client['id'],'ACTIVATE',['token'=>$preview['token'],'requestKey'=>$uuid],110);
            telegramQueue($tg,"CONFIRMAR ACTIVACIÓN MANUAL\n".$client['name']."\nSe habilitará su secret PPPoE suspendido manualmente. No registra un pago ni elimina la deuda.",[[telegramButton('Confirmar activación','confirm:'.$id),telegramButton('Cancelar','cancel:'.$id)]],$client['id']);return;
        }
        if(preg_match('/^(confirm|cancel|status):([a-f0-9]{32})$/D',$callback,$m)){
            $row=telegramActionOwned($tg,$m[2],$m[1]==='confirm');
            if($m[1]==='cancel'){if($row['status']==='PENDING')db()->prepare("UPDATE TelegramAction SET status='CANCELLED',payloadJson='{}' WHERE id=?")->execute([$row['id']]);telegramQueue($tg,'Confirmación cerrada. Las operaciones ya procesadas conservan su resultado.');return;}
            if($m[1]==='status'){telegramStatus($tg,$row);return;}
            if($row['kind']!=='PAYMENT')throw new \LogicException('Activation requires non-transactional execution.');
            telegramPaymentConfirm($tg,$row);return;
        }
        throw new HttpError(422,'El botón ya no está disponible. Usa /inicio.');
    }
    if(preg_match('/^\/(?:start|inicio|ayuda)(?:@\w+)?$/iD',$text)){telegramCancel($tg);telegramMenu($tg);return;}
    if(preg_match('/^\/cancelar(?:@\w+)?$/iD',$text)){telegramCancel($tg);telegramQueue($tg,'Se cerró la operación pendiente. Los pagos ya confirmados conservan su registro.');telegramMenu($tg);return;}
    if(preg_match('/^\/buscar(?:@\w+)?(?:\s+(.+))?$/iuD',$text,$m)){telegramCancel($tg);telegramSession($tg,'SEARCH');if(isset($m[1]))telegramSearch($tg,$m[1]);else telegramQueue($tg,'Escribe el nombre, DNI o usuario PPPoE del cliente.');return;}
    if(str_starts_with($text,'/')){telegramMenu($tg);return;}
    $session=fetchOne('SELECT * FROM TelegramSession WHERE telegramId=? AND expiresAt>?',[$tg,now()]);
    if(!$session){telegramQueue($tg,'Usa /buscar nombre para comenzar. Las conversaciones vencen a los 10 minutos.');return;}
    if($session['state']==='SEARCH')telegramSearch($tg,$text);else telegramPaymentStep($tg,$session,$text);
}
/** Accept private Telegram-delivered updates only; operator identity is always numeric. */
function telegramEnvelope(array $update): ?array
{
    $callback=$update['callback_query']??null;$message=is_array($callback)?($callback['message']??null):($update['message']??null);
    $from=is_array($callback)?($callback['from']??null):($message['from']??null);
    if(!is_array($message)||!is_array($from)||($from['is_bot']??false)!==false||($message['chat']['type']??'')!=='private')return null;
    $tg=telegramId($from['id']??null);if(!$tg||telegramId($message['chat']['id']??null)!==$tg)return null;
    $text=is_array($callback)?'':($message['text']??'');$data=is_array($callback)?($callback['data']??null):null;
    if(!is_string($text)||strlen($text)>1000||($callback!==null&&(!is_string($data)||strlen($data)>64)))return null;
    return ['telegramId'=>$tg,'text'=>trim($text),'callback'=>$data,'callbackId'=>is_array($callback)&&is_string($callback['id']??null)?substr($callback['id'],0,100):null,'date'=>$message['date']??0];
}
function telegramProcess(array $inbox): void
{
    $update=json_decode($inbox['payloadJson'],true,32,JSON_THROW_ON_ERROR);$e=telegramEnvelope($update);
    $done=static function()use($inbox):void{db()->prepare("UPDATE TelegramInbox SET status='DONE',payloadJson='{}' WHERE botId=? AND updateId=?")->execute([$inbox['botId'],$inbox['updateId']]);};
    if(!$e){$done();return;}$tg=$e['telegramId'];
    try{
        if(preg_match('/^\/id(?:@\w+)?$/iD',$e['text'])){tx(function()use($tg,$done):void{telegramQueue($tg,'Tu ID de Telegram: '.$tg.'. Entrégalo al administrador para autorizar tu acceso.');$done();});return;}
        telegramActor($tg);
        if($e['callback']===null&&(!is_int($e['date'])||abs(time()-$e['date'])>600))throw new HttpError(409,'El mensaje es antiguo. Envía /inicio para comenzar.');
        if(is_string($e['callback'])&&preg_match('/^confirm:([a-f0-9]{32})$/D',$e['callback'],$m)){
            $row=telegramActionOwned($tg,$m[1],true);
            if($row['kind']==='ACTIVATE'){telegramActivationConfirm($tg,$row);tx(function()use($e,$tg,$done):void{if($e['callbackId'])telegramQueueRequest($tg,'answerCallbackQuery',['callback_query_id'=>$e['callbackId']]);$done();});return;}
        }
        tx(function()use($e,$tg,$done):void{telegramHandle($tg,$e['text'],$e['callback']);if($e['callbackId'])telegramQueueRequest($tg,'answerCallbackQuery',['callback_query_id'=>$e['callbackId']]);$done();});
    }catch(HttpError $error){
        tx(function()use($tg,$error,$e,$done):void{telegramQueue($tg,$error->getMessage());if($e['callbackId'])telegramQueueRequest($tg,'answerCallbackQuery',['callback_query_id'=>$e['callbackId'],'text'=>'Revisa el mensaje del bot.']);$done();});
    }
}
function telegramFlush(array $s,string $token,int $limit=3): int
{
    $sent=0;
    foreach(fetchAll("SELECT * FROM TelegramOutbox WHERE nextAttemptAt<=? AND attempts<5 ORDER BY CASE WHEN method='answerCallbackQuery' THEN 0 ELSE 1 END,seq LIMIT ".max(1,min(20,$limit)),[now()]) as $message){
        if((int)$message['configRevision']!==(int)$s['revision']){db()->prepare('DELETE FROM TelegramOutbox WHERE id=?')->execute([$message['id']]);continue;}
        $data=json_decode($message['payloadJson'],true,32,JSON_THROW_ON_ERROR);
        // Identification is the only response allowed to an unknown Telegram account.
        if($message['clientId']!==null){try{telegramActor($message['telegramId']);telegramClient($message['clientId']);}catch(HttpError){db()->prepare('DELETE FROM TelegramOutbox WHERE id=?')->execute([$message['id']]);continue;}}
        try{telegramCall($token,$message['method'],$data);db()->prepare('DELETE FROM TelegramOutbox WHERE id=?')->execute([$message['id']]);$sent++;}
        catch(HttpError $error){$attempt=(int)$message['attempts']+1;db()->prepare('UPDATE TelegramOutbox SET attempts=?,nextAttemptAt=? WHERE id=?')->execute([$attempt,telegramAfter(min(600,15*2**$attempt)),$message['id']]);throw $error;}
    }return $sent;
}
/** CLI-only long polling shares the existing worker, with one database lease per bot. */
function telegramTick(): array
{
    if(PHP_SAPI!=='cli')return ['enabled'=>false,'processed'=>0];
    if(!lock('telegram-poll',0))return ['busy'=>true,'processed'=>0];
    $ownsSettings=false;
    try{
        $s=telegramSettings();if(!(bool)$s['enabled']||!$s['tokenEncrypted']||!$s['verifiedAt'])return ['enabled'=>false,'processed'=>0];
        if($s['nextPollAt']!==null&&$s['nextPollAt']>now())return ['enabled'=>true,'processed'=>0];
        try{
            $token=decryptSecret($s['tokenEncrypted']);
            // Ack only updates already persisted locally. No incoming public endpoint.
            $localWork=fetchOne("SELECT updateId FROM TelegramInbox WHERE botId=? AND status='NEW' LIMIT 1",[$s['botId']])||fetchOne('SELECT id FROM TelegramOutbox WHERE nextAttemptAt<=? AND attempts<5 LIMIT 1',[now()]);
            $updates=telegramCall($token,'getUpdates',['offset'=>(int)$s['nextOffset'],'limit'=>10,'timeout'=>$localWork?0:10,'allowed_updates'=>['message','callback_query']]);
            // A long poll must not block configuration/revocation. Recheck after I/O.
            if(!lock('telegram-bot',0))return ['busy'=>true,'processed'=>0];
            $ownsSettings=true;$current=telegramSettings();
            if(!(bool)$current['enabled']||(int)$current['revision']!==(int)$s['revision'])return ['enabled'=>false,'processed'=>0];
            if(!is_array($updates)||!array_is_list($updates))throw new HttpError(503,'Telegram devolvió una lista de mensajes inválida.');
            tx(function(PDO $pdo)use($updates,$s):void{
                $offset=(int)$s['nextOffset'];
                foreach($updates as $update){if(!is_array($update)||!is_int($update['update_id']??null)||$update['update_id']<0)continue;$offset=max($offset,$update['update_id']+1);if($update['update_id']<(int)$s['nextOffset'])continue;
                    $e=telegramEnvelope($update);$safe=['update_id'=>$update['update_id']];
                    if($e){$message=['from'=>['id'=>$e['telegramId'],'is_bot'=>false],'chat'=>['id'=>$e['telegramId'],'type'=>'private'],'date'=>$e['date'],'text'=>$e['text']];if($e['callback']!==null)$safe['callback_query']=['id'=>$e['callbackId'],'from'=>$message['from'],'message'=>$message,'data'=>$e['callback']];else $safe['message']=$message;}
                    $pdo->prepare('INSERT IGNORE INTO TelegramInbox(botId,updateId,payloadJson,createdAt) VALUES (?,?,?,?)')->execute([$s['botId'],$update['update_id'],telegramJson($safe),now()]);
                }
                $pdo->prepare("UPDATE TelegramSetting SET nextOffset=?,lastPollAt=?,lastError=NULL,failures=0,nextPollAt=? WHERE id='primary'")->execute([$offset,now(),telegramAfter(1)]);
            });
            $processed=0;foreach(fetchAll("SELECT * FROM TelegramInbox WHERE botId=? AND status='NEW' ORDER BY updateId LIMIT 3",[$s['botId']]) as $inbox){telegramProcess($inbox);$processed++;}
            foreach(fetchAll("SELECT * FROM TelegramAction WHERE kind='PAYMENT' AND status='DONE' AND notifiedAt IS NULL AND configRevision=? ORDER BY createdAt LIMIT 5",[$s['revision']]) as $row){try{telegramActor($row['telegramId'],'payment');tx(function(PDO $pdo)use($row):void{if(telegramStatus($row['telegramId'],$row,true))$pdo->prepare('UPDATE TelegramAction SET notifiedAt=? WHERE id=?')->execute([now(),$row['id']]);});}catch(HttpError){db()->prepare('UPDATE TelegramAction SET notifiedAt=? WHERE id=?')->execute([now(),$row['id']]);}}
            $sent=telegramFlush($s,$token);
            db()->prepare('DELETE FROM TelegramSession WHERE expiresAt<?')->execute([now()]);
            db()->prepare("DELETE FROM TelegramInbox WHERE status='DONE' AND createdAt<?")->execute([telegramAfter(-7*86400)]);
            db()->prepare('DELETE FROM TelegramOutbox WHERE createdAt<?')->execute([telegramAfter(-86400)]);
            db()->prepare("UPDATE TelegramAction SET status='CANCELLED',payloadJson='{}' WHERE status='PENDING' AND expiresAt<?")->execute([now()]);
            return ['enabled'=>true,'processed'=>$processed,'sent'=>$sent];
        }catch(Throwable $error){$message=$error instanceof HttpError?$error->getMessage():'No se pudo procesar Telegram. Revisa la base de datos y reinicia el worker.';$failures=min(10,(int)$s['failures']+1);db()->prepare("UPDATE TelegramSetting SET lastError=?,failures=?,nextPollAt=? WHERE id='primary' AND revision=? AND enabled=1")->execute([$message,$failures,telegramAfter(min(300,5*2**$failures)),$s['revision']]);return ['enabled'=>true,'processed'=>0,'error'=>$message];}
    }finally{if($ownsSettings)unlock('telegram-bot');unlock('telegram-poll');}
}
function telegramDispatch(string $method,string $route): bool
{
    if(!str_starts_with($route,'/telegram'))return false;$actor=permit('ADMIN');
    if($route==='/telegram/settings'&&$method==='GET')json(telegramPublic());
    if($route==='/telegram/settings'&&$method==='PATCH')json(telegramSave(body(),$actor));
    if($route==='/telegram/test'&&$method==='POST'){billingInput(body(),[],[]);json(telegramTest($actor));}
    if($route==='/telegram/retry'&&$method==='POST'){
        billingInput(body(),[],[]);
        apiLocks(['telegram-bot'],function()use($actor):void{tx(function(PDO $pdo)use($actor):void{
            $pdo->prepare('UPDATE TelegramOutbox SET attempts=0,nextAttemptAt=?')->execute([now()]);
            $pdo->exec("UPDATE TelegramSetting SET nextPollAt=NULL,lastError=NULL,failures=0 WHERE id='primary'");
            audit('telegram.messages.retry','System',null,$actor['id']);
        });});json(telegramPublic());
    }
    if($route==='/telegram/operators'&&$method==='POST')json(telegramOperatorSave(body(),$actor),201);
    if(preg_match('#^/telegram/operators/([1-9][0-9]{0,15})$#D',$route,$m)&&$method==='DELETE'){
        apiLocks(['telegram-bot'],function()use($m,$actor):void{tx(function(PDO $pdo)use($m,$actor):void{$pdo->prepare('DELETE FROM TelegramOutbox WHERE telegramId=?')->execute([$m[1]]);$pdo->prepare('DELETE FROM TelegramOperator WHERE telegramId=?')->execute([$m[1]]);audit('telegram.operator.revoke','TelegramOperator',$m[1],$actor['id']);});});json(['revoked'=>true]);
    }
    throw new HttpError(405,'Operación de Telegram no disponible.');
}
