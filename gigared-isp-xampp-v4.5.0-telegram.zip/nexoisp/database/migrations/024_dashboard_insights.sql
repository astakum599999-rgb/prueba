-- Additive, read-only network observations and aggregate traffic history.
CREATE TABLE IF NOT EXISTS `DashboardConnection` (
 `clientId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 `routerId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 `connected` TINYINT UNSIGNED NOT NULL,
 `sessionHash` CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NULL,
 `connectedAt` DATETIME(3) NULL,
 `observedAt` DATETIME(3) NOT NULL,
 `addressesJson` TEXT NOT NULL,
 PRIMARY KEY (`clientId`,`routerId`),
 KEY `dashboard_connection_recent` (`connectedAt`,`clientId`),
 CONSTRAINT `dashboard_connection_client_fk` FOREIGN KEY (`clientId`) REFERENCES `Client` (`id`) ON DELETE RESTRICT,
 CONSTRAINT `dashboard_connection_router_fk` FOREIGN KEY (`routerId`) REFERENCES `Router` (`id`) ON DELETE RESTRICT,
 CONSTRAINT `dashboard_connection_boolean` CHECK (`connected` IN (0,1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `DashboardTrafficState` (
 `id` VARCHAR(16) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 `status` VARCHAR(16) NOT NULL DEFAULT 'PENDING',
 `nextRunAt` DATETIME(3) NULL,
 `observedAt` DATETIME(3) NULL,
 `downloadBps` DOUBLE NULL,
 `uploadBps` DOUBLE NULL,
 `coveredRouters` INT UNSIGNED NOT NULL DEFAULT 0,
 `totalRouters` INT UNSIGNED NOT NULL DEFAULT 0,
 `lastError` VARCHAR(500) NULL,
 `failures` INT UNSIGNED NOT NULL DEFAULT 0,
 PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `DashboardTrafficCounter` (
 `routerId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 `clientId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 `sourceKey` CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 `uploadBytes` VARCHAR(20) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 `downloadBytes` VARCHAR(20) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 `observedAt` DATETIME(3) NOT NULL,
 PRIMARY KEY (`routerId`,`sourceKey`),
 KEY `dashboard_counter_client` (`clientId`),
 CONSTRAINT `dashboard_counter_client_fk` FOREIGN KEY (`clientId`) REFERENCES `Client` (`id`) ON DELETE RESTRICT,
 CONSTRAINT `dashboard_counter_router_fk` FOREIGN KEY (`routerId`) REFERENCES `Router` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `DashboardTrafficBucket` (
 `resolution` VARCHAR(6) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 `bucketAt` DATETIME NOT NULL,
 `sampleCount` INT UNSIGNED NOT NULL,
 `downloadSum` DOUBLE NOT NULL,
 `uploadSum` DOUBLE NOT NULL,
 `downloadPeak` DOUBLE NOT NULL,
 `uploadPeak` DOUBLE NOT NULL,
 `firstSampleAt` DATETIME(3) NOT NULL,
 `lastSampleAt` DATETIME(3) NOT NULL,
 PRIMARY KEY (`resolution`,`bucketAt`),
 CONSTRAINT `dashboard_bucket_resolution` CHECK (`resolution` IN ('MINUTE','HOUR') AND `sampleCount`>0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
