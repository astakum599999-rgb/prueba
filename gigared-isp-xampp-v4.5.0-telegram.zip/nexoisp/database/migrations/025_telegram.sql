-- Optional private Telegram bot. Existing financial and network records stay intact.
CREATE TABLE IF NOT EXISTS TelegramSetting (
 id VARCHAR(16) CHARACTER SET ascii COLLATE ascii_bin PRIMARY KEY,
 enabled TINYINT UNSIGNED NOT NULL DEFAULT 0,
 tokenEncrypted TEXT NULL,
 botId VARCHAR(20) CHARACTER SET ascii COLLATE ascii_bin NULL,
 botUsername VARCHAR(100) NULL,
 verifiedAt DATETIME(3) NULL,
 nextOffset BIGINT UNSIGNED NOT NULL DEFAULT 0,
 revision INT UNSIGNED NOT NULL DEFAULT 1,
 lastPollAt DATETIME(3) NULL,
 nextPollAt DATETIME(3) NULL,
 lastError VARCHAR(500) NULL,
 failures INT UNSIGNED NOT NULL DEFAULT 0,
 updatedAt DATETIME(3) NOT NULL,
 CHECK (enabled IN (0,1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS TelegramOperator (
 telegramId VARCHAR(20) CHARACTER SET ascii COLLATE ascii_bin PRIMARY KEY,
 userId CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 label VARCHAR(100) NOT NULL,
 canPayments TINYINT UNSIGNED NOT NULL DEFAULT 0,
 canActivate TINYINT UNSIGNED NOT NULL DEFAULT 0,
 createdAt DATETIME(3) NOT NULL,
 FOREIGN KEY (userId) REFERENCES User(id) ON DELETE RESTRICT,
 CHECK (canPayments IN (0,1) AND canActivate IN (0,1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS TelegramSession (
 telegramId VARCHAR(20) CHARACTER SET ascii COLLATE ascii_bin PRIMARY KEY,
 clientId CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NULL,
 state VARCHAR(20) NOT NULL,
 payloadJson TEXT NOT NULL,
 expiresAt DATETIME(3) NOT NULL,
 FOREIGN KEY (telegramId) REFERENCES TelegramOperator(telegramId) ON DELETE CASCADE,
 FOREIGN KEY (clientId) REFERENCES Client(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS TelegramAction (
 id CHAR(32) CHARACTER SET ascii COLLATE ascii_bin PRIMARY KEY,
 telegramId VARCHAR(20) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 clientId CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 actorId CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 kind VARCHAR(12) NOT NULL,
 status VARCHAR(12) NOT NULL DEFAULT 'PENDING',
 configRevision INT UNSIGNED NOT NULL,
 payloadJson TEXT NOT NULL,
 resultJson TEXT NULL,
 expiresAt DATETIME(3) NOT NULL,
 notifiedAt DATETIME(3) NULL,
 createdAt DATETIME(3) NOT NULL,
 FOREIGN KEY (telegramId) REFERENCES TelegramOperator(telegramId) ON DELETE CASCADE,
 FOREIGN KEY (clientId) REFERENCES Client(id) ON DELETE RESTRICT,
 FOREIGN KEY (actorId) REFERENCES User(id) ON DELETE RESTRICT,
 KEY telegram_action_notifications (status,notifiedAt),
 CHECK (kind IN ('PAYMENT','ACTIVATE')),
 CHECK (status IN ('PENDING','RUNNING','DONE','FAILED','CANCELLED'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS TelegramInbox (
 botId VARCHAR(20) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 updateId BIGINT UNSIGNED NOT NULL,
 payloadJson MEDIUMTEXT NOT NULL,
 status VARCHAR(12) NOT NULL DEFAULT 'NEW',
 createdAt DATETIME(3) NOT NULL,
 PRIMARY KEY (botId,updateId),
 KEY telegram_inbox_pending (botId,status,updateId)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS TelegramOutbox (
 seq BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
 id CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL UNIQUE,
 telegramId VARCHAR(20) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 clientId CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NULL,
 configRevision INT UNSIGNED NOT NULL,
 method VARCHAR(24) NOT NULL,
 payloadJson TEXT NOT NULL,
 attempts INT UNSIGNED NOT NULL DEFAULT 0,
 nextAttemptAt DATETIME(3) NOT NULL,
 createdAt DATETIME(3) NOT NULL,
 FOREIGN KEY (clientId) REFERENCES Client(id) ON DELETE RESTRICT,
 KEY telegram_outbox_pending (nextAttemptAt,createdAt)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
