<?php
declare(strict_types=1);
namespace Nexo;

use PDO;

require_once __DIR__ . '/RouterTransport.php';

const SECRET_IMPORT_PROPERTIES = '.id,name,service,profile,remote-address,local-address,caller-id,disabled,comment';
const SECRET_IMPORT_LIMIT = 20000;

/** RouterOS values are observations, never a source of SQL names or commands. */
function secretImportText(mixed $value, int $maximum, bool $multiline = false): string
{
    if (!is_string($value) || strlen($value) > $maximum * 4 || preg_match('//u', $value) !== 1 ||
        preg_match($multiline ? '/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/' : '/[\x00-\x1F\x7F]/', $value)) {
        throw new HttpError(502, 'El router devolvió texto PPP inválido; no se importó ningún registro.', 'INVALID_ROUTER_RESPONSE');
    }
    $length = preg_match_all('/./us', $value);
    if ($length === false || $length > $maximum) {
        throw new HttpError(502, 'Un campo PPP excede el límite admitido; no se importó ningún registro.', 'INVALID_ROUTER_RESPONSE');
    }
    return $value;
}

function secretImportDisabled(mixed $value): bool
{
    if (in_array($value, [true, 1, 'true', 'yes', '1'], true)) return true;
    if (in_array($value, [false, 0, 'false', 'no', '0'], true)) return false;
    throw new HttpError(502, 'El router devolvió un estado PPP inválido; no se importó ningún registro.', 'INVALID_ROUTER_RESPONSE');
}

/** Validate the full list before opening a write transaction or marking absences. */
function secretImportNormalize(array $rows): array
{
    if (!array_is_list($rows) || count($rows) > SECRET_IMPORT_LIMIT) {
        throw new HttpError(502, 'La lista PPP no es válida o excede 20000 entradas; no se realizó una importación parcial.', 'INVALID_ROUTER_RESPONSE');
    }
    $result = []; $names = []; $remoteIds = [];
    foreach ($rows as $row) {
        if (!is_array($row) || array_is_list($row) || !array_key_exists('.id', $row) || !array_key_exists('name', $row) || !array_key_exists('disabled', $row)) {
            throw new HttpError(502, 'La respuesta PPP está incompleta; no se importó ningún registro.', 'INVALID_ROUTER_RESPONSE');
        }
        $remoteId = secretImportText($row['.id'], 128);
        $username = secretImportText($row['name'], 255);
        if ($remoteId === '' || $username === '') {
            throw new HttpError(502, 'Una cuenta PPP no tiene identidad; no se importó ningún registro.', 'INVALID_ROUTER_RESPONSE');
        }
        // Array keys use a hash prefix to avoid PHP converting numeric usernames.
        $nameKey = 'n:' . bin2hex($username); $remoteKey = 'r:' . bin2hex($remoteId);
        if (isset($names[$nameKey]) || isset($remoteIds[$remoteKey])) {
            throw new HttpError(502, 'El router devolvió identidades PPP duplicadas; no se importó ningún registro.', 'INVALID_ROUTER_RESPONSE');
        }
        $names[$nameKey] = true; $remoteIds[$remoteKey] = true;
        // Explicit whitelist: even a router ignoring .proplist cannot persist passwords.
        $record = [
            'remoteId' => $remoteId, 'username' => $username,
            'pppService' => secretImportText($row['service'] ?? '', 32),
            'profile' => secretImportText($row['profile'] ?? '', 255),
            'remoteAddress' => secretImportText($row['remote-address'] ?? '', 255),
            'localAddress' => secretImportText($row['local-address'] ?? '', 255),
            'callerId' => secretImportText($row['caller-id'] ?? '', 255),
            'disabled' => secretImportDisabled($row['disabled']),
            'comment' => secretImportText($row['comment'] ?? '', 16000, true),
        ];
        $record['snapshotHash'] = hash('sha256', json_encode($record, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        $result[] = $record;
    }
    return $result;
}

/** The only remote command used by import; close is guaranteed on every outcome. */
function secretImportRead(RouterTransport $transport): array
{
    try {
        return secretImportNormalize($transport->print('/ppp/secret', [], ['.proplist' => SECRET_IMPORT_PROPERTIES]));
    } finally {
        $transport->close();
    }
}

function secretImportTransport(array $router): RouterTransport
{
    if (!in_array($router['transport'] ?? '', ['REST', 'SOCKET'], true)) {
        throw new HttpError(422, 'Selecciona un router real con API Socket o REST para importar sus cuentas PPP.', 'INVALID_ROUTER');
    }
    $password = decryptSecret((string)$router['passwordEncrypted']);
    return match ($router['transport']) {
        'REST' => new RouterRestTransport($router, $password),
        'SOCKET' => new RouterSocketTransport($router, $password),
        default => throw new HttpError(422, 'Selecciona un router real con API Socket o REST para importar sus cuentas PPP.', 'INVALID_ROUTER'),
    };
}

function secretImportClientCode(string $routerId, string $username): string
{
    return 'MT-' . substr(hash('sha256', $routerId . "\0" . $username), 0, 32);
}

function secretImportClientName(string $username): string
{
    preg_match_all('/./us', $username, $characters);
    $name = implode('', array_slice($characters[0], 0, 200));
    return trim($name) === '' ? 'Cuenta PPP' : $name;
}

/** Also callable with a recording transport by integration tests; never makes Services. */
function secretImportRun(string $routerId, string $actorId, ?RouterTransport $transport = null): array
{
    if (!preg_match('/^[a-f0-9]{24}$/D', $routerId)) throw new HttpError(422, 'Identificador de router inválido.', 'VALIDATION_ERROR');
    $key = 'router:' . $routerId;
    if (!lock($key, 10)) throw new HttpError(409, 'El router está ocupado. Intenta la lectura de nuevo.', 'RESOURCE_BUSY');
    try {
        $router = fetchOne('SELECT * FROM `Router` WHERE id=?', [$routerId]) ?? throw new HttpError(404, 'Router no encontrado.', 'NOT_FOUND');
        $observed = secretImportRead($transport ?? secretImportTransport($router));
        return tx(function (PDO $pdo) use ($router, $observed, $actorId): array {
            $timestamp = now();
            $existingRows = fetchAll('SELECT s.*,c.status AS clientStatus FROM `RouterSecretImport` s JOIN `Client` c ON c.id=s.clientId WHERE s.routerId=? FOR UPDATE', [$router['id']]);
            $existing = [];
            foreach ($existingRows as $entry) $existing['n:' . bin2hex($entry['username'])] = $entry;
            $summary = ['router' => ['id' => $router['id'], 'name' => $router['name']], 'total' => count($observed), 'created' => 0, 'updated' => 0, 'unchanged' => 0, 'missing' => 0, 'networkReadOnly' => true];
            $insertClient = $pdo->prepare('INSERT INTO `Client` (id,code,name,status,createdAt,updatedAt) VALUES (?,?,?,?,?,?)');
            $insertSnapshot = $pdo->prepare('INSERT INTO `RouterSecretImport` (id,routerId,clientId,remoteId,username,pppService,profile,remoteAddress,localAddress,callerId,disabled,comment,present,snapshotHash,firstSeenAt,lastSeenAt) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,1,?,?,?)');
            $updateSnapshot = $pdo->prepare('UPDATE `RouterSecretImport` SET remoteId=?,pppService=?,profile=?,remoteAddress=?,localAddress=?,callerId=?,disabled=?,comment=?,present=1,snapshotHash=?,lastSeenAt=? WHERE id=?');
            foreach ($observed as $entry) {
                $identity = 'n:' . bin2hex($entry['username']);
                $old = $existing[$identity] ?? null;
                unset($existing[$identity]);
                if ($old === null) {
                    $clientId = id();
                    $insertClient->execute([$clientId, secretImportClientCode($router['id'], $entry['username']), secretImportClientName($entry['username']), $entry['disabled'] ? 'SUSPENDED' : 'ACTIVE', $timestamp, $timestamp]);
                    $insertSnapshot->execute([id(), $router['id'], $clientId, $entry['remoteId'], $entry['username'], $entry['pppService'], $entry['profile'], $entry['remoteAddress'], $entry['localAddress'], $entry['callerId'], (int)$entry['disabled'], $entry['comment'], $entry['snapshotHash'], $timestamp, $timestamp]);
                    $summary['created']++;
                } else {
                    $changed = $old['snapshotHash'] !== $entry['snapshotHash'] || !(bool)$old['present'];
                    $updateSnapshot->execute([$entry['remoteId'], $entry['pppService'], $entry['profile'], $entry['remoteAddress'], $entry['localAddress'], $entry['callerId'], (int)$entry['disabled'], $entry['comment'], $entry['snapshotHash'], $timestamp, $old['id']]);
                    // Preserve edited personal data, manual states and locally retired clients.
                    $previousObservedState = (bool)$old['disabled'] ? 'SUSPENDED' : 'ACTIVE';
                    $nextObservedState = $entry['disabled'] ? 'SUSPENDED' : 'ACTIVE';
                    if ($old['clientStatus'] === $previousObservedState && $nextObservedState !== $previousObservedState) {
                        $pdo->prepare('UPDATE `Client` SET status=?,updatedAt=? WHERE id=? AND status=?')->execute([$nextObservedState, $timestamp, $old['clientId'], $previousObservedState]);
                    }
                    $summary[$changed ? 'updated' : 'unchanged']++;
                }
            }
            foreach ($existing as $entry) {
                $summary['missing']++;
                if ((bool)$entry['present']) $pdo->prepare('UPDATE `RouterSecretImport` SET present=0 WHERE id=?')->execute([$entry['id']]);
            }
            audit('router.secrets.import', 'Router', $router['id'], $actorId);
            unset($GLOBALS['nexo_secret_import_cache']);
            return $summary;
        });
    } finally {
        unlock($key);
    }
}

function secretImportPublic(array $row): array
{
    return [
        'id' => $row['id'], 'routerId' => $row['routerId'], 'routerName' => $row['routerName'],
        'router' => ['id' => $row['routerId'], 'name' => $row['routerName']],
        'clientId' => $row['clientId'], 'remoteId' => $row['remoteId'], 'username' => $row['username'],
        'pppService' => $row['pppService'], 'profile' => $row['profile'],
        'remoteAddress' => $row['remoteAddress'], 'localAddress' => $row['localAddress'], 'callerId' => $row['callerId'],
        'disabled' => (bool)$row['disabled'], 'comment' => $row['comment'], 'present' => (bool)$row['present'],
        'firstSeenAt' => $row['firstSeenAt'], 'lastSeenAt' => $row['lastSeenAt'], 'networkReadOnly' => true,
    ];
}

function secretImportWarmClients(array $ids): void
{
    $ids = array_values(array_unique(array_filter($ids, static fn($value): bool => is_string($value) && preg_match('/^[a-f0-9]{24}$/D', $value) === 1)));
    if ($ids === []) return;
    $missing = [];
    foreach ($ids as $identifier) if (!array_key_exists($identifier, $GLOBALS['nexo_secret_import_cache'] ?? [])) $missing[] = $identifier;
    if ($missing === []) return;
    foreach ($missing as $identifier) $GLOBALS['nexo_secret_import_cache'][$identifier] = [];
    foreach (array_chunk($missing, 200) as $batch) {
        $rows = fetchAll('SELECT s.*,r.name AS routerName FROM `RouterSecretImport` s JOIN `Router` r ON r.id=s.routerId WHERE s.clientId IN (' . implode(',', array_fill(0, count($batch), '?')) . ') ORDER BY r.name,s.username,s.id', $batch);
        foreach ($rows as $row) $GLOBALS['nexo_secret_import_cache'][$row['clientId']][] = secretImportPublic($row);
    }
}

function secretImportClientRows(string $clientId): array
{
    secretImportWarmClients([$clientId]);
    return $GLOBALS['nexo_secret_import_cache'][$clientId] ?? [];
}

function secretImportDispatch(string $method, string $route): bool
{
    if ($method === 'POST' && preg_match('#^/routers/([a-f0-9]{24})/import-secrets$#D', $route, $match)) {
        $actor = permit('ADMIN', 'TECHNICIAN');
        if (body() !== []) throw new HttpError(422, 'La importación no admite parámetros ni cambios de configuración.', 'VALIDATION_ERROR');
        try { json(secretImportRun($match[1], $actor['id'])); }
        catch (RouterError $error) { throw new HttpError(502, 'No se pudo completar la lectura PPP del router. Comprueba conectividad, API y permisos de lectura.', $error->routerCode); }
    }
    if ($method === 'GET' && preg_match('#^/clients/([a-f0-9]{24})/router-secrets$#D', $route, $match)) {
        requireAuth();
        if (!fetchOne('SELECT id FROM `Client` WHERE id=?', [$match[1]])) throw new HttpError(404, 'Cliente no encontrado.', 'NOT_FOUND');
        $rows = secretImportClientRows($match[1]);
        json(['results' => $rows, 'count' => count($rows), 'page' => 1, 'pageSize' => max(1, count($rows))]);
    }
    return false;
}
