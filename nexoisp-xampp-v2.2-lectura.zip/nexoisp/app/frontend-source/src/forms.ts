import type { Capabilities, Client, Invoice, Plan, Router, Service, User } from './types';
import type { FieldSpec, FormValues } from './ui';

export type Row = { id: string; [key: string]: unknown };
export interface Lookups { clients: Client[]; plans: Plan[]; routers: Router[]; services: Service[]; users: User[]; invoices: Invoice[] }
export const emptyLookups: Lookups = { clients: [], plans: [], routers: [], services: [], users: [], invoices: [] };
const options = (values: string[]) => values.map(value => ({ value, label: value }));

export function formFields(kind: string, editing: boolean, lookups: Lookups, capabilities: Capabilities, values: FormValues): FieldSpec[] {
  if (kind === 'clients') return [
    { name: 'code', label: 'Código de cliente', required: true, hint: 'Identificador único de tu operación.' },
    { name: 'name', label: 'Nombre completo / razón social', required: true, hint: values.importedClient === true ? 'Al repetir la importación, se toma de nuevo el comentario del secret de MikroTik como nombre.' : undefined },
    { name: 'document', label: 'RFC / DNI / documento' }, { name: 'email', label: 'Correo electrónico', type: 'email' },
    { name: 'phone', label: 'Teléfono' }, { name: 'zone', label: 'Zona' },
    { name: 'address', label: 'Dirección de instalación', full: true },
    { name: 'latitude', label: 'Latitud GPS', type: 'number', min: -90, max: 90, step: 'any' },
    { name: 'longitude', label: 'Longitud GPS', type: 'number', min: -180, max: 180, step: 'any' },
  ];
  if (kind === 'plans') return [
    { name: 'name', label: 'Nombre del plan', required: true, full: true },
    { name: 'downloadKbps', label: 'Bajada (kbps)', type: 'number', required: true, min: 1, disabled: editing && values.importedProfile === true, hint: values.importedProfile === true ? 'Velocidad base copiada del perfil. Se actualiza al repetir su lectura.' : '10000 kbps = 10 Mbps.' },
    { name: 'uploadKbps', label: 'Subida (kbps)', type: 'number', required: true, min: 1, disabled: editing && values.importedProfile === true },
    { name: 'price', label: 'Precio mensual', type: 'number', required: true, min: 0, step: '0.01', hint: values.importedProfile === true ? 'RouterOS no guarda la tarifa. Escribe el precio comercial local; cero sólo si el plan es deliberadamente gratuito.' : undefined },
    { name: 'currency', label: 'Moneda ISO 4217', required: true, hint: values.importedProfile === true ? 'Moneda comercial local: no se obtiene del MikroTik. Por ejemplo: USD, MXN o PEN.' : 'Por ejemplo: USD, MXN o PEN.' },
    { name: 'queueParent', label: 'Queue Tree Parent', required: true },
    { name: 'priority', label: 'Prioridad de cola (1–8)', type: 'number', required: true, min: 1, max: 8 },
    { name: 'pppoeProfile', label: 'Perfil PPPoE / Hotspot', required: true, full: true, disabled: editing && values.importedProfile === true, hint: values.importedProfile === true ? 'Perfil de origen observado. Editar la tarifa local no modifica este perfil.' : 'Debe existir en el router. Su configuración de pools y autenticación se mantiene.' },
    ...(editing ? [{ name: 'active', label: 'Plan disponible para nuevas altas', type: 'checkbox' as const }] : []),
  ];
  if (kind === 'routers') return [
    { name: 'name', label: 'Nombre del router', required: true },
    { name: 'host', label: 'IP / hostname de administración', required: true },
    { name: 'transport', label: 'Protocolo de administración', type: 'select', required: true, options: [{ value: 'REST', label: 'RouterOS v7 · REST' }, { value: 'SOCKET', label: 'RouterOS v6/v7 · API Socket' }, ...(capabilities.simulatedRouters ? [{ value: 'SIMULATED', label: 'Simulador de desarrollo' }] : [])] },
    { name: 'port', label: 'Puerto', type: 'number', min: 1, max: 65535, required: true },
    { name: 'username', label: 'Usuario RouterOS', required: true },
    { name: 'password', label: editing ? 'Nueva contraseña (opcional)' : 'Contraseña RouterOS', type: 'password', required: !editing, hint: editing ? 'Déjala vacía para conservar la contraseña actual.' : 'Se cifra en el servidor; no se vuelve a mostrar.' },
    { name: 'useTls', label: 'Usar TLS (HTTPS / API-SSL)', type: 'checkbox', hint: 'Mantén TLS habilitado. El puerto habitual es 443 para REST y 8729 para API-SSL.' },
    { name: 'cutAddressList', label: 'Address List de corte', required: true },
    { name: 'cutProfile', label: 'Perfil PPPoE de corte', required: true, hint: 'Debe existir en RouterOS antes de suspender clientes PPPoE.' },
    { name: 'paymentPortalIp', label: 'IP del portal de pago', hint: 'Opcional. La redirección del firewall corresponde a HTTP; HTTPS requiere portal cautivo.' },
    { name: 'paymentPortalPort', label: 'Puerto HTTP del portal', type: 'number', min: 1, max: 65535 },
    { name: 'dhcpServer', label: 'Servidor DHCP', required: true },
    { name: 'hotspotServer', label: 'Servidor Hotspot', required: true },
  ];
  if (kind === 'services') {
    const needsCredentials = values.type === 'PPPOE' || values.type === 'HOTSPOT';
    const needsMac = ['IP_MAC', 'DHCP', 'HOTSPOT'].includes(String(values.type));
    return [
      { name: 'clientId', label: 'Cliente', type: 'select', required: true, disabled: editing, options: lookups.clients.filter(row => row.status !== 'RETIRED').map(row => ({ value: row.id, label: `${row.code} · ${row.name}` })) },
      { name: 'planId', label: 'Plan de Internet', type: 'select', required: true, options: lookups.plans.filter(row => row.active || row.id === values.planId).map(row => ({ value: row.id, label: `${row.name} · ${row.downloadKbps / 1000}/${row.uploadKbps / 1000} Mbps` })) },
      { name: 'routerId', label: 'Router asignado', type: 'select', required: true, disabled: editing, options: lookups.routers.map(row => ({ value: row.id, label: `${row.name} · ${row.host}${row.transport === 'SIMULATED' ? ' (simulado)' : ''}` })) },
      { name: 'type', label: 'Tipo de servicio', type: 'select', required: true, disabled: editing, options: [{ value: 'PPPOE', label: 'PPPoE' }, { value: 'SIMPLE_QUEUE', label: 'Simple Queue' }, { value: 'QUEUE_TREE', label: 'Queue Tree' }, { value: 'IP_MAC', label: 'IP / MAC' }, { value: 'HOTSPOT', label: 'Hotspot' }, { value: 'DHCP', label: 'DHCP Lease' }] },
      { name: 'ipAddress', label: 'Dirección IPv4 asignada', required: true, disabled: editing, hint: 'IP individual, sin máscara. Debe ser única dentro del router.' },
      { name: 'macAddress', label: 'MAC del equipo', required: needsMac, hint: 'Formato AA:BB:CC:DD:EE:FF.' },
      ...(needsCredentials ? [
        { name: 'username', label: 'Usuario del servicio', required: true, disabled: editing },
        { name: 'password', label: editing ? 'Nueva contraseña (opcional)' : 'Contraseña del servicio', type: 'password' as const, required: !editing },
      ] : []),
      { name: 'billingDay', label: 'Día de facturación UTC (1–28)', type: 'number', min: 1, max: 28, required: true },
      { name: 'dueDays', label: 'Días hasta vencimiento', type: 'number', min: 0, max: 90, required: true },
      { name: 'graceDays', label: 'Días de gracia después de vencer', type: 'number', min: 0, max: 90, required: true },
    ];
  }
  if (kind === 'tickets') return [
    { name: 'clientId', label: 'Cliente', type: 'select', required: true, disabled: editing, options: lookups.clients.map(row => ({ value: row.id, label: `${row.code} · ${row.name}` })) },
    { name: 'assigneeId', label: 'Técnico asignado', type: 'select', options: lookups.users.map(row => ({ value: row.id, label: row.name })) },
    { name: 'subject', label: 'Asunto', required: true, full: true },
    { name: 'body', label: 'Descripción del problema', type: 'textarea', required: true, full: true },
    { name: 'priority', label: 'Prioridad', type: 'select', required: true, options: [{ value: 'LOW', label: 'Baja' }, { value: 'NORMAL', label: 'Normal' }, { value: 'HIGH', label: 'Alta' }, { value: 'URGENT', label: 'Urgente' }] },
    { name: 'status', label: 'Estado', type: 'select', required: true, options: [{ value: 'OPEN', label: 'Abierto' }, { value: 'IN_PROGRESS', label: 'En atención' }, { value: 'RESOLVED', label: 'Resuelto' }, { value: 'CLOSED', label: 'Cerrado' }] },
  ];
  if (kind === 'users') return [
    { name: 'name', label: 'Nombre completo', required: true }, { name: 'email', label: 'Correo electrónico', type: 'email', required: true },
    { name: 'role', label: 'Rol de acceso', type: 'select', required: true, options: [{ value: 'ADMIN', label: 'Administrador' }, { value: 'BILLING', label: 'Facturación' }, { value: 'TECHNICIAN', label: 'Técnico' }, { value: 'VIEWER', label: 'Solo consulta' }] },
    { name: 'password', label: editing ? 'Nueva contraseña (opcional)' : 'Contraseña', type: 'password', required: !editing, hint: 'Mínimo 12 caracteres. Usa una contraseña única.' },
    ...(editing ? [{ name: 'active', label: 'Cuenta habilitada', type: 'checkbox' as const }] : []),
  ];
  if (kind === 'keys') return [
    { name: 'label', label: 'Nombre de la integración', required: true, full: true },
    { name: 'expiresAt', label: 'Fecha de vencimiento (opcional)', type: 'datetime-local', full: true, hint: 'La clave tendrá los mismos permisos que tu cuenta.' },
  ];
  if (kind === 'invoice') return [
    { name: 'serviceId', label: 'Servicio', type: 'select', required: true, full: true, options: lookups.services.filter(row => row.desiredState !== 'RETIRED').map(row => ({ value: row.id, label: `${row.client?.name || row.clientId} · ${row.ipAddress} · ${row.plan?.name || ''}` })) },
    { name: 'period', label: 'Periodo de facturación', required: true, full: true, hint: 'Formato AAAA-MM. Cada servicio admite una sola factura por periodo.' },
  ];
  if (kind === 'payment') return [
    { name: 'invoiceId', label: 'Factura', type: 'select', required: true, full: true, options: lookups.invoices.filter(row => row.status === 'OPEN').map(row => ({ value: row.id, label: `${row.number} · ${row.client?.name || ''} · saldo ${((row.amountCents - row.paidCents) / 100).toFixed(2)} ${row.currency}` })) },
    { name: 'amount', label: 'Importe recibido', type: 'number', required: true, min: 0.01, step: '0.01' },
    { name: 'currency', label: 'Moneda', required: true, disabled: true },
    { name: 'externalReference', label: 'Referencia única del pago', required: true, full: true, hint: 'Folio bancario o comprobante. La misma referencia no puede acreditarse dos veces.' },
  ];
  return [];
}

export function initialValues(kind: string, row?: Row): FormValues {
  const defaults: Record<string, FormValues> = {
    plans: { downloadKbps: '10000', uploadKbps: '5000', price: '0.00', currency: 'USD', queueParent: 'global', priority: '8', pppoeProfile: 'default', active: true },
    routers: { transport: 'REST', port: '443', useTls: true, verifyTls: true, cutAddressList: 'CORTE_WISPHUB', cutProfile: 'Perfil_Corte', paymentPortalPort: '80', dhcpServer: 'all', hotspotServer: 'all' },
    services: { type: 'PPPOE', billingDay: '1', dueDays: '10', graceDays: '3' },
    tickets: { status: 'OPEN', priority: 'NORMAL' }, users: { role: 'VIEWER', active: true },
    invoice: { period: new Date().toISOString().slice(0, 7) }, payment: { provider: 'manual', externalReference: '' },
  };
  const values = { ...defaults[kind] };
  if (row) for (const [key, value] of Object.entries(row)) {
    if (typeof value === 'boolean') values[key] = value;
    else if (typeof value === 'string' || typeof value === 'number') values[key] = String(value);
    else if (value === null) values[key] = '';
  }
  if (kind === 'plans' && row) {
    const imported = row.profileImport && typeof row.profileImport === 'object' ? row.profileImport as Record<string, unknown> : null;
    values.importedProfile = imported !== null;
    values.price = imported?.priceConfigured === false ? '' : (Number(row.priceCents) / 100).toFixed(2);
  }
  if (kind === 'clients' && row) values.importedClient = Array.isArray(row.routerSecrets) && row.routerSecrets.length > 0;
  values.password = '';
  return values;
}

export function formPayload(kind: string, fields: FieldSpec[], values: FormValues, editing: boolean): Record<string, unknown> {
  const payload: Record<string, unknown> = {};
  for (const field of fields) {
    if (field.disabled || field.name === 'price' || field.name === 'amount') continue;
    const value = values[field.name];
    if (field.type === 'checkbox') payload[field.name] = Boolean(value);
    else if (field.type === 'password' && !value) continue;
    else if (field.type === 'number') { if (value !== '' && value !== undefined) payload[field.name] = Number(value); else if (editing) payload[field.name] = null; }
    else if (value === '' || value === undefined) {
      if (editing && ['email', 'phone', 'document', 'address', 'zone', 'macAddress', 'assigneeId', 'paymentPortalIp'].includes(field.name)) payload[field.name] = null;
    } else payload[field.name] = String(value).trim();
  }
  if (kind === 'plans') { payload.priceCents = Math.round(Number(values.price) * 100); payload.currency = String(values.currency).toUpperCase(); }
  if (kind === 'routers') payload.verifyTls = true;
  if (kind === 'keys' && payload.expiresAt) payload.expiresAt = new Date(String(payload.expiresAt)).toISOString();
  if (kind === 'payment') { payload.amountCents = Math.round(Number(values.amount) * 100); payload.currency = String(values.currency).toUpperCase(); payload.provider = 'manual'; }
  if (kind === 'users') payload.email = String(values.email).toLowerCase();
  if (kind === 'tickets' && editing) delete payload.clientId;
  return payload;
}

export const stringOptions = options;
