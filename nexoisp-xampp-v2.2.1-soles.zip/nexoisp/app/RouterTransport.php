<?php
declare(strict_types=1);

namespace Nexo;

use RuntimeException;
use Throwable;

final class RouterError extends RuntimeException
{
    public function __construct(string $message, public readonly string $routerCode = 'ROUTER_ERROR')
    {
        parent::__construct($message);
    }
}

interface RouterTransport
{
    public function isSimulated(): bool;
    public function print(string $resource, array $filters = [], array $options = []): array;
    public function add(string $resource, array $values): string;
    public function set(string $resource, string $id, array $values): void;
    public function remove(string $resource, string $id): void;
    public function execute(string $command, array $values = []): array;
    public function close(): void;
}

final class RouterTransportUtil
{
    public static function readOnly(): bool
    {
        if (function_exists(__NAMESPACE__ . '\networkReadOnly')) return networkReadOnly();
        if (function_exists(__NAMESPACE__ . '\config')) return config('network_read_only', true) !== false;
        return true;
    }

    public static function requireWrite(): void
    {
        if (self::readOnly()) throw new RouterError('La red está en modo solo lectura; no se permite modificar RouterOS.', 'NETWORK_READ_ONLY');
    }

    public static function requirePrint(array $filters = [], array $options = []): void
    {
        if (!self::readOnly()) return;
        $allowed = ['.proplist','stats','detail','count-only','without-paging','terse','brief','as-value'];
        if (array_diff(array_keys($options), $allowed)) {
            throw new RouterError('La consulta incluye opciones no admitidas en modo solo lectura.', 'NETWORK_READ_ONLY');
        }
        foreach (array_keys($filters) as $key) {
            if (in_array(strtolower((string)$key), ['file','append','save','save-to','output','output-file'], true)) {
                throw new RouterError('No se permite guardar la salida de una consulta en el router.', 'NETWORK_READ_ONLY');
            }
        }
    }

    public static function requireCommand(string $command, array $values = []): void
    {
        if (!self::readOnly()) return;
        $command = self::path($command);
        if (str_ends_with($command, '/print')) { self::requirePrint([], $values); return; }
        $allowed = match ($command) {
            '/ping' => ['address','count','interval','size','packet-size','interface','arp-ping','arp','timeout','src-address','routing-table','ttl','do-not-fragment','dscp'],
            '/interface/monitor-traffic' => ['interface','once','interval','duration'],
            default => null,
        };
        if ($allowed !== null && !array_diff(array_keys($values), $allowed)) return;
        throw new RouterError('El comando o sus opciones están bloqueados en modo solo lectura.', 'NETWORK_READ_ONLY');
    }

    public static function truthy(mixed $value): bool
    {
        return $value === true || $value === 1 || in_array(strtolower((string)$value), ['1', 'true', 'yes', 'on'], true);
    }

    public static function validate(array $router): void
    {
        $host = (string)($router['host'] ?? '');
        if ($host === '' || strlen($host) > 253 || !preg_match('/^[a-z\d](?:[a-z\d.-]*[a-z\d])?$/iD', $host)) {
            throw new RouterError('El host debe ser una IPv4 o un nombre DNS sin protocolo, ruta ni credenciales.', 'INVALID_ROUTER');
        }
        $port = (int)($router['port'] ?? 0);
        if ($port < 1 || $port > 65535) {
            throw new RouterError('Puerto de router inválido.', 'INVALID_ROUTER');
        }
        if (self::truthy($router['useTls'] ?? true) && !self::truthy($router['verifyTls'] ?? true)) {
            throw new RouterError('La verificación TLS es obligatoria. Configure la CA del router.', 'TLS_REQUIRED');
        }
    }

    public static function path(string $path): string
    {
        if (!preg_match('~^/(?:[a-z][a-z\d-]*/?)+$~iD', $path)) {
            throw new RouterError('Ruta RouterOS inválida.', 'INVALID_COMMAND');
        }
        return rtrim($path, '/');
    }

    public static function strings(array $values): array
    {
        $result = [];
        foreach ($values as $key => $value) {
            if (!is_string($key) || !preg_match('/^[.a-z\d_-]+$/iD', $key) || (!is_scalar($value) && $value !== null)) {
                throw new RouterError('Atributo RouterOS inválido.', 'INVALID_COMMAND');
            }
            $result[$key] = is_bool($value) ? ($value ? 'true' : 'false') : (string)($value ?? '');
        }
        return $result;
    }

    public static function record(mixed $value): array
    {
        if (!is_array($value) || ($value !== [] && array_is_list($value))) {
            throw new RouterError('Respuesta RouterOS inválida.', 'INVALID_RESPONSE');
        }
        $result = [];
        foreach ($value as $key => $item) {
            if (!is_scalar($item) && $item !== null) {
                throw new RouterError('Propiedad RouterOS no escalar.', 'INVALID_RESPONSE');
            }
            $result[(string)$key] = is_bool($item) ? ($item ? 'true' : 'false') : (string)($item ?? '');
        }
        return $result;
    }

    public static function sslOptions(string $host): array
    {
        $options = ['verify_peer' => true, 'verify_peer_name' => true, 'allow_self_signed' => false, 'peer_name' => $host, 'SNI_enabled' => true];
        $ca = function_exists(__NAMESPACE__ . '\\config') ? config('router_ca_file') : null;
        if (is_string($ca) && $ca !== '') {
            if (!is_file($ca) || !is_readable($ca)) {
                throw new RouterError('El archivo CA del router no se puede leer.', 'INVALID_CA');
            }
            $options['cafile'] = $ca;
        }
        return $options;
    }
}

/** Native PHP streams implementation; no Composer, cURL or sockets extension required. */
final class RouterRestTransport implements RouterTransport
{
    private string $origin;
    private string $authorization;
    private array $ssl;

    public function __construct(array $router, string $password, private readonly float $timeoutSeconds = 15.0)
    {
        RouterTransportUtil::validate($router);
        $this->origin = (RouterTransportUtil::truthy($router['useTls'] ?? true) ? 'https' : 'http') . '://' . $router['host'] . ':' . (int)$router['port'] . '/rest';
        $this->authorization = 'Basic ' . base64_encode((string)$router['username'] . ':' . $password);
        $this->ssl = RouterTransportUtil::sslOptions((string)$router['host']);
    }

    public function isSimulated(): bool { return false; }

    private function call(string $method, string $path, ?array $body = null): mixed
    {
        $http = [
            'method' => $method,
            'header' => "Authorization: {$this->authorization}\r\nContent-Type: application/json\r\nAccept: application/json\r\nConnection: close\r\n",
            'ignore_errors' => true, 'follow_location' => 0, 'max_redirects' => 0,
            'timeout' => $this->timeoutSeconds, 'protocol_version' => 1.1,
        ];
        if ($body !== null) {
            $http['content'] = json_encode((object)$body, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES);
        }
        $context = stream_context_create(['http' => $http, 'ssl' => $this->ssl]);
        $deadline = microtime(true) + $this->timeoutSeconds;
        $stream = @fopen($this->origin . $path, 'rb', false, $context);
        if ($stream === false) {
            throw new RouterError('No se pudo abrir la conexión REST al router. Compruebe host, TLS, CA y allow_url_fopen.', 'TRANSPORT_ERROR');
        }
        $raw = '';
        try {
            $status = 0;
            $metadata = stream_get_meta_data($stream);
            foreach (($metadata['wrapper_data'] ?? []) as $header) {
                if (preg_match('~^HTTP/\d(?:\.\d)?\s+(\d{3})~i', (string)$header, $match)) {
                    $status = (int)$match[1];
                }
            }
            while (!feof($stream)) {
                $remaining = $deadline - microtime(true);
                if ($remaining <= 0) {
                    throw new RouterError('Tiempo total REST agotado.', 'TIMEOUT');
                }
                stream_set_timeout($stream, (int)$remaining, max(1, (int)(($remaining - floor($remaining)) * 1000000)));
                $part = @fread($stream, 8192);
                $metadata = stream_get_meta_data($stream);
                if ($part === false || !empty($metadata['timed_out'])) {
                    throw new RouterError('No se completó la lectura REST del router.', !empty($metadata['timed_out']) ? 'TIMEOUT' : 'TRANSPORT_ERROR');
                }
                $raw .= $part;
                if (strlen($raw) > 4 * 1024 * 1024) {
                    throw new RouterError('La respuesta REST excede 4 MiB.', 'RESPONSE_LIMIT');
                }
            }
            if ($status < 200 || $status >= 300) {
                throw new RouterError('RouterOS REST respondió HTTP ' . $status . '.', $status === 401 ? 'AUTH_FAILED' : 'ROUTER_TRAP');
            }
        } finally {
            fclose($stream);
        }
        if ($raw === '') {
            return null;
        }
        try {
            return json_decode($raw, true, 64, JSON_THROW_ON_ERROR);
        } catch (\JsonException) {
            throw new RouterError('RouterOS REST no devolvió JSON válido.', 'INVALID_RESPONSE');
        }
    }

    public function print(string $resource, array $filters = [], array $options = []): array
    {
        RouterTransportUtil::requirePrint($filters, $options);
        $filters = RouterTransportUtil::strings($filters);
        $options = RouterTransportUtil::strings($options);
        $path = RouterTransportUtil::path($resource);
        if ($options !== []) {
            $body = $options;
            if ($filters !== []) {
                $body['.query'] = array_map(static fn($key, $value) => $key . '=' . $value, array_keys($filters), array_values($filters));
            }
            $result = $this->call('POST', $path . '/print', $body);
        } else {
            $query = http_build_query($filters, '', '&', PHP_QUERY_RFC3986);
            $result = $this->call('GET', $path . ($query !== '' ? '?' . $query : ''));
        }
        if (!is_array($result) || !array_is_list($result)) {
            throw new RouterError('RouterOS REST no devolvió una lista.', 'INVALID_RESPONSE');
        }
        return array_map([RouterTransportUtil::class, 'record'], $result);
    }

    public function add(string $resource, array $values): string
    {
        RouterTransportUtil::requireWrite();
        $result = RouterTransportUtil::record($this->call('PUT', RouterTransportUtil::path($resource), RouterTransportUtil::strings($values)));
        if (empty($result['.id'])) {
            throw new RouterError('RouterOS no devolvió identificador al crear el recurso.', 'INVALID_RESPONSE');
        }
        return $result['.id'];
    }

    public function set(string $resource, string $id, array $values): void
    {
        RouterTransportUtil::requireWrite();
        $this->call('PATCH', RouterTransportUtil::path($resource) . '/' . rawurlencode($id), RouterTransportUtil::strings($values));
    }

    public function remove(string $resource, string $id): void
    {
        RouterTransportUtil::requireWrite();
        $this->call('DELETE', RouterTransportUtil::path($resource) . '/' . rawurlencode($id));
    }

    public function execute(string $command, array $values = []): array
    {
        RouterTransportUtil::requireCommand($command, $values);
        $result = $this->call('POST', RouterTransportUtil::path($command), RouterTransportUtil::strings($values));
        if ($result === null || $result === []) { return []; }
        return array_map([RouterTransportUtil::class, 'record'], is_array($result) && array_is_list($result) ? $result : [$result]);
    }

    public function close(): void {}
}

final class RouterSocketTransport implements RouterTransport
{
    private mixed $socket = null;
    private bool $connected = false;
    private bool $closed = false;
    private const MAX_WORD = 4194304;
    private const MAX_RESPONSE = 8388608;

    public function __construct(private readonly array $router, private readonly string $password, private readonly float $timeoutSeconds = 15.0)
    {
        RouterTransportUtil::validate($router);
    }

    public function isSimulated(): bool { return false; }

    public static function encodeLength(int $length): string
    {
        if ($length < 0 || $length > 0xffffffff) { throw new RouterError('Longitud API inválida.', 'INVALID_COMMAND'); }
        if ($length < 0x80) { return chr($length); }
        if ($length < 0x4000) { return pack('n', $length | 0x8000); }
        if ($length < 0x200000) { return chr(($length >> 16) | 0xc0) . chr(($length >> 8) & 0xff) . chr($length & 0xff); }
        if ($length < 0x10000000) { return pack('N', $length | 0xe0000000); }
        return chr(0xf0) . pack('N', $length);
    }

    public static function decodeLength(string $input): ?array
    {
        if ($input === '') { return null; }
        $first = ord($input[0]);
        $bytes = $first < 0x80 ? 1 : ($first < 0xc0 ? 2 : ($first < 0xe0 ? 3 : ($first < 0xf0 ? 4 : ($first === 0xf0 ? 5 : 0))));
        if ($bytes === 0) { throw new RouterError('Prefijo de longitud API reservado.', 'INVALID_RESPONSE'); }
        if (strlen($input) < $bytes) { return null; }
        $length = match ($bytes) {
            1 => $first,
            2 => unpack('n', substr($input, 0, 2))[1] & 0x3fff,
            3 => (($first & 0x1f) << 16) | (ord($input[1]) << 8) | ord($input[2]),
            4 => unpack('N', substr($input, 0, 4))[1] & 0x0fffffff,
            5 => unpack('N', substr($input, 1, 4))[1],
        };
        return ['length' => $length, 'bytes' => $bytes];
    }

    public static function encodeSentence(array $words): string
    {
        $result = '';
        foreach ($words as $word) {
            $word = (string)$word;
            if (strlen($word) > self::MAX_WORD) { throw new RouterError('Palabra API demasiado grande.', 'RESPONSE_LIMIT'); }
            $result .= self::encodeLength(strlen($word)) . $word;
            if (strlen($result) > self::MAX_RESPONSE) { throw new RouterError('Oración API demasiado grande.', 'RESPONSE_LIMIT'); }
        }
        return $result . "\0";
    }

    private function connect(): void
    {
        if ($this->closed) { throw new RouterError('La conexión API está cerrada.', 'CONNECTION_CLOSED'); }
        if ($this->connected) { return; }
        $tls = RouterTransportUtil::truthy($this->router['useTls'] ?? true);
        $context = stream_context_create(['ssl' => RouterTransportUtil::sslOptions((string)$this->router['host'])]);
        $socket = @stream_socket_client(($tls ? 'tls' : 'tcp') . '://' . $this->router['host'] . ':' . (int)$this->router['port'], $errno, $error, $this->timeoutSeconds, STREAM_CLIENT_CONNECT, $context);
        if ($socket === false) { throw new RouterError('No se pudo conectar con la API Socket del router. Compruebe host, puerto y CA.', 'TRANSPORT_ERROR'); }
        $this->socket = $socket;
        stream_set_blocking($this->socket, true);
        try {
            $legacy = false;
            try { $response = $this->exchange(['/login', '=name=' . $this->router['username'], '=password=' . $this->password]); }
            catch (RouterError $error) {
                if ($error->routerCode !== 'ROUTER_TRAP') { throw $error; }
                $legacy = true;
                $response = $this->exchange(['/login']);
            }
            $challenge = null;
            foreach ($response as $row) { if (isset($row['ret'])) { $challenge = $row['ret']; break; } }
            if ($legacy && !$challenge) { throw new RouterError('RouterOS no aceptó las credenciales API.', 'AUTH_FAILED'); }
            if ($challenge !== null) {
                if (!preg_match('/^[a-f\d]{32}$/iD', $challenge)) { throw new RouterError('Desafío de autenticación API inválido.', 'AUTH_FAILED'); }
                $digest = md5("\0" . $this->password . hex2bin($challenge));
                $this->exchange(['/login', '=name=' . $this->router['username'], '=response=00' . $digest]);
            }
            $this->connected = true;
        } catch (Throwable $error) {
            $this->close();
            throw $error;
        }
    }

    private function timeout(float $deadline): void
    {
        $remaining = $deadline - microtime(true);
        if ($remaining <= 0) { $this->close(); throw new RouterError('Tiempo total API Socket agotado.', 'TIMEOUT'); }
        stream_set_timeout($this->socket, (int)$remaining, max(1, (int)(($remaining - floor($remaining)) * 1000000)));
    }

    private function readExact(int $length, float $deadline): string
    {
        $result = '';
        while (strlen($result) < $length) {
            $this->timeout($deadline);
            $part = @fread($this->socket, min(8192, $length - strlen($result)));
            $metadata = stream_get_meta_data($this->socket);
            if ($part === false || $part === '' || !empty($metadata['timed_out'])) {
                $this->close();
                throw new RouterError(!empty($metadata['timed_out']) ? 'Tiempo de respuesta API agotado.' : 'El router cerró la conexión API.', !empty($metadata['timed_out']) ? 'TIMEOUT' : 'CONNECTION_CLOSED');
            }
            $result .= $part;
        }
        return $result;
    }

    private function readSentence(float $deadline): array
    {
        $words = []; $size = 0;
        while (true) {
            $header = $this->readExact(1, $deadline);
            $first = ord($header);
            $bytes = $first < 0x80 ? 1 : ($first < 0xc0 ? 2 : ($first < 0xe0 ? 3 : ($first < 0xf0 ? 4 : ($first === 0xf0 ? 5 : 0))));
            if ($bytes === 0) { $this->close(); throw new RouterError('Prefijo de longitud API reservado.', 'INVALID_RESPONSE'); }
            if ($bytes > 1) { $header .= $this->readExact($bytes - 1, $deadline); }
            $length = self::decodeLength($header)['length'];
            if ($length === 0) { return $words; }
            $size += $length;
            if ($length > self::MAX_WORD || $size > self::MAX_RESPONSE || count($words) > 20000) {
                $this->close(); throw new RouterError('La respuesta API excede los límites de tamaño.', 'RESPONSE_LIMIT');
            }
            $words[] = $this->readExact($length, $deadline);
        }
    }

    private function exchange(array $words): array
    {
        if (!is_resource($this->socket)) { throw new RouterError('API Socket no conectada.', 'CONNECTION_CLOSED'); }
        $deadline = microtime(true) + $this->timeoutSeconds;
        $wire = self::encodeSentence($words);
        $written = 0;
        while ($written < strlen($wire)) {
            $this->timeout($deadline);
            $part = @fwrite($this->socket, substr($wire, $written));
            if ($part === false || $part === 0) { $this->close(); throw new RouterError('No se pudo escribir el comando API.', 'TRANSPORT_ERROR'); }
            $written += $part;
        }
        $records = []; $trap = null; $size = 0;
        while (true) {
            $sentence = $this->readSentence($deadline);
            $size += array_sum(array_map('strlen', $sentence));
            if ($size > self::MAX_RESPONSE || count($records) > 20000) { $this->close(); throw new RouterError('Respuesta API demasiado grande.', 'RESPONSE_LIMIT'); }
            $record = [];
            foreach (array_slice($sentence, 1) as $word) {
                if (!str_starts_with($word, '=')) { continue; }
                $separator = strpos($word, '=', 1);
                if ($separator !== false && $separator > 1) { $record[substr($word, 1, $separator - 1)] = substr($word, $separator + 1); }
            }
            $type = $sentence[0] ?? '';
            if ($type === '!re') { $records[] = $record; }
            elseif ($type === '!trap') { $trap = preg_match('/^\d{1,3}$/D', (string)($record['category'] ?? '')) ? $record['category'] : 'unknown'; }
            elseif ($type === '!fatal') { $this->close(); throw new RouterError('RouterOS cerró el comando con !fatal.', 'ROUTER_FATAL'); }
            elseif ($type === '!done') {
                if ($trap !== null) { throw new RouterError('RouterOS rechazó el comando (categoría ' . $trap . ').', 'ROUTER_TRAP'); }
                if ($record !== []) { $records[] = $record; }
                return $records;
            }
        }
    }

    private function run(string $command, array $values = [], array $filters = []): array
    {
        $this->connect();
        $words = [RouterTransportUtil::path($command)];
        foreach (RouterTransportUtil::strings($values) as $key => $value) { $words[] = '=' . $key . '=' . $value; }
        foreach (RouterTransportUtil::strings($filters) as $key => $value) { $words[] = '?' . $key . '=' . $value; }
        return $this->exchange($words);
    }

    public function print(string $resource, array $filters = [], array $options = []): array {
        RouterTransportUtil::requirePrint($filters, $options); return $this->run(RouterTransportUtil::path($resource) . '/print', $options, $filters); }
    public function add(string $resource, array $values): string
    {
        RouterTransportUtil::requireWrite();
        foreach ($this->run(RouterTransportUtil::path($resource) . '/add', $values) as $row) {
            if (!empty($row['ret'])) { return $row['ret']; }
        }
        throw new RouterError('RouterOS no devolvió el identificador del recurso.', 'INVALID_RESPONSE');
    }
    public function set(string $resource, string $id, array $values): void {
        RouterTransportUtil::requireWrite(); $this->run(RouterTransportUtil::path($resource) . '/set', [...$values, '.id' => $id]); }
    public function remove(string $resource, string $id): void {
        RouterTransportUtil::requireWrite(); $this->run(RouterTransportUtil::path($resource) . '/remove', ['.id' => $id]); }
    public function execute(string $command, array $values = []): array {
        RouterTransportUtil::requireCommand($command, $values); return $this->run($command, $values); }
    public function close(): void
    {
        if (is_resource($this->socket)) { fclose($this->socket); }
        $this->socket = null; $this->connected = false; $this->closed = true;
    }
    public function __destruct() { $this->close(); }
}

final class RouterSimulatedTransport implements RouterTransport
{
    private static array $routers = [];
    private static int $sequence = 0;
    private string $routerId;

    public function __construct(array $router)
    {
        if (!function_exists(__NAMESPACE__ . '\\config') || !RouterTransportUtil::truthy(config('allow_simulated_routers'))) {
            throw new RouterError('Los routers simulados están deshabilitados.', 'SIMULATION_DISABLED');
        }
        $this->routerId = (string)$router['id'];
        self::$routers[$this->routerId] ??= [
            '/ppp/profile' => [['.id' => '*default', 'name' => 'default']],
            '/system/identity' => [['name' => 'SIMULATED']],
            '/system/resource' => [['version' => 'SIMULATED', 'board-name' => 'Development adapter']],
        ];
    }
    public function isSimulated(): bool { return true; }
    public function print(string $resource, array $filters = [], array $options = []): array
    {
        RouterTransportUtil::requirePrint($filters, $options);
        return array_values(array_filter(self::$routers[$this->routerId][$resource] ?? [], static function ($row) use ($filters) {
            foreach ($filters as $key => $value) { if (($row[$key] ?? null) !== (string)$value) { return false; } }
            return true;
        }));
    }
    public function add(string $resource, array $values): string
    {
        RouterTransportUtil::requireWrite();
        $id = '*sim' . ++self::$sequence;
        self::$routers[$this->routerId][$resource][] = [...RouterTransportUtil::strings($values), '.id' => $id];
        return $id;
    }
    public function set(string $resource, string $id, array $values): void
    {
        RouterTransportUtil::requireWrite();
        foreach (self::$routers[$this->routerId][$resource] ?? [] as $index => $row) {
            if (($row['.id'] ?? '') === $id) { self::$routers[$this->routerId][$resource][$index] = [...$row, ...RouterTransportUtil::strings($values)]; return; }
        }
        throw new RouterError('Recurso simulado inexistente.', 'NOT_FOUND');
    }
    public function remove(string $resource, string $id): void
    {
        RouterTransportUtil::requireWrite();
        self::$routers[$this->routerId][$resource] = array_values(array_filter(self::$routers[$this->routerId][$resource] ?? [], static fn($row) => ($row['.id'] ?? '') !== $id));
    }
    public function execute(string $command, array $values = []): array
    {
        RouterTransportUtil::requireCommand($command, $values);
        if (str_ends_with($command, '/move')) { return []; }
        if ($command === '/ping') { return [['status' => 'simulated: no network packets sent']]; }
        if ($command === '/interface/monitor-traffic') { return []; }
        throw new RouterError('Comando no disponible en simulación.', 'SIMULATED_COMMAND');
    }
    public function close(): void {}
}


/** Guards injected transports as well as the native clients at their own boundaries. */
final class RouterGuardedTransport implements RouterTransport
{
    public function __construct(private readonly RouterTransport $inner) {}
    public function isSimulated(): bool { return $this->inner->isSimulated(); }
    public function print(string $resource, array $filters = [], array $options = []): array
    {
        RouterTransportUtil::requirePrint($filters, $options);
        return $this->inner->print($resource, $filters, $options);
    }
    public function add(string $resource, array $values): string
    {
        RouterTransportUtil::requireWrite();
        return $this->inner->add($resource, $values);
    }
    public function set(string $resource, string $id, array $values): void
    {
        RouterTransportUtil::requireWrite();
        $this->inner->set($resource, $id, $values);
    }
    public function remove(string $resource, string $id): void
    {
        RouterTransportUtil::requireWrite();
        $this->inner->remove($resource, $id);
    }
    public function execute(string $command, array $values = []): array
    {
        RouterTransportUtil::requireCommand($command, $values);
        return $this->inner->execute($command, $values);
    }
    public function close(): void { $this->inner->close(); }
}
