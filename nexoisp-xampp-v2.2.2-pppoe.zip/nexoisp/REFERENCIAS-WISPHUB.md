# Referencias públicas y alcance de la implementación

NexoISP es una implementación independiente de administración de un ISP. Su código, interfaz y textos se desarrollaron para este proyecto. No contiene código privado, identidad gráfica ni artículos copiados de WispHub. Las referencias públicas sirven para estudiar funciones y contratos observables; no permiten certificar una réplica completa del producto privado.

## Fuentes consultadas

Se consultaron las siguientes fuentes públicas el 25 de octubre de 2026, con verificación TLS habilitada, sin credenciales y sin ejecutar operaciones en cuentas de WispHub:

| Fuente | Resultado observado | Uso en la investigación |
| --- | --- | --- |
| [Sitio oficial](https://wisphub.net/) | HTTP 200 | Identificar el enlace oficial al manual. |
| [Manual de usuario](https://wisphub.net/documentacion/home-1/) | HTTP 200 | Revisar su introducción e índice. El índice contenía 551 enlaces de documentación; no se descargaron todos sus artículos. |
| [Documentación de la API](https://wisphub.net/api-docs/) | HTTP 200 | Identificar la especificación pública enlazada desde ReDoc. |
| [Especificación de la API](https://wisphub.net/static/yaml/api/api-main.yaml) | HTTP 200 | OpenAPI 3.0.0, versión de API declarada 1.2.0. Se revisaron sus 58 definiciones públicas de rutas, que describían 71 operaciones; una corresponde a recomendaciones sin respuestas definidas. |
| [Promesas de pago](https://wisphub.net/documentacion/articulo/promesas-de-pago-45/) | HTTP 200 | Estudiar la extensión de la fecha límite de corte y la trazabilidad del compromiso. |
| [Prorrateo](https://wisphub.net/documentacion/articulo/prorrateo-188/) | HTTP 200 | Estudiar el cobro inicial proporcional y la distinción entre prepago y postpago. |
| [Agendar instalación](https://wisphub.net/documentacion/articulo/agendar-instalacion-71/) | HTTP 200 | Estudiar la relación entre cliente, zona, técnico, fecha de instalación, plan y servicio de red. |

Los sitios ayuda.wisphub.net y wisphub.io/documentacion no fueron accesibles desde el entorno de investigación: el proxy respondió 403. No se utilizaron como fuentes verificadas. La ruta genérica wisphub.net/documentacion/ devolvió 404; el manual accesible fue la ruta home-1 enlazada por el sitio oficial.

## Patrones observados

La especificación pública utiliza claves de API en el encabezado Authorization y ejemplos con el prefijo Api-Key. Asocia permisos al personal de la empresa; algunas acciones financieras, como modificar fechas o importes de cobro, tienen permisos específicos. Los listados describen resultados paginados con count, next, previous y results, junto con filtros por campo y parámetros de límite y desplazamiento.

Las operaciones de red pesadas pueden devolver un identificador task_id para consultar posteriormente el resultado. La documentación del ping contempla un máximo de diez intentos y opciones de interfaz y ARP. El esquema de consulta de tareas agrupa status, id y result dentro de task, pero no enumera todos los valores posibles de estado.

Además del control de clientes, la documentación pública presenta instalaciones, servicios adicionales, facturas, pagos, promesas de pago, gastos, soporte, fichas Hotspot, planes, zonas, personal, proveedores y distintas integraciones de cobranza. La presencia de una función en ese índice no demuestra que NexoISP implemente cada proveedor, pantalla o variante de WispHub.

El artículo de promesas de pago describe un plazo que evita el corte, su resolución al pagar y la auditoría del personal que registró la operación. El artículo de prorrateo explica modalidades de primera factura y efectos sobre el calendario siguiente. El de instalaciones reúne información del cliente y su ubicación con la asignación técnica y los datos del servicio. Estos comportamientos orientan las funciones propias de NexoISP; sus reglas exactas se deben verificar en la documentación y pruebas del módulo entregado.

## Límites de equivalencia y validación

- La API propia de NexoISP y su portal del cliente tienen sus contratos definidos en el código entregado. No se afirma que todas las rutas o estructuras JSON sean intercambiables con la API de WispHub.
- El esquema público de referencia tiene inconsistencias, como un desplazamiento tipado de forma distinta entre listados y ejemplos introductorios que no coinciden con el método declarado en una ruta. No se corrigieron mediante suposiciones sobre el servidor privado.
- Las integraciones fiscales, bancarias, de mensajería y de televisión de terceros requieren sus propios servicios, contratos y credenciales. Un catálogo o un reporte interno no sustituye una conexión verificada con esos proveedores.
- Un pago informado por el cliente queda sujeto a revisión del personal. No acredita dinero ni provoca reconexión por sí mismo.
- La aceptación de un contrato en el portal registra el nombre y la fecha. No es una firma electrónica certificada ni una certificación fiscal.
- Las pruebas con servidores RouterOS de laboratorio verifican contratos de comunicación y reglas del código. No sustituyen la validación en equipos físicos, su firmware y la política de red del ISP.
- No se descargaron el conjunto de la wiki, imágenes, logotipos, archivos privados ni datos de clientes de WispHub.

Los enlaces pueden cambiar después de la revisión. La compatibilidad con servicios externos debe evaluarse nuevamente antes de usarlos en una instalación real.
