<?php
declare(strict_types=1);

namespace Nexo;

use Throwable;

require_once __DIR__ . '/RouterTransport.php';

/** RouterOS controller. The worker serializes operations using its per-router DB lock. */
final class MikroTik
{
    private array $router;
    private RouterTransport $transport;
    private ?bool $qosCompatible = null;
    private const REMOVABLE = ['/ppp/secret', '/queue/simple', '/queue/tree', '/ip/firewall/mangle', '/ip/hotspot/user'];

    public function __construct(array $router, ?RouterTransport $transport = null)
    {
        $this->router = [...[
            'cutAddressList' => 'CORTE_WISPHUB', 'cutProfile' => 'Perfil_Corte',
            'paymentPortalIp' => null, 'paymentPortalPort' => 80, 'dhcpServer' => 'all', 'hotspotServer' => 'all',
            'useTls' => true, 'verifyTls' => true,
        ], ...$router];
        if ($transport !== null) { $this->transport = new RouterGuardedTransport($transport); return; }
        if (($this->router['transport'] ?? '') === 'SIMULATED') {
            $this->transport = new RouterGuardedTransport(new RouterSimulatedTransport($this->router));
            return;
        }
        $password = decryptSecret((string)($this->router['passwordEncrypted'] ?? ''));
        $this->transport = new RouterGuardedTransport(match ($this->router['transport'] ?? '') {
            'REST' => new RouterRestTransport($this->router, $password),
            'SOCKET' => new RouterSocketTransport($this->router, $password),
            default => throw new RouterError('Transporte RouterOS inválido.', 'INVALID_ROUTER'),
        });
    }

    private function comment(array $service, string $suffix = ''): string { return 'nexoisp:' . $service['id'] . $suffix; }
    private static function id(array $row): string
    {
        if (empty($row['.id'])) { throw new RouterError('Un recurso RouterOS no tiene .id.', 'INVALID_RESPONSE'); }
        return (string)$row['.id'];
    }

    private function validate(array $service): void
    {
        if (($service['routerId'] ?? null) !== ($this->router['id'] ?? null)) { throw new RouterError('El servicio pertenece a otro router.', 'INVALID_SERVICE'); }
        if (!filter_var($service['ipAddress'] ?? '', FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) { throw new RouterError('Este controlador de Address Lists requiere una dirección IPv4.', 'INVALID_SERVICE'); }
        if (!preg_match('/^[\w-]+$/D', (string)($service['id'] ?? ''))) { throw new RouterError('Identificador de servicio inválido.', 'INVALID_SERVICE'); }
        if (!in_array($service['type'] ?? '', ['PPPOE', 'SIMPLE_QUEUE', 'QUEUE_TREE', 'IP_MAC', 'HOTSPOT', 'DHCP'], true)) { throw new RouterError('Tipo de servicio inválido.', 'INVALID_SERVICE'); }
        if (!in_array($service['desiredState'] ?? '', ['ACTIVE', 'SUSPENDED', 'RETIRED'], true)) { throw new RouterError('Estado deseado inválido.', 'INVALID_SERVICE'); }
        foreach (['downloadKbps', 'uploadKbps'] as $key) {
            $speed = filter_var($service['plan'][$key] ?? null, FILTER_VALIDATE_INT);
            if ($speed === false || $speed < 1 || $speed > 100000000) { throw new RouterError('Velocidad de plan inválida.', 'INVALID_PLAN'); }
        }
        $priority = filter_var($service['plan']['priority'] ?? null, FILTER_VALIDATE_INT);
        if ($priority === false || $priority < 1 || $priority > 8) { throw new RouterError('Prioridad fuera del intervalo 1–8.', 'INVALID_PLAN'); }
        if (in_array($service['type'], ['PPPOE', 'HOTSPOT'], true) && (!is_string($service['username'] ?? null) || $service['username'] === '' || !is_string($service['passwordEncrypted'] ?? null) || $service['passwordEncrypted'] === '')) { throw new RouterError('El servicio requiere usuario y contraseña.', 'INVALID_SERVICE'); }
        if (in_array($service['type'], ['IP_MAC', 'DHCP', 'HOTSPOT'], true) && empty($service['macAddress'])) { throw new RouterError('Este servicio requiere una dirección MAC.', 'INVALID_SERVICE'); }
        if (!empty($service['macAddress']) && !preg_match('/^(?:[a-f\d]{2}:){5}[a-f\d]{2}$/iD', (string)$service['macAddress'])) { throw new RouterError('Dirección MAC inválida.', 'INVALID_SERVICE'); }
    }

    private function upsert(string $resource, string $comment, array $values, array $identities = []): string
    {
        $owned = $this->transport->print($resource, ['comment' => $comment]);
        if (count($owned) > 1) { throw new RouterError('Existen recursos administrados duplicados en ' . $resource . '.', 'RESOURCE_CONFLICT'); }
        foreach ($identities as $identity) {
            foreach ($this->transport->print($resource, $identity) as $conflict) {
                if (!isset($owned[0]) || ($conflict['.id'] ?? null) !== ($owned[0]['.id'] ?? null)) { throw new RouterError('Un recurso ajeno ya utiliza esa identidad en ' . $resource . '. No se modificó.', 'RESOURCE_CONFLICT'); }
            }
        }
        if (isset($owned[0])) {
            $id = self::id($owned[0]);
            $this->transport->set($resource, $id, [...$values, 'comment' => $comment]);
            return $id;
        }
        return $this->transport->add($resource, [...$values, 'comment' => $comment]);
    }

    private function ensureQosCompatible(): void
    {
        if ($this->qosCompatible === null) {
            $this->qosCompatible = true;
            try {
                foreach ($this->transport->print('/ip/firewall/filter', ['action' => 'fasttrack-connection']) as $rule) {
                    if (!RouterTransportUtil::truthy($rule['disabled'] ?? false)) { $this->qosCompatible = false; break; }
                }
            } catch (Throwable $error) {
                $this->qosCompatible = null;
                throw $error;
            }
        }
        if (!$this->qosCompatible) { throw new RouterError('Desactive FastTrack o use router/política de QoS compatible antes de provisionar', 'FASTTRACK_CONFLICT'); }
    }

    private function ensureCutProfile(): void
    {
        if ($this->transport->print('/ppp/profile', ['name' => $this->router['cutProfile']]) === []) {
            $this->transport->add('/ppp/profile', ['name' => $this->router['cutProfile'], 'address-list' => $this->router['cutAddressList'], 'rate-limit' => '64k/64k', 'comment' => 'nexoisp:router:' . $this->router['id'] . ':cut-profile']);
        }
    }

    private function ensureCut(array $service): void
    {
        $this->configureFirewall();
        $this->upsert('/ip/firewall/address-list', $this->comment($service, ':cut'), ['list' => $this->router['cutAddressList'], 'address' => $service['ipAddress'], 'disabled' => 'no']);
    }

    private function queue(array $service): void
    {
        $priority = (int)$service['plan']['priority'];
        $this->upsert('/queue/simple', $this->comment($service, ':queue'), [
            'name' => 'nx-' . $service['id'], 'target' => $service['ipAddress'] . '/32',
            'max-limit' => (int)$service['plan']['uploadKbps'] . 'k/' . (int)$service['plan']['downloadKbps'] . 'k',
            'priority' => $priority . '/' . $priority, 'disabled' => 'no',
        ], [['name' => 'nx-' . $service['id']]]);
    }

    public function crearServicio(array $service): array
    {
        RouterTransportUtil::requireWrite();
        $this->validate($service);
        if ($service['desiredState'] === 'RETIRED') { return $this->retirarServicio($service); }
        $suspended = $service['desiredState'] === 'SUSPENDED';
        if (!$suspended) { $this->ensureQosCompatible(); }
        if ($suspended) {
            $this->ensureCut($service);
            $this->evictSubscriberConnections($service);
        }
        switch ($service['type']) {
            case 'PPPOE':
                $profile = $suspended ? $this->router['cutProfile'] : $service['plan']['pppoeProfile'];
                if ($suspended) { $this->ensureCutProfile(); }
                if ($this->transport->print('/ppp/profile', ['name' => $profile]) === []) { throw new RouterError('El perfil PPPoE del plan no existe en el router.', 'MISSING_PROFILE'); }
                $this->upsert('/ppp/secret', $this->comment($service, ':pppoe'), [
                    'name' => $service['username'], 'password' => decryptSecret($service['passwordEncrypted']), 'service' => 'pppoe',
                    'profile' => $profile, 'remote-address' => $service['ipAddress'], 'disabled' => 'no',
                ], [['name' => $service['username']]]);
                // Preserve the ISP's shared PPP routing/DNS profile and enforce this
                // subscriber's selected bandwidth with a managed static Simple Queue.
                $this->queue($service);
                break;
            case 'SIMPLE_QUEUE':
                $this->queue($service);
                break;
            case 'QUEUE_TREE':
                $parent = (string)$service['plan']['queueParent'];
                if ($parent !== 'global' && $this->transport->print('/queue/tree', ['name' => $parent]) === [] && $this->transport->print('/interface', ['name' => $parent]) === []) { throw new RouterError('El parent Queue Tree no existe en el router.', 'MISSING_QUEUE_PARENT'); }
                foreach (['up', 'down'] as $direction) {
                    $mark = 'nx-' . $service['id'] . '-' . $direction;
                    $mangle = $this->upsert('/ip/firewall/mangle', $this->comment($service, ':mangle-' . $direction), [
                        'chain' => 'forward', $direction === 'up' ? 'src-address' : 'dst-address' => $service['ipAddress'] . '/32',
                        'action' => 'mark-packet', 'new-packet-mark' => $mark, 'passthrough' => 'no', 'disabled' => 'no',
                    ]);
                    $this->transport->execute('/ip/firewall/mangle/move', ['numbers' => $mangle, 'destination' => '0']);
                    $this->upsert('/queue/tree', $this->comment($service, ':tree-' . $direction), [
                        'name' => $mark, 'parent' => $parent, 'packet-mark' => $mark, 'priority' => (string)$service['plan']['priority'],
                        'max-limit' => (int)$service['plan'][$direction === 'up' ? 'uploadKbps' : 'downloadKbps'] . 'k', 'disabled' => 'no',
                    ], [['name' => $mark]]);
                }
                break;
            case 'IP_MAC':
            case 'DHCP':
                $this->upsert('/ip/dhcp-server/lease', $this->comment($service, ':lease'), [
                    'address' => $service['ipAddress'], 'mac-address' => $service['macAddress'], 'server' => $this->router['dhcpServer'], 'disabled' => 'no',
                ], [['address' => $service['ipAddress']], ['mac-address' => $service['macAddress']]]);
                $this->queue($service);
                break;
            case 'HOTSPOT':
                $this->upsert('/ip/hotspot/user', $this->comment($service, ':hotspot-user'), [
                    'name' => $service['username'], 'password' => decryptSecret($service['passwordEncrypted']), 'server' => $this->router['hotspotServer'],
                    'mac-address' => $service['macAddress'], 'disabled' => $suspended ? 'yes' : 'no',
                ], [['name' => $service['username']]]);
                $this->upsert('/ip/hotspot/ip-binding', $this->comment($service, ':binding'), [
                    'address' => $service['ipAddress'], 'mac-address' => $service['macAddress'], 'server' => $this->router['hotspotServer'],
                    'type' => $suspended ? 'blocked' : 'bypassed', 'disabled' => 'no',
                ], [['address' => $service['ipAddress']], ['mac-address' => $service['macAddress']]]);
                $this->queue($service);
                break;
        }
        return ['simulated' => $this->transport->isSimulated(), 'serviceId' => $service['id'], 'state' => $service['desiredState']];
    }

    public function suspenderServicio(array $service): array
    {
        RouterTransportUtil::requireWrite();
        $this->crearServicio([...$service, 'desiredState' => 'SUSPENDED']);
        if ($service['type'] === 'PPPOE') { $this->disconnectPppoe($service); }
        if ($service['type'] === 'HOTSPOT') {
            foreach ($this->transport->print('/ip/hotspot/active', ['user' => $service['username']]) as $row) { $this->transport->remove('/ip/hotspot/active', self::id($row)); }
        }
        return ['simulated' => $this->transport->isSimulated(), 'serviceId' => $service['id'], 'state' => 'SUSPENDED'];
    }

    public function reactivarServicio(array $service): array
    {
        RouterTransportUtil::requireWrite();
        $previousCut = $this->transport->print('/ip/firewall/address-list', ['list' => $this->router['cutAddressList'], 'address' => $service['ipAddress']]);
        $previousSecret = $service['type'] === 'PPPOE' ? ($this->transport->print('/ppp/secret', ['comment' => $this->comment($service, ':pppoe')])[0] ?? null) : null;
        $this->crearServicio([...$service, 'desiredState' => 'ACTIVE']);
        $list = $this->transport->print('/ip/firewall/address-list', ['list' => $this->router['cutAddressList'], 'address' => $service['ipAddress']]);
        foreach ($list as $row) {
            if (($row['comment'] ?? '') !== $this->comment($service, ':cut') && !RouterTransportUtil::truthy($row['dynamic'] ?? false)) { throw new RouterError('Existe un corte externo para esta IP; debe resolverlo el administrador del router.', 'EXTERNAL_SUSPENSION'); }
        }
        foreach ($list as $row) { if (($row['comment'] ?? '') === $this->comment($service, ':cut')) { $this->transport->remove('/ip/firewall/address-list', self::id($row)); } }
        if ($service['type'] === 'PPPOE' && ($previousCut !== [] || ($previousSecret['profile'] ?? null) === $this->router['cutProfile'])) { $this->disconnectPppoe($service); }
        if ($this->transport->print('/ip/firewall/address-list', ['list' => $this->router['cutAddressList'], 'address' => $service['ipAddress']]) !== []) { throw new RouterError('Un corte externo sigue activo después de la reconexión.', 'EXTERNAL_SUSPENSION'); }
        return ['simulated' => $this->transport->isSimulated(), 'serviceId' => $service['id'], 'state' => 'ACTIVE'];
    }

    private function disconnectPppoe(array $service): void
    {
        foreach ($this->transport->print('/ppp/active', ['name' => $service['username']]) as $row) { $this->transport->remove('/ppp/active', self::id($row)); }
    }

    private function evictSubscriberConnections(array $service): void
    {
        foreach ($this->transport->print('/ip/firewall/connection') as $row) {
            foreach (['src-address', 'dst-address', 'reply-src-address', 'reply-dst-address'] as $key) {
                $address = (string)($row[$key] ?? '');
                if ($address === $service['ipAddress'] || str_starts_with($address, $service['ipAddress'] . ':')) {
                    $this->transport->remove('/ip/firewall/connection', self::id($row));
                    break;
                }
            }
        }
    }

    /** Only the worker may supply IDs verified RETIRED/applied RETIRED on this router/IP. */
    public function transferirReservasRetiradas(array $service, array $retiredServiceIds): array
    {
        RouterTransportUtil::requireWrite();
        $this->validate($service);
        if ($service['desiredState'] === 'RETIRED') { throw new RouterError('No se transfieren reservas a un servicio retirado.', 'INVALID_SERVICE'); }
        $ids = array_values(array_unique($retiredServiceIds));
        foreach ($ids as $id) { if (!is_string($id) || !preg_match('/^[\w-]+$/D', $id) || $id === $service['id']) { throw new RouterError('Identificador retirado inválido para transferencia.', 'INVALID_SERVICE'); } }
        if ($ids === []) { return ['simulated' => $this->transport->isSimulated(), 'transferred' => 0]; }
        $hasReservation = false;
        foreach ($ids as $id) {
            foreach ([['/ip/firewall/address-list', ':cut'], ['/ip/dhcp-server/lease', ':lease'], ['/ip/hotspot/ip-binding', ':binding']] as [$resource, $suffix]) {
                foreach ($this->transport->print($resource, ['comment' => 'nexoisp:' . $id . $suffix]) as $row) {
                    if (($row['address'] ?? null) === $service['ipAddress']) { $hasReservation = true; }
                }
            }
        }
        if (!$hasReservation) { return ['simulated' => $this->transport->isSimulated(), 'transferred' => 0]; }
        if ($service['desiredState'] === 'ACTIVE') { $this->ensureQosCompatible(); }
        $this->configureFirewall();
        $transferred = 0;
        $ownCuts = $this->transport->print('/ip/firewall/address-list', ['comment' => $this->comment($service, ':cut')]);
        if (count($ownCuts) > 1) { throw new RouterError('El nuevo servicio tiene cortes administrados duplicados.', 'RESOURCE_CONFLICT'); }
        if (isset($ownCuts[0])) { $this->transport->set('/ip/firewall/address-list', self::id($ownCuts[0]), ['list' => $this->router['cutAddressList'], 'address' => $service['ipAddress'], 'disabled' => 'no']); }
        foreach ($ids as $oldId) {
            foreach ($this->transport->print('/ip/firewall/address-list', ['comment' => 'nexoisp:' . $oldId . ':cut']) as $row) {
                if (($row['address'] ?? null) !== $service['ipAddress']) { continue; }
                if (isset($ownCuts[0])) { $this->transport->remove('/ip/firewall/address-list', self::id($row)); }
                else {
                    $this->transport->set('/ip/firewall/address-list', self::id($row), ['comment' => $this->comment($service, ':cut'), 'list' => $this->router['cutAddressList'], 'address' => $service['ipAddress'], 'disabled' => 'no']);
                    $ownCuts = [$row];
                }
                $transferred++;
            }
        }
        if ($ownCuts === []) { $this->ensureCut($service); }
        foreach ($ids as $oldId) {
            foreach ([['/ip/dhcp-server/lease', ':lease', in_array($service['type'], ['DHCP', 'IP_MAC'], true)], ['/ip/hotspot/ip-binding', ':binding', $service['type'] === 'HOTSPOT']] as [$resource, $suffix, $retain]) {
                foreach ($this->transport->print($resource, ['comment' => 'nexoisp:' . $oldId . $suffix]) as $row) {
                    if (($row['address'] ?? null) !== $service['ipAddress']) { continue; }
                    $existing = $this->transport->print($resource, ['comment' => $this->comment($service, $suffix)]);
                    if (count($existing) > 1) { throw new RouterError('Existen reservas administradas duplicadas.', 'RESOURCE_CONFLICT'); }
                    if ($retain && $existing === []) {
                        $this->transport->set($resource, self::id($row), ['comment' => $this->comment($service, $suffix), 'disabled' => 'no', ...($suffix === ':binding' ? ['type' => 'blocked'] : [])]);
                    } else { $this->transport->remove($resource, self::id($row)); }
                    $transferred++;
                }
            }
        }
        return ['simulated' => $this->transport->isSimulated(), 'transferred' => $transferred];
    }

    public function retirarServicio(array $service): array
    {
        RouterTransportUtil::requireWrite();
        $this->validate($service);
        $this->ensureCut($service);
        // FastTracked flows must expire before deleting the subscriber's bandwidth limit.
        $this->evictSubscriberConnections($service);
        if ($service['type'] === 'PPPOE' && $this->transport->print('/ppp/secret', ['comment' => $this->comment($service, ':pppoe')]) !== []) { $this->disconnectPppoe($service); }
        if ($service['type'] === 'HOTSPOT') {
            foreach ($this->transport->print('/ip/hotspot/ip-binding', ['comment' => $this->comment($service, ':binding')]) as $row) { $this->transport->set('/ip/hotspot/ip-binding', self::id($row), ['type' => 'blocked', 'disabled' => 'no']); }
            if ($this->transport->print('/ip/hotspot/user', ['comment' => $this->comment($service, ':hotspot-user')]) !== []) {
                foreach ($this->transport->print('/ip/hotspot/active', ['user' => $service['username']]) as $row) { $this->transport->remove('/ip/hotspot/active', self::id($row)); }
            }
        }
        foreach (self::REMOVABLE as $resource) {
            foreach ($this->transport->print($resource) as $row) {
                $comment = (string)($row['comment'] ?? '');
                if ($comment === $this->comment($service) || str_starts_with($comment, $this->comment($service) . ':')) { $this->transport->remove($resource, self::id($row)); }
            }
        }
        // Keep the cut and DHCP reservation/blocked Hotspot binding until an explicit
        // database-authorized handover to a new subscriber reuses this IP address.
        return ['simulated' => $this->transport->isSimulated(), 'serviceId' => $service['id'], 'state' => 'RETIRED'];
    }

    public function configureFirewall(): array
    {
        RouterTransportUtil::requireWrite();
        if (!preg_match('/^[\w.-]{1,63}$/D', (string)$this->router['cutAddressList'])) { throw new RouterError('Nombre de Address List inválido.', 'INVALID_ROUTER'); }
        $portal = $this->router['paymentPortalIp'];
        if ($portal && (!filter_var($portal, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) || (int)$this->router['paymentPortalPort'] < 1 || (int)$this->router['paymentPortalPort'] > 65535)) { throw new RouterError('Portal de pago IPv4/puerto inválido.', 'INVALID_ROUTER'); }
        $base = 'nexoisp:router:' . $this->router['id'];
        $drop = $this->upsert('/ip/firewall/filter', $base . ':cut-drop', ['chain' => 'forward', 'src-address-list' => $this->router['cutAddressList'], 'action' => 'drop', 'disabled' => 'no']);
        $this->transport->execute('/ip/firewall/filter/move', ['numbers' => $drop, 'destination' => '0']);
        if ($portal) {
            $allow = $this->upsert('/ip/firewall/filter', $base . ':portal-allow', [
                'chain' => 'forward', 'src-address-list' => $this->router['cutAddressList'], 'dst-address' => $portal,
                'protocol' => 'tcp', 'dst-port' => (string)$this->router['paymentPortalPort'], 'action' => 'accept', 'disabled' => 'no',
            ]);
            $this->transport->execute('/ip/firewall/filter/move', ['numbers' => $allow, 'destination' => '0']);
            $nat = $this->upsert('/ip/firewall/nat', $base . ':portal-redirect', [
                'chain' => 'dstnat', 'src-address-list' => $this->router['cutAddressList'], 'protocol' => 'tcp', 'dst-port' => '80',
                'action' => 'dst-nat', 'to-addresses' => $portal, 'to-ports' => (string)$this->router['paymentPortalPort'], 'disabled' => 'no',
            ]);
            $this->transport->execute('/ip/firewall/nat/move', ['numbers' => $nat, 'destination' => '0']);
        } else {
            foreach ([['/ip/firewall/filter', $base . ':portal-allow'], ['/ip/firewall/nat', $base . ':portal-redirect']] as [$resource, $comment]) {
                foreach ($this->transport->print($resource, ['comment' => $comment]) as $row) { $this->transport->remove($resource, self::id($row)); }
            }
        }
        return ['simulated' => $this->transport->isSimulated(), 'paymentPortal' => (bool)$portal, 'httpsRedirect' => false];
    }

    public function testConnection(): array
    {
        $identity = $this->transport->print('/system/identity')[0] ?? [];
        $resource = $this->transport->print('/system/resource')[0] ?? [];
        if (!is_string($resource['version'] ?? null) || $resource['version'] === '' || !is_string($identity['name'] ?? null) || $identity['name'] === '') { throw new RouterError('El router no devolvió identidad y versión.', 'INVALID_RESPONSE'); }
        return ['simulated' => $this->transport->isSimulated(), 'identity' => $identity['name'], 'version' => $resource['version'], 'board' => $resource['board-name'] ?? null];
    }

    private static function number(mixed $value): int|float|null
    {
        if (!is_scalar($value) || $value === '' || !is_numeric($value)) { return null; }
        $number = $value + 0;
        return is_finite((float)$number) ? $number : null;
    }

    private static function pair(?string $value): array
    {
        $parts = explode('/', $value ?? '');
        return [self::number($parts[0] ?? null), self::number($parts[1] ?? null)];
    }

    private static function durationMs(?string $value): ?float
    {
        if ($value === null || $value === '') { return null; }
        if (is_numeric($value)) { return (float)$value; }
        if (preg_match('/^(\d+):(\d{2}):(\d{2}(?:\.\d+)?)$/D', $value, $clock)) { return ((float)$clock[1] * 3600 + (float)$clock[2] * 60 + (float)$clock[3]) * 1000; }
        preg_match_all('/(\d+(?:\.\d+)?)(us|ms|s)/', $value, $matches, PREG_SET_ORDER);
        if ($matches === [] || implode('', array_column($matches, 0)) !== $value) { return null; }
        $total = 0.0;
        foreach ($matches as $match) { $total += (float)$match[1] * ($match[2] === 'us' ? 0.001 : ($match[2] === 's' ? 1000 : 1)); }
        return $total;
    }

    public function obtenerTraficoYDiagnostico(array $service): array
    {
        $this->validate($service);
        $result = ['simulated' => $this->transport->isSimulated(), 'sampledAt' => gmdate('Y-m-d\TH:i:s\Z'), 'serviceId' => $service['id'], 'traffic' => null, 'ping' => ['sent' => 0, 'received' => 0, 'lossPercent' => null, 'averageMs' => null, 'available' => false]];
        if ($this->transport->isSimulated()) { $result['ping']['error'] = 'Simulación: no se enviaron paquetes ni se midió tráfico.'; return $result; }
        if ($service['type'] === 'QUEUE_TREE') {
            $up = $this->transport->print('/queue/tree', ['comment' => $this->comment($service, ':tree-up')], ['stats' => ''])[0] ?? null;
            $down = $this->transport->print('/queue/tree', ['comment' => $this->comment($service, ':tree-down')], ['stats' => ''])[0] ?? null;
            if ($up !== null || $down !== null) { $result['traffic'] = ['uploadBps' => self::number($up['rate'] ?? null), 'downloadBps' => self::number($down['rate'] ?? null), 'uploadBytes' => self::number($up['bytes'] ?? null), 'downloadBytes' => self::number($down['bytes'] ?? null), 'source' => 'queue-tree']; }
        } else {
            $queue = $this->transport->print('/queue/simple', ['comment' => $this->comment($service, ':queue')], ['stats' => ''])[0] ?? null;
            if ($queue !== null) {
                [$upload, $download] = self::pair($queue['rate'] ?? null);
                [$upBytes, $downBytes] = self::pair($queue['bytes'] ?? null);
                $result['traffic'] = ['uploadBps' => $upload, 'downloadBps' => $download, 'uploadBytes' => $upBytes, 'downloadBytes' => $downBytes, 'source' => 'simple-queue'];
            }
        }
        try {
            $packets = $this->transport->execute('/ping', ['address' => $service['ipAddress'], 'count' => '3', 'interval' => '200ms']);
            $summary = [];
            foreach (array_reverse($packets) as $packet) { if (isset($packet['sent'])) { $summary = $packet; break; } }
            $sent = self::number($summary['sent'] ?? null) ?? count($packets);
            $received = self::number($summary['received'] ?? null) ?? count(array_filter($packets, static fn($row) => isset($row['time']) && empty($row['status'])));
            $durations = array_values(array_filter(array_map(static fn($row) => self::durationMs($row['time'] ?? null), $packets), static fn($duration) => $duration !== null));
            $result['ping'] = ['sent' => $sent, 'received' => $received, 'lossPercent' => $sent > 0 ? max(0, ($sent - $received) / $sent * 100) : null, 'averageMs' => self::durationMs($summary['avg-rtt'] ?? null) ?? ($durations !== [] ? array_sum($durations) / count($durations) : null), 'available' => $sent > 0];
        } catch (Throwable $error) {
            $result['ping']['error'] = $error instanceof RouterError ? $error->getMessage() : 'No se completó el ping desde el router.';
        }
        return $result;
    }

    public function close(): void { $this->transport->close(); }
}
