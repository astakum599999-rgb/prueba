<?php
declare(strict_types=1);

namespace Nexo;

use DateTimeImmutable;
use DateTimeZone;
use Throwable;

const BILLING_MAX_CENTS = 2147483647;

function billingCalculationInteger(mixed $value, int $minimum, int $maximum, string $field): int
{
    // PDO may return integer columns as strings depending on the Windows driver.
    if (is_string($value) && preg_match('/^[0-9]{1,10}$/D', $value)) {
        $value = (int) $value;
    }
    if (!is_int($value) || $value < $minimum || $value > $maximum) {
        throw new HttpError(400, 'Valor entero fuera de rango: ' . $field . '.');
    }
    return $value;
}

function billingCalculationActive(array $record): bool
{
    $active = $record['active'] ?? true;
    return $active === true || $active === 1 || $active === '1';
}

function billingCalculationDate(mixed $value, string $field): DateTimeImmutable
{
    if (!is_string($value) || !preg_match('/^(?:[1-9][0-9]{3})-(?:0[1-9]|1[0-2])-(?:0[1-9]|[12][0-9]|3[01])$/D', $value)) {
        throw new HttpError(400, 'Fecha inválida para ' . $field . '; use YYYY-MM-DD.');
    }
    $date = DateTimeImmutable::createFromFormat('!Y-m-d', $value, new DateTimeZone('UTC'));
    $errors = DateTimeImmutable::getLastErrors();
    if ($date === false || ($errors !== false && ($errors['warning_count'] > 0 || $errors['error_count'] > 0)) || $date->format('Y-m-d') !== $value) {
        throw new HttpError(400, 'Fecha inexistente para ' . $field . '.');
    }
    return $date;
}

function billingCalculationName(mixed $value, string $field): string
{
    if (!is_string($value) || trim($value) === '' || strlen($value) > 500) {
        throw new HttpError(400, 'Descripción inválida: ' . $field . '.');
    }
    return trim($value);
}

/** Positive integer half-up division; all callers bound products to int64. */
function billingHalfUp(int $numerator, int $denominator): int
{
    if ($numerator < 0 || $denominator < 1) {
        throw new HttpError(400, 'Operación monetaria inválida.');
    }
    return intdiv($numerator, $denominator) + (2 * ($numerator % $denominator) >= $denominator ? 1 : 0);
}

function billingProrationMetadata(array $input, int $fullPrice): array
{
    $period = $input['period'] ?? null;
    if (!is_string($period) || !preg_match('/^[1-9][0-9]{3}-(0[1-9]|1[0-2])$/D', $period)) {
        throw new HttpError(400, 'Periodo inválido; use YYYY-MM.');
    }
    $start = billingCalculationDate($input['startOn'] ?? null, 'startOn');
    $end = billingCalculationDate($input['endOn'] ?? null, 'endOn');
    if ($start->format('Y-m') !== $period || $end->format('Y-m') !== $period || $end < $start) {
        throw new HttpError(400, 'El prorrateo debe usar días ordenados dentro del mismo mes del periodo.');
    }
    $createdValue = $input['createdAt'] ?? null;
    if (!is_string($createdValue) || strlen($createdValue) < 10) {
        throw new HttpError(400, 'Falta la fecha de alta del servicio para el prorrateo.');
    }
    billingCalculationDate(substr($createdValue, 0, 10), 'createdAt');
    try {
        $created = (new DateTimeImmutable($createdValue, new DateTimeZone('UTC')))->setTimezone(new DateTimeZone('UTC'));
    } catch (Throwable) {
        throw new HttpError(400, 'Fecha de alta del servicio inválida.');
    }
    $activationDay = billingCalculationDate($created->format('Y-m-d'), 'createdAt');
    if ($start < $activationDay) {
        throw new HttpError(409, 'El prorrateo no puede comenzar antes del alta del servicio.');
    }
    $daysInMonth = (int) $start->format('t');
    $chargedDays = (int) $start->diff($end)->days + 1;
    $prorated = billingHalfUp($fullPrice * $chargedDays, $daysInMonth);
    return [
        'period' => $period,
        'startOn' => $start->format('Y-m-d'),
        'endOn' => $end->format('Y-m-d'),
        'daysInMonth' => $daysInMonth,
        'chargedDays' => $chargedDays,
        'factor' => $chargedDays . '/' . $daysInMonth,
        'planFullPriceCents' => $fullPrice,
        'planProratedCents' => $prorated,
        'limitation' => 'Prorrateo del plan; cargos adicionales completos. No calcula todas las variantes de WispHub.',
    ];
}

/**
 * Pure invoice calculation. The caller owns persistence, one-time consumption,
 * first-invoice checks and the transaction that stores these immutable lines.
 */
function calculateBillingLines(array $plan, array $charges, array $discounts, DateTimeImmutable $issuedAt, ?array $proration = null): array
{
    if (PHP_INT_SIZE < 8) {
        throw new HttpError(500, 'Los cálculos monetarios requieren PHP de 64 bits.');
    }
    $price = billingCalculationInteger($plan['priceCents'] ?? null, 0, BILLING_MAX_CENTS, 'priceCents');
    $name = billingCalculationName($plan['name'] ?? null, 'plan');
    $currency = $plan['currency'] ?? null;
    if (!is_string($currency) || !preg_match('/^[A-Z]{3}$/D', $currency)) {
        throw new HttpError(400, 'La moneda del plan debe contener tres letras mayúsculas.');
    }
    $metadata = $proration === null ? null : billingProrationMetadata($proration, $price);
    $base = $metadata === null ? $price : $metadata['planProratedCents'];
    $planDescription = 'Internet: ' . $name;
    if ($metadata !== null) {
        $planDescription .= ' (prorrateo ' . $metadata['startOn'] . ' a ' . $metadata['endOn'] . '; ' . $metadata['factor'] . ' días)';
    }
    $lines = [[
        'type' => 'PLAN', 'chargeId' => null, 'discountId' => null,
        'description' => $planDescription, 'quantity' => 1, 'unitCents' => $base, 'totalCents' => $base,
    ]];
    $extras = 0;
    foreach ($charges as $charge) {
        if (!is_array($charge)) {
            throw new HttpError(400, 'Cargo adicional inválido.');
        }
        if (!billingCalculationActive($charge)) {
            continue;
        }
        $recurrence = $charge['recurrence'] ?? null;
        if (!in_array($recurrence, ['MONTHLY', 'ONE_TIME'], true)) {
            throw new HttpError(400, 'Recurrencia de cargo inválida.');
        }
        if ($recurrence === 'ONE_TIME' && ($charge['consumedAt'] ?? null) !== null) {
            continue;
        }
        $quantity = billingCalculationInteger($charge['quantity'] ?? null, 1, 1000, 'quantity');
        $unitCents = billingCalculationInteger($charge['unitCents'] ?? null, 0, BILLING_MAX_CENTS, 'unitCents');
        $total = $quantity * $unitCents;
        if ($total > BILLING_MAX_CENTS || $extras > BILLING_MAX_CENTS - $total) {
            throw new HttpError(400, 'Los cargos adicionales superan el importe máximo de una factura.');
        }
        $extras += $total;
        $chargeId = $charge['id'] ?? null;
        if ($chargeId !== null && !is_string($chargeId)) {
            throw new HttpError(400, 'Identificador de cargo inválido.');
        }
        $lines[] = [
            'type' => 'CHARGE', 'chargeId' => $chargeId, 'discountId' => null,
            'description' => billingCalculationName($charge['name'] ?? null, 'cargo') . ($recurrence === 'ONE_TIME' ? ' (único)' : ' (mensual)'),
            'quantity' => $quantity, 'unitCents' => $unitCents, 'totalCents' => $total,
        ];
    }
    $issueDay = $issuedAt->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d');
    $effective = [];
    foreach ($discounts as $discount) {
        if (!is_array($discount)) {
            throw new HttpError(400, 'Descuento inválido.');
        }
        if (!billingCalculationActive($discount)) {
            continue;
        }
        $start = billingCalculationDate($discount['startOn'] ?? null, 'startOn');
        $end = billingCalculationDate($discount['endOn'] ?? null, 'endOn');
        if ($end < $start) {
            throw new HttpError(400, 'El fin del descuento debe ser igual o posterior al inicio.');
        }
        if ($start->format('Y-m-d') <= $issueDay && $end->format('Y-m-d') >= $issueDay) {
            $effective[] = $discount;
        }
    }
    if (count($effective) > 1) {
        throw new HttpError(409, 'Sólo se admite un descuento activo efectivo por servicio.');
    }
    $discountAmount = 0;
    if ($effective !== []) {
        $discount = $effective[0];
        $kind = $discount['kind'] ?? null;
        if ($kind === 'FIXED') {
            $value = billingCalculationInteger($discount['value'] ?? null, 1, BILLING_MAX_CENTS, 'value');
            $discountAmount = min($base, $value);
        } elseif ($kind === 'PERCENT') {
            $value = billingCalculationInteger($discount['value'] ?? null, 1, 10000, 'value');
            $discountAmount = min($base, billingHalfUp($base * $value, 10000));
        } else {
            throw new HttpError(400, 'Tipo de descuento inválido.');
        }
        $discountId = $discount['id'] ?? null;
        if ($discountId !== null && !is_string($discountId)) {
            throw new HttpError(400, 'Identificador de descuento inválido.');
        }
        $lines[] = [
            'type' => 'DISCOUNT', 'chargeId' => null, 'discountId' => $discountId,
            'description' => 'Descuento del plan: ' . billingCalculationName($discount['name'] ?? null, 'descuento'),
            'quantity' => 1, 'unitCents' => -$discountAmount, 'totalCents' => -$discountAmount,
        ];
    }
    $netPlan = $base - $discountAmount;
    if ($extras > BILLING_MAX_CENTS - $netPlan) {
        throw new HttpError(400, 'El importe total supera el máximo permitido para una factura.');
    }
    $result = ['lines' => $lines, 'amountCents' => $netPlan + $extras, 'currency' => $currency];
    if ($metadata !== null) {
        $result['proration'] = $metadata;
    }
    return $result;
}
