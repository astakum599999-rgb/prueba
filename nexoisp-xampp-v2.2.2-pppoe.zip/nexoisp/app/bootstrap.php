<?php
declare(strict_types=1);

namespace Nexo;

use DateTimeImmutable;
use DateTimeZone;
use JsonException;
use PDO;
use PDOException;
use RuntimeException;
use Throwable;

const APP_ROOT = __DIR__ . '/..';

final class HttpError extends RuntimeException
{
    public function __construct(public int $status, string $message, public string $errorCode = 'REQUEST_ERROR')
    {
        parent::__construct($message);
    }
}

function config(?string $key = null, mixed $default = null): mixed
{
    static $settings = null;
    if ($settings === null) {
        $file = APP_ROOT . '/storage/config.php';
        if (!is_file($file)) {
            throw new HttpError(503, 'Completa primero la instalación de NexoISP.', 'NOT_INSTALLED');
        }
        $loaded = require $file;
        if (!is_array($loaded)) {
            throw new HttpError(503, 'La configuración de NexoISP no es válida.', 'INVALID_CONFIG');
        }
        $settings = $loaded;
    }
    return $key === null ? $settings : ($settings[$key] ?? $default);
}

function db(): PDO
{
    static $connection = null;
    if ($connection instanceof PDO) {
        return $connection;
    }
    if (!extension_loaded('pdo_mysql')) {
        throw new HttpError(503, 'La extensión pdo_mysql de PHP no está habilitada.', 'DATABASE_UNAVAILABLE');
    }
    $host = (string) config('db_host', '127.0.0.1');
    $name = (string) config('db_name', 'nexoisp');
    $port = (int) config('db_port', 3306);
    if (!preg_match('/^[A-Za-z0-9.\-:]+$/D', $host) || !preg_match('/^[A-Za-z0-9_]{1,64}$/D', $name) || $port < 1 || $port > 65535) {
        throw new HttpError(503, 'La configuración de la base de datos no es válida.', 'INVALID_CONFIG');
    }
    try {
        $connection = new PDO(
            "mysql:host={$host};port={$port};dbname={$name};charset=utf8mb4",
            (string) config('db_user'),
            (string) config('db_password', ''),
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
                PDO::ATTR_STRINGIFY_FETCHES => false,
                PDO::ATTR_TIMEOUT => 10,
                PDO::MYSQL_ATTR_MULTI_STATEMENTS => false,
            ]
        );
        $connection->exec("SET time_zone = '+00:00'");
        $connection->exec("SET SESSION sql_mode = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION'");
        return $connection;
    } catch (PDOException) {
        $connection = null;
        throw new HttpError(503, 'No se pudo conectar con la base de datos. Revisa MySQL y la configuración local.', 'DATABASE_UNAVAILABLE');
    }
}

/** New-record preference only; existing monetary records retain their own currency. */
function localCurrency(): string
{
    try {
        // This also runs before installation/003 during login and schema upgrades.
        // Do not cache it: an administrator may change the preference in this process.
        $currency = fetchOne("SELECT currency FROM CompanyProfile WHERE id='primary'")['currency'] ?? null;
        if (is_string($currency) && preg_match('/^[A-Z]{3}$/D', $currency) === 1) return $currency;
    } catch (Throwable) {
        // A missing configuration, connection or pre-extension schema is expected here.
    }
    return 'PEN';
}

/** A legacy configuration without this key is intentionally read-only. */
function networkReadOnly(): bool
{
    return config('network_read_only', true) !== false;
}

function requireNetworkWrite(): void
{
    if (networkReadOnly()) {
        throw new HttpError(409, 'La red está en modo solo lectura. No se aplica ninguna configuración al MikroTik.', 'NETWORK_READ_ONLY');
    }
}

function id(): string
{
    return bin2hex(random_bytes(12));
}

function now(): string
{
    return (new DateTimeImmutable('now', new DateTimeZone('UTC')))->format('Y-m-d H:i:s.v');
}

function hashToken(string $token): string
{
    return hash('sha256', $token);
}

function base64urlEncode(string $value): string
{
    return rtrim(strtr(base64_encode($value), '+/', '-_'), '=');
}

function base64urlDecode(string $value): string|false
{
    if (!preg_match('/^[A-Za-z0-9_-]*$/D', $value)) {
        return false;
    }
    return base64_decode(strtr($value, '-_', '+/'), true);
}

function encryptionKey(): string
{
    $key = base64_decode((string) config('encryption_key', ''), true);
    if ($key === false || strlen($key) !== 32) {
        throw new HttpError(500, 'La clave de cifrado de la instalación no es válida.', 'ENCRYPTION_ERROR');
    }
    return $key;
}

function encryptSecret(string $value): string
{
    $iv = random_bytes(12);
    $tag = '';
    $ciphertext = openssl_encrypt($value, 'aes-256-gcm', encryptionKey(), OPENSSL_RAW_DATA, $iv, $tag, 'nexoisp:v1', 16);
    if ($ciphertext === false) {
        throw new HttpError(500, 'No se pudo cifrar la credencial.', 'ENCRYPTION_ERROR');
    }
    return 'v1.' . base64urlEncode($iv) . '.' . base64urlEncode($tag) . '.' . base64urlEncode($ciphertext);
}

function decryptSecret(string $value): string
{
    $parts = explode('.', $value);
    if (count($parts) !== 4 || $parts[0] !== 'v1') {
        throw new HttpError(500, 'No se pudo descifrar una credencial.', 'ENCRYPTION_ERROR');
    }
    $iv = base64urlDecode($parts[1]);
    $tag = base64urlDecode($parts[2]);
    $ciphertext = base64urlDecode($parts[3]);
    if ($iv === false || strlen($iv) !== 12 || $tag === false || strlen($tag) !== 16 || $ciphertext === false) {
        throw new HttpError(500, 'No se pudo descifrar una credencial.', 'ENCRYPTION_ERROR');
    }
    $plain = openssl_decrypt($ciphertext, 'aes-256-gcm', encryptionKey(), OPENSSL_RAW_DATA, $iv, $tag, 'nexoisp:v1');
    if ($plain === false) {
        throw new HttpError(500, 'No se pudo descifrar una credencial. Revisa la clave de la instalación.', 'ENCRYPTION_ERROR');
    }
    return $plain;
}

function hashPassword(string $password): string
{
    if (strlen($password) < 12 || strlen($password) > 128) {
        throw new HttpError(422, 'La contraseña debe tener entre 12 y 128 bytes.', 'VALIDATION_ERROR');
    }
    $argon = defined('PASSWORD_ARGON2ID') && in_array('argon2id', password_algos(), true);
    if (!$argon && strlen($password) > 72) {
        throw new HttpError(422, 'Esta instalación admite contraseñas de hasta 72 bytes.', 'VALIDATION_ERROR');
    }
    $hash = password_hash($password, $argon ? PASSWORD_ARGON2ID : PASSWORD_BCRYPT, $argon ? ['memory_cost' => 65536, 'time_cost' => 3, 'threads' => 1] : ['cost' => 12]);
    if (!is_string($hash)) {
        throw new HttpError(500, 'No se pudo proteger la contraseña.', 'PASSWORD_ERROR');
    }
    return $hash;
}

function verifyPassword(string $password, string $hash): bool
{
    if (strlen($password) > 128 || (str_starts_with($hash, '$2') && strlen($password) > 72)) {
        return false;
    }
    return password_verify($password, $hash);
}

function fetchOne(string $sql, array $params = []): ?array
{
    $statement = db()->prepare($sql);
    $statement->execute($params);
    $row = $statement->fetch();
    return $row === false ? null : $row;
}

function fetchAll(string $sql, array $params = []): array
{
    $statement = db()->prepare($sql);
    $statement->execute($params);
    return $statement->fetchAll();
}

function tx(callable $callback): mixed
{
    $connection = db();
    if ($connection->inTransaction()) {
        return $callback($connection);
    }
    $connection->beginTransaction();
    try {
        $result = $callback($connection);
        $connection->commit();
        return $result;
    } catch (Throwable $error) {
        if ($connection->inTransaction()) {
            $connection->rollBack();
        }
        throw $error;
    }
}

function lockName(string $key): string
{
    return 'nexo:' . substr(hash('sha256', $key), 0, 59);
}

function lock(string $key, int $timeout = 10): bool
{
    $statement = db()->prepare('SELECT GET_LOCK(?, ?)');
    $statement->execute([lockName($key), max(0, min(60, $timeout))]);
    return (int) $statement->fetchColumn() === 1;
}

function unlock(string $key): void
{
    try {
        $statement = db()->prepare('SELECT RELEASE_LOCK(?)');
        $statement->execute([lockName($key)]);
    } catch (PDOException) {
        // A disconnected MariaDB session has already released its advisory locks.
    }
}

function audit(string $action, string $entityType, ?string $entityId = null, ?string $userId = null): void
{
    $statement = db()->prepare('INSERT INTO `AuditLog` (`id`,`userId`,`action`,`entityType`,`entityId`) VALUES (?,?,?,?,?)');
    $statement->execute([id(), $userId, $action, $entityType, $entityId]);
}

function enqueue(string $kind, array $payload, ?string $dedupeKey = null): array
{
    if (!in_array($kind, ['SERVICE_SYNC','DIAGNOSTIC','ROUTER_TEST','FIREWALL_SYNC','BILLING_RUN','AUTOCUT_RUN','BULK_SYNC'], true)) {
        throw new HttpError(422, 'Tipo de tarea no admitido.', 'VALIDATION_ERROR');
    }
    $taskId = id();
    $encoded = json_encode((object) $payload, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    try {
        $statement = db()->prepare('INSERT INTO `Task` (`id`,`kind`,`payload`,`dedupeKey`) VALUES (?,?,?,?)');
        $statement->execute([$taskId, $kind, $encoded, $dedupeKey]);
    } catch (PDOException $error) {
        if ($dedupeKey !== null && $error->getCode() === '23000') {
            $previous = fetchOne('SELECT * FROM `Task` WHERE `dedupeKey` = ?', [$dedupeKey]);
            if ($previous !== null && $previous['kind'] === $kind) {
                return $previous;
            }
        }
        throw $error;
    }
    return fetchOne('SELECT * FROM `Task` WHERE `id` = ?', [$taskId]) ?? throw new HttpError(500, 'No se pudo recuperar la tarea.', 'TASK_ERROR');
}

function body(): array
{
    if (isset($GLOBALS['nexo_raw_body']) && is_string($GLOBALS['nexo_raw_body'])) {
        $raw = $GLOBALS['nexo_raw_body'];
    } else {
        $stream = fopen('php://input', 'rb');
        if ($stream === false) {
            throw new HttpError(400, 'No se pudo leer la solicitud.', 'INVALID_JSON');
        }
        $raw = stream_get_contents($stream, 1048577);
        fclose($stream);
        if ($raw === false) {
            throw new HttpError(400, 'No se pudo leer la solicitud.', 'INVALID_JSON');
        }
        $GLOBALS['nexo_raw_body'] = $raw;
    }
    if (strlen($raw) > 1048576) {
        throw new HttpError(413, 'El cuerpo excede el límite de 1 MiB.', 'BODY_TOO_LARGE');
    }
    try {
        $object = json_decode($raw, false, 128, JSON_THROW_ON_ERROR);
        if (!$object instanceof \stdClass) {
            throw new HttpError(400, 'El cuerpo debe ser un objeto JSON.', 'INVALID_JSON');
        }
        return json_decode($raw, true, 128, JSON_THROW_ON_ERROR);
    } catch (JsonException) {
        throw new HttpError(400, 'El cuerpo no contiene JSON válido.', 'INVALID_JSON');
    }
}

function normalize(mixed $value): mixed
{
    $wasObject = $value instanceof \stdClass;
    if ($value instanceof \stdClass) {
        $value = (array) $value;
    }
    if (!is_array($value)) {
        return $value;
    }
    $result = [];
    $secretKeys = ['passwordEncrypted','passwordHash','tokenHash','db_password','encryption_key','worker_secret','payment_webhook_secret'];
    foreach ($value as $key => $item) {
        if (is_string($key) && in_array($key, $secretKeys, true)) {
            continue;
        }
        if ($item === null) {
            $result[$key] = null;
            continue;
        }
        if (is_string($key) && in_array($key, ['payload','result','details'], true) && is_string($item)) {
            try {
                $item = json_decode($item, false, 128, JSON_THROW_ON_ERROR);
            } catch (JsonException) {
                $item = null;
            }
        }
        if (is_string($key) && in_array($key, ['active','useTls','verifyTls','online','simulated','available','replayed','httpsRedirect','paymentPortal','simulatedRouters'], true)) {
            $item = $item === true || $item === 1 || $item === '1';
        } elseif (is_string($key) && is_string($item) && preg_match('/(?:At|Until)$/D', $key) && preg_match('/^\d{4}-\d{2}-\d{2}[ T]/D', $item)) {
            try {
                $item = (new DateTimeImmutable($item, new DateTimeZone('UTC')))->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d\TH:i:s.v\Z');
            } catch (Throwable) {
                $item = null;
            }
        } elseif (is_string($key) && (in_array($key, ['port','paymentPortalPort','priority','revision','billingDay','dueDays','graceDays','attempts','count','page','pageSize','sent','received'], true) || preg_match('/(?:Cents|Kbps|Bps|Bytes|Count)$/D', $key)) && is_numeric($item)) {
            $item = str_contains((string) $item, '.') ? (float) $item : (int) $item;
        } elseif (is_string($key) && in_array($key, ['latitude','longitude','lossPercent','averageMs'], true) && is_numeric($item)) {
            $item = (float) $item;
        }
        $result[$key] = is_array($item) || $item instanceof \stdClass ? normalize($item) : $item;
    }
    return $wasObject ? (object) $result : $result;
}

function json(mixed $value, int $status = 200): never
{
    if ($status === 204) {
        http_response_code(204);
        header('Cache-Control: no-store');
        exit;
    }
    $encoded = json_encode(normalize($value), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE | JSON_THROW_ON_ERROR);
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    header('X-Content-Type-Options: nosniff');
    echo $encoded;
    exit;
}
