import { useEffect, useId, useRef, useState } from 'react';
import { Eye, EyeOff, RefreshCw } from 'lucide-react';
import { api } from './api';
import { errorMessage, Loading } from './ui';

interface PppoeAccount {
  id: string;
  source: 'imported' | 'service';
  routerId: string;
  routerName: string;
  username: string;
  profile?: string | null;
  present: boolean;
  canRevealPassword: boolean;
  passwordSource: 'MikroTik' | 'NexoISP';
}

interface PppoeAccountsResponse { results: PppoeAccount[]; canRevealPassword: boolean }
interface PppoePasswordResponse {
  status: 'AVAILABLE' | 'EMPTY' | 'UNAVAILABLE';
  password?: string;
  message: string;
  source: 'MikroTik' | 'NexoISP';
}

function PppoeAccountFields({ clientId, account, canReveal }: { clientId: string; account: PppoeAccount; canReveal: boolean }) {
  const fieldId = useId();
  const request = useRef<AbortController | null>(null);
  const [result, setResult] = useState<PppoePasswordResponse | null>(null);
  const [busy, setBusy] = useState(false), [error, setError] = useState('');
  useEffect(() => () => { request.current?.abort(); }, []);
  const revealed = result?.status === 'AVAILABLE' || result?.status === 'EMPTY';
  const reveal = async () => {
    if (busy) return;
    const controller = new AbortController();
    request.current = controller;
    setBusy(true); setError(''); setResult(null);
    try {
      const response = await api<PppoePasswordResponse>(`/clients/${encodeURIComponent(clientId)}/pppoe-accounts/${account.source}/${encodeURIComponent(account.id)}/password`, {
        method: 'POST', body: '{}', signal: controller.signal, cache: 'no-store',
      });
      if (!controller.signal.aborted) setResult(response);
    } catch (err) {
      if (!controller.signal.aborted) setError(errorMessage(err));
    } finally {
      if (!controller.signal.aborted) { setBusy(false); request.current = null; }
    }
  };
  const hide = () => { setResult(null); setError(''); };
  return <article className="pppoe-account">
    <div className="pppoe-account-heading"><strong>{account.routerName || 'Router asociado'}</strong><span className="subtle">{account.source === 'imported' ? 'Cuenta importada de MikroTik' : 'Servicio local en NexoISP'}</span></div>
    <div className="form-grid">
      <label className="field" htmlFor={`${fieldId}-username`}><span className="field-label">Usuario PPPoE</span><input id={`${fieldId}-username`} type="text" value={account.username} readOnly autoComplete="off" spellCheck={false} /></label>
      <label className="field" htmlFor={`${fieldId}-password`}><span className="field-label">Contraseña PPPoE</span><input id={`${fieldId}-password`} type={revealed ? 'text' : 'password'} value={revealed ? result.password ?? '' : ''} placeholder={result?.status === 'EMPTY' ? 'Contraseña vacía' : result?.status === 'UNAVAILABLE' ? 'No disponible' : 'Sin consultar'} readOnly autoComplete="off" spellCheck={false} /></label>
    </div>
    {account.profile && <p className="field-hint">Perfil: {account.profile}</p>}
    <div className="pppoe-password-actions">
      {canReveal && account.canRevealPassword ? <button className="button small" type="button" disabled={busy} onClick={() => revealed ? hide() : void reveal()}>{revealed ? <EyeOff size={15} /> : <Eye size={15} />}{busy ? 'Consultando…' : revealed ? 'Ocultar contraseña' : 'Mostrar contraseña'}</button> : <span className="field-hint">{!canReveal ? 'Solo un administrador puede consultar la contraseña.' : account.source === 'imported' && !account.present ? 'Esta cuenta no aparece en la última importación del router.' : 'No hay una contraseña disponible para consultar.'}</span>}
      <span className="field-hint">Origen de la contraseña: {account.passwordSource}.</span>
    </div>
    {result && <p className="field-hint" role="status">{result.message}</p>}
    {error && <p className="alert error" role="alert">{error}</p>}
  </article>;
}

export function ClientPppoeFields({ clientId }: { clientId: string }) {
  const [response, setResponse] = useState<PppoeAccountsResponse | null>(null);
  const [loading, setLoading] = useState(true), [error, setError] = useState(''), [reload, setReload] = useState(0);
  useEffect(() => {
    const controller = new AbortController();
    setResponse(null); setError(''); setLoading(true);
    void api<PppoeAccountsResponse>(`/clients/${encodeURIComponent(clientId)}/pppoe-accounts`, { signal: controller.signal, cache: 'no-store' })
      .then(value => { if (!controller.signal.aborted) setResponse(value); })
      .catch(err => { if (!controller.signal.aborted) setError(errorMessage(err)); })
      .finally(() => { if (!controller.signal.aborted) setLoading(false); });
    return () => { controller.abort(); };
  }, [clientId, reload]);
  return <section className="pppoe-fields" aria-label="Credenciales PPPoE">
    <h3 className="section-label">Credenciales PPPoE · solo lectura</h3>
    <p className="field-hint">Consulta el usuario y la contraseña de cada cuenta asociada. La contraseña se obtiene al pulsar «Mostrar contraseña».</p>
    {loading ? <Loading label="Cargando cuentas PPPoE…" /> : error ? <div className="alert error" role="alert"><span>{error}</span><button className="button small" type="button" onClick={() => setReload(value => value + 1)}><RefreshCw size={14} />Reintentar</button></div> : response?.results.length ? response.results.map(account => <PppoeAccountFields key={`${account.source}:${account.id}`} clientId={clientId} account={account} canReveal={response.canRevealPassword} />) : <p className="field-hint">Este cliente no tiene cuentas PPPoE asociadas. Para consultar una cuenta del router, usa «Importar secrets de MikroTik» en Clientes.</p>}
  </section>;
}
