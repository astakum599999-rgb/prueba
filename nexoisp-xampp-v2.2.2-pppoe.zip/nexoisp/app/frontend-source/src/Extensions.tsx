import { useCallback, useEffect, useState, type FormEvent, type ReactNode } from 'react';
import { ArrowRightLeft, Building2, Download, FileText, LoaderCircle, MoreHorizontal, Pencil, Plus, RefreshCw, Search, Trash2 } from 'lucide-react';
import { api, apiBase, choices, patch, post, remove } from './api';
import { defaultCurrencyHint, getDefaultCurrency, setDefaultCurrency } from './currency';
import { ConfirmDialog } from './dialogs';
import type { Row } from './forms';
import { pageMeta } from './pages';
import type { Client, ExtensionPageName, Invoice, PageResult, Payment, Plan, Role, Router, Service, User } from './types';
import { Badge, date, DynamicForm, EmptyState, errorMessage, labels, Loading, Modal, money, Pagination, SearchBox, text, type FieldSpec, type FormValues } from './ui';

export const extensionNames: ExtensionPageName[] = ['portal-accounts', 'payment-reports', 'contracts', 'payment-promises', 'service-charges', 'service-discounts', 'inventory-assets', 'inventory-movements', 'installations', 'cash-accounts', 'cash-movements', 'reports', 'company-settings'];
export const isExtensionPage = (name: string): name is ExtensionPageName => extensionNames.includes(name as ExtensionPageName);
export const documentUrl = (type: 'invoice' | 'receipt' | 'contract', id: string) => `${apiBase.replace(/\/api\/v1$/, '')}/portal/documento.php?type=${type}&id=${encodeURIComponent(id)}`;
export const exportUrl = (type: string, query?: URLSearchParams) => `${apiBase}/exports/${type}.csv${query?.size ? `?${query}` : ''}`;
const nested = (row: Row, key: string): Record<string, unknown> => row[key] && typeof row[key] === 'object' ? row[key] as Record<string, unknown> : {};
const newPrefix = (kind: string) => ['payment-promises', 'installations', 'cash-accounts'].includes(kind) ? 'Nueva' : 'Nuevo';
const option = (value: string, label: string) => ({ value, label });
const opts = (values: string[]) => values.map(value => option(value, labels[value] || value));
const readableMoney = (row: Row, key: string) => money(row[key], row.currency || nested(row, 'account').currency || nested(row, 'invoice').currency);
const clientName = (row: Row) => text(nested(row, 'client').name, text(row.clientName, text(row.clientId)));
const serviceName = (row: Row) => `${text(nested(row, 'service').ipAddress, text(row.serviceId))}${nested(row, 'service').client ? ` · ${text((nested(row, 'service').client as Record<string, unknown>).name)}` : ''}`;
export function extensionCanRead(page: ExtensionPageName, role: Role): boolean {
  if (['cash-accounts', 'cash-movements', 'reports'].includes(page)) return role !== 'TECHNICIAN';
  if (['portal-accounts', 'payment-reports'].includes(page)) return ['ADMIN', 'BILLING'].includes(role);
  return true;
}
function canEdit(page: ExtensionPageName, role: Role): boolean {
  if (['inventory-movements', 'reports'].includes(page)) return false;
  if (role === 'ADMIN') return true;
  if (['inventory-assets', 'installations'].includes(page)) return role === 'TECHNICIAN';
  if (page === 'company-settings') return false;
  return role === 'BILLING';
}
const relationDisplay = (row: Row, key: string, primary: string, fallback: string) => text(nested(row, key)[primary], text(row[fallback]));

interface ExtColumn { label: string; render: (row: Row) => ReactNode }
function columns(kind: ExtensionPageName): ExtColumn[] {
  switch (kind) {
    case 'portal-accounts': return [
      { label: 'Cliente', render: row => <><strong>{clientName(row)}</strong><div className="table-secondary">{text(nested(row, 'client').code)}</div></> },
      { label: 'Usuario del portal', render: row => text(row.username) },
      { label: 'Acceso', render: row => <Badge value={row.active ? 'ACTIVE' : 'RETIRED'}>{row.active ? 'Habilitado' : 'Deshabilitado'}</Badge> },
      { label: 'Última actualización', render: row => date(row.updatedAt, true) },
    ];
    case 'payment-reports': return [
      { label: 'Cliente / factura', render: row => <><strong>{clientName(row)}</strong><div className="table-secondary">{text(nested(row, 'invoice').number, text(row.invoiceId))}</div></> },
      { label: 'Referencia', render: row => text(row.reference) },
      { label: 'Importe reportado', render: row => readableMoney(row, 'amountCents') },
      { label: 'Estado', render: row => <Badge value={row.status} /> },
      { label: 'Fecha', render: row => date(row.createdAt, true) },
    ];
    case 'contracts': return [
      { label: 'Contrato', render: row => <><strong>{text(row.title)}</strong><div className="table-secondary">{clientName(row)}</div></> },
      { label: 'Servicio', render: row => serviceName(row) },
      { label: 'Estado', render: row => <Badge value={row.status} /> },
      { label: 'Aceptación', render: row => <><div>{text(row.acceptedName)}</div><div className="table-secondary">{date(row.acceptedAt, true)}</div></> },
    ];
    case 'payment-promises': return [
      { label: 'Factura / cliente', render: row => <><strong>{text(nested(row, 'invoice').number, text(row.invoiceId))}</strong><div className="table-secondary">{clientName(row)}</div></> },
      { label: 'Importe comprometido', render: row => readableMoney(row, 'amountCents') },
      { label: 'Fecha de compromiso', render: row => date(row.promisedUntil) },
      { label: 'Estado', render: row => <Badge value={row.effectiveStatus || row.status || (row.cancelledAt ? 'CANCELLED' : 'ACTIVE')} /> },
    ];
    case 'service-charges': return [
      { label: 'Concepto', render: row => <><strong>{text(row.name)}</strong><div className="table-secondary">{serviceName(row)}</div></> },
      { label: 'Cantidad', render: row => text(row.quantity) },
      { label: 'Precio unitario', render: row => readableMoney(row, 'unitCents') },
      { label: 'Frecuencia', render: row => <Badge value={row.recurrence} /> },
      { label: 'Estado', render: row => <Badge value={row.active ? 'ACTIVE' : 'RETIRED'} /> },
    ];
    case 'service-discounts': return [
      { label: 'Descuento', render: row => <><strong>{text(row.name)}</strong><div className="table-secondary">{serviceName(row)}</div></> },
      { label: 'Importe', render: row => row.kind === 'PERCENT' ? `${Number(row.value) / 100} %` : money(row.value, row.currency || nested(row, 'service').currency || (nested(row, 'service').plan as Record<string, unknown> | undefined)?.currency) },
      { label: 'Vigencia', render: row => `${date(row.startOn)} — ${date(row.endOn)}` },
      { label: 'Estado', render: row => <Badge value={row.active ? 'ACTIVE' : 'RETIRED'} /> },
    ];
    case 'inventory-assets': return [
      { label: 'Equipo', render: row => <><strong>{text(row.name)}</strong><div className="table-secondary">{[row.category, row.brand, row.model].filter(Boolean).join(' · ')}</div></> },
      { label: 'Serie / MAC', render: row => <><span className="mono">{text(row.serialNumber)}</span><div className="table-secondary mono">{text(row.macAddress)}</div></> },
      { label: 'Ubicación / cliente', render: row => <><div>{text(row.location)}</div><div className="table-secondary">{row.clientId ? clientName(row) : 'Sin asignar'}</div></> },
      { label: 'Estado', render: row => <Badge value={row.state} /> },
      { label: 'Costo', render: row => readableMoney(row, 'costCents') },
    ];
    case 'inventory-movements': return [
      { label: 'Equipo', render: row => relationDisplay(row, 'asset', 'name', 'assetId') },
      { label: 'Operación', render: row => <Badge value={row.action} /> },
      { label: 'Cambio', render: row => <><span>{labels[String(row.fromState)] || text(row.fromState)}</span><span> → {labels[String(row.toState)] || text(row.toState)}</span></> },
      { label: 'Cliente', render: row => row.clientId ? clientName(row) : '—' },
      { label: 'Fecha', render: row => date(row.createdAt, true) },
    ];
    case 'installations': return [
      { label: 'Visita / cliente', render: row => <><strong>{row.clientId ? clientName(row) : text(row.prospectName, 'Nueva solicitud')}</strong><div className="table-secondary">{text(row.address)}</div></> },
      { label: 'Agenda', render: row => <><div>{date(row.scheduledAt, true)}</div><div className="table-secondary">{relationDisplay(row, 'assignedUser', 'name', 'assignedUserId')}</div></> },
      { label: 'Zona', render: row => text(row.zone) },
      { label: 'Estado', render: row => <Badge value={row.status} /> },
      { label: 'Estimado', render: row => readableMoney(row, 'estimatedCents') },
    ];
    case 'cash-accounts': return [
      { label: 'Caja / cuenta', render: row => <strong>{text(row.name)}</strong> },
      { label: 'Moneda', render: row => text(row.currency) },
      { label: 'Saldo inicial', render: row => readableMoney(row, 'openingCents') },
      { label: 'Saldo actual', render: row => <strong>{readableMoney(row, 'balanceCents')}</strong> },
      { label: 'Estado', render: row => <Badge value={row.active ? 'ACTIVE' : 'RETIRED'} /> },
    ];
    case 'cash-movements': return [
      { label: 'Cuenta / concepto', render: row => <><strong>{relationDisplay(row, 'account', 'name', 'accountId')}</strong><div className="table-secondary">{text(row.description)}</div></> },
      { label: 'Tipo', render: row => <Badge value={row.type} /> },
      { label: 'Importe', render: row => readableMoney(row, 'amountCents') },
      { label: 'Origen / categoría', render: row => <><div>{labels[String(row.source)] || text(row.source)}</div><div className="table-secondary">{text(row.category)}</div></> },
      { label: 'Estado', render: row => row.reversed ? <Badge value="CANCELLED">Reversado</Badge> : <Badge value="ACTIVE">Vigente</Badge> },
      { label: 'Fecha', render: row => date(row.occurredAt, true) },
    ];
    default: return [];
  }
}

interface ExtensionLookups { clients: Client[]; services: Service[]; invoices: Invoice[]; accounts: Row[]; payments: Payment[]; users: User[]; plans: Plan[]; routers: Router[] }
const emptyLookups: ExtensionLookups = { clients: [], services: [], invoices: [], accounts: [], payments: [], users: [], plans: [], routers: [] };
const serviceOptions = (lookups: ExtensionLookups) => lookups.services.filter(row => row.desiredState !== 'RETIRED').map(row => option(row.id, `${row.client?.name || row.clientId} · ${row.ipAddress} · ${row.plan?.name || ''}`));

async function loadLookups(kind: string): Promise<ExtensionLookups> {
  const result = { ...emptyLookups };
  const jobs: Promise<void>[] = [];
  if (['portal-accounts', 'inventory-assign', 'installations'].includes(kind)) jobs.push(choices<Client>('/clients').then(rows => { result.clients = rows; }));
  if (['contracts', 'service-charges', 'service-discounts', 'prorate'].includes(kind)) jobs.push(choices<Service>('/services').then(rows => { result.services = rows; }));
  if (kind === 'payment-promises') jobs.push(choices<Invoice>('/invoices').then(rows => { result.invoices = rows; }));
  if (kind === 'installations') {
    jobs.push(choices<User>('/technicians').then(rows => { result.users = rows; }));
    jobs.push(choices<Plan>('/plans').then(rows => { result.plans = rows; }));
    jobs.push(choices<Router>('/routers').then(rows => { result.routers = rows; }));
  }
  if (['cash-movements', 'cash-transfer'].includes(kind)) jobs.push(choices<Row>('/cash-accounts').then(rows => { result.accounts = rows; }));
  if (kind === 'cash-movements') jobs.push(choices<Payment>('/payments').then(rows => { result.payments = rows; }));
  await Promise.all(jobs);
  return result;
}

function extensionFields(kind: string, editing: boolean, lookups: ExtensionLookups, values: FormValues): FieldSpec[] {
  const services: FieldSpec = { name: 'serviceId', label: 'Servicio', type: 'select', required: true, disabled: editing, options: serviceOptions(lookups), full: true };
  const clients: FieldSpec = { name: 'clientId', label: 'Cliente', type: 'select', required: true, disabled: editing, options: lookups.clients.filter(row => row.status !== 'RETIRED').map(row => option(row.id, `${row.code} · ${row.name}`)), full: true };
  const active: FieldSpec = { name: 'active', label: 'Habilitado', type: 'checkbox' };
  const accountOptions = lookups.accounts.filter(row => row.active).map(row => option(row.id, `${text(row.name)} · ${text(row.currency)} · ${money(row.balanceCents, row.currency)}`));
  if (kind === 'portal-accounts') return [clients, { name: 'username', label: 'Usuario del portal', required: true }, { name: 'password', label: editing ? 'Nueva contraseña (opcional)' : 'Contraseña del portal', type: 'password', required: !editing, hint: editing ? 'Déjala vacía para conservar la actual.' : 'Al menos 12 caracteres. Compártela de forma segura con el cliente.' }, ...(editing ? [active] : [])];
  if (kind === 'contracts') return [...(!editing ? [services] : []), { name: 'title', label: 'Título del contrato', required: true, full: true }, { name: 'terms', label: 'Condiciones del servicio', type: 'textarea', required: true, full: true, hint: 'Escribe tus condiciones. El cliente debe aceptarlas desde su portal.' }];
  if (kind === 'payment-promises') return [
    { name: 'invoiceId', label: 'Factura pendiente', type: 'select', required: true, full: true, options: lookups.invoices.filter(row => row.status === 'OPEN').map(row => option(row.id, `${row.number} · ${row.client?.name || row.clientId} · saldo ${money(row.amountCents - row.paidCents, row.currency)}`)) },
    { name: 'amount', label: 'Monto comprometido', type: 'number', required: true, min: 0.01, step: '0.01', hint: 'Debe cubrir al menos el saldo pendiente de la factura.' },
    { name: 'currency', label: 'Moneda', disabled: true },
    { name: 'promisedUntil', label: 'Fecha de compromiso', type: 'date', required: true, full: true, hint: 'Desde hoy hasta un máximo de 90 días.' },
  ];
  if (kind === 'service-charges') return [services, { name: 'name', label: 'Concepto del cargo', required: true, full: true }, { name: 'quantity', label: 'Cantidad', type: 'number', min: 1, required: true }, { name: 'unitPrice', label: 'Precio unitario', type: 'number', required: true, min: 0, step: '0.01' }, { name: 'recurrence', label: 'Frecuencia', type: 'select', required: true, options: opts(['MONTHLY', 'ONE_TIME']), full: true }, ...(editing ? [active] : [])];
  if (kind === 'service-discounts') return [services, { name: 'name', label: 'Motivo del descuento', required: true, full: true }, { name: 'kind', label: 'Tipo de descuento', type: 'select', required: true, options: [option('FIXED', 'Importe fijo'), option('PERCENT', 'Porcentaje')] }, { name: 'discountValue', label: values.kind === 'PERCENT' ? 'Porcentaje (%)' : 'Importe de descuento', type: 'number', min: 0.01, ...(values.kind === 'PERCENT' ? { max: 100 } : {}), step: '0.01', required: true }, { name: 'startOn', label: 'Inicio de vigencia', type: 'date', required: true }, { name: 'endOn', label: 'Fin de vigencia', type: 'date', required: true }, ...(editing ? [active] : [])];
  if (kind === 'inventory-assets') return [
    { name: 'name', label: 'Nombre del equipo', required: true }, { name: 'category', label: 'Categoría', required: true, hint: 'Por ejemplo: CPE, router, ONU o herramienta.' },
    { name: 'brand', label: 'Marca' }, { name: 'model', label: 'Modelo' }, { name: 'serialNumber', label: 'Número de serie' }, { name: 'macAddress', label: 'MAC' },
    { name: 'cost', label: 'Costo de adquisición', type: 'number', min: 0, step: '0.01', required: true }, { name: 'currency', label: 'Moneda ISO', required: true, hint: defaultCurrencyHint() }, { name: 'location', label: 'Ubicación física', full: true },
  ];
  if (kind.startsWith('inventory-')) return [...(kind === 'inventory-assign' ? [{ ...clients, disabled: false }] : []), { name: 'note', label: 'Nota del movimiento', type: 'textarea', full: true }];
  if (kind === 'installations') {
    const transitions: Record<string, string[]> = { REQUESTED: ['REQUESTED', 'SCHEDULED', 'CANCELLED'], SCHEDULED: ['SCHEDULED', 'REQUESTED', 'IN_PROGRESS', 'CANCELLED'], IN_PROGRESS: ['IN_PROGRESS', 'SCHEDULED', 'COMPLETED', 'CANCELLED'] };
    const statuses = editing ? transitions[String(values.originalStatus)] || [String(values.originalStatus)] : ['REQUESTED', 'SCHEDULED'];
    const scheduled = ['SCHEDULED', 'IN_PROGRESS', 'COMPLETED'].includes(String(values.status));
    return [
    { ...clients, required: false, disabled: false, full: false }, { name: 'prospectName', label: 'Nombre del prospecto', hint: 'Requerido si aún no existe un cliente.' },
    { name: 'phone', label: 'Teléfono de contacto' }, { name: 'zone', label: 'Zona' }, { name: 'address', label: 'Dirección de la visita', required: true, full: true },
    { name: 'latitude', label: 'Latitud GPS', type: 'number', min: -90, max: 90, step: 'any' }, { name: 'longitude', label: 'Longitud GPS', type: 'number', min: -180, max: 180, step: 'any' },
    { name: 'scheduledAt', label: 'Fecha y hora local de la visita', type: 'datetime-local', required: scheduled }, { name: 'assignedUserId', label: 'Técnico asignado', type: 'select', required: scheduled, options: lookups.users.map(row => option(row.id, row.name)) },
    { name: 'planId', label: 'Plan solicitado', type: 'select', options: lookups.plans.filter(row => row.active).map(row => option(row.id, row.name)) }, { name: 'routerId', label: 'Router previsto', type: 'select', options: lookups.routers.map(row => option(row.id, row.name)) },
    { name: 'status', label: 'Estado de la instalación', type: 'select', required: true, options: opts(statuses) },
    { name: 'estimated', label: 'Costo estimado', type: 'number', required: true, min: 0, step: '0.01' }, { name: 'currency', label: 'Moneda ISO', required: true, hint: defaultCurrencyHint() }, { name: 'notes', label: 'Notas de la visita', type: 'textarea', full: true },
  ];
  }
  if (kind === 'cash-accounts') return [{ name: 'name', label: 'Nombre de la caja o cuenta', required: true, full: true }, ...(!editing ? [{ name: 'currency', label: 'Moneda ISO', required: true, hint: defaultCurrencyHint() }, { name: 'opening', label: 'Saldo de apertura', type: 'number' as const, min: 0, step: '0.01', required: true }] : [active])];
  if (kind === 'cash-movements') return [
    { name: 'accountId', label: 'Caja / cuenta', type: 'select', required: true, full: true, options: accountOptions },
    { name: 'type', label: 'Tipo de movimiento', type: 'select', required: true, options: opts(['INCOME', 'EXPENSE']) }, { name: 'amount', label: 'Importe', type: 'number', required: true, min: 0.01, step: '0.01' },
    { name: 'category', label: 'Categoría contable', required: true }, { name: 'occurredAt', label: 'Fecha y hora local', type: 'datetime-local' },
    { name: 'description', label: 'Descripción del movimiento', required: true, full: true },
    ...(values.type === 'INCOME' ? [{ name: 'paymentId', label: 'Vincular pago recibido (opcional)', type: 'select' as const, full: true, hint: 'El importe y la moneda deben coincidir por completo. Un pago solo se registra una vez en caja.', options: lookups.payments.map(row => option(row.id, `${row.externalReference} · ${money(row.amountCents, row.invoice?.currency)}`)) }] : []),
  ];
  if (kind === 'cash-transfer') {
    const from = lookups.accounts.find(row => row.id === values.fromAccountId);
    return [
      { name: 'fromAccountId', label: 'Cuenta de origen', type: 'select', required: true, full: true, options: accountOptions },
      { name: 'toAccountId', label: 'Cuenta de destino', type: 'select', required: true, full: true, options: lookups.accounts.filter(row => row.active && row.id !== values.fromAccountId && (!from || row.currency === from.currency)).map(row => option(row.id, `${text(row.name)} · ${text(row.currency)}`)) },
      { name: 'amount', label: 'Importe de la transferencia', type: 'number', min: 0.01, step: '0.01', required: true }, { name: 'externalReference', label: 'Referencia única', required: true }, { name: 'description', label: 'Descripción', required: true, full: true },
    ];
  }
  if (kind === 'reject-report' || kind === 'cash-reverse') return [{ name: 'reason', label: 'Motivo', type: 'textarea', required: true, full: true }];
  if (kind === 'prorate') return [services, { name: 'period', label: 'Periodo (AAAA-MM)', required: true }, { name: 'startOn', label: 'Primer día facturado', type: 'date', required: true }, { name: 'endOn', label: 'Último día facturado', type: 'date', required: true }];
  return [];
}

function formDefaults(kind: string, row?: Row): FormValues {
  const today = new Date().toISOString().slice(0, 10);
  const defaults: Record<string, FormValues> = {
    'portal-accounts': { active: true }, contracts: { title: 'Contrato de servicio de Internet' },
    'payment-promises': { promisedUntil: today }, 'service-charges': { quantity: '1', unitPrice: '0.00', recurrence: 'MONTHLY', active: true },
    'service-discounts': { kind: 'FIXED', discountValue: '0.00', startOn: today, endOn: today, active: true },
    'inventory-assets': { cost: '0.00', currency: getDefaultCurrency() }, installations: { status: 'REQUESTED', estimated: '0.00', currency: getDefaultCurrency() },
    'cash-accounts': { currency: getDefaultCurrency(), opening: '0.00', active: true }, 'cash-movements': { type: 'INCOME', category: 'Operación' },
    prorate: { period: today.slice(0, 7), startOn: today, endOn: new Date(Date.UTC(new Date().getUTCFullYear(), new Date().getUTCMonth() + 1, 0)).toISOString().slice(0, 10) },
  };
  const values: FormValues = { ...defaults[kind] };
  if (row) for (const [key, value] of Object.entries(row)) {
    if (typeof value === 'boolean') values[key] = value;
    else if (typeof value === 'string' || typeof value === 'number') values[key] = String(value);
  }
  for (const field of ['startOn', 'endOn', 'promisedUntil']) if (values[field]) values[field] = String(values[field]).slice(0, 10);
  for (const field of ['scheduledAt', 'occurredAt']) if (values[field]) {
    const time = new Date(String(values[field]));
    if (!Number.isNaN(time.getTime())) values[field] = new Date(time.getTime() - time.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
  }
  if (row?.unitCents !== undefined) values.unitPrice = (Number(row.unitCents) / 100).toFixed(2);
  if (row?.costCents !== undefined) values.cost = (Number(row.costCents) / 100).toFixed(2);
  if (row?.estimatedCents !== undefined) values.estimated = (Number(row.estimatedCents) / 100).toFixed(2);
  if (row?.value !== undefined) values.discountValue = (Number(row.value) / 100).toFixed(2);
  if (kind === 'installations' && row) values.originalStatus = String(row.status);
  values.password = '';
  return values;
}

function payloadFor(kind: string, values: FormValues, fields: FieldSpec[], editing: boolean): Record<string, unknown> {
  const payload: Record<string, unknown> = {};
  const converted = ['amount', 'unitPrice', 'cost', 'estimated', 'opening', 'discountValue'];
  for (const field of fields) {
    if (field.disabled || converted.includes(field.name)) continue;
    const value = values[field.name];
    if (field.type === 'password' && !value) continue;
    if (field.type === 'checkbox') payload[field.name] = Boolean(value);
    else if (value === '' || value === undefined) { if (editing && !field.required) payload[field.name] = null; }
    else if (field.type === 'number') payload[field.name] = Number(value);
    else if (field.type === 'datetime-local') payload[field.name] = new Date(String(value)).toISOString();
    else payload[field.name] = String(value).trim();
  }
  const cents = (field: string) => Math.round(Number(values[field]) * 100);
  if (['payment-promises', 'cash-movements', 'cash-transfer'].includes(kind)) payload.amountCents = cents('amount');
  if (kind === 'payment-promises') payload.currency = values.currency;
  if (kind === 'service-charges') payload.unitCents = cents('unitPrice');
  if (kind === 'service-discounts') payload.value = cents('discountValue');
  if (kind === 'inventory-assets') payload.costCents = cents('cost');
  if (kind === 'installations') payload.estimatedCents = cents('estimated');
  if (kind === 'cash-accounts' && !editing) payload.openingCents = cents('opening');
  if (payload.currency) payload.currency = String(payload.currency).toUpperCase();
  if (kind === 'cash-movements' && values.type !== 'INCOME') delete payload.paymentId;
  return payload;
}

interface ProratePreview { amountCents: number; currency: string; lines: { description: string; quantity: number; unitCents: number; totalCents: number }[]; dueAt: string; graceUntil: string; proration: { chargedDays: number; daysInMonth: number; limitation: string } }
export function ExtensionFormDialog({ kind, row, close, onSaved, notify }: { kind: string; row?: Row; close: () => void; onSaved: () => void; notify: (message: string, error?: boolean) => void }) {
  const editing = Boolean(row?.id) && extensionNames.includes(kind as ExtensionPageName) && !['payment-promises', 'cash-movements'].includes(kind);
  const [values, setValues] = useState<FormValues>(() => formDefaults(kind, row)), [lookups, setLookups] = useState(emptyLookups), [loading, setLoading] = useState(true), [busy, setBusy] = useState(false), [error, setError] = useState(''), [reload, setReload] = useState(0);
  const [preview, setPreview] = useState<ProratePreview | null>(null);
  const closeStable = useCallback(() => close(), [close]);
  useEffect(() => {
    let active = true;
    void loadLookups(kind).then(data => { if (active) { setLookups(data); setError(''); } }).catch(err => { if (active) setError(errorMessage(err)); }).finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [kind, reload]);
  useEffect(() => {
    if (kind !== 'payment-promises' || !values.invoiceId) return;
    const invoice = lookups.invoices.find(row => row.id === values.invoiceId);
    if (invoice) setValues(current => ({ ...current, currency: invoice.currency, amount: ((invoice.amountCents - invoice.paidCents) / 100).toFixed(2) }));
  }, [kind, values.invoiceId, lookups.invoices]);
  const fields = extensionFields(kind, editing, lookups, values);
  const setFormValues = (next: FormValues) => { setValues(next); setPreview(null); };
  const submit = async (event: FormEvent) => {
    event.preventDefault(); setBusy(true); setError('');
    try {
      if (kind === 'portal-accounts' && values.password && String(values.password).length < 12) throw new Error('La contraseña del portal debe tener al menos 12 caracteres.');
      if (kind === 'installations' && !values.clientId && !String(values.prospectName || '').trim()) throw new Error('Selecciona un cliente o escribe el nombre del prospecto.');
      const payload = payloadFor(kind, values, fields, editing);
      if (kind === 'prorate') { setPreview(await post<ProratePreview>('/billing/prorate-preview', payload)); return; }
      if (kind === 'reject-report') await post(`/payment-reports/${row!.id}/reject`, payload);
      else if (kind === 'cash-reverse') await post(`/cash-movements/${row!.id}/reverse`, payload);
      else if (kind === 'cash-transfer') await post('/cash-transfers', payload);
      else if (kind.startsWith('inventory-') && kind !== 'inventory-assets') await post(`/inventory-assets/${row!.id}/${kind.split('-')[1]}`, payload);
      else if (editing) await patch(`/${kind}/${row!.id}`, payload);
      else await post(`/${kind}`, payload);
      onSaved(); notify('Información guardada.'); close();
    } catch (err) { setError(errorMessage(err)); }
    finally { setBusy(false); }
  };
  const issueProrate = async () => {
    setBusy(true); setError('');
    try { await post('/billing/prorate', payloadFor(kind, values, fields, false)); onSaved(); notify('Factura prorrateada emitida.'); close(); }
    catch (err) { setError(errorMessage(err)); } finally { setBusy(false); }
  };
  const customTitles: Record<string, string> = { 'inventory-assign': 'Asignar equipo al cliente', 'inventory-return': 'Registrar devolución', 'inventory-repair': 'Enviar equipo a reparación', 'inventory-retire': 'Retirar equipo', 'reject-report': 'Rechazar pago reportado', 'cash-transfer': 'Transferir entre cuentas', 'cash-reverse': 'Reversar movimiento de caja', prorate: 'Primera factura con prorrateo' };
  const title = customTitles[kind] || `${editing ? 'Editar' : newPrefix(kind)} ${pageMeta[kind as ExtensionPageName]?.singular || 'registro'}`;
  return <Modal title={title} close={closeStable} wide={['contracts', 'installations', 'prorate'].includes(kind)}>{loading ? <Loading label="Cargando opciones…" /> : <>{error && <div className="alert error" role="alert">{error}<button className="button small" onClick={() => { setLoading(true); setReload(value => value + 1); }}>Recargar opciones</button></div>}<DynamicForm fields={fields} values={values} setValues={setFormValues} submit={event => void submit(event)} busy={busy} submitLabel={kind === 'prorate' ? 'Calcular prorrateo' : editing ? 'Guardar cambios' : 'Guardar'}>{kind === 'service-discounts' && <div className="alert info">Se admite un descuento activo por servicio. El importe se aplica a facturas nuevas dentro de su vigencia.</div>}{kind === 'installations' && <div className="alert info">Completar una visita no provisiona el servicio de red. Registra y sincroniza el servicio desde su módulo cuando la instalación esté lista.</div>}{kind === 'cash-movements' && <div className="alert info">Los movimientos se conservan como historial. Para corregir uno registrado, utiliza la acción de reverso.</div>}{preview && <section className="panel" style={{ marginTop: 20 }}><header className="panel-heading"><h3 className="panel-title">Vista previa · {preview.proration.chargedDays}/{preview.proration.daysInMonth} días</h3><strong>{money(preview.amountCents, preview.currency)}</strong></header><div className="panel-body"><p className="subtle">{preview.proration.limitation}</p>{preview.lines.map((line, index) => <div className="invoice-line" key={index}><span>{line.description}</span><strong>{money(line.totalCents, preview.currency)}</strong></div>)}<p className="subtle">Vence: {date(preview.dueAt)} · Gracia hasta: {date(preview.graceUntil)}</p><button type="button" className="button primary" disabled={busy} onClick={() => void issueProrate()}><FileText size={16} />Emitir esta factura</button></div></section>}</DynamicForm></>}</Modal>;
}

type ExtensionDialog = { type: 'form'; kind: string; row?: Row } | { type: 'details'; row: Row } | { type: 'confirm'; title: string; description: string; confirm: () => Promise<void> };
export function ExtensionsPage({ page, user, notify }: { page: ExtensionPageName; user: User; notify: (message: string, error?: boolean) => void }) {
  const [result, setResult] = useState<PageResult<Row>>({ results: [], count: 0, page: 1, pageSize: 15 }), [loading, setLoading] = useState(true), [error, setError] = useState(''), [search, setSearch] = useState(''), [query, setQuery] = useState(''), [pageNumber, setPageNumber] = useState(1), [refresh, setRefresh] = useState(0), [status, setStatus] = useState('');
  const [dialog, setDialog] = useState<ExtensionDialog | null>(null);
  const close = useCallback(() => setDialog(null), []), saved = useCallback(() => setRefresh(value => value + 1), []);
  useEffect(() => { const timer = window.setTimeout(() => { setQuery(search); setPageNumber(1); }, 250); return () => window.clearTimeout(timer); }, [search]);
  useEffect(() => {
    if (['reports', 'company-settings'].includes(page)) return;
    let active = true; setLoading(true);
    const params = new URLSearchParams({ page: String(pageNumber), pageSize: '15', search: query, q: query, ...(status ? { status } : {}) });
    api<PageResult<Row>>(`/${page}?${params}`).then(data => { if (active) { setResult(data); setError(''); if (!data.results.length && data.count && pageNumber > 1) setPageNumber(Math.ceil(data.count / 15)); } }).catch(err => { if (active) setError(errorMessage(err)); }).finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [page, pageNumber, query, refresh, status]);
  if (page === 'reports') return <ReportsPage />;
  if (page === 'company-settings') return <CompanySettings user={user} notify={notify} />;
  const writable = canEdit(page, user.role), tableColumns = columns(page), Icon = pageMeta[page].icon;
  const allowCreate = writable && !['payment-reports', 'inventory-movements'].includes(page);
  const mutate = async (path: string, payload: unknown = {}) => { await post(path, payload); saved(); notify('Operación registrada.'); };
  const confirm = (title: string, description: string, callback: () => Promise<void>) => setDialog({ type: 'confirm', title, description, confirm: callback });
  const rowActions = (row: Row) => <div className="table-actions"><button className="icon-button" aria-label="Ver detalle" onClick={() => setDialog({ type: 'details', row })}><MoreHorizontal size={18} /></button>{writable && !['payment-reports', 'payment-promises', 'inventory-movements', 'cash-movements'].includes(page) && !(page === 'contracts' && row.status !== 'DRAFT') && !(page === 'installations' && ['COMPLETED', 'CANCELLED'].includes(String(row.status))) && <button className="icon-button" aria-label="Editar" onClick={() => setDialog({ type: 'form', kind: page, row })}><Pencil size={16} /></button>}{page === 'payment-reports' && writable && row.status === 'SUBMITTED' && <><button className="button small" onClick={() => confirm('Aprobar pago reportado', 'Confirma que recibiste el dinero. La aprobación registrará el pago y solicitará la reconexión que corresponda; reportar un pago no equivale a validarlo.', () => mutate(`/payment-reports/${row.id}/approve`))}>Aprobar</button><button className="button small danger" onClick={() => setDialog({ type: 'form', kind: 'reject-report', row })}>Rechazar</button></>}{page === 'contracts' && writable && row.status !== 'CANCELLED' && <button className="button small danger" onClick={() => confirm('Cancelar contrato', 'El documento y su aceptación se conservarán como historial. Se marcará como cancelado.', async () => { await patch(`/contracts/${row.id}`, { status: 'CANCELLED' }); saved(); notify('Contrato cancelado.'); })}>Cancelar</button>}{page === 'payment-promises' && writable && (row.effectiveStatus || row.status) === 'ACTIVE' && new Date(String(row.promisedUntil)).getTime() > Date.now() && <button className="button small danger" onClick={() => confirm('Cancelar promesa', 'Se cancelará el acuerdo y se revisará nuevamente si corresponde un corte por deuda vencida.', () => mutate(`/payment-promises/${row.id}/cancel`))}>Cancelar</button>}{['service-charges', 'service-discounts'].includes(page) && writable && Boolean(row.active) && <button className="icon-button" aria-label="Desactivar" onClick={() => confirm('Desactivar concepto', 'El concepto dejará de aplicarse a nuevas facturas. Los documentos ya emitidos conservarán sus importes.', async () => { await remove(`/${page}/${row.id}`); saved(); notify('Concepto desactivado.'); })}><Trash2 size={16} /></button>}{page === 'inventory-assets' && writable && <>{row.state === 'AVAILABLE' && <button className="button small" onClick={() => setDialog({ type: 'form', kind: 'inventory-assign', row })}>Asignar</button>}{['ASSIGNED', 'IN_REPAIR'].includes(String(row.state)) && <button className="button small" onClick={() => setDialog({ type: 'form', kind: 'inventory-return', row })}>Devolver</button>}{row.state === 'AVAILABLE' && <button className="button small" onClick={() => setDialog({ type: 'form', kind: 'inventory-repair', row })}>Reparar</button>}{['AVAILABLE', 'IN_REPAIR'].includes(String(row.state)) && <button className="button small danger" onClick={() => setDialog({ type: 'form', kind: 'inventory-retire', row })}>Retirar</button>}</>}{page === 'cash-movements' && writable && !row.reversed && !['TRANSFER', 'REVERSAL'].includes(String(row.source)) && <button className="button small danger" onClick={() => setDialog({ type: 'form', kind: 'cash-reverse', row })}>Reversar</button>}</div>;
  return <><div className="page-actions" style={{ justifyContent: 'flex-end', marginBottom: 20 }}>{page === 'cash-accounts' && writable && <button className="button" onClick={() => setDialog({ type: 'form', kind: 'cash-transfer' })}><ArrowRightLeft size={16} />Transferir entre cuentas</button>}{allowCreate && <button className="button primary" onClick={() => setDialog({ type: 'form', kind: page })}><Plus size={17} />{newPrefix(page)} {pageMeta[page].singular}</button>}{['inventory-assets', 'cash-movements'].includes(page) && <a className="button" href={exportUrl(page === 'inventory-assets' ? 'inventory' : 'cash')}><Download size={16} />Exportar CSV</a>}</div><section className="panel"><header className="table-toolbar"><div className="inline-gap"><h2 className="panel-title">{pageMeta[page].title}</h2><span className="count-pill">{result.count}</span></div><div className="inline-gap"><SearchBox value={search} onChange={setSearch} label={`Buscar ${pageMeta[page].title.toLowerCase()}`} />{page === 'payment-reports' && <select aria-label="Estado del pago reportado" value={status} onChange={event => { setStatus(event.target.value); setPageNumber(1); }}><option value="">Todos los estados</option>{opts(['SUBMITTED', 'APPROVED', 'REJECTED']).map(item => <option key={item.value} value={item.value}>{item.label}</option>)}</select>}<button className="icon-button" aria-label="Actualizar listado" onClick={saved}><RefreshCw size={17} className={loading ? 'spinner' : ''} /></button></div></header>{error && <div className="alert error" role="alert">{error}</div>}{loading && !result.results.length ? <Loading /> : result.results.length ? <><div className="table-wrap"><table className="data-table"><thead><tr>{tableColumns.map(column => <th key={column.label}>{column.label}</th>)}<th className="right">Acciones</th></tr></thead><tbody>{result.results.map(row => <tr key={row.id}>{tableColumns.map(column => <td key={column.label}>{column.render(row)}</td>)}<td>{rowActions(row)}</td></tr>)}</tbody></table></div><Pagination page={pageNumber} pageSize={15} count={result.count} change={setPageNumber} /></> : !error && <EmptyState icon={<Icon size={26} />} title={query ? 'No encontramos coincidencias' : `Aún no hay ${pageMeta[page].title.toLowerCase()}`} description={query ? 'Prueba otro término de búsqueda.' : 'Los registros que agregues aparecerán aquí.'} />}</section>{page === 'portal-accounts' && <div className="alert info">Los clientes acceden a su área privada en <a href={`${apiBase.replace(/\/api\/v1$/, '')}/portal/`} target="_blank" rel="noreferrer">Portal de clientes</a>. Estas cuentas tienen una sesión separada de la administración.</div>}{dialog?.type === 'form' && <ExtensionFormDialog kind={dialog.kind} row={dialog.row} close={close} onSaved={saved} notify={notify} />}{dialog?.type === 'confirm' && <ConfirmDialog title={dialog.title} description={dialog.description} confirm={dialog.confirm} close={close} />}{dialog?.type === 'details' && <Modal title={`Detalle de ${pageMeta[page].singular}`} close={close} wide={page === 'contracts'}><div className="details-list">{tableColumns.map(column => <div key={column.label}><span>{column.label}</span><strong>{column.render(dialog.row)}</strong></div>)}</div>{page === 'contracts' && <><h3 className="section-label">Condiciones</h3><div className="contract-terms">{text(dialog.row.terms)}</div><a className="button primary" href={documentUrl('contract', dialog.row.id)} target="_blank" rel="noreferrer"><FileText size={16} />Ver documento para imprimir</a></>}{['payment-reports', 'inventory-movements', 'installations'].includes(page) && <><h3 className="section-label">Notas</h3><p className="contract-terms">{text(dialog.row.note || dialog.row.notes)}</p>{Boolean(dialog.row.rejectionReason) && <div className="alert error">{text(dialog.row.rejectionReason)}</div>}</>}</Modal>}</>;
}

interface Company { name: string; address: string; taxId: string; phone: string; email: string; currency: string; invoiceNotes: string }
function CompanySettings({ user, notify }: { user: User; notify: (message: string, error?: boolean) => void }) {
  const [values, setValues] = useState<FormValues>({}), [loading, setLoading] = useState(true), [busy, setBusy] = useState(false), [error, setError] = useState('');
  useEffect(() => { let active = true; api<Company>('/company-settings').then(data => { if (active) { setDefaultCurrency(data.currency); setValues({ ...data }); } }).catch(err => { if (active) setError(errorMessage(err)); }).finally(() => { if (active) setLoading(false); }); return () => { active = false; }; }, []);
  const fields: FieldSpec[] = [{ name: 'name', label: 'Nombre comercial del ISP', required: true, full: true }, { name: 'taxId', label: 'RFC / RUC / identificación fiscal' }, { name: 'currency', label: 'Moneda ISO predeterminada', required: true, hint: 'Soles peruanos: PEN. Cambiar la moneda local no convierte facturas, pagos o cuentas existentes.' }, { name: 'phone', label: 'Teléfono de atención' }, { name: 'email', label: 'Correo de atención', type: 'email' }, { name: 'address', label: 'Dirección comercial', full: true }, { name: 'invoiceNotes', label: 'Notas de las facturas', type: 'textarea', full: true }];
  const submit = async (event: FormEvent) => { event.preventDefault(); setBusy(true); setError(''); try { const payload = Object.fromEntries(fields.map(field => [field.name, String(values[field.name] || '').trim()])); payload.currency = payload.currency!.toUpperCase(); const saved = await patch<Company>('/company-settings', payload); setDefaultCurrency(saved.currency); setValues({ ...saved }); notify('Datos de la empresa guardados. La moneda predeterminada se aplica a registros nuevos.'); } catch (err) { setError(errorMessage(err)); } finally { setBusy(false); } };
  if (loading) return <Loading />;
  return <section className="panel"><header className="panel-heading"><h2 className="panel-title"><Building2 size={20} />Identidad de tu empresa</h2></header><div className="panel-body">{error && <div className="alert error">{error}</div>}{user.role === 'ADMIN' ? <DynamicForm fields={fields} values={values} setValues={setValues} submit={event => void submit(event)} busy={busy} /> : <div className="details-list">{fields.map(field => <div key={field.name}><span>{field.label}</span><strong>{text(values[field.name])}</strong></div>)}</div>}</div></section>;
}

interface FinancialReport { range: { from: string; to: string }; currencies: { currency: string; invoicedCents: number; paidCents: number; outstandingCents: number; overdueCents: number; cashIncomeCents: number; cashExpenseCents: number }[]; counts: { clients: number; activeClients: number; suspendedClients: number; services: number; openTickets: number }; receivables: { invoiceId: string; number: string; clientName: string; currency: string; balanceCents: number; dueAt: string; graceUntil: string; daysOverdue: number }[]; zones: { zone: string; clients: number; active: number; suspended: number }[] }
function ReportsPage() {
  const today = new Date().toISOString().slice(0, 10);
  const [from, setFrom] = useState(`${today.slice(0, 7)}-01`), [to, setTo] = useState(today), [data, setData] = useState<FinancialReport | null>(null), [loading, setLoading] = useState(false), [error, setError] = useState(''), [currency, setCurrency] = useState('');
  const load = useCallback(async (start: string, end: string) => { setLoading(true); setError(''); try { if (start > end) throw new Error('La fecha inicial debe ser anterior o igual a la final.'); const query = new URLSearchParams({ from: start, to: end }); setData(await api<FinancialReport>(`/reports?${query}`)); } catch (err) { setError(errorMessage(err)); } finally { setLoading(false); } }, []);
  useEffect(() => { void load(`${today.slice(0, 7)}-01`, today); }, [load, today]);
  const currencies = data?.currencies.filter(row => !currency || row.currency === currency) || [];
  const query = new URLSearchParams({ from: data?.range.from || from, to: data?.range.to || to });
  return <><section className="panel"><header className="panel-heading"><h2 className="panel-title">Periodo del reporte</h2></header><form className="report-filters" onSubmit={event => { event.preventDefault(); void load(from, to); }}><label className="field"><span className="field-label">Desde (UTC)</span><input type="date" value={from} onChange={event => setFrom(event.target.value)} required /></label><label className="field"><span className="field-label">Hasta (UTC)</span><input type="date" value={to} onChange={event => setTo(event.target.value)} required /></label><label className="field"><span className="field-label">Moneda</span><select value={currency} onChange={event => setCurrency(event.target.value)}><option value="">Todas las monedas</option>{data?.currencies.map(row => <option key={row.currency} value={row.currency}>{row.currency}</option>)}</select></label><button className="button primary" disabled={loading} type="submit">{loading ? <LoaderCircle size={16} className="spinner" /> : <Search size={16} />}Consultar</button></form></section>{error && <div className="alert error" role="alert">{error}</div>}{loading && !data ? <Loading /> : data && <><div className="alert info">Los ingresos y la facturación corresponden al periodo {date(data.range.from)} — {date(data.range.to)}. La cartera pendiente y vencida muestra los saldos actuales.</div>{currencies.length ? currencies.map(group => <section className="panel" key={group.currency}><header className="panel-heading"><h2 className="panel-title">Resumen en {group.currency}</h2></header><div className="report-metrics">{[['Facturado en el periodo', group.invoicedCents], ['Cobrado en el periodo', group.paidCents], ['Cartera pendiente actual', group.outstandingCents], ['Cartera vencida actual', group.overdueCents], ['Ingresos de caja', group.cashIncomeCents], ['Gastos de caja', group.cashExpenseCents]].map(([label, amount]) => <div key={String(label)}><span className="subtle">{label}</span><strong>{money(amount, group.currency)}</strong></div>)}</div></section>) : <EmptyState title="Sin importes en el periodo" description="No hay movimientos registrados para los filtros elegidos." />}<section className="panel"><header className="panel-heading"><h2 className="panel-title">Cartera pendiente actual</h2><div className="inline-gap"><a className="button small" href={exportUrl('invoices', query)}><Download size={15} />Facturas CSV</a><a className="button small" href={exportUrl('payments', query)}><Download size={15} />Pagos CSV</a><a className="button small" href={exportUrl('cash', query)}><Download size={15} />Caja CSV</a></div></header>{data.receivables.length ? <div className="table-wrap"><table className="data-table"><thead><tr><th>Factura</th><th>Cliente</th><th>Saldo</th><th>Vencimiento</th><th>Días vencidos</th></tr></thead><tbody>{data.receivables.filter(row => !currency || row.currency === currency).map(row => <tr key={row.invoiceId}><td>{row.number}</td><td>{row.clientName}</td><td>{money(row.balanceCents, row.currency)}</td><td>{date(row.dueAt)}</td><td>{row.daysOverdue}</td></tr>)}</tbody></table></div> : <EmptyState title="Sin cartera pendiente" description="No hay facturas con saldo por cobrar." />}</section><section className="panel"><header className="panel-heading"><h2 className="panel-title">Clientes por zona</h2></header>{data.zones.length ? <div className="table-wrap"><table className="data-table"><thead><tr><th>Zona</th><th>Clientes</th><th>Activos</th><th>Suspendidos</th></tr></thead><tbody>{data.zones.map(row => <tr key={row.zone}><td>{row.zone || 'Sin zona'}</td><td>{row.clients}</td><td>{row.active}</td><td>{row.suspended}</td></tr>)}</tbody></table></div> : <EmptyState title="Sin zonas registradas" description="Asigna una zona a tus clientes para comparar su estado." />}</section></>}</>;
}
