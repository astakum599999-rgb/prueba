import { useCallback, useEffect, useRef, useState } from 'react';
import { CheckCircle2, Download, LoaderCircle, Router as RouterIcon, ShieldCheck } from 'lucide-react';
import { choices, post } from './api';
import type { Router } from './types';
import { EmptyState, errorMessage, Loading, Modal } from './ui';

interface ImportResult {
  router: { id: string; name: string };
  total: number;
  created: number;
  updated: number;
  unchanged: number;
  missing: number;
  plansCreated: number;
  plansUpdated: number;
  pending: number;
  networkReadOnly: boolean;
}
interface Progress { router: Router; state: 'waiting' | 'reading' | 'done' | 'error'; result?: ImportResult; error?: string }

export default function ProfileImportDialog({ close, saved }: { close: () => void; saved: () => void }) {
  const [routers, setRouters] = useState<Router[]>([]), [selected, setSelected] = useState('all');
  const [loading, setLoading] = useState(true), [loadError, setLoadError] = useState(''), [reload, setReload] = useState(0);
  const [busy, setBusy] = useState(false), [started, setStarted] = useState(false), [progress, setProgress] = useState<Progress[]>([]);
  const active = useRef(true), running = useRef(false);
  useEffect(() => { active.current = true; return () => { active.current = false; }; }, []);
  useEffect(() => {
    let current = true;
    setLoading(true); setLoadError('');
    void choices<Router>('/routers').then(rows => {
      if (!current) return;
      const physical = rows.filter(router => router.transport === 'SOCKET' || router.transport === 'REST');
      setRouters(physical); setSelected(physical.length === 1 ? physical[0]!.id : 'all');
    }).catch(error => { if (current) setLoadError(errorMessage(error)); }).finally(() => { if (current) setLoading(false); });
    return () => { current = false; };
  }, [reload]);
  const safeClose = useCallback(() => { if (!running.current) close(); }, [close]);
  const start = async () => {
    if (running.current) return;
    const targets = selected === 'all' ? routers : routers.filter(router => router.id === selected);
    if (!targets.length) return;
    running.current = true; setBusy(true); setStarted(true);
    setProgress(targets.map(router => ({ router, state: 'waiting' })));
    try {
      for (const router of targets) {
        if (!active.current) break;
        setProgress(rows => rows.map(row => row.router.id === router.id ? { ...row, state: 'reading' } : row));
        try {
          const result = await post<ImportResult>(`/routers/${encodeURIComponent(router.id)}/import-profiles`, {});
          if (!active.current) break;
          setProgress(rows => rows.map(row => row.router.id === router.id ? { ...row, state: 'done', result } : row));
          saved();
        } catch (error) {
          if (!active.current) break;
          setProgress(rows => rows.map(row => row.router.id === router.id ? { ...row, state: 'error', error: errorMessage(error) } : row));
        }
      }
    } finally { running.current = false; if (active.current) setBusy(false); }
  };
  const results = progress.flatMap(row => row.result ? [row.result] : []);
  const total = (key: 'total' | 'plansCreated' | 'plansUpdated' | 'pending') => results.reduce((sum, result) => sum + result[key], 0);
  const failed = progress.filter(row => row.state === 'error').length;
  return <Modal title="Importar perfiles de MikroTik" description="Leer los perfiles PPP y copiar sus velocidades base a planes locales." close={safeClose} wide footer={<><button className="button" disabled={busy} onClick={safeClose}>{started ? 'Volver a Planes' : 'Cancelar'}</button>{!started && !loading && !loadError && routers.length > 0 && <button className="button primary" disabled={busy} onClick={() => void start()}><Download size={17} />Leer e importar perfiles</button>}</>}>
    <div className="alert info"><ShieldCheck size={20} /><span>Solo lectura en MikroTik. No se crean ni modifican perfiles, usuarios o reglas en el router. Los perfiles se guardan como observaciones locales; los planes que se puedan crear quedan inactivos hasta configurar su tarifa.</span></div>
    <div className="alert warning">RouterOS no guarda el precio mensual ni la moneda comercial. Se mostrarán como pendientes de configurar; una velocidad vacía o ilimitada no se convierte en una velocidad inventada.</div>
    {loading ? <Loading label="Consultando routers registrados…" /> : loadError ? <div className="alert error" role="alert">{loadError}<button className="button small" onClick={() => setReload(value => value + 1)}>Reintentar listado de routers</button></div> : !routers.length ? <EmptyState icon={<RouterIcon size={25} />} title="Primero registra tu MikroTik" description="Agrega su IP y acceso API o REST en Routers y nodos. La lectura no cambia su configuración." /> : <>
      {!started && <><label className="field"><span className="field-label">Router de origen</span><select aria-label="Router de origen" value={selected} onChange={event => setSelected(event.target.value)} disabled={busy}><option value="all">Todos los routers registrados ({routers.length})</option>{routers.map(router => <option key={router.id} value={router.id}>{router.name} · {router.host}</option>)}</select></label><p className="subtle">La bajada y subida se toman del primer par de rate-limit. Los parámetros de ráfaga se conservan para consulta. Repetir la lectura actualiza el mismo perfil sin duplicarlo ni sustituir una tarifa local ya configurada.</p></>}
      {started && <><div className={`alert ${busy ? 'info' : failed ? 'warning' : 'success'}`} role="status">{busy ? <LoaderCircle size={19} className="spinner" /> : <CheckCircle2 size={19} />}<span>{busy ? 'Consultando perfiles de los routers uno por uno. Mantén esta ventana abierta.' : `Lectura de perfiles finalizada: ${results.length} router${results.length === 1 ? '' : 's'} consultado${results.length === 1 ? '' : 's'}${failed ? `; ${failed} con error` : ''}.`}</span></div><div className="secret-import-summary" aria-label="Resumen de perfiles importados"><div><span>Perfiles leídos</span><strong>{total('total')}</strong></div><div><span>Planes nuevos</span><strong>{total('plansCreated')}</strong></div><div><span>Planes actualizados</span><strong>{total('plansUpdated')}</strong></div><div><span>Pendientes de completar</span><strong>{total('pending')}</strong></div></div><div className="secret-import-progress">{progress.map(row => <article key={row.router.id}><div className="inline-gap"><RouterIcon size={18} /><strong>{row.router.name}</strong><span className="subtle mono">{row.router.host}</span></div><p className={row.state === 'error' ? 'error-text' : 'subtle'}>{row.state === 'waiting' ? 'Pendiente de lectura' : row.state === 'reading' ? 'Leyendo perfiles…' : row.state === 'error' ? row.error : `${row.result!.total} perfiles · ${row.result!.plansCreated} planes nuevos · ${row.result!.plansUpdated} actualizados · ${row.result!.pending} pendientes`}</p>{row.result && row.result.missing > 0 && <p className="subtle">{row.result.missing} perfiles anteriores no observados; su historial se conserva.</p>}</article>)}</div>{!busy && failed > 0 && <p className="subtle">Los errores no se reintentan automáticamente. Revisa la conexión o los permisos y vuelve a abrir la importación cuando los hayas corregido.</p>}</>}
    </>}
  </Modal>;
}
