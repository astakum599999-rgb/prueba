import { useCallback, useEffect, useRef, useState } from 'react';
import { CheckCircle2, Download, LoaderCircle, Router as RouterIcon, ShieldCheck } from 'lucide-react';
import { choices, post } from './api';
import type { Router } from './types';
import { EmptyState, errorMessage, Loading, Modal } from './ui';

interface ImportResult {
  router: { id: string; name: string };
  total: number;
  created: number;
  updated: number;
  unchanged: number;
  missing: number;
  networkReadOnly: boolean;
}
interface RouterProgress { router: Router; state: 'waiting' | 'reading' | 'done' | 'error'; result?: ImportResult; error?: string }

export default function SecretImportDialog({ close, saved }: { close: () => void; saved: () => void }) {
  const [routers, setRouters] = useState<Router[]>([]), [selected, setSelected] = useState('all');
  const [loading, setLoading] = useState(true), [loadError, setLoadError] = useState(''), [reload, setReload] = useState(0);
  const [busy, setBusy] = useState(false), [started, setStarted] = useState(false), [progress, setProgress] = useState<RouterProgress[]>([]);
  const active = useRef(true), running = useRef(false);
  useEffect(() => { active.current = true; return () => { active.current = false; }; }, []);
  useEffect(() => {
    let current = true;
    setLoading(true); setLoadError('');
    void choices<Router>('/routers').then(rows => {
      if (!current) return;
      const physical = rows.filter(router => router.transport === 'SOCKET' || router.transport === 'REST');
      setRouters(physical); setSelected(physical.length === 1 ? physical[0]!.id : 'all');
    }).catch(error => { if (current) setLoadError(errorMessage(error)); }).finally(() => { if (current) setLoading(false); });
    return () => { current = false; };
  }, [reload]);
  const safeClose = useCallback(() => { if (!running.current) close(); }, [close]);
  const start = async () => {
    // A ref closes the gap before React renders the disabled button.
    if (running.current) return;
    const targets = selected === 'all' ? routers : routers.filter(router => router.id === selected);
    if (!targets.length) return;
    running.current = true; setBusy(true); setStarted(true);
    setProgress(targets.map(router => ({ router, state: 'waiting' })));
    try {
      for (const router of targets) {
        if (!active.current) break;
        setProgress(rows => rows.map(row => row.router.id === router.id ? { ...row, state: 'reading' } : row));
        try {
          const result = await post<ImportResult>(`/routers/${encodeURIComponent(router.id)}/import-secrets`, {});
          if (!active.current) break;
          setProgress(rows => rows.map(row => row.router.id === router.id ? { ...row, state: 'done', result } : row));
          saved();
        } catch (error) {
          if (!active.current) break;
          setProgress(rows => rows.map(row => row.router.id === router.id ? { ...row, state: 'error', error: errorMessage(error) } : row));
        }
      }
    } finally {
      running.current = false;
      if (active.current) setBusy(false);
    }
  };
  const results = progress.flatMap(row => row.result ? [row.result] : []);
  const total = (key: 'created' | 'updated' | 'unchanged' | 'total' | 'missing') => results.reduce((sum, result) => sum + result[key], 0);
  const failed = progress.filter(row => row.state === 'error').length;
  return <Modal title="Importar secrets de MikroTik" description="Leer usuarios PPP y agregarlos a Clientes." close={safeClose} wide footer={<><button className="button" disabled={busy} onClick={safeClose}>{started ? 'Volver a Clientes' : 'Cancelar'}</button>{!started && !loading && !loadError && routers.length > 0 && <button className="button primary" disabled={busy} onClick={() => void start()}><Download size={17} />Leer e importar clientes</button>}</>}>
    <div className="alert info"><ShieldCheck size={20} /><span>Solo lectura en MikroTik. Se consultan todos los secrets locales, incluidos los deshabilitados y los de otros tipos PPP. No se cambian usuarios, perfiles, velocidades ni reglas. El comentario de cada secret se usa como nombre del cliente. No se copian contraseñas ni se crean servicios o facturas.</span></div>
    {loading ? <Loading label="Consultando routers registrados…" /> : loadError ? <div className="alert error" role="alert">{loadError}<button className="button small" onClick={() => setReload(value => value + 1)}>Reintentar listado de routers</button></div> : !routers.length ? <EmptyState icon={<RouterIcon size={25} />} title="Primero registra tu MikroTik" description="Agrega su IP y credenciales en Routers y nodos y prueba la conexión. La importación admite API Socket y REST." /> : <>
      {!started && <><label className="field"><span className="field-label">Router de origen</span><select aria-label="Router de origen" value={selected} disabled={busy} onChange={event => setSelected(event.target.value)}><option value="all">Todos los routers registrados ({routers.length})</option>{routers.map(router => <option key={router.id} value={router.id}>{router.name} · {router.host}</option>)}</select></label><p className="subtle">Cada secret se identifica por su router y usuario. Repetir la importación actualiza su información y toma de nuevo el comentario como nombre, sin duplicar el usuario PPP. Los clientes que dejen de aparecer conservan su historial y se marcan como no observados.</p></>}
      {started && <><div className={`alert ${busy ? 'info' : failed ? 'warning' : 'success'}`} role="status">{busy ? <LoaderCircle size={19} className="spinner" /> : <CheckCircle2 size={19} />}<span>{busy ? 'Consultando los routers uno por uno. Mantén esta ventana abierta.' : `Lectura finalizada: ${results.length} router${results.length === 1 ? '' : 's'} consultado${results.length === 1 ? '' : 's'}${failed ? `; ${failed} con error` : ''}.`}</span></div>
        <div className="secret-import-summary" aria-label="Resumen de la importación"><div><span>Secrets leídos</span><strong>{total('total')}</strong></div><div><span>Clientes nuevos</span><strong>{total('created')}</strong></div><div><span>Actualizados</span><strong>{total('updated')}</strong></div><div><span>Sin cambios</span><strong>{total('unchanged')}</strong></div></div>
        <div className="secret-import-progress">{progress.map(row => <article key={row.router.id}><div className="inline-gap"><RouterIcon size={18} /><strong>{row.router.name}</strong><span className="subtle mono">{row.router.host}</span></div><p className={row.state === 'error' ? 'error-text' : 'subtle'}>{row.state === 'waiting' ? 'Pendiente de lectura' : row.state === 'reading' ? 'Leyendo secrets…' : row.state === 'error' ? row.error : `${row.result!.total} secrets · ${row.result!.created} nuevos · ${row.result!.updated} actualizados · ${row.result!.unchanged} sin cambios`}</p>{row.result && row.result.missing > 0 && <p className="subtle">{row.result.missing} registros anteriores no observados; no se eliminaron clientes.</p>}</article>)}</div>
        {!busy && failed > 0 && <p className="subtle">Los errores no se reintentan automáticamente. Revisa la conexión o los permisos y vuelve a abrir la importación cuando los hayas corregido.</p>}
      </>}
    </>}
  </Modal>;
}
