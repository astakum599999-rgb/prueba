import { useEffect, useState, type FormEvent } from 'react';
import { RefreshCw } from 'lucide-react';
import { api } from './api';
import { TrafficChart } from './dialogs';
import type { Row } from './forms';
import type { PageResult } from './types';
import { date, EmptyState, errorMessage, Loading, Modal, Pagination, text } from './ui';

interface Sample { id: string; sampledAt: string; uploadBps: number | null; downloadBps: number | null; uploadBytes: number | null; downloadBytes: number | null; averageMs: number | null; lossPercent: number | null }
const localDateTime = (time: Date) => new Date(time.getTime() - time.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
export default function TrafficHistory({ service, close }: { service: Row; close: () => void }) {
  const [from, setFrom] = useState(() => localDateTime(new Date(Date.now() - 86400000))), [to, setTo] = useState(() => localDateTime(new Date()));
  const [range, setRange] = useState({ from, to }), [page, setPage] = useState(1), [refresh, setRefresh] = useState(0), [loading, setLoading] = useState(true), [error, setError] = useState('');
  const [data, setData] = useState<PageResult<Sample>>({ results: [], count: 0, page: 1, pageSize: 100 });
  useEffect(() => {
    let active = true; setLoading(true);
    const params = new URLSearchParams({ from: new Date(range.from).toISOString(), to: new Date(range.to).toISOString(), page: String(page), pageSize: '100' });
    api<PageResult<Sample>>(`/services/${service.id}/traffic?${params}`).then(result => { if (active) { setData(result); setError(''); } }).catch(err => { if (active) setError(errorMessage(err)); }).finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [service.id, range, page, refresh]);
  const submit = (event: FormEvent) => { event.preventDefault(); if (from > to) { setError('La fecha inicial debe ser anterior a la final.'); return; } setRange({ from, to }); setPage(1); };
  const points = data.results.filter(row => row.downloadBps !== null && row.uploadBps !== null).map(row => ({ at: new Date(row.sampledAt).getTime(), rx: row.downloadBps!, tx: row.uploadBps! }));
  return <Modal title={`Histórico de tráfico · ${text(service.ipAddress)}`} description="Muestras de diagnósticos reales guardadas durante los últimos 30 días." close={close} wide><form className="report-filters" style={{ padding: '0 0 20px' }} onSubmit={submit}><label className="field"><span className="field-label">Desde (hora local)</span><input type="datetime-local" value={from} onChange={event => setFrom(event.target.value)} required /></label><label className="field"><span className="field-label">Hasta (hora local)</span><input type="datetime-local" value={to} onChange={event => setTo(event.target.value)} required /></label><button className="button primary" type="submit" disabled={loading}><RefreshCw size={16} />Consultar</button><button className="button" type="button" disabled={loading} onClick={() => setRefresh(value => value + 1)}>Actualizar</button></form>{error && <div className="alert error">{error}</div>}{loading && !data.results.length ? <Loading /> : data.results.length ? <><TrafficChart points={points} /><div className="table-wrap"><table className="data-table"><thead><tr><th>Muestra</th><th>Bajada</th><th>Subida</th><th>Ping promedio</th><th>Pérdida</th></tr></thead><tbody>{data.results.map(row => <tr key={row.id}><td>{date(row.sampledAt, true)}</td><td>{row.downloadBps === null ? '—' : `${(row.downloadBps / 1000000).toFixed(2)} Mbps`}</td><td>{row.uploadBps === null ? '—' : `${(row.uploadBps / 1000000).toFixed(2)} Mbps`}</td><td>{row.averageMs === null ? '—' : `${row.averageMs.toFixed(1)} ms`}</td><td>{row.lossPercent === null ? '—' : `${row.lossPercent.toFixed(1)} %`}</td></tr>)}</tbody></table></div><Pagination page={page} pageSize={100} count={data.count} change={setPage} /></> : !error && <EmptyState title="Todavía no hay muestras" description="Ejecuta un diagnóstico de este servicio para guardar mediciones reales. Los routers simulados no generan historial ficticio." />}</Modal>;
}
