let defaultCurrency = 'PEN';

/** Defaults apply to new local records, never to an existing record's currency. */
export function getDefaultCurrency(): string { return defaultCurrency; }

export function setDefaultCurrency(value: unknown): void {
  const normalized = typeof value === 'string' ? value.trim().toUpperCase() : '';
  defaultCurrency = /^[A-Z]{3}$/.test(normalized) ? normalized : 'PEN';
}

export function formatMoney(cents: unknown, currency?: unknown): string {
  const selected = currency === undefined || currency === null ? getDefaultCurrency() : String(currency).trim().toUpperCase();
  const amount = Number(cents || 0) / 100;
  try {
    return new Intl.NumberFormat('es-PE', { style: 'currency', currency: selected, currencyDisplay: selected === 'PEN' ? 'symbol' : 'code' }).format(amount);
  } catch {
    return `${amount.toFixed(2)} ${selected || '—'}`;
  }
}

export function defaultCurrencyHint(): string {
  return getDefaultCurrency() === 'PEN' ? 'Soles peruanos (PEN). Puedes indicar otra moneda con su código ISO 4217.' : `Moneda local predeterminada: ${getDefaultCurrency()}. Soles peruanos usa el código PEN.`;
}
