import { useEffect, useRef, type FormEvent, type ReactNode } from 'react';
import { Check, ChevronLeft, ChevronRight, LoaderCircle, Search, X } from 'lucide-react';
import { formatMoney } from './currency';

export const labels: Record<string, string> = {
  ACTIVE: 'Activo', SUSPENDED: 'Suspendido', RETIRED: 'Retirado', OPEN: 'Abierto', PAID: 'Pagada', VOID: 'Anulada',
  PENDING: 'Pendiente', SYNCED: 'Sincronizado', FAILED: 'Falló', QUEUED: 'En cola', RUNNING: 'En proceso', SUCCEEDED: 'Completada',
  IN_PROGRESS: 'En atención', RESOLVED: 'Resuelto', CLOSED: 'Cerrado', LOW: 'Baja', NORMAL: 'Normal', HIGH: 'Alta', URGENT: 'Urgente',
  ADMIN: 'Administrador', BILLING: 'Facturación', TECHNICIAN: 'Técnico', VIEWER: 'Consulta',
  PPPOE: 'PPPoE', SIMPLE_QUEUE: 'Simple Queue', QUEUE_TREE: 'Queue Tree', IP_MAC: 'IP / MAC', HOTSPOT: 'Hotspot', DHCP: 'DHCP',
  SERVICE_SYNC: 'Sincronización', DIAGNOSTIC: 'Diagnóstico', ROUTER_TEST: 'Conexión de router', FIREWALL_SYNC: 'Firewall de corte',
  SUBMITTED: 'Pendiente de validación', APPROVED: 'Aprobado', REJECTED: 'Rechazado', DRAFT: 'Borrador', ACCEPTED: 'Aceptado', CANCELLED: 'Cancelado', FULFILLED: 'Cumplida', EXPIRED: 'Vencida', MONTHLY: 'Mensual', ONE_TIME: 'Una sola vez', AVAILABLE: 'Disponible', ASSIGNED: 'Asignado', IN_REPAIR: 'En reparación', RECEIVE: 'Entrada', ASSIGN: 'Asignación', RETURN: 'Devolución', REPAIR: 'Reparación', RETIRE: 'Retiro', REQUESTED: 'Solicitada', SCHEDULED: 'Agendada', COMPLETED: 'Completada', INCOME: 'Ingreso', EXPENSE: 'Gasto', MANUAL: 'Manual', PAYMENT: 'Pago', TRANSFER: 'Transferencia', REVERSAL: 'Reverso',
  BILLING_RUN: 'Facturación mensual', AUTOCUT_RUN: 'Revisión de autocorte', BULK_SYNC: 'Operación masiva', SIMULATED: 'Simulado',
};

export const text = (value: unknown, fallback = '—'): string => value === null || value === undefined || value === '' ? fallback : String(value);
export const date = (value: unknown, time = false): string => {
  if (!value) return '—';
  const dt = new Date(String(value));
  return Number.isNaN(dt.getTime()) ? '—' : new Intl.DateTimeFormat('es', { dateStyle: 'medium', ...(time ? { timeStyle: 'short' as const } : {}) }).format(dt);
};
export const money = formatMoney;
export const errorMessage = (err: unknown) => err instanceof Error ? err.message : 'No se pudo completar la operación.';

export function Badge({ value, children }: { value?: unknown; children?: ReactNode }) {
  const normalized = String(value || 'neutral').toLowerCase();
  return <span className={`badge ${normalized}`}><span aria-hidden="true" />{children || labels[String(value)] || text(value)}</span>;
}

export function Loading({ label = 'Cargando información…' }: { label?: string }) {
  return <div className="loading" role="status"><LoaderCircle size={22} className="spinner" /><span>{label}</span></div>;
}

export function EmptyState({ title = 'Todo empieza con un registro', description = 'Los datos aparecerán aquí cuando los agregues.', icon, action }: { title?: string; description?: string; icon?: ReactNode; action?: ReactNode }) {
  return <div className="empty-state"><div className="empty-icon">{icon || <Check size={25} />}</div><h3>{title}</h3><p>{description}</p>{action}</div>;
}

export function Modal({ title, description, children, footer, close, wide = false }: { title: string; description?: string; children: ReactNode; footer?: ReactNode; close: () => void; wide?: boolean }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null;
    const dialog = ref.current;
    const first = dialog?.querySelector<HTMLElement>('input,select,textarea,button,[tabindex="0"]');
    first?.focus();
    const listener = (event: KeyboardEvent) => {
      if (event.key === 'Escape') close();
      if (event.key !== 'Tab') return;
      const fields = Array.from(dialog?.querySelectorAll<HTMLElement>('button:not(:disabled),input:not(:disabled),select:not(:disabled),textarea:not(:disabled),[tabindex="0"]') || []);
      const start = fields[0], end = fields[fields.length - 1];
      if (event.shiftKey && document.activeElement === start) { event.preventDefault(); end?.focus(); }
      else if (!event.shiftKey && document.activeElement === end) { event.preventDefault(); start?.focus(); }
    };
    document.addEventListener('keydown', listener);
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => { document.removeEventListener('keydown', listener); document.body.style.overflow = previousOverflow; previous?.focus(); };
  }, [close]);
  return <div className="modal-overlay" onMouseDown={event => { if (event.target === event.currentTarget) close(); }}><div ref={ref} className={`modal ${wide ? 'wide' : ''}`} role="dialog" aria-modal="true" aria-labelledby="modal-title"><header className="modal-header"><div><h2 id="modal-title">{title}</h2>{description && <p className="subtle">{description}</p>}</div><button className="icon-button" aria-label="Cerrar" onClick={close}><X size={20} /></button></header><div className="modal-body">{children}</div>{footer && <footer className="modal-footer">{footer}</footer>}</div></div>;
}

export function SearchBox({ value, onChange, label }: { value: string; onChange: (value: string) => void; label: string }) {
  return <label className="search-input"><Search size={17} aria-hidden="true" /><input aria-label={label} type="search" value={value} onChange={event => onChange(event.target.value)} placeholder={label} /></label>;
}

export function Pagination({ page, pageSize, count, change }: { page: number; pageSize: number; count: number; change: (page: number) => void }) {
  const pages = Math.max(1, Math.ceil(count / pageSize));
  return <footer className="pagination"><span>{count ? `${(page - 1) * pageSize + 1}–${Math.min(page * pageSize, count)} de ${count}` : '0 registros'}</span><div className="inline-gap"><button className="icon-button" aria-label="Página anterior" disabled={page <= 1} onClick={() => change(page - 1)}><ChevronLeft size={18} /></button><span>Página {page} de {pages}</span><button className="icon-button" aria-label="Página siguiente" disabled={page >= pages} onClick={() => change(page + 1)}><ChevronRight size={18} /></button></div></footer>;
}

export interface FieldOption { value: string; label: string }
export interface FieldSpec { name: string; label: string; type?: 'text' | 'email' | 'password' | 'number' | 'select' | 'textarea' | 'checkbox' | 'date' | 'datetime-local'; required?: boolean; min?: number; max?: number; step?: string; options?: FieldOption[]; hint?: string; full?: boolean; disabled?: boolean; placeholder?: string; autoComplete?: string }
export type FormValues = Record<string, string | boolean>;

export function DynamicForm({ fields, values, setValues, submit, busy, children, submitLabel = 'Guardar cambios' }: { fields: FieldSpec[]; values: FormValues; setValues: (values: FormValues) => void; submit: (event: FormEvent) => void; busy: boolean; children?: ReactNode; submitLabel?: string }) {
  return <form onSubmit={submit}><div className="form-grid">{fields.map(field => <label key={field.name} className={`field ${field.full ? 'full' : ''} ${field.type === 'checkbox' ? 'checkbox-row' : ''}`}><span className="field-label">{field.label}{field.required && <span aria-hidden="true"> *</span>}</span>{field.type === 'checkbox' ? <input aria-label={field.label} aria-describedby={field.hint ? `hint-${field.name}` : undefined} type="checkbox" checked={Boolean(values[field.name])} disabled={field.disabled || busy} onChange={event => setValues({ ...values, [field.name]: event.target.checked })} /> : field.type === 'select' ? <select aria-label={field.label} aria-describedby={field.hint ? `hint-${field.name}` : undefined} required={field.required} value={String(values[field.name] || '')} disabled={field.disabled || busy} onChange={event => setValues({ ...values, [field.name]: event.target.value })}>{!field.required && <option value="">Sin asignar</option>}{field.required && <option value="" disabled>Seleccionar…</option>}{field.options?.map(option => <option key={option.value} value={option.value}>{option.label}</option>)}</select> : field.type === 'textarea' ? <textarea aria-label={field.label} aria-describedby={field.hint ? `hint-${field.name}` : undefined} rows={4} required={field.required} value={String(values[field.name] || '')} disabled={field.disabled || busy} onChange={event => setValues({ ...values, [field.name]: event.target.value })} /> : <input aria-label={field.label} aria-describedby={field.hint ? `hint-${field.name}` : undefined} type={field.type || 'text'} required={field.required} value={String(values[field.name] ?? '')} min={field.min} max={field.max} step={field.step} placeholder={field.placeholder} disabled={field.disabled || busy} autoComplete={field.autoComplete || (field.type === 'password' ? 'new-password' : 'off')} onChange={event => setValues({ ...values, [field.name]: event.target.value })} />}{field.hint && <span id={`hint-${field.name}`} className="field-hint">{field.hint}</span>}</label>)}</div>{children}<div className="modal-footer" style={{ paddingLeft: 0, paddingRight: 0, marginBottom: -8 }}><button className="button primary" type="submit" disabled={busy}>{busy ? <LoaderCircle size={16} className="spinner" /> : <Check size={16} />}{busy ? 'Guardando…' : submitLabel}</button></div></form>;
}
