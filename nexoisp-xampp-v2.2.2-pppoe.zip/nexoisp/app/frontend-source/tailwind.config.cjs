module.exports = { content: ['./index.html', './src/**/*.{ts,tsx}'], darkMode: ['selector', '[data-theme="dark"]'], theme: { extend: {} }, plugins: [] };
