<?php
declare(strict_types=1);
namespace Nexo;

use DateTimeImmutable;
use DateTimeZone;
use PDO;
use Throwable;

const OPERATIONS_ASSET_STATES = ['AVAILABLE','ASSIGNED','IN_REPAIR','RETIRED'];
const OPERATIONS_INSTALLATION_STATES = ['REQUESTED','SCHEDULED','IN_PROGRESS','COMPLETED','CANCELLED'];

function operationsSchemaReady(string $table): bool
{
    static $ready = [];
    if (!in_array($table, ['InventoryAsset','InventoryMovement','Installation','TrafficSample'], true)) throw new \LogicException('Tabla de operaciones inválida');
    if (isset($ready[$table])) return true;
    $exists = fetchOne('SELECT 1 AS present FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=?', [$table]) !== null;
    if ($exists) $ready[$table] = true;
    return $exists;
}

function operationsRequireSchema(string $table): void
{
    if (!operationsSchemaReady($table)) throw new HttpError(503, 'Aplica las migraciones de la instalación para habilitar este módulo.', 'MIGRATION_REQUIRED');
}

function operationsFields(string $table): array
{
    return match ($table) {
        'InventoryAsset' => ['id','name','category','brand','model','serialNumber','macAddress','costCents','currency','location','state','clientId','createdAt','updatedAt'],
        'InventoryMovement' => ['id','assetId','action','clientId','fromState','toState','userId','note','createdAt'],
        'Installation' => ['id','clientId','prospectName','phone','address','zone','latitude','longitude','scheduledAt','assignedUserId','planId','routerId','status','estimatedCents','currency','notes','completedAt','createdAt','updatedAt'],
        'TrafficSample' => ['id','serviceId','sampledAt','uploadBps','downloadBps','uploadBytes','downloadBytes','averageMs','lossPercent'],
        default => throw new \LogicException('Entidad de operaciones inválida'),
    };
}

function operationsRecord(string $table, string $identifier, bool $forUpdate = false): array
{
    operationsFields($table);
    return fetchOne('SELECT * FROM `' . $table . '` WHERE id=?' . ($forUpdate ? ' FOR UPDATE' : ''), [$identifier]) ?? throw new HttpError(404, 'Registro no encontrado.', 'NOT_FOUND');
}

function operationsInsert(string $table, array $data): array
{
    $fields = operationsFields($table);
    if (array_diff(array_keys($data), $fields)) throw new \LogicException('Campo no permitido');
    $data['id'] ??= id();
    if (in_array('createdAt', $fields, true)) $data['createdAt'] ??= now();
    if (in_array('updatedAt', $fields, true)) $data['updatedAt'] ??= now();
    db()->prepare('INSERT INTO `' . $table . '` (`' . implode('`,`', array_keys($data)) . '`) VALUES (' . implode(',', array_fill(0, count($data), '?')) . ')')->execute(array_values($data));
    return operationsRecord($table, $data['id']);
}

function operationsUpdate(string $table, string $identifier, array $data): array
{
    if (array_diff(array_keys($data), operationsFields($table)) || array_key_exists('id', $data) || array_key_exists('createdAt', $data)) throw new \LogicException('Campo de actualización no permitido');
    $data['updatedAt'] = now();
    db()->prepare('UPDATE `' . $table . '` SET ' . implode(',', array_map(static fn($key) => '`' . $key . '`=?', array_keys($data))) . ' WHERE id=?')->execute([...array_values($data), $identifier]);
    return operationsRecord($table, $identifier);
}

function operationsLocks(array $keys, callable $operation): mixed
{
    $keys = array_values(array_unique($keys)); sort($keys, SORT_STRING); $held = [];
    try {
        foreach ($keys as $key) { if (!lock($key, 10)) throw new HttpError(409, 'Recurso ocupado. Intenta nuevamente.', 'RESOURCE_BUSY'); $held[] = $key; }
        return $operation();
    } finally { foreach (array_reverse($held) as $key) unlock($key); }
}

function operationsDate(string $value): string
{
    if (!preg_match('/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(?::\d{2}(?:\.\d{1,6})?)?(?:Z|[+-]\d{2}:\d{2})$/D', $value)) throw new HttpError(422, 'Usa una fecha ISO 8601 con zona horaria.', 'VALIDATION_ERROR');
    try {
        $date = new DateTimeImmutable($value);
        $errors = DateTimeImmutable::getLastErrors();
        if ($errors !== false && ($errors['warning_count'] || $errors['error_count'])) throw new \RuntimeException('Fecha inválida');
        return $date->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s.v');
    } catch (Throwable) { throw new HttpError(422, 'Fecha inválida.', 'VALIDATION_ERROR'); }
}

function operationsValidate(array $input, array $rules, bool $partial = false): array
{
    if (array_diff(array_keys($input), array_keys($rules))) throw new HttpError(422, 'La solicitud contiene campos no permitidos.', 'VALIDATION_ERROR');
    $output = [];
    foreach ($rules as $key => $rule) {
        if (!array_key_exists($key, $input)) {
            if (!$partial && array_key_exists('default', $rule)) $output[$key] = $rule['default'];
            elseif (!$partial && ($rule['required'] ?? false)) throw new HttpError(422, 'El campo ' . $key . ' es obligatorio.', 'VALIDATION_ERROR');
            continue;
        }
        $value = $input[$key];
        if ($value === null && ($rule['nullable'] ?? false)) { $output[$key] = null; continue; }
        $type = $rule['type'];
        if (in_array($type, ['string','id','mac','date','enum'], true)) {
            if (!is_string($value) || preg_match('//u', $value) !== 1) throw new HttpError(422, 'El campo ' . $key . ' debe ser texto UTF-8 válido.', 'VALIDATION_ERROR');
            $value = trim($value);
            if ($value === '' && ($rule['nullable'] ?? false)) { $output[$key] = null; continue; }
            $length = preg_match_all('/./us', $value);
            if ($length < ($rule['min'] ?? 0) || $length > ($rule['max'] ?? 500)) throw new HttpError(422, 'La longitud de ' . $key . ' no es válida.', 'VALIDATION_ERROR');
            if ($type === 'id' && !preg_match('/^[A-Za-z0-9_-]{1,128}$/D', $value)) throw new HttpError(422, 'Identificador inválido en ' . $key . '.', 'VALIDATION_ERROR');
            if ($type === 'mac') { $value = strtoupper($value); if (!preg_match('/^(?:[A-F0-9]{2}:){5}[A-F0-9]{2}$/D', $value)) throw new HttpError(422, 'Dirección MAC inválida.', 'VALIDATION_ERROR'); }
            if ($type === 'date') $value = operationsDate($value);
            if ($type === 'enum' && !in_array($value, $rule['values'], true)) throw new HttpError(422, 'Valor inválido en ' . $key . '.', 'VALIDATION_ERROR');
            if (isset($rule['pattern']) && !preg_match($rule['pattern'], $value)) throw new HttpError(422, 'Formato inválido en ' . $key . '.', 'VALIDATION_ERROR');
        } elseif ($type === 'integer' || $type === 'number') {
            if (($type === 'integer' && !is_int($value)) || ($type === 'number' && !is_int($value) && !is_float($value)) || !is_finite((float)$value) || $value < ($rule['min'] ?? 0) || $value > ($rule['max'] ?? 2147483647)) throw new HttpError(422, 'Número inválido en ' . $key . '.', 'VALIDATION_ERROR');
        }
        $output[$key] = $value;
    }
    if ($partial && $output === []) throw new HttpError(422, 'Indica al menos un campo para actualizar.', 'VALIDATION_ERROR');
    return $output;
}

function operationsAssetRules(): array
{
    return [
        'name' => ['type'=>'string','required'=>true,'min'=>1,'max'=>200],
        'category' => ['type'=>'string','required'=>true,'min'=>1,'max'=>100],
        'brand' => ['type'=>'string','nullable'=>true,'max'=>100], 'model' => ['type'=>'string','nullable'=>true,'max'=>100],
        'serialNumber' => ['type'=>'string','nullable'=>true,'max'=>160], 'macAddress' => ['type'=>'mac','nullable'=>true,'max'=>17],
        'costCents' => ['type'=>'integer','default'=>0], 'currency' => ['type'=>'string','max'=>3,'pattern'=>'/^[A-Z]{3}$/D','default'=>localCurrency()],
        'location' => ['type'=>'string','nullable'=>true,'max'=>500],
    ];
}

function operationsAssetTransitionData(array $asset, string $action, ?string $clientId): array
{
    $state = $asset['state']; $oldClient = $asset['clientId'] ?? null;
    if ($state === 'RETIRED') throw new HttpError(409, 'Un equipo retirado no admite nuevos movimientos.', 'INVALID_TRANSITION');
    return match ($action) {
        'ASSIGN' => $state === 'AVAILABLE' && $clientId !== null ? ['state'=>'ASSIGNED','clientId'=>$clientId,'movementClientId'=>$clientId] : throw new HttpError(409, 'Sólo se asignan equipos disponibles a un cliente.', 'INVALID_TRANSITION'),
        'RETURN' => in_array($state, ['ASSIGNED','IN_REPAIR'], true) ? ['state'=>'AVAILABLE','clientId'=>null,'movementClientId'=>$oldClient] : throw new HttpError(409, 'Sólo se devuelven equipos asignados o en reparación.', 'INVALID_TRANSITION'),
        'REPAIR' => $state === 'AVAILABLE' ? ['state'=>'IN_REPAIR','clientId'=>null,'movementClientId'=>null] : throw new HttpError(409, 'Devuelve el equipo antes de enviarlo a reparación.', 'INVALID_TRANSITION'),
        'RETIRE' => in_array($state, ['AVAILABLE','IN_REPAIR'], true) ? ['state'=>'RETIRED','clientId'=>null,'movementClientId'=>null] : throw new HttpError(409, 'Devuelve el equipo antes de retirarlo.', 'INVALID_TRANSITION'),
        default => throw new HttpError(422, 'Movimiento de inventario inválido.', 'VALIDATION_ERROR'),
    };
}

function operationsAssetCreate(array $input, array $user): array
{
    operationsRequireSchema('InventoryAsset');
    $data = operationsValidate($input, operationsAssetRules());
    return tx(function (PDO $pdo) use ($data, $user): array {
        $asset = operationsInsert('InventoryAsset', $data + ['state'=>'AVAILABLE','clientId'=>null]);
        operationsInsert('InventoryMovement', ['assetId'=>$asset['id'],'action'=>'RECEIVE','clientId'=>null,'fromState'=>null,'toState'=>'AVAILABLE','userId'=>$user['id'],'note'=>null]);
        audit('INVENTORY_RECEIVE', 'InventoryAsset', $asset['id'], $user['id']);
        return $asset;
    });
}

function operationsAssetUpdate(string $identifier, array $input, array $user): array
{
    $data = operationsValidate($input, operationsAssetRules(), true);
    return operationsLocks(['asset:' . $identifier], fn() => tx(function (PDO $pdo) use ($identifier, $data, $user): array {
        operationsRecord('InventoryAsset', $identifier, true);
        $asset = operationsUpdate('InventoryAsset', $identifier, $data);
        audit('INVENTORY_METADATA', 'InventoryAsset', $asset['id'], $user['id']); return $asset;
    }));
}

function operationsAssetTransition(string $identifier, string $action, array $input, array $user): array
{
    $rules = ['note'=>['type'=>'string','max'=>5000,'nullable'=>true]];
    if ($action === 'ASSIGN') $rules['clientId'] = ['type'=>'id','required'=>true];
    $data = operationsValidate($input, $rules);
    return operationsLocks(['asset:' . $identifier], function () use ($identifier, $action, $data, $user): array {
        $initial = operationsRecord('InventoryAsset', $identifier);
        $clientId = $action === 'ASSIGN' ? $data['clientId'] : ($initial['clientId'] ?? null);
        return operationsLocks($clientId !== null ? ['client:' . $clientId] : [], fn() => tx(function (PDO $pdo) use ($identifier, $action, $data, $user): array {
            $asset = operationsRecord('InventoryAsset', $identifier, true);
            $transition = operationsAssetTransitionData($asset, $action, $data['clientId'] ?? null);
            if ($action === 'ASSIGN') {
                $client = fetchOne('SELECT id,status FROM `Client` WHERE id=? FOR UPDATE', [$data['clientId']]) ?? throw new HttpError(404, 'Cliente no encontrado.', 'NOT_FOUND');
                if ($client['status'] === 'RETIRED') throw new HttpError(409, 'No se asignan equipos a clientes retirados.', 'RETIRED_CLIENT');
            }
            $updated = operationsUpdate('InventoryAsset', $identifier, ['state'=>$transition['state'],'clientId'=>$transition['clientId']]);
            operationsInsert('InventoryMovement', ['assetId'=>$identifier,'action'=>$action,'clientId'=>$transition['movementClientId'],'fromState'=>$asset['state'],'toState'=>$transition['state'],'userId'=>$user['id'],'note'=>$data['note'] ?? null]);
            audit('INVENTORY_' . $action, 'InventoryAsset', $identifier, $user['id']); return $updated;
        }));
    });
}

function operationsInstallationRules(): array
{
    $id = ['type'=>'id','nullable'=>true];
    return [
        'clientId'=>$id,'prospectName'=>['type'=>'string','max'=>200,'nullable'=>true], 'phone'=>['type'=>'string','max'=>100,'nullable'=>true],
        'address'=>['type'=>'string','required'=>true,'min'=>1,'max'=>1000], 'zone'=>['type'=>'string','max'=>500,'nullable'=>true],
        'latitude'=>['type'=>'number','min'=>-90,'max'=>90,'nullable'=>true], 'longitude'=>['type'=>'number','min'=>-180,'max'=>180,'nullable'=>true],
        'scheduledAt'=>['type'=>'date','nullable'=>true], 'assignedUserId'=>$id,'planId'=>$id,'routerId'=>$id,
        'status'=>['type'=>'enum','values'=>OPERATIONS_INSTALLATION_STATES,'default'=>'REQUESTED'],
        'estimatedCents'=>['type'=>'integer','default'=>0], 'currency'=>['type'=>'string','max'=>3,'pattern'=>'/^[A-Z]{3}$/D','default'=>localCurrency()],
        'notes'=>['type'=>'string','max'=>20000,'nullable'=>true],
    ];
}

function operationsInstallationState(?string $previous, string $next): void
{
    $allowed = [
        'REQUESTED'=>['REQUESTED','SCHEDULED','CANCELLED'],
        'SCHEDULED'=>['SCHEDULED','REQUESTED','IN_PROGRESS','CANCELLED'],
        'IN_PROGRESS'=>['IN_PROGRESS','SCHEDULED','COMPLETED','CANCELLED'],
    ];
    if ($previous === null && in_array($next, ['REQUESTED','SCHEDULED'], true)) return;
    if ($previous !== null && isset($allowed[$previous]) && in_array($next, $allowed[$previous], true)) return;
    throw new HttpError(409, 'Transición de instalación inválida. Las visitas completadas o canceladas conservan su historial.', 'INVALID_TRANSITION');
}

function operationsValidateInstallationReferences(array $data): void
{
    if (($data['clientId'] ?? null) === null && ($data['prospectName'] ?? null) === null) throw new HttpError(422, 'Indica un cliente o el nombre del prospecto.', 'VALIDATION_ERROR');
    if (($data['clientId'] ?? null) !== null) {
        $client = fetchOne('SELECT id,status FROM `Client` WHERE id=? FOR UPDATE', [$data['clientId']]) ?? throw new HttpError(404, 'Cliente no encontrado.', 'NOT_FOUND');
        if ($client['status'] === 'RETIRED' && $data['status'] !== 'CANCELLED') throw new HttpError(409, 'El cliente está retirado.', 'RETIRED_CLIENT');
    }
    if (in_array($data['status'], ['SCHEDULED','IN_PROGRESS','COMPLETED'], true) && (($data['scheduledAt'] ?? null) === null || ($data['assignedUserId'] ?? null) === null)) throw new HttpError(422, 'Una visita programada requiere fecha y técnico asignado.', 'VALIDATION_ERROR');
    if (($data['assignedUserId'] ?? null) !== null) {
        $assignee = fetchOne('SELECT id,role,active FROM `User` WHERE id=? FOR UPDATE', [$data['assignedUserId']]) ?? throw new HttpError(422, 'Técnico no encontrado.', 'INVALID_ASSIGNEE');
        if ($data['status'] !== 'CANCELLED' && (!(bool)$assignee['active'] || !in_array($assignee['role'], ['ADMIN','TECHNICIAN'], true))) throw new HttpError(422, 'Asigna un técnico o administrador activo.', 'INVALID_ASSIGNEE');
    }
    if (($data['planId'] ?? null) !== null) {
        $plan = fetchOne('SELECT id,active FROM `Plan` WHERE id=? FOR UPDATE', [$data['planId']]) ?? throw new HttpError(404, 'Plan no encontrado.', 'NOT_FOUND');
        if (!$plan['active'] && $data['status'] !== 'CANCELLED') throw new HttpError(422, 'El plan está inactivo.', 'INACTIVE_PLAN');
    }
    if (($data['routerId'] ?? null) !== null && fetchOne('SELECT id FROM `Router` WHERE id=?', [$data['routerId']]) === null) throw new HttpError(404, 'Router no encontrado.', 'NOT_FOUND');
}

function operationsInstallationCreate(array $input, array $user): array
{
    operationsRequireSchema('Installation'); $data = operationsValidate($input, operationsInstallationRules());
    operationsInstallationState(null, $data['status']);
    return operationsLocks(isset($data['clientId']) ? ['client:' . $data['clientId']] : [], fn() => tx(function (PDO $pdo) use ($data, $user): array {
        operationsValidateInstallationReferences($data);
        $record = operationsInsert('Installation', $data + ['completedAt'=>null]);
        audit('INSTALLATION_CREATE', 'Installation', $record['id'], $user['id']); return $record;
    }));
}

function operationsInstallationUpdate(string $identifier, array $input, array $user): array
{
    $data = operationsValidate($input, operationsInstallationRules(), true);
    return operationsLocks(['installation:' . $identifier], function () use ($identifier, $data, $user): array {
        $initial = operationsRecord('Installation', $identifier);
        $clientId = array_key_exists('clientId', $data) ? $data['clientId'] : $initial['clientId'];
        return operationsLocks($clientId !== null ? ['client:' . $clientId] : [], fn() => tx(function (PDO $pdo) use ($identifier, $data, $user): array {
            $previous = operationsRecord('Installation', $identifier, true);
            $merged = [...$previous, ...$data];
            operationsInstallationState($previous['status'], $merged['status']);
            if ($previous['status'] === 'SCHEDULED' && $merged['status'] === 'REQUESTED') { $data['scheduledAt'] = null; $merged['scheduledAt'] = null; }
            operationsValidateInstallationReferences($merged);
            $data['completedAt'] = $merged['status'] === 'COMPLETED' ? now() : null;
            $record = operationsUpdate('Installation', $identifier, $data);
            // This completes the technical visit only. Service creation remains an
            // explicit, separately authorized provisioning operation in Servicios.
            audit('INSTALLATION_' . $merged['status'], 'Installation', $identifier, $user['id']); return $record;
        }));
    });
}

function operationsQueryString(string $key): ?string
{
    if (!isset($_GET[$key])) return null;
    if (!is_string($_GET[$key]) || strlen($_GET[$key]) > 500) throw new HttpError(422, 'Filtro inválido: ' . $key . '.', 'VALIDATION_ERROR');
    return trim($_GET[$key]);
}

function operationsQueryId(string $key): ?string
{
    $value = operationsQueryString($key);
    if ($value !== null && !preg_match('/^[A-Za-z0-9_-]{1,128}$/D', $value)) throw new HttpError(422, 'Identificador de filtro inválido.', 'VALIDATION_ERROR');
    return $value;
}

function operationsQueryEnum(string $key, array $allowed): ?string
{
    $value = operationsQueryString($key);
    if ($value !== null && !in_array($value, $allowed, true)) throw new HttpError(422, 'Filtro inválido: ' . $key . '.', 'VALIDATION_ERROR');
    return $value;
}

function operationsSearch(array $columns, string $search, array &$where, array &$params): void
{
    if ($search === '') return;
    $parts = [];
    foreach ($columns as $column) { $parts[] = '`' . $column . "` LIKE ? ESCAPE '='"; $params[] = '%' . strtr($search, ['='=>'==','%'=>'=%','_'=>'=_']) . '%'; }
    $where[] = '(' . implode(' OR ', $parts) . ')';
}

function operationsRowsDto(string $table, array $rows): array
{
    $relations = [
        'Client'=>['fields'=>['id','code','name','status'],'keys'=>['clientId']],
        'User'=>['fields'=>['id','name','role'],'keys'=>['userId','assignedUserId']],
        'Plan'=>['fields'=>['id','name','priceCents','currency'],'keys'=>['planId']],
        'Router'=>['fields'=>['id','name','host'],'keys'=>['routerId']],
        'InventoryAsset'=>['fields'=>['id','name','category','serialNumber','state'],'keys'=>['assetId']],
    ];
    $maps = [];
    foreach ($relations as $entity => $relation) {
        $ids = [];
        foreach ($rows as $row) foreach ($relation['keys'] as $key) if (isset($row[$key])) $ids[$row[$key]] = $row[$key];
        if ($ids === []) continue;
        $fields = '`' . implode('`,`', $relation['fields']) . '`';
        foreach (fetchAll('SELECT ' . $fields . ' FROM `' . $entity . '` WHERE id IN (' . implode(',', array_fill(0, count($ids), '?')) . ')', array_values($ids)) as $related) $maps[$entity][$related['id']] = $related;
    }
    return array_map(static function ($row) use ($table, $maps): array {
        $record = array_intersect_key($row, array_flip(operationsFields($table)));
        if ($table === 'InventoryAsset') $record['client'] = $maps['Client'][$row['clientId'] ?? ''] ?? null;
        if ($table === 'InventoryMovement') { $record['asset'] = $maps['InventoryAsset'][$row['assetId']] ?? null; $record['client'] = $maps['Client'][$row['clientId'] ?? ''] ?? null; $record['user'] = $maps['User'][$row['userId']] ?? null; }
        if ($table === 'Installation') { $record['client'] = $maps['Client'][$row['clientId'] ?? ''] ?? null; $record['assignedUser'] = $maps['User'][$row['assignedUserId'] ?? ''] ?? null; $record['plan'] = $maps['Plan'][$row['planId'] ?? ''] ?? null; $record['router'] = $maps['Router'][$row['routerId'] ?? ''] ?? null; }
        return $record;
    }, $rows);
}

function operationsList(string $table, array $p, array $where = [], array $params = [], string $order = 'createdAt DESC,id DESC'): array
{
    operationsRequireSchema($table); operationsFields($table);
    $clause = $where !== [] ? ' WHERE ' . implode(' AND ', $where) : '';
    $count = (int)fetchOne('SELECT COUNT(*) AS n FROM `' . $table . '`' . $clause, $params)['n'];
    $rows = fetchAll('SELECT * FROM `' . $table . '`' . $clause . ' ORDER BY ' . $order . ' LIMIT ' . (int)$p['pageSize'] . ' OFFSET ' . (int)$p['offset'], $params);
    return ['results'=>operationsRowsDto($table, $rows),'count'=>$count,'page'=>$p['page'],'pageSize'=>$p['pageSize']];
}

function operationsDiagnosticIds(array $input): array
{
    if (array_keys($input) !== ['ids'] || !is_array($input['ids']) || !array_is_list($input['ids']) || count($input['ids']) < 1 || count($input['ids']) > 100) throw new HttpError(422, 'Selecciona entre 1 y 100 servicios.', 'VALIDATION_ERROR');
    foreach ($input['ids'] as $identifier) if (!is_string($identifier) || !preg_match('/^[A-Za-z0-9_-]{1,128}$/D', $identifier)) throw new HttpError(422, 'Identificador de servicio inválido.', 'VALIDATION_ERROR');
    return array_values(array_unique($input['ids']));
}

function operationsBulkDiagnostics(array $input, array $user): array
{
    $ids = operationsDiagnosticIds($input); sort($ids, SORT_STRING);
    $initial = fetchAll('SELECT id,clientId FROM `Service` WHERE id IN (' . implode(',', array_fill(0, count($ids), '?')) . ')', $ids);
    if (count($initial) !== count($ids)) throw new HttpError(404, 'Algún servicio del lote no existe.', 'NOT_FOUND');
    return operationsLocks(array_map(static fn($row) => 'client:' . $row['clientId'], $initial), fn() => tx(function (PDO $pdo) use ($ids, $user): array {
        $tasks = [];
        foreach ($ids as $identifier) {
            $service = fetchOne('SELECT id,desiredState,appliedState FROM `Service` WHERE id=? FOR UPDATE', [$identifier]) ?? throw new HttpError(404, 'Servicio no encontrado.', 'NOT_FOUND');
            if ($service['desiredState'] === 'RETIRED' || $service['appliedState'] === 'RETIRED') throw new HttpError(409, 'No se diagnostican servicios retirados: su IP puede tener otro titular.', 'RETIRED_SERVICE');
            $tasks[] = enqueue('DIAGNOSTIC', ['serviceId'=>$identifier,'source'=>'bulk-diagnostics','requestedBy'=>$user['id']]);
            audit('BULK_DIAGNOSTIC', 'Service', $identifier, $user['id']);
        }
        return $tasks;
    }));
}

function operationsMeasurement(mixed $value, float $maximum = 9007199254740991): int|float|null
{
    if ((!is_int($value) && !is_float($value) && !is_string($value)) || !is_numeric($value) || !is_finite((float)$value) || (float)$value < 0 || (float)$value > $maximum) return null;
    return $value + 0;
}

function operationsRecordTraffic(array $service, array $result): void
{
    if (($result['simulated'] ?? true) !== false || ($result['serviceId'] ?? null) !== ($service['id'] ?? null) || ($service['desiredState'] ?? null) === 'RETIRED' || ($service['appliedState'] ?? null) === 'RETIRED') return;
    if (!is_string($result['sampledAt'] ?? null)) return;
    try { $sampledAt = operationsDate($result['sampledAt']); } catch (HttpError) { return; }
    if ($sampledAt < gmdate('Y-m-d H:i:s', time() - 30 * 86400) || $sampledAt > gmdate('Y-m-d H:i:s', time() + 300)) return;
    $traffic = is_array($result['traffic'] ?? null) ? $result['traffic'] : [];
    $ping = is_array($result['ping'] ?? null) && ($result['ping']['available'] ?? false) === true ? $result['ping'] : [];
    $data = [];
    foreach (['uploadBps','downloadBps','uploadBytes','downloadBytes'] as $key) $data[$key] = operationsMeasurement($traffic[$key] ?? null);
    $data['averageMs'] = operationsMeasurement($ping['averageMs'] ?? null, 3600000);
    $data['lossPercent'] = operationsMeasurement($ping['lossPercent'] ?? null, 100);
    if (count(array_filter($data, static fn($value) => $value !== null)) === 0 || !operationsSchemaReady('TrafficSample')) return;
    $current = fetchOne('SELECT id,desiredState,appliedState,routerId FROM `Service` WHERE id=?', [$service['id']]);
    if ($current === null || $current['desiredState'] === 'RETIRED' || $current['appliedState'] === 'RETIRED' || (isset($service['routerId']) && $current['routerId'] !== $service['routerId'])) return;
    $values = ['id'=>id(),'serviceId'=>$service['id'],'sampledAt'=>$sampledAt] + $data;
    db()->prepare('INSERT INTO `TrafficSample` (`' . implode('`,`', array_keys($values)) . '`) VALUES (' . implode(',', array_fill(0, count($values), '?')) . ') ON DUPLICATE KEY UPDATE id=id')->execute(array_values($values));
    db()->exec('DELETE FROM `TrafficSample` WHERE sampledAt < UTC_TIMESTAMP(3) - INTERVAL 30 DAY LIMIT 5000');
}

function operationsTrafficHistory(string $serviceId, array $p, ?string $from = null, ?string $to = null): array
{
    operationsRequireSchema('TrafficSample');
    if (fetchOne('SELECT id FROM `Service` WHERE id=?', [$serviceId]) === null) throw new HttpError(404, 'Servicio no encontrado.', 'NOT_FOUND');
    $now = new DateTimeImmutable('now', new DateTimeZone('UTC'));
    $earliest = $now->modify('-30 days')->format('Y-m-d H:i:s.v');
    $start = $from !== null ? operationsDate($from) : $now->modify('-24 hours')->format('Y-m-d H:i:s.v');
    $end = $to !== null ? operationsDate($to) : $now->format('Y-m-d H:i:s.v');
    if ($start < $earliest) $start = $earliest;
    if ($end > $now->format('Y-m-d H:i:s.v')) $end = $now->format('Y-m-d H:i:s.v');
    if ($start > $end) throw new HttpError(422, 'El rango de fechas está invertido o fuera de los últimos 30 días.', 'VALIDATION_ERROR');
    db()->exec('DELETE FROM `TrafficSample` WHERE sampledAt < UTC_TIMESTAMP(3) - INTERVAL 30 DAY LIMIT 5000');
    return operationsList('TrafficSample', $p, ['serviceId=?','sampledAt>=?','sampledAt<=?'], [$serviceId,$start,$end], 'sampledAt ASC,id ASC');
}

function operationsDispatch(string $method, string $route): bool
{
    if ($route === '/network/bulk-diagnostics' && $method === 'POST') {
        $user = permit('ADMIN','TECHNICIAN');
        $tasks = operationsBulkDiagnostics(body(), $user);
        json(['tasks'=>array_map(static fn($row) => array_intersect_key($row, array_flip(['id','kind','status','payload','attempts','createdAt'])), $tasks)], 202);
    }
    if (preg_match('#^/services/([A-Za-z0-9_-]{1,128})/traffic$#D', $route, $match) && $method === 'GET') {
        requireAuth(); json(operationsTrafficHistory($match[1], pagination(), operationsQueryString('from'), operationsQueryString('to')));
    }
    if (preg_match('#^/inventory-assets(?:/([A-Za-z0-9_-]{1,128}))?(?:/(assign|return|repair|retire))?$#D', $route, $match)) {
        requireAuth(); operationsRequireSchema('InventoryAsset');
        $identifier = $match[1] ?? null; $action = $match[2] ?? null;
        if ($method === 'GET' && $action === null) {
            if ($identifier !== null) json(operationsRowsDto('InventoryAsset', [operationsRecord('InventoryAsset', $identifier)])[0]);
            $p = pagination(); $where = []; $params = [];
            $state = operationsQueryEnum('state', OPERATIONS_ASSET_STATES) ?? operationsQueryEnum('status', OPERATIONS_ASSET_STATES);
            if ($state !== null) { $where[]='state=?'; $params[]=$state; }
            if (($client = operationsQueryId('clientId')) !== null) { $where[]='clientId=?'; $params[]=$client; }
            operationsSearch(['name','category','brand','model','serialNumber','macAddress','location'], $p['search'], $where, $params);
            json(operationsList('InventoryAsset', $p, $where, $params));
        }
        if ($method === 'POST' && $identifier === null && $action === null) { $user=permit('ADMIN','TECHNICIAN'); json(operationsRowsDto('InventoryAsset', [operationsAssetCreate(body(), $user)])[0], 201); }
        if ($method === 'PATCH' && $identifier !== null && $action === null) { $user=permit('ADMIN','TECHNICIAN'); json(operationsRowsDto('InventoryAsset', [operationsAssetUpdate($identifier, body(), $user)])[0]); }
        if ($method === 'POST' && $identifier !== null && $action !== null) { $user=permit('ADMIN','TECHNICIAN'); json(operationsRowsDto('InventoryAsset', [operationsAssetTransition($identifier, strtoupper($action), body(), $user)])[0]); }
    }
    if (preg_match('#^/inventory-movements(?:/([A-Za-z0-9_-]{1,128}))?$#D', $route, $match) && $method === 'GET') {
        requireAuth(); operationsRequireSchema('InventoryMovement');
        if (isset($match[1])) json(operationsRowsDto('InventoryMovement', [operationsRecord('InventoryMovement', $match[1])])[0]);
        $p = pagination(); $where = []; $params = [];
        foreach (['assetId','clientId'] as $field) if (($value=operationsQueryId($field)) !== null) { $where[]='`'.$field.'`=?'; $params[]=$value; }
        if (($action=operationsQueryEnum('action',['RECEIVE','ASSIGN','RETURN','REPAIR','RETIRE'])) !== null) { $where[]='action=?'; $params[]=$action; }
        json(operationsList('InventoryMovement', $p, $where, $params));
    }
    if (preg_match('#^/installations(?:/([A-Za-z0-9_-]{1,128}))?$#D', $route, $match)) {
        requireAuth(); operationsRequireSchema('Installation'); $identifier=$match[1] ?? null;
        if ($method === 'GET') {
            if ($identifier !== null) json(operationsRowsDto('Installation', [operationsRecord('Installation', $identifier)])[0]);
            $p=pagination(); $where=[]; $params=[];
            if (($status=operationsQueryEnum('status',OPERATIONS_INSTALLATION_STATES)) !== null) { $where[]='status=?'; $params[]=$status; }
            foreach (['clientId','assignedUserId'] as $field) if (($value=operationsQueryId($field)) !== null) { $where[]='`'.$field.'`=?'; $params[]=$value; }
            foreach (['from'=>'>=','to'=>'<='] as $field=>$operator) if (($date=operationsQueryString($field)) !== null) { $where[]='scheduledAt'.$operator.'?'; $params[]=operationsDate($date); }
            operationsSearch(['prospectName','phone','address','zone','notes'], $p['search'], $where, $params);
            json(operationsList('Installation', $p, $where, $params, 'CASE WHEN scheduledAt IS NULL THEN 1 ELSE 0 END,scheduledAt ASC,createdAt DESC,id DESC'));
        }
        if ($method === 'POST' && $identifier === null) { $user=permit('ADMIN','TECHNICIAN','BILLING'); json(operationsRowsDto('Installation', [operationsInstallationCreate(body(), $user)])[0], 201); }
        if ($method === 'PATCH' && $identifier !== null) { $user=permit('ADMIN','TECHNICIAN'); json(operationsRowsDto('Installation', [operationsInstallationUpdate($identifier, body(), $user)])[0]); }
    }
    return false;
}
