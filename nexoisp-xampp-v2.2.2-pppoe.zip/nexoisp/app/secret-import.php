<?php
declare(strict_types=1);
namespace Nexo;

use PDO;

require_once __DIR__ . '/RouterTransport.php';

const SECRET_IMPORT_PROPERTIES = '.id,name,service,profile,remote-address,local-address,caller-id,disabled,comment';
const SECRET_IMPORT_LIMIT = 20000;

/** Context contains only fixed field names and a one-based position, never values. */
function secretImportInvalid(string $field, int $row): never
{
    if (!in_array($field, ['.id','name','service','profile','remote-address','local-address','caller-id','disabled','comment','lista','registro','texto'], true)) $field = 'registro';
    throw new HttpError(502, 'El router devolvió un valor no admitido en el campo ' . $field . ', fila ' . max(1, $row) . '; no se importó ningún registro.', 'INVALID_ROUTER_RESPONSE');
}

/**
 * Display/persistence projection only. Raw usernames never pass through this
 * decoder when used as identities or sent to the database's VARBINARY column.
 * RouterOS Socket can return legacy Windows-1252 bytes; no iconv/mbstring needed.
 */
function secretImportDisplayText(string $raw, bool $multiline = false): string
{
    if (preg_match('//u', $raw) === 1) {
        $text = $raw;
    } else {
        $windows1252 = [
            0x80=>'€', 0x81=>'\\x81', 0x82=>'‚', 0x83=>'ƒ', 0x84=>'„', 0x85=>'…', 0x86=>'†', 0x87=>'‡',
            0x88=>'ˆ', 0x89=>'‰', 0x8A=>'Š', 0x8B=>'‹', 0x8C=>'Œ', 0x8D=>'\\x8D', 0x8E=>'Ž', 0x8F=>'\\x8F',
            0x90=>'\\x90', 0x91=>'‘', 0x92=>'’', 0x93=>'“', 0x94=>'”', 0x95=>'•', 0x96=>'–', 0x97=>'—',
            0x98=>'˜', 0x99=>'™', 0x9A=>'š', 0x9B=>'›', 0x9C=>'œ', 0x9D=>'\\x9D', 0x9E=>'ž', 0x9F=>'Ÿ',
        ];
        $text = '';
        for ($offset = 0, $bytes = strlen($raw); $offset < $bytes; $offset++) {
            $byte = ord($raw[$offset]);
            $text .= $byte < 0x80 ? $raw[$offset] : ($byte < 0xA0 ? $windows1252[$byte] : chr(0xC0 | ($byte >> 6)) . chr(0x80 | ($byte & 0x3F)));
        }
    }
    $pattern = $multiline ? '/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F-\x{009F}]/u' : '/[\x00-\x1F\x7F-\x{009F}]/u';
    return preg_replace_callback($pattern, static function (array $match): string {
        $first = ord($match[0][0]);
        $codepoint = $first < 0x80 ? $first : ((($first & 0x1F) << 6) | (ord($match[0][1]) & 0x3F));
        return sprintf('\\x%02X', $codepoint);
    }, $text);
}

/** Validate bounds before and after display escaping; never truncate metadata. */
function secretImportText(mixed $value, int $maximum, bool $multiline = false, string $field = 'texto', int $row = 1): string
{
    if (!is_string($value) || strlen($value) > $maximum * 4) secretImportInvalid($field, $row);
    $length = preg_match('//u', $value) === 1 ? preg_match_all('/./us', $value) : strlen($value);
    if ($length === false || $length > $maximum) secretImportInvalid($field, $row);
    $display = secretImportDisplayText($value, $multiline);
    if (strlen($display) > $maximum * 4 || preg_match_all('/./us', $display) > $maximum) secretImportInvalid($field, $row);
    return $display;
}

/** Binary identity: preserve every original byte, including spaces and controls. */
function secretImportUsername(mixed $value, int $row = 1): string
{
    if (!is_string($value) || $value === '' || strlen($value) > 1020) secretImportInvalid('name', $row);
    $length = preg_match('//u', $value) === 1 ? preg_match_all('/./us', $value) : strlen($value);
    if ($length === false || $length > 255) secretImportInvalid('name', $row);
    return $value;
}

function secretImportDisabled(mixed $value, int $row = 1): bool
{
    if (in_array($value, [true, 1, 'true', 'yes', '1'], true)) return true;
    if (in_array($value, [false, 0, 'false', 'no', '0'], true)) return false;
    secretImportInvalid('disabled', $row);
}

/** Validate the full list before opening a write transaction or marking absences. */
function secretImportNormalize(array $rows): array
{
    if (!array_is_list($rows) || count($rows) > SECRET_IMPORT_LIMIT) {
        secretImportInvalid('lista', 1);
    }
    $result = []; $names = []; $remoteIds = [];
    foreach ($rows as $position => $row) {
        $rowNumber = $position + 1;
        if (!is_array($row) || array_is_list($row)) secretImportInvalid('registro', $rowNumber);
        foreach (['.id','name','disabled'] as $required) if (!array_key_exists($required, $row)) secretImportInvalid($required, $rowNumber);
        $remoteId = $row['.id'];
        if (!is_string($remoteId) || $remoteId === '' || strlen($remoteId) > 512 || preg_match('//u', $remoteId) !== 1 ||
            preg_match('/[\x00-\x1F\x7F]/', $remoteId) || preg_match_all('/./us', $remoteId) > 128) secretImportInvalid('.id', $rowNumber);
        $username = secretImportUsername($row['name'], $rowNumber);
        // Array keys use a hash prefix to avoid PHP converting numeric usernames.
        $nameKey = 'n:' . bin2hex($username); $remoteKey = 'r:' . bin2hex($remoteId);
        if (isset($names[$nameKey])) secretImportInvalid('name', $rowNumber);
        if (isset($remoteIds[$remoteKey])) secretImportInvalid('.id', $rowNumber);
        $names[$nameKey] = true; $remoteIds[$remoteKey] = true;
        // Explicit whitelist: even a router ignoring .proplist cannot persist passwords.
        $record = [
            'remoteId' => $remoteId, 'username' => $username,
            'pppService' => secretImportText($row['service'] ?? '', 32, false, 'service', $rowNumber),
            'profile' => secretImportText($row['profile'] ?? '', 255, false, 'profile', $rowNumber),
            'remoteAddress' => secretImportText($row['remote-address'] ?? '', 255, false, 'remote-address', $rowNumber),
            'localAddress' => secretImportText($row['local-address'] ?? '', 255, false, 'local-address', $rowNumber),
            'callerId' => secretImportText($row['caller-id'] ?? '', 255, false, 'caller-id', $rowNumber),
            'disabled' => secretImportDisabled($row['disabled'], $rowNumber),
            'comment' => secretImportText($row['comment'] ?? '', 16000, true, 'comment', $rowNumber),
        ];
        $fingerprint = $record;
        $fingerprint['username'] = secretImportDisplayText($username);
        if ($fingerprint['username'] !== $username) $fingerprint['_rawUsernameHex'] = bin2hex($username);
        $record['snapshotHash'] = hash('sha256', json_encode($fingerprint, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        $result[] = $record;
    }
    return $result;
}

/** The only remote command used by import; close is guaranteed on every outcome. */
function secretImportRead(RouterTransport $transport): array
{
    try {
        return secretImportNormalize($transport->print('/ppp/secret', [], ['.proplist' => SECRET_IMPORT_PROPERTIES]));
    } finally {
        $transport->close();
    }
}

function secretImportTransport(array $router): RouterTransport
{
    if (!in_array($router['transport'] ?? '', ['REST', 'SOCKET'], true)) {
        throw new HttpError(422, 'Selecciona un router real con API Socket o REST para importar sus cuentas PPP.', 'INVALID_ROUTER');
    }
    $password = decryptSecret((string)$router['passwordEncrypted']);
    return match ($router['transport']) {
        'REST' => new RouterRestTransport($router, $password),
        'SOCKET' => new RouterSocketTransport($router, $password),
        default => throw new HttpError(422, 'Selecciona un router real con API Socket o REST para importar sus cuentas PPP.', 'INVALID_ROUTER'),
    };
}

function secretImportClientCode(string $routerId, string $username): string
{
    return 'MT-' . substr(hash('sha256', $routerId . "\0" . $username), 0, 32);
}

/** The secret comment is the operator's customer name; its complete text stays in the snapshot. */
function secretImportCommentName(string $comment): string
{
    $display = secretImportDisplayText($comment, true);
    $name = trim(preg_replace('/[\s\p{Z}]+/u', ' ', $display));
    if ($name === '') return '';
    preg_match_all('/./us', $name, $characters);
    return implode('', array_slice($characters[0], 0, 200));
}

function secretImportClientName(string $username, ?string $comment = null): string
{
    if ($comment !== null && ($commentName = secretImportCommentName($comment)) !== '') return $commentName;
    preg_match_all('/./us', secretImportDisplayText($username), $characters);
    $name = implode('', array_slice($characters[0], 0, 200));
    return trim($name) === '' ? 'Cuenta PPP' : $name;
}

/** Also callable with a recording transport by integration tests; never makes Services. */
function secretImportRun(string $routerId, string $actorId, ?RouterTransport $transport = null): array
{
    if (!preg_match('/^[a-f0-9]{24}$/D', $routerId)) throw new HttpError(422, 'Identificador de router inválido.', 'VALIDATION_ERROR');
    $key = 'router:' . $routerId;
    if (!lock($key, 10)) throw new HttpError(409, 'El router está ocupado. Intenta la lectura de nuevo.', 'RESOURCE_BUSY');
    try {
        $router = fetchOne('SELECT * FROM `Router` WHERE id=?', [$routerId]) ?? throw new HttpError(404, 'Router no encontrado.', 'NOT_FOUND');
        $observed = secretImportRead($transport ?? secretImportTransport($router));
        return tx(function (PDO $pdo) use ($router, $observed, $actorId): array {
            $timestamp = now();
            $existingRows = fetchAll('SELECT s.*,c.status AS clientStatus,c.name AS clientName FROM `RouterSecretImport` s JOIN `Client` c ON c.id=s.clientId WHERE s.routerId=? FOR UPDATE', [$router['id']]);
            $existing = [];
            foreach ($existingRows as $entry) $existing['n:' . bin2hex($entry['username'])] = $entry;
            $summary = ['router' => ['id' => $router['id'], 'name' => $router['name']], 'total' => count($observed), 'created' => 0, 'updated' => 0, 'unchanged' => 0, 'missing' => 0, 'namesUpdated' => 0, 'networkReadOnly' => true];
            $insertClient = $pdo->prepare('INSERT INTO `Client` (id,code,name,status,createdAt,updatedAt) VALUES (?,?,?,?,?,?)');
            $updateClientName = $pdo->prepare('UPDATE `Client` SET name=?,updatedAt=? WHERE id=?');
            $insertSnapshot = $pdo->prepare('INSERT INTO `RouterSecretImport` (id,routerId,clientId,remoteId,username,pppService,profile,remoteAddress,localAddress,callerId,disabled,comment,present,snapshotHash,firstSeenAt,lastSeenAt) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,1,?,?,?)');
            $updateSnapshot = $pdo->prepare('UPDATE `RouterSecretImport` SET remoteId=?,pppService=?,profile=?,remoteAddress=?,localAddress=?,callerId=?,disabled=?,comment=?,present=1,snapshotHash=?,lastSeenAt=? WHERE id=?');
            foreach ($observed as $entry) {
                $identity = 'n:' . bin2hex($entry['username']);
                $old = $existing[$identity] ?? null;
                unset($existing[$identity]);
                if ($old === null) {
                    $clientId = id();
                    $insertClient->execute([$clientId, secretImportClientCode($router['id'], $entry['username']), secretImportClientName($entry['username'], $entry['comment']), $entry['disabled'] ? 'SUSPENDED' : 'ACTIVE', $timestamp, $timestamp]);
                    $insertSnapshot->execute([id(), $router['id'], $clientId, $entry['remoteId'], $entry['username'], $entry['pppService'], $entry['profile'], $entry['remoteAddress'], $entry['localAddress'], $entry['callerId'], (int)$entry['disabled'], $entry['comment'], $entry['snapshotHash'], $timestamp, $timestamp]);
                    $summary['created']++;
                } else {
                    $changed = $old['snapshotHash'] !== $entry['snapshotHash'] || !(bool)$old['present'];
                    $updateSnapshot->execute([$entry['remoteId'], $entry['pppService'], $entry['profile'], $entry['remoteAddress'], $entry['localAddress'], $entry['callerId'], (int)$entry['disabled'], $entry['comment'], $entry['snapshotHash'], $timestamp, $old['id']]);
                    // A nonempty router comment is authoritative for name only.
                    // Empty comments retain an existing local name; all other personal data is preserved.
                    $commentName = secretImportCommentName($entry['comment']);
                    if ($commentName !== '' && $old['clientName'] !== $commentName) {
                        $updateClientName->execute([$commentName, $timestamp, $old['clientId']]);
                        $summary['namesUpdated']++;
                        $changed = true;
                    }
                    // Preserve manual states and locally retired clients.
                    $previousObservedState = (bool)$old['disabled'] ? 'SUSPENDED' : 'ACTIVE';
                    $nextObservedState = $entry['disabled'] ? 'SUSPENDED' : 'ACTIVE';
                    if ($old['clientStatus'] === $previousObservedState && $nextObservedState !== $previousObservedState) {
                        $pdo->prepare('UPDATE `Client` SET status=?,updatedAt=? WHERE id=? AND status=?')->execute([$nextObservedState, $timestamp, $old['clientId'], $previousObservedState]);
                    }
                    $summary[$changed ? 'updated' : 'unchanged']++;
                }
            }
            foreach ($existing as $entry) {
                $summary['missing']++;
                if ((bool)$entry['present']) $pdo->prepare('UPDATE `RouterSecretImport` SET present=0 WHERE id=?')->execute([$entry['id']]);
            }
            audit('router.secrets.import', 'Router', $router['id'], $actorId);
            unset($GLOBALS['nexo_secret_import_cache']);
            return $summary;
        });
    } finally {
        unlock($key);
    }
}

function secretImportPublic(array $row): array
{
    return [
        'id' => $row['id'], 'routerId' => $row['routerId'], 'routerName' => $row['routerName'],
        'router' => ['id' => $row['routerId'], 'name' => $row['routerName']],
        'clientId' => $row['clientId'], 'remoteId' => $row['remoteId'], 'username' => secretImportDisplayText($row['username']),
        'pppService' => $row['pppService'], 'profile' => $row['profile'],
        'remoteAddress' => $row['remoteAddress'], 'localAddress' => $row['localAddress'], 'callerId' => $row['callerId'],
        'disabled' => (bool)$row['disabled'], 'comment' => $row['comment'], 'present' => (bool)$row['present'],
        'firstSeenAt' => $row['firstSeenAt'], 'lastSeenAt' => $row['lastSeenAt'], 'networkReadOnly' => true,
    ];
}

function secretImportWarmClients(array $ids): void
{
    $ids = array_values(array_unique(array_filter($ids, static fn($value): bool => is_string($value) && preg_match('/^[a-f0-9]{24}$/D', $value) === 1)));
    if ($ids === []) return;
    $missing = [];
    foreach ($ids as $identifier) if (!array_key_exists($identifier, $GLOBALS['nexo_secret_import_cache'] ?? [])) $missing[] = $identifier;
    if ($missing === []) return;
    foreach ($missing as $identifier) $GLOBALS['nexo_secret_import_cache'][$identifier] = [];
    foreach (array_chunk($missing, 200) as $batch) {
        $rows = fetchAll('SELECT s.*,r.name AS routerName FROM `RouterSecretImport` s JOIN `Router` r ON r.id=s.routerId WHERE s.clientId IN (' . implode(',', array_fill(0, count($batch), '?')) . ') ORDER BY r.name,s.username,s.id', $batch);
        foreach ($rows as $row) $GLOBALS['nexo_secret_import_cache'][$row['clientId']][] = secretImportPublic($row);
    }
}

function secretImportClientRows(string $clientId): array
{
    secretImportWarmClients([$clientId]);
    return $GLOBALS['nexo_secret_import_cache'][$clientId] ?? [];
}

function secretImportDispatch(string $method, string $route): bool
{
    if ($method === 'POST' && preg_match('#^/routers/([a-f0-9]{24})/import-secrets$#D', $route, $match)) {
        $actor = permit('ADMIN', 'TECHNICIAN');
        if (body() !== []) throw new HttpError(422, 'La importación no admite parámetros ni cambios de configuración.', 'VALIDATION_ERROR');
        try { json(secretImportRun($match[1], $actor['id'])); }
        catch (RouterError $error) { throw new HttpError(502, 'No se pudo completar la lectura PPP del router. Comprueba conectividad, API y permisos de lectura.', $error->routerCode); }
    }
    if ($method === 'GET' && preg_match('#^/clients/([a-f0-9]{24})/router-secrets$#D', $route, $match)) {
        requireAuth();
        if (!fetchOne('SELECT id FROM `Client` WHERE id=?', [$match[1]])) throw new HttpError(404, 'Cliente no encontrado.', 'NOT_FOUND');
        $rows = secretImportClientRows($match[1]);
        json(['results' => $rows, 'count' => count($rows), 'page' => 1, 'pageSize' => max(1, count($rows))]);
    }
    return false;
}
