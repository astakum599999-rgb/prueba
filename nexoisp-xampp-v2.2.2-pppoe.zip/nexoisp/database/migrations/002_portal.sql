CREATE TABLE IF NOT EXISTS `PortalAccount` (
  `id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `clientId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `username` VARCHAR(100) NOT NULL,
  `passwordHash` VARCHAR(255) NOT NULL,
  `active` TINYINT(1) NOT NULL DEFAULT 1,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`), UNIQUE KEY `portal_client_unique` (`clientId`), UNIQUE KEY `portal_username_unique` (`username`),
  CONSTRAINT `portal_account_client_fk` FOREIGN KEY (`clientId`) REFERENCES `Client` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `portal_account_active_check` CHECK (`active` IN (0,1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `PortalSession` (
  `id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `accountId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `tokenHash` CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `expiresAt` DATETIME(3) NOT NULL,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`), UNIQUE KEY `portal_session_hash_unique` (`tokenHash`), KEY `portal_session_account_idx` (`accountId`), KEY `portal_session_expiry_idx` (`expiresAt`),
  CONSTRAINT `portal_session_account_fk` FOREIGN KEY (`accountId`) REFERENCES `PortalAccount` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `PaymentReport` (
  `id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `invoiceId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `clientId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `amountCents` INT UNSIGNED NOT NULL,
  `currency` CHAR(3) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `reference` VARCHAR(180) COLLATE utf8mb4_bin NOT NULL,
  `note` TEXT NULL,
  `status` VARCHAR(20) NOT NULL DEFAULT 'SUBMITTED',
  `rejectionReason` TEXT NULL,
  `decidedAt` DATETIME(3) NULL,
  `decidedBy` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NULL,
  `paymentId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NULL,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`), KEY `payment_report_client_idx` (`clientId`,`createdAt`), KEY `payment_report_status_idx` (`status`,`createdAt`),
  KEY `payment_report_reference_idx` (`clientId`,`reference`), UNIQUE KEY `payment_report_payment_unique` (`paymentId`),
  CONSTRAINT `payment_report_invoice_fk` FOREIGN KEY (`invoiceId`) REFERENCES `Invoice` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `payment_report_client_fk` FOREIGN KEY (`clientId`) REFERENCES `Client` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `payment_report_decider_fk` FOREIGN KEY (`decidedBy`) REFERENCES `User` (`id`) ON DELETE SET NULL,
  CONSTRAINT `payment_report_payment_fk` FOREIGN KEY (`paymentId`) REFERENCES `Payment` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `payment_report_amount_check` CHECK (`amountCents` BETWEEN 1 AND 2147483647),
  CONSTRAINT `payment_report_currency_check` CHECK (`currency` REGEXP '^[A-Z]{3}$'),
  CONSTRAINT `payment_report_status_check` CHECK (`status` IN ('SUBMITTED','APPROVED','REJECTED'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `ServiceContract` (
  `id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `clientId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `serviceId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `title` VARCHAR(200) NOT NULL,
  `terms` MEDIUMTEXT NOT NULL,
  `clientName` VARCHAR(200) NOT NULL,
  `document` VARCHAR(500) NULL,
  `address` VARCHAR(500) NULL,
  `planName` VARCHAR(200) NOT NULL,
  `serviceType` VARCHAR(20) NOT NULL,
  `ipAddress` VARCHAR(45) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `priceCents` INT UNSIGNED NOT NULL,
  `currency` CHAR(3) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `status` VARCHAR(20) NOT NULL DEFAULT 'DRAFT',
  `acceptedName` VARCHAR(200) NULL,
  `acceptedAt` DATETIME(3) NULL,
  `acceptedIp` VARCHAR(45) CHARACTER SET ascii COLLATE ascii_bin NULL,
  `cancelledAt` DATETIME(3) NULL,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`), KEY `contract_client_idx` (`clientId`,`createdAt`), KEY `contract_service_idx` (`serviceId`,`createdAt`),
  CONSTRAINT `contract_client_fk` FOREIGN KEY (`clientId`) REFERENCES `Client` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `contract_service_fk` FOREIGN KEY (`serviceId`) REFERENCES `Service` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `contract_status_check` CHECK (`status` IN ('DRAFT','ACCEPTED','CANCELLED')),
  CONSTRAINT `contract_currency_check` CHECK (`currency` REGEXP '^[A-Z]{3}$')
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
