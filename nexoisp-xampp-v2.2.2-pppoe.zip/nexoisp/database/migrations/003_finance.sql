CREATE TABLE IF NOT EXISTS CompanyProfile (
  id VARCHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  name VARCHAR(200) NOT NULL DEFAULT '',
  address VARCHAR(500) NOT NULL DEFAULT '',
  taxId VARCHAR(100) NOT NULL DEFAULT '',
  phone VARCHAR(100) NOT NULL DEFAULT '',
  email VARCHAR(254) NOT NULL DEFAULT '',
  currency CHAR(3) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'USD',
  invoiceNotes TEXT NULL,
  updatedAt DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY(id),
  CONSTRAINT company_currency_valid CHECK (currency REGEXP '^[A-Z]{3}$')
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS CashAccount (
  id CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  name VARCHAR(200) NOT NULL,
  currency CHAR(3) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  openingCents BIGINT NOT NULL DEFAULT 0,
  active TINYINT(1) NOT NULL DEFAULT 1,
  createdAt DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  updatedAt DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY(id), UNIQUE KEY cash_account_name(name),
  CONSTRAINT cash_opening_valid CHECK(openingCents BETWEEN 0 AND 2147483647),
  CONSTRAINT cash_account_currency_valid CHECK(currency REGEXP '^[A-Z]{3}$'),
  CONSTRAINT cash_account_active_valid CHECK(active IN (0,1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS CashTransfer (
  id CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  fromAccountId CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  toAccountId CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  amountCents BIGINT NOT NULL,
  description VARCHAR(1000) NOT NULL,
  externalReference VARCHAR(191) COLLATE utf8mb4_bin NOT NULL,
  createdBy CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  createdAt DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY(id), UNIQUE KEY cash_transfer_reference(externalReference),
  CONSTRAINT cash_transfer_source_fk FOREIGN KEY(fromAccountId) REFERENCES CashAccount(id),
  CONSTRAINT cash_transfer_target_fk FOREIGN KEY(toAccountId) REFERENCES CashAccount(id),
  CONSTRAINT cash_transfer_user_fk FOREIGN KEY(createdBy) REFERENCES User(id),
  CONSTRAINT cash_transfer_distinct CHECK(fromAccountId <> toAccountId),
  CONSTRAINT cash_transfer_positive CHECK(amountCents BETWEEN 1 AND 2147483647)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS CashMovement (
  id CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  accountId CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  type VARCHAR(16) NOT NULL,
  amountCents BIGINT NOT NULL,
  category VARCHAR(100) NOT NULL,
  description VARCHAR(1000) NOT NULL,
  occurredAt DATETIME(3) NOT NULL,
  paymentId CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NULL,
  reversalOf CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NULL,
  transferId CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NULL,
  source VARCHAR(16) NOT NULL DEFAULT 'MANUAL',
  createdBy CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  createdAt DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY(id),
  UNIQUE KEY cash_payment_once(paymentId),
  UNIQUE KEY cash_reversal_once(reversalOf),
  KEY cash_movement_account_date(accountId,occurredAt),
  KEY cash_movement_date(occurredAt),
  KEY cash_movement_transfer(transferId),
  CONSTRAINT cash_movement_account_fk FOREIGN KEY(accountId) REFERENCES CashAccount(id),
  CONSTRAINT cash_movement_payment_fk FOREIGN KEY(paymentId) REFERENCES Payment(id),
  CONSTRAINT cash_movement_reversal_fk FOREIGN KEY(reversalOf) REFERENCES CashMovement(id),
  CONSTRAINT cash_movement_transfer_fk FOREIGN KEY(transferId) REFERENCES CashTransfer(id),
  CONSTRAINT cash_movement_author_fk FOREIGN KEY(createdBy) REFERENCES User(id),
  CONSTRAINT cash_movement_positive CHECK(amountCents BETWEEN 1 AND 2147483647),
  CONSTRAINT cash_movement_type CHECK(type IN ('INCOME','EXPENSE')),
  CONSTRAINT cash_movement_source CHECK(source IN ('MANUAL','PAYMENT','TRANSFER','REVERSAL'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
