-- Operaciones ISP: activos individuales, movimientos inmutables desde la API,
-- visitas de instalación y muestras reales de diagnóstico con retención de 30 días.
CREATE TABLE IF NOT EXISTS `InventoryAsset` (
  `id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `name` VARCHAR(200) NOT NULL,
  `category` VARCHAR(100) NOT NULL,
  `brand` VARCHAR(100) NULL,
  `model` VARCHAR(100) NULL,
  `serialNumber` VARCHAR(160) NULL,
  `macAddress` VARCHAR(17) CHARACTER SET ascii COLLATE ascii_bin NULL,
  `costCents` INT UNSIGNED NOT NULL DEFAULT 0,
  `currency` CHAR(3) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'USD',
  `location` VARCHAR(500) NULL,
  `state` VARCHAR(20) NOT NULL DEFAULT 'AVAILABLE',
  `clientId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NULL,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`), UNIQUE KEY `inventory_serial_unique` (`serialNumber`),
  UNIQUE KEY `inventory_mac_unique` (`macAddress`), KEY `inventory_state_idx` (`state`,`createdAt`),
  KEY `inventory_client_idx` (`clientId`),
  CONSTRAINT `inventory_client_fk` FOREIGN KEY (`clientId`) REFERENCES `Client` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `inventory_state_check` CHECK (`state` IN ('AVAILABLE','ASSIGNED','IN_REPAIR','RETIRED')),
  CONSTRAINT `inventory_assignment_check` CHECK ((`state`='ASSIGNED' AND `clientId` IS NOT NULL) OR (`state`<>'ASSIGNED' AND `clientId` IS NULL)),
  CONSTRAINT `inventory_cost_check` CHECK (`costCents` <= 2147483647),
  CONSTRAINT `inventory_currency_check` CHECK (`currency` REGEXP '^[A-Z]{3}$'),
  CONSTRAINT `inventory_name_check` CHECK (CHAR_LENGTH(`name`) >= 1 AND CHAR_LENGTH(`category`) >= 1),
  CONSTRAINT `inventory_mac_check` CHECK (`macAddress` IS NULL OR `macAddress` REGEXP '^([A-F0-9]{2}:){5}[A-F0-9]{2}$')
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `InventoryMovement` (
  `id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `assetId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `action` VARCHAR(20) NOT NULL,
  `clientId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NULL,
  `fromState` VARCHAR(20) NULL,
  `toState` VARCHAR(20) NOT NULL,
  `userId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `note` TEXT NULL,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`), KEY `movement_asset_created_idx` (`assetId`,`createdAt`),
  KEY `movement_client_idx` (`clientId`,`createdAt`), KEY `movement_created_idx` (`createdAt`),
  CONSTRAINT `movement_asset_fk` FOREIGN KEY (`assetId`) REFERENCES `InventoryAsset` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `movement_client_fk` FOREIGN KEY (`clientId`) REFERENCES `Client` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `movement_user_fk` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `movement_origin_check` CHECK ((`action`='RECEIVE' AND `fromState` IS NULL) OR (`action`<>'RECEIVE' AND `fromState` IS NOT NULL)),
  CONSTRAINT `movement_transition_check` CHECK (
    (`action`='RECEIVE' AND `fromState` IS NULL AND `toState`='AVAILABLE' AND `clientId` IS NULL) OR
    (`action`='ASSIGN' AND `fromState`='AVAILABLE' AND `toState`='ASSIGNED' AND `clientId` IS NOT NULL) OR
    (`action`='RETURN' AND `fromState`='ASSIGNED' AND `toState`='AVAILABLE' AND `clientId` IS NOT NULL) OR
    (`action`='RETURN' AND `fromState`='IN_REPAIR' AND `toState`='AVAILABLE' AND `clientId` IS NULL) OR
    (`action`='REPAIR' AND `fromState`='AVAILABLE' AND `toState`='IN_REPAIR' AND `clientId` IS NULL) OR
    (`action`='RETIRE' AND `fromState` IN ('AVAILABLE','IN_REPAIR') AND `toState`='RETIRED' AND `clientId` IS NULL)
  )
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `Installation` (
  `id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `clientId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NULL,
  `prospectName` VARCHAR(200) NULL,
  `phone` VARCHAR(100) NULL,
  `address` VARCHAR(1000) NOT NULL,
  `zone` VARCHAR(500) NULL,
  `latitude` DOUBLE NULL,
  `longitude` DOUBLE NULL,
  `scheduledAt` DATETIME(3) NULL,
  `assignedUserId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NULL,
  `planId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NULL,
  `routerId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NULL,
  `status` VARCHAR(20) NOT NULL DEFAULT 'REQUESTED',
  `estimatedCents` INT UNSIGNED NOT NULL DEFAULT 0,
  `currency` CHAR(3) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'USD',
  `notes` TEXT NULL,
  `completedAt` DATETIME(3) NULL,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`), KEY `installation_schedule_idx` (`status`,`scheduledAt`),
  KEY `installation_assignee_idx` (`assignedUserId`,`scheduledAt`), KEY `installation_client_idx` (`clientId`),
  CONSTRAINT `installation_client_fk` FOREIGN KEY (`clientId`) REFERENCES `Client` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `installation_user_fk` FOREIGN KEY (`assignedUserId`) REFERENCES `User` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `installation_plan_fk` FOREIGN KEY (`planId`) REFERENCES `Plan` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `installation_router_fk` FOREIGN KEY (`routerId`) REFERENCES `Router` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `installation_status_check` CHECK (`status` IN ('REQUESTED','SCHEDULED','IN_PROGRESS','COMPLETED','CANCELLED')),
  CONSTRAINT `installation_contact_check` CHECK (`clientId` IS NOT NULL OR (`prospectName` IS NOT NULL AND CHAR_LENGTH(`prospectName`) > 0)),
  CONSTRAINT `installation_schedule_check` CHECK (`status` NOT IN ('SCHEDULED','IN_PROGRESS','COMPLETED') OR (`scheduledAt` IS NOT NULL AND `assignedUserId` IS NOT NULL)),
  CONSTRAINT `installation_completion_check` CHECK ((`status`='COMPLETED' AND `completedAt` IS NOT NULL) OR (`status`<>'COMPLETED' AND `completedAt` IS NULL)),
  CONSTRAINT `installation_estimate_check` CHECK (`estimatedCents` <= 2147483647),
  CONSTRAINT `installation_currency_check` CHECK (`currency` REGEXP '^[A-Z]{3}$'),
  CONSTRAINT `installation_address_check` CHECK (CHAR_LENGTH(`address`) > 0),
  CONSTRAINT `installation_latitude_check` CHECK (`latitude` IS NULL OR `latitude` BETWEEN -90 AND 90),
  CONSTRAINT `installation_longitude_check` CHECK (`longitude` IS NULL OR `longitude` BETWEEN -180 AND 180)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `TrafficSample` (
  `id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `serviceId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `sampledAt` DATETIME(3) NOT NULL,
  `uploadBps` DECIMAL(20,3) NULL,
  `downloadBps` DECIMAL(20,3) NULL,
  `uploadBytes` DECIMAL(24,0) NULL,
  `downloadBytes` DECIMAL(24,0) NULL,
  `averageMs` DECIMAL(14,3) NULL,
  `lossPercent` DECIMAL(7,4) NULL,
  PRIMARY KEY (`id`), UNIQUE KEY `traffic_service_time_unique` (`serviceId`,`sampledAt`),
  KEY `traffic_retention_idx` (`sampledAt`),
  CONSTRAINT `traffic_service_fk` FOREIGN KEY (`serviceId`) REFERENCES `Service` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `traffic_measurement_check` CHECK (`uploadBps` IS NOT NULL OR `downloadBps` IS NOT NULL OR `uploadBytes` IS NOT NULL OR `downloadBytes` IS NOT NULL OR `averageMs` IS NOT NULL OR `lossPercent` IS NOT NULL),
  CONSTRAINT `traffic_nonnegative_check` CHECK ((`uploadBps` IS NULL OR `uploadBps` >= 0) AND (`downloadBps` IS NULL OR `downloadBps` >= 0) AND (`uploadBytes` IS NULL OR `uploadBytes` >= 0) AND (`downloadBytes` IS NULL OR `downloadBytes` >= 0) AND (`averageMs` IS NULL OR `averageMs` >= 0)),
  CONSTRAINT `traffic_loss_check` CHECK (`lossPercent` IS NULL OR `lossPercent` BETWEEN 0 AND 100)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
