CREATE TABLE IF NOT EXISTS `PaymentPromise` (
  `id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `invoiceId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `amountCents` INT UNSIGNED NOT NULL,
  `currency` CHAR(3) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `promisedUntil` DATETIME(3) NOT NULL,
  `status` VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',
  `createdBy` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NULL,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `resolvedAt` DATETIME(3) NULL,
  `activeInvoiceId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin GENERATED ALWAYS AS (CASE WHEN `status` = 'ACTIVE' THEN `invoiceId` ELSE NULL END) PERSISTENT,
  PRIMARY KEY (`id`),
  UNIQUE KEY `payment_promise_active_invoice_unique` (`activeInvoiceId`),
  KEY `payment_promise_due_idx` (`status`,`promisedUntil`),
  KEY `payment_promise_invoice_idx` (`invoiceId`,`createdAt`),
  CONSTRAINT `payment_promise_invoice_fk` FOREIGN KEY (`invoiceId`) REFERENCES `Invoice` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `payment_promise_user_fk` FOREIGN KEY (`createdBy`) REFERENCES `User` (`id`) ON DELETE SET NULL,
  CONSTRAINT `payment_promise_status_check` CHECK (`status` IN ('ACTIVE','FULFILLED','EXPIRED','CANCELLED')),
  CONSTRAINT `payment_promise_amount_check` CHECK (`amountCents` BETWEEN 1 AND 2147483647),
  CONSTRAINT `payment_promise_currency_check` CHECK (`currency` REGEXP '^[A-Z]{3}$')
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `ServiceCharge` (
  `id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `serviceId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `name` VARCHAR(180) NOT NULL,
  `quantity` INT UNSIGNED NOT NULL DEFAULT 1,
  `unitCents` INT UNSIGNED NOT NULL,
  `currency` CHAR(3) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `recurrence` VARCHAR(20) NOT NULL,
  `active` TINYINT(1) NOT NULL DEFAULT 1,
  `consumedAt` DATETIME(3) NULL,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `service_charge_service_idx` (`serviceId`,`active`,`createdAt`),
  CONSTRAINT `service_charge_service_fk` FOREIGN KEY (`serviceId`) REFERENCES `Service` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `service_charge_quantity_check` CHECK (`quantity` BETWEEN 1 AND 1000),
  CONSTRAINT `service_charge_amount_check` CHECK (`unitCents` <= 2147483647 AND `quantity` * `unitCents` <= 2147483647),
  CONSTRAINT `service_charge_recurrence_check` CHECK (`recurrence` IN ('MONTHLY','ONE_TIME')),
  CONSTRAINT `service_charge_active_check` CHECK (`active` IN (0,1)),
  CONSTRAINT `service_charge_currency_check` CHECK (`currency` REGEXP '^[A-Z]{3}$')
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `ServiceDiscount` (
  `id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `serviceId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `name` VARCHAR(180) NOT NULL,
  `kind` VARCHAR(20) NOT NULL,
  `value` INT UNSIGNED NOT NULL,
  `currency` CHAR(3) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `startOn` DATE NOT NULL,
  `endOn` DATE NOT NULL,
  `active` TINYINT(1) NOT NULL DEFAULT 1,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `activeServiceId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin GENERATED ALWAYS AS (CASE WHEN `active` = 1 THEN `serviceId` ELSE NULL END) PERSISTENT,
  PRIMARY KEY (`id`),
  UNIQUE KEY `service_discount_active_service_unique` (`activeServiceId`),
  KEY `service_discount_service_idx` (`serviceId`,`startOn`,`endOn`),
  CONSTRAINT `service_discount_service_fk` FOREIGN KEY (`serviceId`) REFERENCES `Service` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `service_discount_kind_check` CHECK (`kind` IN ('FIXED','PERCENT')),
  CONSTRAINT `service_discount_value_check` CHECK (`value` >= 1 AND ((`kind` = 'PERCENT' AND `value` <= 10000) OR (`kind` = 'FIXED' AND `value` <= 2147483647))),
  CONSTRAINT `service_discount_dates_check` CHECK (`endOn` >= `startOn`),
  CONSTRAINT `service_discount_active_check` CHECK (`active` IN (0,1)),
  CONSTRAINT `service_discount_currency_check` CHECK (`currency` REGEXP '^[A-Z]{3}$')
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `InvoiceLine` (
  `id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `invoiceId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `type` VARCHAR(20) NOT NULL,
  `chargeId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NULL,
  `discountId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NULL,
  `position` INT UNSIGNED NOT NULL,
  `description` VARCHAR(768) NOT NULL,
  `quantity` INT UNSIGNED NOT NULL DEFAULT 1,
  `unitCents` INT NOT NULL,
  `totalCents` INT NOT NULL,
  `currency` CHAR(3) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `recurrence` VARCHAR(20) NULL,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `oneTimeChargeId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin GENERATED ALWAYS AS (CASE WHEN `type` = 'CHARGE' AND `recurrence` = 'ONE_TIME' THEN `chargeId` ELSE NULL END) PERSISTENT,
  PRIMARY KEY (`id`),
  UNIQUE KEY `invoice_line_position_unique` (`invoiceId`,`position`),
  UNIQUE KEY `invoice_line_once_unique` (`oneTimeChargeId`),
  KEY `invoice_line_charge_idx` (`chargeId`),
  KEY `invoice_line_discount_idx` (`discountId`),
  CONSTRAINT `invoice_line_invoice_fk` FOREIGN KEY (`invoiceId`) REFERENCES `Invoice` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `invoice_line_charge_fk` FOREIGN KEY (`chargeId`) REFERENCES `ServiceCharge` (`id`) ON DELETE SET NULL,
  CONSTRAINT `invoice_line_discount_fk` FOREIGN KEY (`discountId`) REFERENCES `ServiceDiscount` (`id`) ON DELETE SET NULL,
  CONSTRAINT `invoice_line_type_check` CHECK (`type` IN ('PLAN','CHARGE','DISCOUNT','LEGACY')),
  CONSTRAINT `invoice_line_quantity_check` CHECK (`quantity` BETWEEN 1 AND 1000),
  CONSTRAINT `invoice_line_money_check` CHECK (`totalCents` = CAST(`unitCents` AS SIGNED) * CAST(`quantity` AS SIGNED) AND ((`type` = 'DISCOUNT' AND `quantity` = 1 AND `unitCents` <= 0) OR (`type` <> 'DISCOUNT' AND `unitCents` >= 0))),
  CONSTRAINT `invoice_line_recurrence_check` CHECK (`recurrence` IS NULL OR `recurrence` IN ('MONTHLY','ONE_TIME')),
  CONSTRAINT `invoice_line_currency_check` CHECK (`currency` REGEXP '^[A-Z]{3}$')
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `InvoiceLine` (`id`,`invoiceId`,`type`,`position`,`description`,`quantity`,`unitCents`,`totalCents`,`currency`,`createdAt`)
SELECT LEFT(SHA2(CONCAT('legacy-invoice-line:',i.`id`),256),24),i.`id`,'LEGACY',0,'Servicio de Internet: importe conservado de la factura anterior al desglose',1,i.`amountCents`,i.`amountCents`,i.`currency`,i.`createdAt`
FROM `Invoice` i
WHERE NOT EXISTS (SELECT 1 FROM `InvoiceLine` l WHERE l.`invoiceId` = i.`id`);
