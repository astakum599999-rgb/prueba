-- User-authorized preference for new local records. This is not an FX conversion.
-- Existing plans, invoices, payments, invoice lines, contracts and cash retain their currencies.
INSERT INTO CompanyProfile (id,currency) VALUES ('primary','PEN')
ON DUPLICATE KEY UPDATE currency='PEN';
