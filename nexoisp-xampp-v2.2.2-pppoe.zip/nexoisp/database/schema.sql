CREATE TABLE IF NOT EXISTS `User` (
  `id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `name` VARCHAR(200) NOT NULL,
  `email` VARCHAR(254) NOT NULL,
  `passwordHash` VARCHAR(255) NOT NULL,
  `role` VARCHAR(20) NOT NULL DEFAULT 'VIEWER',
  `active` TINYINT(1) NOT NULL DEFAULT 1,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`), UNIQUE KEY `user_email_unique` (`email`),
  CONSTRAINT `user_role_check` CHECK (`role` IN ('ADMIN','BILLING','TECHNICIAN','VIEWER')),
  CONSTRAINT `user_active_check` CHECK (`active` IN (0,1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `ApiKey` (
  `id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `userId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `label` VARCHAR(100) NOT NULL,
  `prefix` VARCHAR(16) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `tokenHash` CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `expiresAt` DATETIME(3) NULL,
  `revokedAt` DATETIME(3) NULL,
  `lastUsedAt` DATETIME(3) NULL,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`), UNIQUE KEY `apikey_hash_unique` (`tokenHash`), KEY `apikey_user_idx` (`userId`),
  CONSTRAINT `apikey_user_fk` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `Session` (
  `id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `userId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `tokenHash` CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `expiresAt` DATETIME(3) NOT NULL,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`), UNIQUE KEY `session_hash_unique` (`tokenHash`),
  KEY `session_user_idx` (`userId`), KEY `session_expires_idx` (`expiresAt`),
  CONSTRAINT `session_user_fk` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `Client` (
  `id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `code` VARCHAR(40) NOT NULL,
  `name` VARCHAR(200) NOT NULL,
  `email` VARCHAR(254) NULL,
  `phone` VARCHAR(500) NULL,
  `document` VARCHAR(500) NULL,
  `address` VARCHAR(500) NULL,
  `latitude` DOUBLE NULL,
  `longitude` DOUBLE NULL,
  `zone` VARCHAR(500) NULL,
  `status` VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`), UNIQUE KEY `client_code_unique` (`code`), KEY `client_status_zone_idx` (`status`,`zone`(100)),
  CONSTRAINT `client_status_check` CHECK (`status` IN ('ACTIVE','SUSPENDED','RETIRED')),
  CONSTRAINT `client_latitude_check` CHECK (`latitude` IS NULL OR `latitude` BETWEEN -90 AND 90),
  CONSTRAINT `client_longitude_check` CHECK (`longitude` IS NULL OR `longitude` BETWEEN -180 AND 180)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `Plan` (
  `id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `name` VARCHAR(200) NOT NULL,
  `downloadKbps` INT UNSIGNED NOT NULL,
  `uploadKbps` INT UNSIGNED NOT NULL,
  `queueParent` VARCHAR(200) NOT NULL DEFAULT 'global',
  `priority` TINYINT UNSIGNED NOT NULL DEFAULT 8,
  `pppoeProfile` VARCHAR(200) NOT NULL DEFAULT 'default',
  `priceCents` INT UNSIGNED NOT NULL,
  `currency` CHAR(3) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'USD',
  `active` TINYINT(1) NOT NULL DEFAULT 1,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`), UNIQUE KEY `plan_name_unique` (`name`),
  CONSTRAINT `plan_speed_check` CHECK (`downloadKbps` BETWEEN 1 AND 10000000 AND `uploadKbps` BETWEEN 1 AND 10000000),
  CONSTRAINT `plan_priority_check` CHECK (`priority` BETWEEN 1 AND 8),
  CONSTRAINT `plan_price_check` CHECK (`priceCents` <= 100000000),
  CONSTRAINT `plan_currency_check` CHECK (`currency` REGEXP '^[A-Z]{3}$'),
  CONSTRAINT `plan_active_check` CHECK (`active` IN (0,1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `Router` (
  `id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `name` VARCHAR(200) NOT NULL,
  `host` VARCHAR(253) NOT NULL,
  `port` SMALLINT UNSIGNED NOT NULL,
  `transport` VARCHAR(20) NOT NULL DEFAULT 'REST',
  `username` VARCHAR(200) NOT NULL,
  `passwordEncrypted` TEXT NOT NULL,
  `useTls` TINYINT(1) NOT NULL DEFAULT 1,
  `verifyTls` TINYINT(1) NOT NULL DEFAULT 1,
  `cutAddressList` VARCHAR(63) NOT NULL DEFAULT 'CORTE_WISPHUB',
  `cutProfile` VARCHAR(200) NOT NULL DEFAULT 'Perfil_Corte',
  `paymentPortalIp` VARCHAR(45) CHARACTER SET ascii COLLATE ascii_bin NULL,
  `paymentPortalPort` SMALLINT UNSIGNED NOT NULL DEFAULT 80,
  `dhcpServer` VARCHAR(200) NOT NULL DEFAULT 'all',
  `hotspotServer` VARCHAR(200) NOT NULL DEFAULT 'all',
  `online` TINYINT(1) NULL,
  `lastSeenAt` DATETIME(3) NULL,
  `lastError` TEXT NULL,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`), UNIQUE KEY `router_name_unique` (`name`),
  CONSTRAINT `router_transport_check` CHECK (`transport` IN ('SOCKET','REST','SIMULATED')),
  CONSTRAINT `router_port_check` CHECK (`port` BETWEEN 1 AND 65535 AND `paymentPortalPort` BETWEEN 1 AND 65535),
  CONSTRAINT `router_tls_check` CHECK (`useTls` IN (0,1) AND `verifyTls` = 1),
  CONSTRAINT `router_online_check` CHECK (`online` IS NULL OR `online` IN (0,1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `Service` (
  `id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `clientId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `planId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `routerId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `type` VARCHAR(20) NOT NULL,
  `ipAddress` VARCHAR(45) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `macAddress` VARCHAR(17) CHARACTER SET ascii COLLATE ascii_bin NULL,
  `username` VARCHAR(100) COLLATE utf8mb4_bin NULL,
  `passwordEncrypted` TEXT NULL,
  `desiredState` VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',
  `suspensionReason` VARCHAR(24) NULL,
  `appliedState` VARCHAR(20) NULL,
  `syncStatus` VARCHAR(20) NOT NULL DEFAULT 'PENDING',
  `revision` INT UNSIGNED NOT NULL DEFAULT 1,
  `lastSyncAt` DATETIME(3) NULL,
  `lastError` TEXT NULL,
  `billingDay` TINYINT UNSIGNED NOT NULL DEFAULT 1,
  `dueDays` TINYINT UNSIGNED NOT NULL DEFAULT 10,
  `graceDays` TINYINT UNSIGNED NOT NULL DEFAULT 3,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `occupiedIp` VARCHAR(45) CHARACTER SET ascii COLLATE ascii_bin GENERATED ALWAYS AS (CASE WHEN `appliedState` IS NULL OR `appliedState` <> 'RETIRED' THEN `ipAddress` ELSE NULL END) STORED,
  `occupiedUsername` VARCHAR(100) COLLATE utf8mb4_bin GENERATED ALWAYS AS (CASE WHEN `appliedState` IS NULL OR `appliedState` <> 'RETIRED' THEN `username` ELSE NULL END) STORED,
  PRIMARY KEY (`id`),
  UNIQUE KEY `service_occupied_ip_unique` (`routerId`,`occupiedIp`),
  UNIQUE KEY `service_occupied_username_unique` (`routerId`,`occupiedUsername`),
  KEY `service_client_idx` (`clientId`), KEY `service_plan_idx` (`planId`),
  KEY `service_state_sync_idx` (`desiredState`,`syncStatus`),
  CONSTRAINT `service_client_fk` FOREIGN KEY (`clientId`) REFERENCES `Client` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `service_plan_fk` FOREIGN KEY (`planId`) REFERENCES `Plan` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `service_router_fk` FOREIGN KEY (`routerId`) REFERENCES `Router` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `service_type_check` CHECK (`type` IN ('PPPOE','SIMPLE_QUEUE','QUEUE_TREE','IP_MAC','HOTSPOT','DHCP')),
  CONSTRAINT `service_desired_state_check` CHECK (`desiredState` IN ('ACTIVE','SUSPENDED','RETIRED')),
  CONSTRAINT `service_applied_state_check` CHECK (`appliedState` IS NULL OR `appliedState` IN ('ACTIVE','SUSPENDED','RETIRED')),
  CONSTRAINT `service_reason_check` CHECK (`suspensionReason` IS NULL OR `suspensionReason` IN ('MANUAL','BILLING')),
  CONSTRAINT `service_sync_check` CHECK (`syncStatus` IN ('PENDING','SYNCED','FAILED')),
  CONSTRAINT `service_revision_check` CHECK (`revision` >= 1),
  CONSTRAINT `service_calendar_check` CHECK (`billingDay` BETWEEN 1 AND 28 AND `dueDays` <= 90 AND `graceDays` <= 90)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `Invoice` (
  `id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `number` VARCHAR(100) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `clientId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `serviceId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `period` CHAR(7) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `amountCents` INT UNSIGNED NOT NULL,
  `paidCents` INT UNSIGNED NOT NULL DEFAULT 0,
  `currency` CHAR(3) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `status` VARCHAR(20) NOT NULL DEFAULT 'OPEN',
  `issuedAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `dueAt` DATETIME(3) NOT NULL,
  `graceUntil` DATETIME(3) NOT NULL,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`), UNIQUE KEY `invoice_number_unique` (`number`),
  UNIQUE KEY `invoice_service_period_unique` (`serviceId`,`period`),
  KEY `invoice_client_idx` (`clientId`), KEY `invoice_status_grace_idx` (`status`,`graceUntil`),
  CONSTRAINT `invoice_client_fk` FOREIGN KEY (`clientId`) REFERENCES `Client` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `invoice_service_fk` FOREIGN KEY (`serviceId`) REFERENCES `Service` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `invoice_status_check` CHECK (`status` IN ('OPEN','PAID','VOID')),
  CONSTRAINT `invoice_money_check` CHECK (`amountCents` <= 2147483647 AND `paidCents` <= `amountCents`),
  CONSTRAINT `invoice_currency_check` CHECK (`currency` REGEXP '^[A-Z]{3}$'),
  CONSTRAINT `invoice_period_check` CHECK (`period` REGEXP '^[0-9]{4}-(0[1-9]|1[0-2])$'),
  CONSTRAINT `invoice_dates_check` CHECK (`dueAt` >= `issuedAt` AND `graceUntil` >= `dueAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `Payment` (
  `id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `invoiceId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `amountCents` INT UNSIGNED NOT NULL,
  `provider` VARCHAR(80) COLLATE utf8mb4_bin NOT NULL,
  `externalReference` VARCHAR(180) COLLATE utf8mb4_bin NOT NULL,
  `receivedAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`), UNIQUE KEY `payment_reference_unique` (`provider`,`externalReference`),
  KEY `payment_invoice_idx` (`invoiceId`),
  CONSTRAINT `payment_invoice_fk` FOREIGN KEY (`invoiceId`) REFERENCES `Invoice` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `payment_amount_check` CHECK (`amountCents` BETWEEN 1 AND 2147483647)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `WebhookEvent` (
  `id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `provider` VARCHAR(80) COLLATE utf8mb4_bin NOT NULL,
  `eventId` VARCHAR(180) COLLATE utf8mb4_bin NOT NULL,
  `bodyHash` CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`), UNIQUE KEY `webhook_event_unique` (`provider`,`eventId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `Ticket` (
  `id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `clientId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `assigneeId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NULL,
  `subject` VARCHAR(200) NOT NULL,
  `body` MEDIUMTEXT NOT NULL,
  `status` VARCHAR(20) NOT NULL DEFAULT 'OPEN',
  `priority` VARCHAR(20) NOT NULL DEFAULT 'NORMAL',
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`), KEY `ticket_client_idx` (`clientId`), KEY `ticket_state_assignee_idx` (`status`,`assigneeId`),
  KEY `ticket_assignee_idx` (`assigneeId`),
  CONSTRAINT `ticket_client_fk` FOREIGN KEY (`clientId`) REFERENCES `Client` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `ticket_assignee_fk` FOREIGN KEY (`assigneeId`) REFERENCES `User` (`id`) ON DELETE SET NULL,
  CONSTRAINT `ticket_status_check` CHECK (`status` IN ('OPEN','IN_PROGRESS','RESOLVED','CLOSED')),
  CONSTRAINT `ticket_priority_check` CHECK (`priority` IN ('LOW','NORMAL','HIGH','URGENT'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `TicketComment` (
  `id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `ticketId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `authorName` VARCHAR(200) NOT NULL,
  `body` MEDIUMTEXT NOT NULL,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`), KEY `comment_ticket_idx` (`ticketId`),
  CONSTRAINT `comment_ticket_fk` FOREIGN KEY (`ticketId`) REFERENCES `Ticket` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `Task` (
  `id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `kind` VARCHAR(30) NOT NULL,
  `status` VARCHAR(20) NOT NULL DEFAULT 'QUEUED',
  `payload` JSON NOT NULL,
  `result` JSON NULL,
  `error` TEXT NULL,
  `attempts` INT UNSIGNED NOT NULL DEFAULT 0,
  `dedupeKey` VARCHAR(191) COLLATE utf8mb4_bin NULL,
  `nextRunAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `lockedAt` DATETIME(3) NULL,
  `lockedBy` VARCHAR(128) CHARACTER SET ascii COLLATE ascii_bin NULL,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `startedAt` DATETIME(3) NULL,
  `completedAt` DATETIME(3) NULL,
  PRIMARY KEY (`id`), UNIQUE KEY `task_dedupe_unique` (`dedupeKey`),
  KEY `task_dispatch_idx` (`status`,`nextRunAt`,`lockedAt`),
  CONSTRAINT `task_kind_check` CHECK (`kind` IN ('SERVICE_SYNC','DIAGNOSTIC','ROUTER_TEST','FIREWALL_SYNC','BILLING_RUN','AUTOCUT_RUN','BULK_SYNC')),
  CONSTRAINT `task_status_check` CHECK (`status` IN ('QUEUED','RUNNING','SUCCEEDED','FAILED'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `AuditLog` (
  `id` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `userId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NULL,
  `action` VARCHAR(100) NOT NULL,
  `entityType` VARCHAR(100) NOT NULL,
  `entityId` VARCHAR(100) NULL,
  `details` JSON NULL,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`), KEY `audit_user_idx` (`userId`), KEY `audit_created_idx` (`createdAt`),
  CONSTRAINT `audit_user_fk` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `RateLimit` (
  `key` VARCHAR(191) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `attempts` INT UNSIGNED NOT NULL DEFAULT 0,
  `windowStartedAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `expiresAt` DATETIME(3) NULL,
  `updatedAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`key`), KEY `ratelimit_expires_idx` (`expiresAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
