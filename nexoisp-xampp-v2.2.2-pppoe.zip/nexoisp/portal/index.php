<?php
declare(strict_types=1);

ini_set('display_errors', '0');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('Referrer-Policy: same-origin');
if (!is_file(dirname(__DIR__) . '/storage/config.php')) {
    http_response_code(503);
    header('Content-Type: text/plain; charset=utf-8');
    echo 'El portal todavía no está instalado. Contacta a tu proveedor de Internet.';
    exit;
}
try {
    require_once dirname(__DIR__) . '/app/bootstrap.php';
    require_once dirname(__DIR__) . '/app/migrations.php';
    if (\Nexo\migrationNeedsUpgrade()) {
        http_response_code(503);
        header('Content-Type: text/plain; charset=utf-8');
        echo 'El proveedor está actualizando el portal. Inténtalo nuevamente más tarde.';
        exit;
    }
    $base = rtrim((string)\Nexo\config('base_path', ''), '/');
    $escape = static fn(string $value): string => htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    $template = file_get_contents(dirname(__DIR__) . '/app/index.html');
    if ($template === false) throw new \RuntimeException('Interfaz no disponible');
    $meta = '<base href="' . $escape($base . '/') . '"><meta name="nexoisp-mode" content="client"><meta name="nexoisp-api-base" content="' . $escape($base . '/api/v1') . '">';
    header('Content-Type: text/html; charset=utf-8');
    echo str_replace('<head>', '<head>' . $meta, $template);
} catch (\Throwable) {
    http_response_code(503);
    header('Content-Type: text/plain; charset=utf-8');
    echo 'El portal no está disponible en este momento. Contacta a tu proveedor de Internet.';
}
