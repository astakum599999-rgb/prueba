import { useEffect, useId, useRef, useState, type KeyboardEvent } from 'react';
import { Eye, EyeOff, RefreshCw, Save } from 'lucide-react';
import { api, ApiError } from './api';
import { errorMessage, Loading } from './ui';

interface PppoeAccount {
  id: string;
  source: 'imported' | 'service';
  routerId: string;
  routerName: string;
  username: string;
  profile?: string | null;
  present: boolean;
  canRevealPassword: boolean;
  passwordSource: 'MikroTik' | 'NexoISP';
  canEdit: boolean;
  editVersion: string;
  editBlockedReason?: string | null;
  pendingEdit?: { id: string; status: 'PREPARED' | 'UNCERTAIN'; createdAt: string } | null;
}

interface PppoeAccountsResponse { results: PppoeAccount[]; canRevealPassword: boolean; canEdit: boolean }
interface PppoePasswordResponse {
  status: 'AVAILABLE' | 'EMPTY' | 'UNAVAILABLE';
  password?: string;
  message: string;
  source: 'MikroTik' | 'NexoISP';
}
interface PppoeEditResponse { status: 'CONFIRMED' | 'UNCERTAIN' | 'FAILED'; message: string; operationId: string; account?: PppoeAccount }

function PppoeAccountFields({ clientId, account, canReveal, canEdit, refresh, updated, report }: { clientId: string; account: PppoeAccount; canReveal: boolean; canEdit: boolean; refresh: () => void; updated?: () => void; report: (message: string) => void }) {
  const fieldId = useId();
  const request = useRef<AbortController | null>(null);
  const [result, setResult] = useState<PppoePasswordResponse | null>(null);
  const [busy, setBusy] = useState<'reveal' | 'save' | 'reconcile' | ''>(''), [error, setError] = useState(''), [notice, setNotice] = useState('');
  const [username, setUsername] = useState(account.username), [newPassword, setNewPassword] = useState('');
  const [pending, setPending] = useState(Boolean(account.pendingEdit));
  useEffect(() => () => { request.current?.abort(); }, []);
  useEffect(() => { setPending(Boolean(account.pendingEdit)); }, [account.pendingEdit]);
  const editable = canEdit && account.canEdit && !pending;
  const changed = username !== account.username || newPassword !== '';
  const revealed = result?.status === 'AVAILABLE' || result?.status === 'EMPTY';
  const accountPath = `/clients/${encodeURIComponent(clientId)}/pppoe-accounts/${account.source}/${encodeURIComponent(account.id)}`;
  const reveal = async () => {
    if (busy) return;
    const controller = new AbortController();
    request.current = controller;
    setBusy('reveal'); setError(''); setResult(null);
    try {
      const response = await api<PppoePasswordResponse>(accountPath + '/password', { method: 'POST', body: '{}', signal: controller.signal, cache: 'no-store' });
      if (!controller.signal.aborted) setResult(response);
    } catch (err) {
      if (!controller.signal.aborted) setError(errorMessage(err));
    } finally {
      if (!controller.signal.aborted) { setBusy(''); request.current = null; }
    }
  };
  const save = async (reconcile = false) => {
    if (busy || (!reconcile && (!editable || !changed))) return;
    if (!reconcile && (username === '' || !username.trim())) { setError('Escribe un usuario PPPoE válido.'); return; }
    const controller = new AbortController();
    request.current = controller;
    setBusy(reconcile ? 'reconcile' : 'save'); setError(''); setNotice(''); setResult(null); report('');
    const payload = reconcile ? {} : {
      editVersion: account.editVersion,
      ...(username !== account.username ? { username } : {}),
      ...(newPassword !== '' ? { password: newPassword } : {}),
    };
    try {
      const response = await api<PppoeEditResponse>(accountPath + (reconcile ? '/reconcile' : ''), {
        method: reconcile ? 'POST' : 'PATCH', body: JSON.stringify(payload), signal: controller.signal, cache: 'no-store',
      });
      if (controller.signal.aborted) return;
      setNewPassword(''); setPending(response.status === 'UNCERTAIN'); report(response.message);
      if (response.status === 'CONFIRMED') {
        setUsername(response.account?.username ?? username); setNotice(response.message); updated?.();
      } else if (response.status === 'FAILED') {
        setUsername(account.username); setError(response.message);
      } else setError(response.message);
      refresh();
    } catch (err) {
      if (controller.signal.aborted) return;
      const uncertain = !(err instanceof ApiError) || err.status >= 500;
      if (uncertain) {
        setPending(true); setNewPassword('');
        setError('No se recibió una confirmación. Verifica los cambios pendientes antes de volver a guardar.');
        refresh();
      } else {
        setError(errorMessage(err));
        // A conflict must be reloaded explicitly, preserving the user's unsaved fields.
        if (err.status === 409) setNotice('Usa Actualizar estado para consultar la cuenta antes de intentar otro cambio.');
      }
    } finally {
      if (!controller.signal.aborted) { setBusy(''); request.current = null; }
    }
  };
  const stopImplicitSubmit = (event: KeyboardEvent<HTMLInputElement>) => { if (event.key === 'Enter') event.preventDefault(); };
  return <article className="pppoe-account">
    <div className="pppoe-account-heading"><strong>{account.routerName || 'Router asociado'}</strong><span className="subtle">{account.source === 'imported' ? 'Cuenta importada de MikroTik' : 'Servicio local en NexoISP'}</span></div>
    <div className="form-grid">
      <label className="field" htmlFor={`${fieldId}-username`}><span className="field-label">Usuario PPPoE</span><input id={`${fieldId}-username`} type="text" value={username} onChange={event => { setUsername(event.target.value); setNotice(''); }} readOnly={!editable} disabled={Boolean(busy)} maxLength={account.source === 'service' ? 100 : 255} onKeyDown={stopImplicitSubmit} autoComplete="off" spellCheck={false} /></label>
      <label className="field" htmlFor={`${fieldId}-password`}><span className="field-label">Contraseña PPPoE</span><input id={`${fieldId}-password`} type={revealed ? 'text' : 'password'} value={revealed ? result.password ?? '' : ''} placeholder={result?.status === 'EMPTY' ? 'Contraseña vacía' : result?.status === 'UNAVAILABLE' ? 'No disponible' : 'Sin consultar'} readOnly autoComplete="off" spellCheck={false} /></label>
    </div>
    {account.profile && <p className="field-hint">Perfil: {account.profile}</p>}
    <div className="pppoe-password-actions">
      {canReveal && account.canRevealPassword ? <button className="button small" type="button" disabled={Boolean(busy)} onClick={() => { if (revealed) setResult(null); else void reveal(); }}>{revealed ? <EyeOff size={15} /> : <Eye size={15} />}{busy === 'reveal' ? 'Consultando…' : revealed ? 'Ocultar contraseña' : 'Mostrar contraseña'}</button> : <span className="field-hint">{!canReveal ? 'Solo un administrador puede consultar la contraseña.' : account.source === 'imported' && !account.present ? 'Esta cuenta no aparece en la última importación del router.' : 'No hay una contraseña disponible para consultar.'}</span>}
      <span className="field-hint">Origen de la contraseña: {account.passwordSource}.</span>
    </div>
    {result && <p className="field-hint" role="status">{result.message}</p>}
    {canEdit && <div className="pppoe-edit-controls">
      {editable && <><label className="field" htmlFor={`${fieldId}-new-password`}><span className="field-label">Nueva contraseña PPPoE (opcional)</span><input id={`${fieldId}-new-password`} type="password" aria-label="Nueva contraseña PPPoE (opcional)" value={newPassword} onChange={event => { setNewPassword(event.target.value); setNotice(''); }} disabled={Boolean(busy)} maxLength={200} onKeyDown={stopImplicitSubmit} autoComplete="new-password" spellCheck={false} /><span className="field-hint">Déjala vacía para conservar la contraseña actual. La contraseña consultada no se envía al guardar.</span></label><p className="field-hint">Este botón actualiza la cuenta en MikroTik. El equipo del cliente deberá usar los nuevos datos al autenticarse de nuevo; no se solicita una desconexión.</p><button className="button small primary" type="button" disabled={Boolean(busy) || !changed} onClick={() => void save()}><Save size={15} />{busy === 'save' ? 'Guardando en MikroTik…' : 'Guardar cambios PPPoE en MikroTik'}</button></>}
      {!editable && account.editBlockedReason && <p className="field-hint">{account.editBlockedReason}</p>}
      {pending && <div className="alert warning"><span>Hay un cambio pendiente de confirmar. Verificar sólo consulta el router; no vuelve a aplicar los cambios.</span><button className="button small" type="button" disabled={Boolean(busy)} onClick={() => void save(true)}><RefreshCw size={14} />{busy === 'reconcile' ? 'Verificando…' : 'Verificar cambios pendientes'}</button></div>}
    </div>}
    {notice && <p className="field-hint" role="status">{notice}</p>}
    {error && <p className="alert error" role="alert">{error}</p>}
    {canEdit && <button className="button small ghost" type="button" disabled={Boolean(busy)} onClick={refresh}><RefreshCw size={14} />Actualizar estado</button>}
  </article>;
}

export function ClientPppoeFields({ clientId, updated }: { clientId: string; updated?: () => void }) {
  const [response, setResponse] = useState<PppoeAccountsResponse | null>(null);
  const [loading, setLoading] = useState(true), [error, setError] = useState(''), [reload, setReload] = useState(0), [message, setMessage] = useState('');
  useEffect(() => {
    const controller = new AbortController();
    setError(''); setLoading(true);
    void api<PppoeAccountsResponse>(`/clients/${encodeURIComponent(clientId)}/pppoe-accounts`, { signal: controller.signal, cache: 'no-store' })
      .then(value => { if (!controller.signal.aborted) setResponse(value); })
      .catch(err => { if (!controller.signal.aborted) setError(errorMessage(err)); })
      .finally(() => { if (!controller.signal.aborted) setLoading(false); });
    return () => { controller.abort(); };
  }, [clientId, reload]);
  return <section className="pppoe-fields" aria-label="Credenciales PPPoE">
    <h3 className="section-label">Credenciales PPPoE</h3>
    <p className="field-hint">Consulta las cuentas asociadas. Un administrador puede guardar cambios de usuario y contraseña en MikroTik mediante el botón de cada cuenta. Guardar cambios del cliente sólo modifica los datos administrativos.</p>
    {message && <p className="alert info" role="status">{message}</p>}{loading && !response ? <Loading label="Cargando cuentas PPPoE…" /> : <>{error && <div className="alert error" role="alert"><span>{error}</span><button className="button small" type="button" onClick={() => setReload(value => value + 1)}><RefreshCw size={14} />Reintentar</button></div>}{response?.results.length ? response.results.map(account => <PppoeAccountFields key={`${account.source}:${account.id}:${account.editVersion}:${account.pendingEdit?.id ?? ''}`} clientId={clientId} account={account} canReveal={response.canRevealPassword} canEdit={response.canEdit} refresh={() => setReload(value => value + 1)} updated={updated} report={setMessage} />) : !error && <p className="field-hint">Este cliente no tiene cuentas PPPoE asociadas. Para consultar una cuenta del router, usa «Importar secrets de MikroTik» en Clientes.</p>}</>}
  </section>;
}
