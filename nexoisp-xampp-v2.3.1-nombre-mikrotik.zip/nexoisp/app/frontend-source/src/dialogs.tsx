import { useCallback, useEffect, useRef, useState, type FormEvent } from 'react';
import { Activity, ArrowDownLeft, ArrowUpRight, Check, Copy, ExternalLink, LoaderCircle, Plus, RefreshCw, ShieldAlert } from 'lucide-react';
import { api, apiBase, choices, patch, post } from './api';
import { emptyLookups, formFields, formPayload, initialValues, type Lookups, type Row } from './forms';
import { RouterSecretInfo, canWrite, pageMeta, planImportInfo, type PageActions } from './pages';
import type { Capabilities, Client, Invoice, PageName, Plan, Router, Service, Task, Ticket, TrafficPoint, User } from './types';
import { Badge, date, DynamicForm, errorMessage, Loading, money, Modal, text, labels, type FormValues } from './ui';
import { ClientPppoeFields } from './ClientPppoeFields';
import { ClientNameSyncNotice, useClientNameSync } from './ClientNameSync';

export function FormDialog({ kind, row, capabilities, close, saved, notify }: { kind: string; row?: Row; capabilities: Capabilities; close: () => void; saved: () => void; notify: (message: string, error?: boolean) => void }) {
  const editing = Boolean(row?.id) && !['payment', 'invoice', 'keys'].includes(kind);
  const [values, setValues] = useState<FormValues>(() => initialValues(kind, row));
  const nameSyncEnabled = editing && kind === 'clients' && capabilities.clientNameSync === true;
  const nameSync = useClientNameSync(nameSyncEnabled ? String(row!.id) : undefined);
  const nameInitialized = useRef(false);
  useEffect(() => {
    if (nameSync.info && !nameInitialized.current) {
      nameInitialized.current = true;
      setValues(current => ({ ...current, name: nameSync.info!.currentName }));
    }
  }, [nameSync.info]);
  const [lookups, setLookups] = useState<Lookups>(emptyLookups), [loading, setLoading] = useState(['services', 'tickets', 'payment', 'invoice'].includes(kind));
  const [busy, setBusy] = useState(false), [error, setError] = useState(''), [token, setToken] = useState(''), [reload, setReload] = useState(0);
  useEffect(() => {
    let active = true;
    const load = async () => {
      const needed: Partial<Lookups> = {};
      if (kind === 'services') { const [clients, plans, routers] = await Promise.all([choices<Client>('/clients'), choices<Plan>('/plans'), choices<Router>('/routers')]); Object.assign(needed, { clients, plans, routers }); }
      if (kind === 'tickets') { const [clients, users] = await Promise.all([choices<Client>('/clients'), choices<User>('/technicians')]); Object.assign(needed, { clients, users }); }
      if (kind === 'invoice') needed.services = await choices<Service>('/services');
      if (kind === 'payment') needed.invoices = await choices<Invoice>('/invoices');
      if (active) { setLookups({ ...emptyLookups, ...needed }); setError(''); }
    };
    void load().catch(err => { if (active) setError(errorMessage(err)); }).finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [kind, reload]);
  useEffect(() => {
    if (kind !== 'payment' || !values.invoiceId) return;
    const invoice = lookups.invoices.find(invoice => invoice.id === values.invoiceId);
    if (invoice) setValues(current => ({ ...current, currency: invoice.currency, amount: ((invoice.amountCents - invoice.paidCents) / 100).toFixed(2) }));
  }, [kind, values.invoiceId, lookups.invoices]);
  const formValues = nameSyncEnabled ? { ...values, nameSyncEnabled: true, nameSyncSupported: nameSync.info?.supported === true, nameSyncCanChangeName: nameSync.info?.canChangeName === true } : values;
  const fields = formFields(kind, editing, lookups, capabilities, formValues);
  const verifyName = async () => {
    const result = await nameSync.reconcile();
    if (result?.status === 'CONFIRMED') {
      if (result.client) setValues(current => ({ ...current, name: result.client!.name }));
      saved(); notify(result.message);
    }
  };
  const onValues = (next: FormValues) => {
    if (kind === 'routers' && next.transport !== values.transport) { next.port = next.transport === 'SOCKET' ? '8729' : next.transport === 'SIMULATED' ? '8728' : '443'; next.useTls = next.transport !== 'SIMULATED'; }
    if (kind === 'routers' && next.useTls !== values.useTls && next.transport === 'SOCKET') next.port = next.useTls ? '8729' : '8728';
    setValues(next);
  };
  const submit = async (event: FormEvent) => {
    event.preventDefault();
    if (nameSyncEnabled && (nameSync.loading || nameSync.reconciling || nameSync.info?.pending)) {
      setError('Verifica el nombre pendiente o espera a que termine su consulta antes de guardar.'); return;
    }
    setBusy(true); setError('');
    try {
      if (kind === 'users' && values.password && String(values.password).length < 12) throw new Error('La contraseña debe tener al menos 12 caracteres.');
      if (kind === 'invoice' && !/^\d{4}-(0[1-9]|1[0-2])$/.test(String(values.period))) throw new Error('El periodo debe tener el formato AAAA-MM.');
      if (kind === 'plans' && String(values.price ?? '').trim() === '') throw new Error('Escribe el precio mensual local. MikroTik no proporciona una tarifa comercial.');
      const payload = formPayload(kind, fields, values, editing);
      if (nameSyncEnabled && nameSync.info?.supported && nameSync.info.editVersion && Object.hasOwn(payload, 'name')) payload.nameSyncVersion = nameSync.info.editVersion;
      const endpoint = kind === 'payment' ? '/payments' : kind === 'invoice' ? '/invoices' : `/${kind}`;
      const response = editing ? await patch<Record<string, unknown>>(`${endpoint}/${row!.id}`, payload) : await post<Record<string, unknown>>(endpoint, payload);
      saved();
      const syncedName = response.nameSync && typeof response.nameSync === 'object' ? response.nameSync as { status?: string; message?: string } : null;
      if (kind === 'clients' && syncedName?.status === 'CONFIRMED') { notify(syncedName.message || 'Nombre guardado en NexoISP y en el comentario de MikroTik.'); close(); return; }
      if (kind === 'keys') { setToken(String(response.token)); notify('Clave creada. Guárdala antes de cerrar esta ventana.'); }
      else { notify(kind === 'payment' ? capabilities.networkReadOnly === true ? 'Pago registrado localmente. La red permanece en solo lectura.' : 'Pago registrado. La reconexión aplicable se procesará en segundo plano.' : kind === 'services' ? 'Servicio guardado. Revisa su sincronización en Operaciones de red.' : 'Información guardada.'); close(); }
    } catch (err) { setError(errorMessage(err)); if (nameSyncEnabled) await nameSync.refresh(); }
    finally { setBusy(false); }
  };
  const singular = kind === 'invoice' ? 'factura' : kind === 'payment' ? 'pago' : pageMeta[kind as PageName]?.singular || 'registro';
  return <Modal title={token ? 'Tu clave de API está lista' : `${editing ? 'Editar' : kind === 'payment' ? 'Registrar' : 'Nuevo'} ${singular}`} description={token ? 'Por seguridad, este valor solo se muestra ahora.' : editing && kind === 'services' ? 'Para cambiar router, IP o tipo de conexión, retira este servicio y crea otro.' : 'Los campos con asterisco son obligatorios.'} close={close} wide={['services', 'routers'].includes(kind)}>{token ? <><div className="alert warning"><ShieldAlert size={19} /><span>Guarda esta clave en un gestor seguro. Cerrar esta ventana elimina el valor de la pantalla.</span></div><pre className="key-token" tabIndex={0}>{token}</pre><div className="inline-gap"><button className="button primary" onClick={() => { void (navigator.clipboard ? navigator.clipboard.writeText(token) : Promise.reject(new Error('Clipboard unavailable'))).then(() => notify('Clave copiada al portapapeles.')).catch(() => notify('No se pudo copiar. Selecciona el valor y cópialo manualmente.', true)); }}><Copy size={17} />Copiar clave</button><button className="button" onClick={close}>Ya la guardé</button></div></> : loading || nameSyncEnabled && nameSync.loading && !nameSync.info ? <Loading label="Cargando opciones del formulario…" /> : <>{error && <div className="alert error" role="alert">{error}{['services', 'tickets', 'payment', 'invoice'].includes(kind) && <button className="button small ghost" onClick={() => { setLoading(true); setReload(value => value + 1); }}>Recargar opciones</button>}</div>}{kind === 'services' && !editing && (!lookups.clients.length || !lookups.plans.some(plan => plan.active) || !lookups.routers.length) ? <div className="alert info">Para dar de alta un servicio, registra al menos un cliente, un plan activo y un router. Encontrarás cada módulo en el menú principal.</div> : kind === 'invoice' && !lookups.services.length ? <div className="alert info">Primero registra un servicio con un plan para generar su factura.</div> : kind === 'payment' && !lookups.invoices.some(invoice => invoice.status === 'OPEN') ? <div className="alert info">No hay facturas abiertas pendientes de pago.</div> : <DynamicForm fields={fields} values={values} setValues={onValues} submit={event => void submit(event)} busy={busy} submitDisabled={nameSyncEnabled && (nameSync.loading || nameSync.reconciling || Boolean(nameSync.info?.pending))} submitLabel={kind === 'payment' ? 'Registrar pago validado' : kind === 'keys' ? 'Crear clave de API' : editing ? 'Guardar cambios' : `Crear ${singular}`}>{nameSyncEnabled && <ClientNameSyncNotice state={nameSync} verify={() => void verifyName()} busy={busy} />}{editing && kind === 'clients' && capabilities.pppoeCredentials === true && <ClientPppoeFields key={String(row!.id)} clientId={String(row!.id)} updated={saved} />}{kind === 'payment' && <div className="alert info">Confirma que el dinero fue recibido antes de registrarlo. La reconexión solo procede cuando no existen facturas vencidas pendientes del servicio.</div>}{kind === 'routers' && !values.useTls && values.transport !== 'SIMULATED' && <div className="alert warning">Sin TLS, las credenciales viajan sin cifrar. Utiliza este protocolo únicamente dentro de una red privada protegida o una VPN.</div>}</DynamicForm>}</>}</Modal>;
}

function DetailLine({ label, value }: { label: string; value: unknown }) { return <div><span>{label}</span><strong>{text(value)}</strong></div>; }

export function DetailDialog({ kind, row, user, close, actions, notify, saved, extensions = false, networkReadOnly = false }: { kind: PageName; row: Row; user: User; close: () => void; actions: PageActions; notify: (message: string, error?: boolean) => void; saved: () => void; extensions?: boolean; networkReadOnly?: boolean }) {
  const [data, setData] = useState<Row>(row), [loading, setLoading] = useState(!['audit', 'keys', 'payments', 'users'].includes(kind)), [error, setError] = useState(''), [comment, setComment] = useState(''), [busy, setBusy] = useState(false);
  useEffect(() => {
    if (['audit', 'keys', 'payments', 'users'].includes(kind)) return;
    let active = true;
    api<Row>(`/${kind}/${row.id}`).then(result => { if (active) setData(result); }).catch(err => { if (active) setError(errorMessage(err)); }).finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [kind, row.id]);
  const edit = () => { close(); actions.form(kind, data); };
  const run = (action: string) => { close(); actions.action(action, data); };
  const submitComment = async (event: FormEvent) => {
    event.preventDefault(); setBusy(true);
    try { await post(`/tickets/${row.id}/comments`, { body: comment }); const ticket = await api<Row>(`/tickets/${row.id}`); setData(ticket); setComment(''); saved(); notify('Comentario agregado.'); }
    catch (err) { notify(errorMessage(err), true); }
    finally { setBusy(false); }
  };
  const details = () => {
    if (kind === 'clients') return <><div className="details-list"><DetailLine label="Código" value={data.code} /><DetailLine label="Nombre" value={data.name} /><DetailLine label="RFC / DNI" value={data.document} /><DetailLine label="Correo" value={data.email} /><DetailLine label="Teléfono" value={data.phone} /><DetailLine label="Zona" value={data.zone} /><DetailLine label="Dirección" value={data.address} /><DetailLine label="Estado" value={data.status} /></div>{Array.isArray(data.routerSecrets) && data.routerSecrets.length > 0 && <><h3 className="section-label">Origen MikroTik · solo lectura</h3><RouterSecretInfo row={data} detail /></>}{data.latitude !== null && data.latitude !== undefined && data.longitude !== null && data.longitude !== undefined && <a className="button" href={`https://www.openstreetmap.org/?mlat=${encodeURIComponent(String(data.latitude))}&mlon=${encodeURIComponent(String(data.longitude))}#map=17/${encodeURIComponent(String(data.latitude))}/${encodeURIComponent(String(data.longitude))}`} target="_blank" rel="noreferrer"><ExternalLink size={16} />Ver ubicación GPS</a>}</>;
    if (kind === 'services') {
      const service = data as unknown as Service;
      return <><div className="inline-gap" style={{ marginBottom: 18 }}><Badge value={service.desiredState} /><Badge value={service.syncStatus} /></div><div className="details-list"><DetailLine label="Cliente" value={service.client?.name || service.clientId} /><DetailLine label="Plan" value={service.plan?.name || service.planId} /><DetailLine label="Router" value={service.router?.name || service.routerId} /><DetailLine label="Conexión" value={service.type} /><DetailLine label="IP" value={service.ipAddress} /><DetailLine label="MAC" value={service.macAddress} /><DetailLine label="Usuario" value={service.username} /><DetailLine label="Estado confirmado en router" value={service.appliedState || 'Sin sincronizar'} /><DetailLine label="Última sincronización" value={date(service.lastSyncAt, true)} /><DetailLine label="Facturación UTC" value={`Día ${service.billingDay}, vence en ${service.dueDays} días + ${service.graceDays} de gracia`} /></div>{service.lastError && <div className="alert error">{service.lastError}</div>}{['ADMIN', 'TECHNICIAN'].includes(user.role) && service.desiredState !== 'RETIRED' && <div className="inline-gap"><button className="button" onClick={() => run('diagnostics')}><Activity size={17} />Diagnóstico</button>{extensions && <button className="button" onClick={() => run('traffic')}>Histórico de tráfico</button>}{!networkReadOnly && <><button className="button" onClick={() => run('sync')}><RefreshCw size={16} />Sincronizar</button><button className={`button ${service.desiredState === 'SUSPENDED' ? 'primary' : 'danger'}`} onClick={() => run(service.desiredState === 'SUSPENDED' ? 'reactivate' : 'suspend')}>{service.desiredState === 'SUSPENDED' ? 'Reactivar' : 'Suspender'}</button></>}</div>}</>;
    }
    if (kind === 'invoices') {
      const invoice = data as unknown as Invoice;
      return <><div className="inline-gap" style={{ marginBottom: 18 }}><Badge value={invoice.status} /><strong>{invoice.number}</strong></div><div className="details-list"><DetailLine label="Cliente" value={invoice.client?.name || invoice.clientId} /><DetailLine label="Periodo" value={invoice.period} /><DetailLine label="Importe" value={money(invoice.amountCents, invoice.currency)} /><DetailLine label="Pagado" value={money(invoice.paidCents, invoice.currency)} /><DetailLine label="Saldo pendiente" value={money(invoice.amountCents - invoice.paidCents, invoice.currency)} /><DetailLine label="Emisión" value={date(invoice.issuedAt, true)} /><DetailLine label="Vencimiento" value={date(invoice.dueAt, true)} /><DetailLine label="Gracia hasta" value={date(invoice.graceUntil, true)} /></div>{invoice.lines?.length ? <><h3 className="section-label">Conceptos facturados</h3>{invoice.lines.map((line, index) => <div className="invoice-line" key={line.id || index}><span>{line.description || line.name} <small>× {line.quantity}</small></span><strong>{money(line.totalCents ?? line.amountCents ?? line.quantity * line.unitCents, line.currency || invoice.currency)}</strong></div>)}</> : null}{extensions && <a className="button" href={`${apiBase.replace(/\/api\/v1$/, '')}/portal/documento.php?type=invoice&id=${encodeURIComponent(invoice.id)}`} target="_blank" rel="noreferrer">Ver factura para imprimir</a>}{invoice.payments?.length ? <><h3 className="section-label">Pagos de la factura</h3>{invoice.payments.map(payment => <div className="ticket-comment" key={payment.id}><strong>{money(payment.amountCents, invoice.currency)}</strong><div>{payment.externalReference}</div><div className="subtle">{payment.provider} · {date(payment.receivedAt, true)}</div></div>)}</> : null}{['ADMIN', 'BILLING'].includes(user.role) && invoice.status === 'OPEN' && <div className="inline-gap"><button className="button primary" onClick={() => { close(); actions.form('payment', { id: '', invoiceId: invoice.id, amount: ((invoice.amountCents - invoice.paidCents) / 100).toFixed(2), currency: invoice.currency }); }}>Registrar pago</button>{invoice.paidCents === 0 && <button className="button danger" onClick={() => run('void-invoice')}>Anular factura</button>}</div>}</>;
    }
    if (kind === 'tickets') {
      const ticket = data as unknown as Ticket;
      return <><div className="inline-gap" style={{ marginBottom: 18 }}><Badge value={ticket.status} /><Badge value={ticket.priority} /></div><h3>{ticket.subject}</h3><p style={{ whiteSpace: 'pre-wrap', lineHeight: 1.7 }}>{ticket.body}</p><div className="details-list"><DetailLine label="Cliente" value={ticket.client?.name || ticket.clientId} /><DetailLine label="Asignado a" value={ticket.assignee?.name || 'Sin asignar'} /><DetailLine label="Creado" value={date(ticket.createdAt, true)} /></div><h3 className="section-label">Seguimiento</h3>{ticket.comments?.length ? ticket.comments.map(item => <article className="ticket-comment" key={item.id}><div className="inline-gap"><strong>{item.authorName}</strong><span className="subtle">{date(item.createdAt, true)}</span></div><p style={{ whiteSpace: 'pre-wrap' }}>{item.body}</p></article>) : <p className="subtle">Todavía no hay comentarios.</p>}{canWrite('tickets', user.role) && <form onSubmit={event => void submitComment(event)}><label className="field"><span className="field-label">Agregar comentario</span><textarea value={comment} onChange={event => setComment(event.target.value)} required maxLength={5000} rows={3} /></label><button className="button primary" disabled={busy} type="submit"><Plus size={16} />{busy ? 'Guardando…' : 'Agregar comentario'}</button></form>}</>;
    }
    if (kind === 'routers') {
      const router = data as unknown as Router;
      return <><div className="details-list"><DetailLine label="Nombre" value={router.name} /><DetailLine label="Host / puerto" value={`${router.host}:${router.port}`} /><DetailLine label="Transporte" value={`${router.transport}${router.useTls ? ' (TLS)' : ''}`} /><DetailLine label="Usuario" value={router.username} /><DetailLine label="Address List de corte" value={router.cutAddressList} /><DetailLine label="Perfil de corte" value={router.cutProfile} /><DetailLine label="Portal HTTP" value={router.paymentPortalIp ? `${router.paymentPortalIp}:${router.paymentPortalPort}` : 'Sin redirección configurada'} /><DetailLine label="Última comunicación" value={date(router.lastSeenAt, true)} /></div>{router.lastError && <div className="alert error">{router.lastError}</div>}{['ADMIN', 'TECHNICIAN'].includes(user.role) && <div className="inline-gap"><button className="button" onClick={() => run('router-test')}>Probar conexión</button>{user.role === 'ADMIN' && !networkReadOnly && <button className="button" onClick={() => run('firewall')}>Configurar firewall de corte</button>}</div>}</>;
    }
    if (kind === 'plans') {
      const observed = planImportInfo(data), ratePending = observed && observed.rateStatus !== 'READY';
      return <><div className="details-list"><DetailLine label="Nombre" value={data.name} /><DetailLine label="Bajada" value={ratePending ? 'Pendiente de revisión' : `${Number(data.downloadKbps) / 1000} Mbps`} /><DetailLine label="Subida" value={ratePending ? 'Pendiente de revisión' : `${Number(data.uploadKbps) / 1000} Mbps`} /><DetailLine label="Precio mensual" value={observed?.priceConfigured === false ? 'Precio pendiente' : money(data.priceCents, data.currency)} /><DetailLine label="Queue Tree Parent" value={data.queueParent} /><DetailLine label="Prioridad" value={data.priority} /><DetailLine label="Perfil PPPoE / Hotspot" value={data.pppoeProfile} />{observed && <><DetailLine label="Router de origen" value={observed.routerName} /><DetailLine label="Perfil observado" value={observed.profileName} /></>}</div>{observed && <div className="alert info">{observed.reason || 'Plan copiado de un perfil MikroTik. La tarifa comercial se configura en este sistema.'} La edición local no aplica cambios al router.</div>}</>;
    }
    if (kind === 'users') return <div className="details-list"><DetailLine label="Nombre" value={data.name} /><DetailLine label="Correo" value={data.email} /><DetailLine label="Rol" value={data.role} /><DetailLine label="Cuenta" value={data.active ? 'Habilitada' : 'Deshabilitada'} /><DetailLine label="Alta" value={date(data.createdAt, true)} /></div>;
    if (kind === 'payments') { const invoice = data.invoice as Invoice | undefined; return <><div className="details-list"><DetailLine label="Referencia" value={data.externalReference} /><DetailLine label="Factura" value={invoice?.number || data.invoiceId} /><DetailLine label="Importe" value={money(data.amountCents, invoice?.currency)} /><DetailLine label="Proveedor" value={data.provider} /><DetailLine label="Fecha" value={date(data.receivedAt, true)} /></div>{extensions && <a className="button primary" href={`${apiBase.replace(/\/api\/v1$/, '')}/portal/documento.php?type=receipt&id=${encodeURIComponent(data.id)}`} target="_blank" rel="noreferrer">Ver comprobante para imprimir</a>}</>; }
    if (kind === 'keys') return <div className="details-list"><DetailLine label="Integración" value={data.label} /><DetailLine label="Identificador" value={`${text(data.prefix)}…`} /><DetailLine label="Creada" value={date(data.createdAt, true)} /><DetailLine label="Vencimiento" value={date(data.expiresAt, true)} /><DetailLine label="Último uso" value={date(data.lastUsedAt, true)} /><DetailLine label="Revocada" value={date(data.revokedAt, true)} /></div>;
    return <pre className="task-result">{JSON.stringify(data, null, 2)}</pre>;
  };
  const deletable = !(networkReadOnly && ['clients', 'services'].includes(kind)) && ['clients', 'services', 'plans', 'routers'].includes(kind) && canWrite(kind, user.role) && (kind !== 'clients' || user.role === 'ADMIN' || user.role === 'BILLING');
  return <Modal title={`Detalle de ${pageMeta[kind].singular}`} close={close} wide={kind === 'tickets'} footer={<><button className="button" onClick={close}>Cerrar</button>{canWrite(kind, user.role) && !(networkReadOnly && kind === 'services') && !(kind === 'services' && data.desiredState === 'RETIRED') && ['clients', 'services', 'plans', 'routers', 'tickets', 'users'].includes(kind) && <button className="button primary" onClick={edit}>Editar</button>}{deletable && <button className="button danger" onClick={() => run(`delete:${kind}`)}>{kind === 'routers' ? 'Eliminar router' : kind === 'plans' ? 'Desactivar plan' : `Retirar ${pageMeta[kind].singular}`}</button>}</>}>{loading ? <Loading /> : error ? <div className="alert error" role="alert">{error}</div> : details()}</Modal>;
}

export function TaskDialog({ id, close, onComplete }: { id: string; close: () => void; onComplete: () => void }) {
  const [task, setTask] = useState<Task | null>(null), [error, setError] = useState(''), [retry, setRetry] = useState(0);
  const completeRef = useRef(onComplete); completeRef.current = onComplete;
  useEffect(() => {
    let active = true, timer: number | undefined;
    const load = async () => {
      try {
        const result = await api<Task>(`/tasks/${id}`);
        if (!active) return;
        setTask(result); setError('');
        if (['SUCCEEDED', 'FAILED'].includes(result.status)) completeRef.current();
        else timer = window.setTimeout(() => void load(), 1500);
      } catch (err) { if (active) setError(errorMessage(err)); }
    };
    void load(); return () => { active = false; window.clearTimeout(timer); };
  }, [id, retry]);
  return <Modal title="Resultado de la operación" description={`Tarea ${id}`} close={close} wide><>{error && <div className="alert error" role="alert">{error}<button className="button small" onClick={() => setRetry(value => value + 1)}>Reintentar consulta</button></div>}{!task && !error ? <Loading label="Consultando el estado de la tarea…" /> : task && <><div className="inline-gap" style={{ marginBottom: 20 }}><Badge value={task.status} /><strong>{labels[task.kind] || task.kind}</strong></div><div className="details-list"><DetailLine label="Creada" value={date(task.createdAt, true)} /><DetailLine label="Intentos" value={task.attempts} /><DetailLine label="Completada" value={date(task.completedAt, true)} /></div>{!['SUCCEEDED', 'FAILED'].includes(task.status) && <div className="alert info"><LoaderCircle size={18} className="spinner" /><span>La operación sigue en segundo plano. Puedes cerrar esta ventana y consultar su resultado en Operaciones de red.</span></div>}{task.error && <div className="alert error" role="alert">{task.error}</div>}{task.result !== null && task.result !== undefined && <pre className="task-result" tabIndex={0}>{JSON.stringify(task.result, null, 2)}</pre>}</>}</></Modal>;
}

interface Diagnostic { simulated: boolean; sampledAt: string; serviceId: string; traffic: { uploadBps: number | null; downloadBps: number | null; uploadBytes: number | null; downloadBytes: number | null; source: string } | null; ping: { sent: number; received: number; lossPercent: number | null; averageMs: number | null; available: boolean; error?: string } }
export function TrafficChart({ points }: { points: TrafficPoint[] }) {
  if (points.length < 2) return <div className="empty-state"><Activity size={24} /><p>La gráfica aparecerá al recibir dos muestras válidas de tráfico.</p></div>;
  const maximum = Math.max(1000, ...points.flatMap(point => [point.rx, point.tx]));
  const width = 640, height = 180;
  const path = (key: 'rx' | 'tx') => points.map((point, index) => `${index === 0 ? 'M' : 'L'}${20 + index / Math.max(1, points.length - 1) * (width - 40)},${height - 20 - point[key] / maximum * (height - 40)}`).join(' ');
  return <div className="chart"><svg role="img" aria-label="Tráfico real de bajada y subida en bits por segundo" viewBox={`0 0 ${width} ${height}`}><title>Tráfico de servicio</title>{[0.25, 0.5, 0.75, 1].map(ratio => <line key={ratio} x1="20" x2={width - 20} y1={height - 20 - ratio * (height - 40)} y2={height - 20 - ratio * (height - 40)} stroke="currentColor" opacity="0.12" />)}<path d={path('rx')} stroke="#10b9a1" strokeWidth="2.5" fill="none" /><path d={path('tx')} stroke="#6d86f4" strokeWidth="2.5" fill="none" /></svg><div className="inline-gap subtle" style={{ justifyContent: 'space-between' }}><span>↓ Bajada · ↑ Subida</span><span>Escala: {(maximum / 1000000).toFixed(2)} Mbps</span><span>{new Date(points[points.length - 1]!.at).toLocaleTimeString('es')}</span></div></div>;
}

export function DiagnosticDialog({ service, close }: { service: Row; close: () => void }) {
  const [diagnostic, setDiagnostic] = useState<Diagnostic | null>(null), [task, setTask] = useState<Task | null>(null), [error, setError] = useState(''), [live, setLive] = useState(true), [reload, setReload] = useState(0), [points, setPoints] = useState<TrafficPoint[]>([]);
  const liveRef = useRef(live); liveRef.current = live;
  useEffect(() => {
    let active = true, timer: number | undefined;
    const run = async () => {
      try {
        const queued = await post<Task>(`/services/${service.id}/diagnostics`);
        if (!active) return;
        setTask(queued); setError('');
        const poll = async () => {
          try {
            const current = await api<Task>(`/tasks/${queued.id}`);
            if (!active) return;
            setTask(current);
            if (current.status === 'FAILED') { setError(current.error || 'El router no pudo completar el diagnóstico.'); return; }
            if (current.status !== 'SUCCEEDED') { timer = window.setTimeout(() => void poll(), 1200); return; }
            const result = current.result as Diagnostic;
            setDiagnostic(result);
            if (result?.traffic?.downloadBps !== null && result?.traffic?.downloadBps !== undefined && result.traffic.uploadBps !== null && !result.simulated) {
              setPoints(old => [...old.slice(-39), { at: new Date(result.sampledAt).getTime(), rx: result.traffic!.downloadBps!, tx: result.traffic!.uploadBps! }]);
            }
            if (liveRef.current) timer = window.setTimeout(() => void run(), 5000);
          } catch (err) { if (active) setError(errorMessage(err)); }
        };
        void poll();
      } catch (err) { if (active) setError(errorMessage(err)); }
    };
    void run(); return () => { active = false; window.clearTimeout(timer); };
  }, [service.id, reload]);
  const onLive = useCallback((checked: boolean) => { setLive(checked); if (checked && task && ['SUCCEEDED', 'FAILED'].includes(task.status)) setReload(value => value + 1); }, [task]);
  return <Modal title={`Diagnóstico · ${text(service.ipAddress)}`} description="Consulta ejecutada desde el router asignado al servicio." close={close} wide><div className="inline-gap" style={{ justifyContent: 'space-between', marginBottom: 20 }}><label className="checkbox-row"><input type="checkbox" checked={live} onChange={event => onLive(event.target.checked)} />Actualizar cada 5 segundos</label><button className="button small" disabled={task !== null && !['SUCCEEDED', 'FAILED'].includes(task.status)} onClick={() => setReload(value => value + 1)}><RefreshCw size={15} />Consultar</button></div>{error && <div className="alert error" role="alert">{error}</div>}{task && <div className="inline-gap" style={{ marginBottom: 18 }}><Badge value={task.status} />{diagnostic?.simulated && <Badge value="SIMULATED" />}</div>}{!diagnostic && !error ? <Loading label="Esperando respuesta del router…" /> : diagnostic && <>{diagnostic.simulated && <div className="alert warning">Este router es un simulador. No se generan mediciones de tráfico ni resultados de ping ficticios.</div>}<div className="diagnostic-grid"><div className="diagnostic-card"><ArrowDownLeft size={20} /><span className="subtle">Bajada</span><strong>{diagnostic.traffic?.downloadBps === null || diagnostic.traffic?.downloadBps === undefined ? 'Sin medición' : `${(diagnostic.traffic.downloadBps / 1000000).toFixed(2)} Mbps`}</strong></div><div className="diagnostic-card"><ArrowUpRight size={20} /><span className="subtle">Subida</span><strong>{diagnostic.traffic?.uploadBps === null || diagnostic.traffic?.uploadBps === undefined ? 'Sin medición' : `${(diagnostic.traffic.uploadBps / 1000000).toFixed(2)} Mbps`}</strong></div><div className="diagnostic-card"><Activity size={20} /><span className="subtle">Ping promedio</span><strong>{diagnostic.ping?.averageMs === null || diagnostic.ping?.averageMs === undefined ? 'Sin medición' : `${diagnostic.ping.averageMs.toFixed(1)} ms`}</strong></div><div className="diagnostic-card"><ShieldAlert size={20} /><span className="subtle">Pérdida de paquetes</span><strong>{diagnostic.ping?.lossPercent === null || diagnostic.ping?.lossPercent === undefined ? 'Sin medición' : `${diagnostic.ping.lossPercent.toFixed(0)} %`}</strong></div></div><TrafficChart points={points} />{diagnostic.ping?.error && <div className="alert warning">{diagnostic.ping.error}</div>}<p className="subtle">Muestra: {date(diagnostic.sampledAt, true)}{diagnostic.traffic?.source ? ` · Fuente: ${diagnostic.traffic.source}` : ''}. El historial se conserva únicamente mientras esta ventana está abierta.</p></>}</Modal>;
}

export function ConfirmDialog({ title, description, confirmLabel = 'Confirmar operación', confirm, close }: { title: string; description: string; confirmLabel?: string; confirm: () => Promise<void>; close: () => void }) {
  const [busy, setBusy] = useState(false), [error, setError] = useState('');
  return <Modal title={title} close={busy ? () => undefined : close} footer={<><button className="button" onClick={close} disabled={busy}>Cancelar</button><button className="button danger" disabled={busy} onClick={() => { setBusy(true); void confirm().then(close).catch(err => setError(errorMessage(err))).finally(() => setBusy(false)); }}>{busy ? <LoaderCircle size={16} className="spinner" /> : <Check size={16} />}{busy ? 'Procesando…' : confirmLabel}</button></>}><div className="alert warning"><ShieldAlert size={20} /><span>{description}</span></div>{error && <div className="alert error" role="alert">{error}</div>}</Modal>;
}
