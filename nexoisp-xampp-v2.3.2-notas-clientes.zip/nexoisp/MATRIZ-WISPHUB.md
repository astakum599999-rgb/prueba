# Alcance de NexoISP 2.3.1 con edición manual PPPoE respecto a WispHub

Esta distribución permite a ADMIN editar explícitamente usuario/contraseña de la cuenta PPPoE seleccionada y sincronizar Nombre completo con su comentario al guardar el cliente importado. Las importaciones son de lectura y los demás cambios de red siguen bloqueados. No habilita cortes, reconexiones, aprovisionamiento ni firewall; el worker nuevo no ejecuta trabajos mutantes antiguos ni programa facturación automática/autocorte.

NexoISP es una implementación propia para PHP/XAMPP. La revisión del manual y la API públicos se recoge en [REFERENCIAS-WISPHUB.md](REFERENCIAS-WISPHUB.md). Esta matriz describe el código entregado; no afirma identidad del producto, sus pantallas ni compatibilidad completa con su API privada.

| Área | Funcionalidad entregada | Límites concretos |
| --- | --- | --- |
| Acceso del personal | Sesiones, claves `Authorization: Api-Key`, cuatro roles y auditoría. | No reproduce todos los permisos ni endpoints de WispHub; una empresa por despliegue. |
| Clientes y servicios | Datos administrativos e historial de servicios existentes; importación de secrets a Clientes y nombre desde su comentario. | El comentario no vacío sustituye el nombre local al reimportar; se conservan contactos y demás datos. No crea servicios/facturas/tareas ni fusiona clientes por nombre. |
| Importación de secrets | Todos los registros locales de `/ppp/secret`, habilitados y deshabilitados, de cualquier tipo PPP; perfil, dirección, caller-id, comentario y fecha de lectura. | Hasta 20 000 por router y sujeto a límites de transporte; sin contraseñas PPP ni RADIUS externo. Identidad exacta router+usuario, incluso mayúsculas y espacios. Los ausentes se conservan como no observados. |
| Planes desde perfiles PPP | Observación de todos los perfiles de `/ppp/profile`; Rx/Tx base como subida/bajada; planes locales vinculados cuando se pueden representar sin inventar datos. | Precio y moneda no vienen del router. Plan nuevo inactivo con Precio pendiente, activación/facturación bloqueadas hasta tarifa explícita. Vacío/ilimitado/no representable o nombre que requiere revisión permanece observado y pendiente. |
| MikroTik | API Socket v6/v7 y REST v7 para consultas, conexión, inventario PPP y diagnóstico permitido. | Bloqueo de escrituras en API, controlador y transporte. La entrega no cambia perfiles, secrets, colas, firewall, DHCP, Hotspot ni FastTrack. |
| Cola y modo lectura | Cola MySQL e historial; el worker procesa pruebas de conexión y diagnósticos permitidos. | Las tareas que modificarían red quedan sin ejecutar. No se agenda facturación automática/autocorte; no se registra un servicio Windows automáticamente. Detén el worker antiguo antes de actualizar. |
| Portal del cliente | Acceso independiente a servicios, facturas, pagos, soporte y contratos propios. | Cuentas creadas por el personal; no hay registro público ni acceso a datos de otros clientes. |
| Pagos informados | Reporte del cliente, aprobación/rechazo y pago idempotente al aprobar. | Un reporte no acredita dinero ni reconecta por sí solo; no hay banco o pasarela preconfigurada. |
| Contratos | Condiciones, copia de datos del servicio, aceptación con nombre/fecha y documento imprimible. | No es firma electrónica certificada ni validación legal automática. |
| Facturación | Periodos, vencimiento, gracia, pagos parciales y desglose persistente por conceptos. | Documentos internos; sin CFDI, SUNAT, DIAN ni contabilidad fiscal certificada. |
| Cargos y descuentos | Conceptos únicos/mensuales, cantidades y descuento fijo o porcentual con vigencia. | Un descuento activo por servicio; no se recalculan facturas emitidas al modificar el catálogo. |
| Prorrateo | Vista previa y primera factura mensual proporcional por días. | No reproduce todas las variantes de prepago, postpago o cambio de calendario de la referencia. |
| Promesas de pago | Historial local de compromiso por factura, monto, vigencia y cancelación. | En lectura no dispara reconexión, autocorte ni tareas de red. No equivale a un pago ni elimina otras facturas vencidas. |
| Caja y gastos | Cuentas por moneda, ingresos, egresos, transferencias y contrapartidas con historial. | Registro interno manual; transferencias en la misma moneda y vinculación de pago a caja explícita, una vez por pago. |
| Inventario | Equipos por serie/MAC, asignación, devolución, reparación y retiro. | Sin compras, proveedores, stock fungible masivo ni ERP de almacenes. |
| Instalaciones | Agenda de clientes/prospectos, ubicación, técnico, plan, router, estados y notas. | Completar una visita no provisiona el servicio ni factura una instalación automáticamente. |
| Soporte | Tickets, prioridades, asignación y comentarios del personal o cliente autorizado. | Sin conectores de correo, chat, WhatsApp ni SLA automatizado de terceros. |
| Tráfico y diagnóstico | Diagnóstico permitido de servicios existentes y muestras conservadas durante 30 días. | Un secret habilitado no significa sesión activa. La importación no crea un servicio ni inventa una IP dinámica o una medición de tráfico. |
| Reportes y documentos | Cartera, facturación/recaudación por fechas, monedas, CSV y documentos imprimibles. | CSV de hasta 50 000 filas; PDF mediante impresión del navegador, sin certificación fiscal. |
| Empresa | Nombre, contacto, documento y notas para documentos del ISP. | Un perfil de empresa por instalación; sin integración tributaria. |
| Demostración de operación | Página estática con factura, suspensión, promesa y pagos simulados, datos ficticios y reloj virtual. | No llama a la API ni guarda datos reales, no conecta a MikroTik y no activa operaciones de red. |
| Actualización | Migraciones SHA-256, bloqueo MySQL y conservación de configuración/claves. | Requiere respaldo; MariaDB confirma DDL por sentencia y no hay rollback global de esta actualización. |

No se incluyen integraciones con OLT, TR-069, RADIUS, fichas Hotspot de venta masiva, televisión, bancos, procesadores de tarjetas o mensajería. Requieren implementaciones, contratos y credenciales específicos; un webhook genérico o registro manual no constituye una conexión verificada con ellos.

Las funciones de redirección de corte permanecen bloqueadas en esta distribución. El portal web puede utilizarse para consultar datos propios; publicar su URL no configura el router. Los registros financieros locales no producen reconexiones en modo lectura.

La entrega no accede a Windows o MikroTik del operador a distancia. Tras copiar el ZIP y aplicar las migraciones pendientes, incluida `010_client_name_sync`, el operador ejecuta las lecturas desde Clientes y Planes de Internet. Consulta [IMPORTAR-SECRETS.txt](IMPORTAR-SECRETS.txt), [IMPORTAR-PERFILES.txt](IMPORTAR-PERFILES.txt) y [DEMOSTRACION.txt](DEMOSTRACION.txt). Los SQL 001 a 009 se conservan intactos.

Las pruebas y sus límites se describen en [PRUEBAS.txt](PRUEBAS.txt). No se entregan código privado, identidad gráfica ni datos de clientes de WispHub.
