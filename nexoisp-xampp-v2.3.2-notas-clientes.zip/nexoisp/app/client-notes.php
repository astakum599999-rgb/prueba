<?php
declare(strict_types=1);
namespace Nexo;

/** Staff-only administrative data; never included in router or portal payloads. */
function clientNotesWarm(array $clientIds): void
{
    $ids = array_values(array_unique(array_filter($clientIds, 'is_string')));
    $missing = array_values(array_filter($ids, static fn(string $id): bool => !array_key_exists($id, $GLOBALS['nexo_client_notes'] ?? [])));
    if (!$missing) return;
    foreach ($missing as $id) $GLOBALS['nexo_client_notes'][$id] = null;
    foreach (array_chunk($missing, 500) as $batch) {
        $rows = fetchAll('SELECT clientId,notes FROM `ClientNote` WHERE clientId IN (' . implode(',', array_fill(0, count($batch), '?')) . ')', $batch);
        foreach ($rows as $row) $GLOBALS['nexo_client_notes'][$row['clientId']] = $row['notes'];
    }
}

function clientNotesGet(string $clientId): ?string
{
    clientNotesWarm([$clientId]);
    return $GLOBALS['nexo_client_notes'][$clientId] ?? null;
}

/** Caller shares the Client insert/update transaction for all-or-nothing saves. */
function clientNotesStore(string $clientId, ?string $notes): void
{
    if ($notes === null || $notes === '') {
        db()->prepare('DELETE FROM `ClientNote` WHERE clientId=?')->execute([$clientId]);
        unset($GLOBALS['nexo_client_notes'][$clientId]);
        return;
    }
    db()->prepare('INSERT INTO `ClientNote` (clientId,notes,updatedAt) VALUES (?,?,?) ON DUPLICATE KEY UPDATE notes=VALUES(notes),updatedAt=VALUES(updatedAt)')->execute([$clientId,$notes,now()]);
    unset($GLOBALS['nexo_client_notes'][$clientId]);
}
