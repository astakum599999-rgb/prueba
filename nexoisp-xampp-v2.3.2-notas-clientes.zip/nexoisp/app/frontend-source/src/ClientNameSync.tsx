import { useCallback, useEffect, useRef, useState } from 'react';
import { RefreshCw } from 'lucide-react';
import { api } from './api';
import type { Client } from './types';
import { errorMessage } from './ui';

export interface ClientNameSyncInfo {
  supported: boolean;
  canSync: boolean;
  canChangeName: boolean;
  pending: { id: string; status: string } | null;
  blockedReason?: string | null;
  editVersion: string | null;
  currentName: string;
  syncNeeded: boolean;
}
interface NameSyncVerification { status: 'CONFIRMED' | 'UNCERTAIN' | 'FAILED'; message: string; client?: Client }

export function useClientNameSync(clientId?: string) {
  const [info, setInfo] = useState<ClientNameSyncInfo | null>(null);
  const [loading, setLoading] = useState(Boolean(clientId));
  const [error, setError] = useState(''), [message, setMessage] = useState(''), [reconciling, setReconciling] = useState(false);
  const request = useRef<AbortController | null>(null), verification = useRef<AbortController | null>(null);
  const refresh = useCallback(async () => {
    if (!clientId) return null;
    request.current?.abort();
    const controller = new AbortController(); request.current = controller;
    setLoading(true); setError('');
    try {
      const next = await api<ClientNameSyncInfo>(`/clients/${encodeURIComponent(clientId)}/name-sync`, { cache: 'no-store', signal: controller.signal });
      if (controller.signal.aborted) return null;
      setInfo(next); return next;
    } catch (err) {
      if (!controller.signal.aborted) setError(errorMessage(err));
      return null;
    } finally {
      if (!controller.signal.aborted) { setLoading(false); request.current = null; }
    }
  }, [clientId]);
  useEffect(() => {
    void refresh();
    return () => { request.current?.abort(); verification.current?.abort(); };
  }, [refresh]);
  const reconcile = async (): Promise<NameSyncVerification | null> => {
    if (!clientId || reconciling) return null;
    const controller = new AbortController(); verification.current = controller;
    setReconciling(true); setError(''); setMessage('');
    try {
      const result = await api<NameSyncVerification>(`/clients/${encodeURIComponent(clientId)}/name-sync/reconcile`, { method: 'POST', body: '{}', cache: 'no-store', signal: controller.signal });
      if (controller.signal.aborted) return null;
      await refresh();
      if (controller.signal.aborted) return null;
      if (result.status === 'CONFIRMED') setMessage(result.message); else setError(result.message);
      return result;
    } catch (err) {
      if (!controller.signal.aborted) { await refresh(); if (!controller.signal.aborted) setError(errorMessage(err)); }
      return null;
    } finally {
      if (!controller.signal.aborted) { setReconciling(false); verification.current = null; }
    }
  };
  return { info, loading, error, message, reconciling, refresh, reconcile };
}

type NameSyncState = ReturnType<typeof useClientNameSync>;
export function ClientNameSyncNotice({ state, verify, busy }: { state: NameSyncState; verify: () => void; busy: boolean }) {
  return <section aria-label="Sincronización del nombre">
    {state.info?.supported && <p className="field-hint">Guardar cambios también actualiza el comentario de la cuenta PPPoE correspondiente en MikroTik. El nombre completo y el usuario PPPoE son datos distintos.</p>}
    {state.info?.syncNeeded && !state.info.pending && state.info.canSync && <div className="alert info">El nombre guardado en NexoISP difiere del comentario observado. Al guardar se enviará este nombre al MikroTik, aunque no vuelvas a escribirlo.</div>}
    {state.info?.blockedReason && <div className="alert warning">{state.info.blockedReason}</div>}
    {state.info?.pending && <div className="alert warning"><span>El cambio de nombre está pendiente de confirmar. Verificar sólo consulta el router y no repite la escritura.</span><button className="button small" type="button" disabled={busy || state.loading || state.reconciling} onClick={verify}><RefreshCw size={15} />{state.reconciling ? 'Verificando nombre…' : 'Verificar nombre pendiente'}</button></div>}
    {state.message && <div className="alert info" role="status">{state.message}</div>}
    {state.error && <div className="alert error" role="alert"><span>{state.error}</span><button className="button small" type="button" disabled={busy || state.loading || state.reconciling} onClick={() => void state.refresh()}><RefreshCw size={15} />Actualizar estado del nombre</button></div>}
  </section>;
}
