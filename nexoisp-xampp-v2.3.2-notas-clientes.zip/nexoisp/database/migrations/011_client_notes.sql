-- Notas administrativas internas. No son el comentario del secret MikroTik.
CREATE TABLE IF NOT EXISTS `ClientNote` (
  `clientId` CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `notes` TEXT NOT NULL,
  `updatedAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`clientId`),
  CONSTRAINT `client_note_client_fk` FOREIGN KEY (`clientId`) REFERENCES `Client` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
