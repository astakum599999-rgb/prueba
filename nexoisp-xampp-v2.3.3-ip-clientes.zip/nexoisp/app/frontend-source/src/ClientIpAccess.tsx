import { useCallback, useEffect, useRef, useState, type FormEvent } from 'react';
import { createPortal } from 'react-dom';
import { ExternalLink, RefreshCw } from 'lucide-react';
import type { ClientIpAddress } from './types';
import { api } from './api';
import { date, errorMessage, Modal } from './ui';

/** Only literal IP hosts are accepted; pool names, credentials and URLs are not. */
export function clientIpHost(address: string): string | null {
  if (/^(?:0|[1-9]\d{0,2})(?:\.(?:0|[1-9]\d{0,2})){3}$/.test(address)) {
    const parts = address.split('.').map(Number);
    if (parts.some(part => part > 255) || parts[0] === 0 || parts[0] === 127 || parts[0]! >= 224) return null;
    return address;
  }
  if (!address.includes(':') || !/^[a-f\d:.]+$/i.test(address)) return null;
  try {
    const host = new URL(`http://[${address}]/`).hostname;
    if (host === '[::]' || host === '[::1]' || /^\[ff/i.test(host)) return null;
    return host;
  } catch { return null; }
}

export function clientIpUrl(address: string, protocol: string, port: string): string | null {
  const host = clientIpHost(address);
  if (!host || !['http', 'https'].includes(protocol) || !/^\d{1,5}$/.test(port) || Number(port) < 1 || Number(port) > 65535) return null;
  try {
    const url = new URL(`${protocol}://${host}:${Number(port)}/`);
    return url.href;
  } catch { return null; }
}

function ClientIpDialog({ entry, clientName, close }: { entry: ClientIpAddress; clientName: string; close: () => void }) {
  const initialProtocol = window.location.protocol === 'https:' ? 'https' : 'http';
  const [protocol, setProtocol] = useState(initialProtocol), [port, setPort] = useState(initialProtocol === 'https' ? '443' : '80');
  const [url, setUrl] = useState(() => clientIpUrl(entry.address, initialProtocol, initialProtocol === 'https' ? '443' : '80'));
  const [reload, setReload] = useState(0), [waiting, setWaiting] = useState(true), [error, setError] = useState('');
  const apply = (event: FormEvent) => {
    event.preventDefault();
    const next = clientIpUrl(entry.address, protocol, port);
    if (!next) { setError('Elige HTTP o HTTPS y un puerto entre 1 y 65535.'); return; }
    setError(''); setWaiting(true); setUrl(next); setReload(value => value + 1);
  };
  const sameOrigin = url !== null && new URL(url).origin === window.location.origin;
  const mixedContent = url !== null && window.location.protocol === 'https:' && new URL(url).protocol === 'http:';
  const embed = url !== null && !sameOrigin && !mixedContent;
  return <Modal title={`Acceso al router del cliente · ${entry.address}`} description={clientName} close={close} wide>
    <p className="field-hint">Se abre la interfaz web del equipo en la IP del cliente. Inicia sesión con el usuario y la contraseña propios de ese equipo.</p>
    <div className="client-ip-origin"><strong className="mono">{entry.address}</strong><span>{entry.routerName || 'Router asignado'} · {entry.source === 'PPP_ACTIVE' ? 'IP observada en sesión PPP activa' : entry.source === 'SERVICE' ? 'IP asignada al servicio' : 'IP configurada en el secret PPP'}</span>{entry.observedAt && <span>Última observación: {date(entry.observedAt, true)}</span>}</div>
    <form className="client-ip-access-form" onSubmit={apply}>
      <label className="field"><span className="field-label">Protocolo web</span><select aria-label="Protocolo web" value={protocol} onChange={event => { setProtocol(event.target.value); setPort(event.target.value === 'https' ? '443' : '80'); }}><option value="http">HTTP</option><option value="https">HTTPS</option></select></label>
      <label className="field"><span className="field-label">Puerto web</span><input aria-label="Puerto web" type="number" inputMode="numeric" min={1} max={65535} step={1} required value={port} onChange={event => setPort(event.target.value)} /></label>
      <button className="button" type="submit"><RefreshCw size={16} />Abrir acceso</button>
    </form>
    {error && <div className="alert error" role="alert">{error}</div>}
    <div className="client-ip-url"><span className="mono">{url}</span>{url && <a className="button small" href={url} target="_blank" rel="noopener noreferrer"><ExternalLink size={15} />Abrir en otra pestaña</a>}</div>
    <p className="field-hint">Tu navegador necesita conexión a esta IP, directamente o mediante VPN. Algunos equipos bloquean su interfaz dentro de un recuadro; en ese caso usa «Abrir en otra pestaña». Una IP registrada o una sesión PPP activa no confirma que su interfaz web esté disponible.</p>
    {sameOrigin && <div className="alert warning">La dirección elegida corresponde al mismo origen que este panel. Usa otra pestaña para evitar cargar el sistema dentro de sí mismo.</div>}
    {mixedContent && <div className="alert warning">Este panel usa HTTPS y el navegador puede bloquear el acceso HTTP dentro del recuadro. Abre el equipo en otra pestaña o utiliza HTTPS si está disponible.</div>}
    {embed && <div className="client-ip-frame-wrap">{waiting && <p className="field-hint" role="status">Cargando interfaz del equipo…</p>}<iframe key={`${url}:${reload}`} title={`Interfaz web del router del cliente ${entry.address}`} className="client-ip-frame" src={url} referrerPolicy="no-referrer" sandbox="allow-forms allow-scripts allow-same-origin allow-popups allow-popups-to-escape-sandbox" onLoad={() => setWaiting(false)} onError={() => { setWaiting(false); setError('No se pudo cargar el acceso dentro del recuadro. Prueba abrirlo en otra pestaña.'); }} /></div>}
  </Modal>;
}

interface ActiveIpLookup { results: ClientIpAddress[]; message: string }

export function ClientIpAddresses({ addresses, clientName, clientId, canQueryActive = false }: { addresses: ClientIpAddress[] | undefined; clientName: string; clientId: string; canQueryActive?: boolean }) {
  const [selected, setSelected] = useState<ClientIpAddress | null>(null);
  const [activeAddresses, setActiveAddresses] = useState<ClientIpAddress[]>([]), [querying, setQuerying] = useState(false);
  const [queryMessage, setQueryMessage] = useState(''), [queryError, setQueryError] = useState('');
  const request = useRef<AbortController | null>(null);
  useEffect(() => () => { request.current?.abort(); }, []);
  const close = useCallback(() => setSelected(null), []);
  const queryActive = async () => {
    if (request.current || !canQueryActive) return;
    const controller = new AbortController(); request.current = controller;
    setQuerying(true); setQueryMessage(''); setQueryError('');
    try {
      const result = await api<ActiveIpLookup>(`/clients/${encodeURIComponent(clientId)}/ip-addresses/active`, { cache: 'no-store', signal: controller.signal });
      if (!controller.signal.aborted) {
        setActiveAddresses(Array.isArray(result.results) ? result.results : []);
        setQueryMessage(typeof result.message === 'string' ? result.message : 'Consulta finalizada.');
      }
    } catch (error) {
      if (!controller.signal.aborted) setQueryError(errorMessage(error));
    } finally {
      if (!controller.signal.aborted) { setQuerying(false); request.current = null; }
    }
  };
  const entries = [...activeAddresses, ...(Array.isArray(addresses) ? addresses : [])];
  const seen = new Set<string>();
  const valid = entries.filter(entry => {
    if (!entry || typeof entry.address !== 'string' || clientIpHost(entry.address) === null) return false;
    const key = `${entry.routerId}:${entry.address}`;
    if (seen.has(key)) return false;
    seen.add(key); return true;
  });
  return <>
    {valid.length ? <div className="client-ip-list">{valid.map(entry => <div className="client-ip-entry" key={`${entry.routerId}:${entry.address}`}><button className="text-link mono client-ip-button" type="button" aria-label={`Abrir router del cliente en ${entry.address} (${entry.routerName})`} onClick={() => setSelected(entry)}>{entry.address}</button><div className="table-secondary">{entry.routerName || 'Router asignado'} · {entry.source === 'PPP_ACTIVE' ? 'Sesión PPP observada' : entry.source === 'SERVICE' ? 'Servicio' : 'Secret PPP'}</div></div>)}</div> : <span className="subtle">Sin IP registrada</span>}
    {canQueryActive && <button className="button small ghost client-ip-query" type="button" disabled={querying} onClick={() => void queryActive()}><RefreshCw size={13} className={querying ? 'spinner' : ''} />{querying ? 'Consultando IP…' : 'Consultar IP actual'}</button>}
    {queryMessage && <div className="table-secondary client-ip-query-message" role="status">{queryMessage}</div>}
    {queryError && <div className="table-secondary client-ip-query-message error-text" role="alert">{queryError}</div>}
    {selected && createPortal(<ClientIpDialog entry={selected} clientName={clientName} close={close} />, document.body)}
  </>;
}
