import { useEffect, useState, type ReactNode } from 'react';
import { Activity, ArrowDownLeft, ArrowUpRight, CircleDollarSign, ClipboardList, CreditCard, Download, FileText, KeyRound, LifeBuoy, MoreHorizontal, Network, Pencil, Plus, RefreshCw, Router as RouterIcon, Search, Server, ShieldCheck, Trash2, Users, Wifi } from 'lucide-react';
import { api } from './api';
import RouterProfiles from './RouterProfiles';
import { ClientIpAddresses } from './ClientIpAccess';
import type { Capabilities, ClientIpAddress, Dashboard, PageName, PageResult, ProfileImportInfo, Role, RouterSecret, User } from './types';
import type { Row } from './forms';
import { Badge, date, EmptyState, errorMessage, Loading, money, Pagination, SearchBox, text, labels } from './ui';

export const pageMeta: Record<PageName, { title: string; description: string; singular: string; icon: typeof Users }> = {
  dashboard: { title: 'Centro de operaciones', description: 'Una visión clara de tu red y tu negocio.', singular: '', icon: Activity },
  clients: { title: 'Clientes', description: 'Cada conexión comienza con una buena relación.', singular: 'cliente', icon: Users },
  services: { title: 'Servicios de Internet', description: 'Altas, sincronización y control de tus conexiones.', singular: 'servicio', icon: Wifi },
  plans: { title: 'Planes de Internet', description: 'Velocidades, precios y políticas de servicio.', singular: 'plan', icon: ClipboardList },
  routers: { title: 'Routers y nodos', description: 'La infraestructura que mantiene a todos conectados.', singular: 'router', icon: RouterIcon },
  invoices: { title: 'Facturación', description: 'Control de vencimientos, periodos y saldos pendientes.', singular: 'factura', icon: FileText },
  payments: { title: 'Pagos', description: 'Cobros registrados y reconexiones automáticas.', singular: 'pago', icon: CreditCard },
  tickets: { title: 'Soporte técnico', description: 'Resuelve incidencias con contexto y seguimiento.', singular: 'ticket', icon: LifeBuoy },
  tasks: { title: 'Operaciones de red', description: 'Cada tarea asíncrona, su progreso y su resultado.', singular: 'tarea', icon: Activity },
  users: { title: 'Equipo y permisos', description: 'Accesos individuales para cada responsabilidad.', singular: 'usuario', icon: ShieldCheck },
  keys: { title: 'Claves de API', description: 'Integra tus herramientas con claves personales y revocables.', singular: 'clave', icon: KeyRound },
  'portal-accounts': { title: 'Acceso de clientes', description: 'Cuentas independientes para el portal de tus clientes.', singular: 'acceso', icon: Users },
  'payment-reports': { title: 'Pagos reportados', description: 'Valida los comprobantes enviados desde el portal.', singular: 'reporte de pago', icon: CreditCard },
  contracts: { title: 'Contratos', description: 'Condiciones de servicio y aceptación del cliente.', singular: 'contrato', icon: FileText },
  'payment-promises': { title: 'Promesas de pago', description: 'Acuerdos de cobro con monto y fecha de cumplimiento.', singular: 'promesa', icon: CircleDollarSign },
  'service-charges': { title: 'Cargos de servicio', description: 'Cargos mensuales y conceptos de una sola ocasión.', singular: 'cargo', icon: ClipboardList },
  'service-discounts': { title: 'Descuentos', description: 'Bonificaciones por servicio con vigencia definida.', singular: 'descuento', icon: CircleDollarSign },
  'inventory-assets': { title: 'Inventario', description: 'Equipos disponibles, asignados y en reparación.', singular: 'equipo', icon: Server },
  'inventory-movements': { title: 'Movimientos de equipos', description: 'Trazabilidad de entradas, entregas y devoluciones.', singular: 'movimiento', icon: ClipboardList },
  installations: { title: 'Agenda de instalaciones', description: 'Solicitudes, visitas y asignación del equipo técnico.', singular: 'instalación', icon: LifeBuoy },
  'cash-accounts': { title: 'Cajas y cuentas', description: 'Saldos operativos por cuenta y moneda.', singular: 'cuenta', icon: CreditCard },
  'cash-movements': { title: 'Ingresos y gastos', description: 'Entradas, salidas y contrapartidas con referencia.', singular: 'movimiento', icon: CircleDollarSign },
  reports: { title: 'Reportes financieros', description: 'Cartera y recaudación por fechas, con exportación CSV.', singular: 'reporte', icon: Activity },
  'company-settings': { title: 'Mi empresa', description: 'Identidad del ISP, datos de contacto y condiciones del portal.', singular: 'configuración', icon: ShieldCheck },
  audit: { title: 'Registro de auditoría', description: 'Trazabilidad de las acciones de tu equipo.', singular: 'registro', icon: Search },
};

const relation = (row: Row, key: string) => row[key] && typeof row[key] === 'object' ? row[key] as Record<string, unknown> : {};
export const planImportInfo = (row: Row): ProfileImportInfo | null => row.profileImport && typeof row.profileImport === 'object' ? row.profileImport as ProfileImportInfo : null;
const countFormat = (value: number) => new Intl.NumberFormat('es').format(value);
export const canWrite = (page: PageName, role: Role) => {
  if (page === 'keys') return true;
  if (role === 'ADMIN') return !['dashboard', 'tasks', 'audit'].includes(page);
  if (role === 'BILLING') return ['clients', 'invoices', 'payments', 'tickets'].includes(page);
  if (role === 'TECHNICIAN') return ['clients', 'services', 'tickets'].includes(page);
  return false;
};

export interface PageActions { form: (kind: string, row?: Row) => void; details: (kind: PageName, row: Row) => void; action: (action: string, row?: Row, ids?: string[]) => void }
export const canRetry = (role: Role, kind: unknown) => role === 'ADMIN' || role === 'BILLING' && ['BILLING_RUN', 'AUTOCUT_RUN'].includes(String(kind)) || role === 'TECHNICIAN' && ['SERVICE_SYNC', 'DIAGNOSTIC', 'ROUTER_TEST', 'BULK_SYNC'].includes(String(kind));
export function RouterSecretInfo({ row, detail = false }: { row: Row; detail?: boolean }) {
  const secrets = Array.isArray(row.routerSecrets) ? row.routerSecrets as RouterSecret[] : [];
  if (!secrets.length) return detail ? null : <span className="subtle">Registro local</span>;
  return <div className="router-secret-list">{secrets.map(secret => <section className={detail ? 'router-secret-detail' : 'router-secret-origin'} key={secret.id}>
    <strong className="mono">{secret.username}</strong><div className="table-secondary">{secret.routerName} · Perfil {secret.profile || 'Sin perfil informado'}</div>
    <div className="table-secondary mono">{secret.remoteAddress || 'Dinámica / pool'}</div>
    <div className="table-secondary">{secret.present === false ? 'No observado en la última lectura' : secret.disabled ? 'Secret deshabilitado' : 'Secret habilitado'}</div>
    {detail && <><div className="details-list"><div><span>Tipo PPP</span><strong>{secret.pppService || 'Sin informar'}</strong></div><div><span>Dirección local</span><strong>{secret.localAddress || 'No fijada'}</strong></div><div><span>Caller ID / MAC</span><strong>{secret.callerId || 'Sin restricción informada'}</strong></div><div><span>Última lectura</span><strong>{date(secret.lastSeenAt, true)}</strong></div></div>{secret.comment && <p className="secret-comment">{secret.comment}</p>}<p className="subtle">El estado habilitado del secret no confirma una sesión conectada.</p></>}
  </section>)}</div>;
}

interface Column { label: string; render: (row: Row) => ReactNode; className?: string }

function columns(page: PageName, secretImport = false, clientIpAccess = false, canQueryActive = false): Column[] {
  switch (page) {
    case 'clients': return [
      { label: 'Cliente', render: row => <><div className="table-primary">{text(row.name)}</div><div className="table-secondary">{text(row.code)} · {text(row.document, 'Sin documento')}</div></> },
      ...(secretImport ? [{ label: 'Origen MikroTik', render: (row: Row) => <RouterSecretInfo row={row} /> }] : []),
      clientIpAccess ? { label: 'IP', render: row => <ClientIpAddresses addresses={row.ipAddresses as ClientIpAddress[] | undefined} clientName={text(row.name)} clientId={row.id} canQueryActive={canQueryActive} /> } : { label: 'Contacto', render: row => <><div>{text(row.email)}</div><div className="table-secondary">{text(row.phone)}</div></> },
      { label: 'Zona', render: row => text(row.zone) },
      { label: 'Estado', render: row => <Badge value={row.status} /> },
      { label: 'Alta', render: row => date(row.createdAt) },
    ];
    case 'services': return [
      { label: 'Servicio / cliente', render: row => <><div className="table-primary mono">{text(row.ipAddress)}</div><div className="table-secondary">{text(relation(row, 'client').name, text(row.clientId))}</div></> },
      { label: 'Plan / conexión', render: row => <><div>{text(relation(row, 'plan').name)}</div><div className="table-secondary">{text(row.type)}</div></> },
      { label: 'Router', render: row => text(relation(row, 'router').name) },
      { label: 'Estado deseado / aplicado', render: row => <><Badge value={row.desiredState} /><div className="table-secondary">Aplicado: {row.appliedState ? text(row.appliedState) : 'sin confirmar'}</div></> },
      { label: 'Sincronización', render: row => <><Badge value={row.syncStatus} />{Boolean(row.lastError) && <div className="table-secondary" title={text(row.lastError)}>Revisar error en detalle</div>}</> },
    ];
    case 'plans': return [
      { label: 'Plan', render: row => <><div className="table-primary">{text(row.name)}</div><div className="table-secondary">Perfil {text(row.pppoeProfile)}</div></> },
      { label: 'Velocidad', render: row => planImportInfo(row) && planImportInfo(row)!.rateStatus !== 'READY' ? <span className="subtle">Velocidad pendiente de revisión</span> : <div><span className="inline-gap"><ArrowDownLeft size={14} />{Number(row.downloadKbps) / 1000} Mbps</span><span className="inline-gap table-secondary"><ArrowUpRight size={14} />{Number(row.uploadKbps) / 1000} Mbps</span></div> },
      { label: 'Precio mensual', render: row => planImportInfo(row)?.priceConfigured === false ? <span className="profile-price-pending">Precio pendiente</span> : <strong>{money(row.priceCents, row.currency)}</strong> },
      { label: 'Queue Tree', render: row => <><div>{text(row.queueParent)}</div><div className="table-secondary">Prioridad {text(row.priority)}</div></> },
      { label: 'Disponibilidad', render: row => <Badge value={row.active ? 'ACTIVE' : 'RETIRED'}>{row.active ? 'Disponible' : 'Inactivo'}</Badge> },
    ];
    case 'routers': return [
      { label: 'Router', render: row => <><div className="table-primary">{text(row.name)}</div><div className="table-secondary mono">{text(row.host)}:{text(row.port)}</div></> },
      { label: 'Protocolo', render: row => <Badge value={row.transport}>{row.transport === 'SIMULATED' ? 'Simulado' : `${text(row.transport)}${row.useTls ? ' · TLS' : ''}`}</Badge> },
      { label: 'Estado de conexión', render: row => <Badge value={row.online === null ? 'PENDING' : row.online ? 'ACTIVE' : 'FAILED'}>{row.online === null ? 'Sin comprobar' : row.online ? 'En línea' : 'Sin conexión'}</Badge> },
      { label: 'Última comunicación', render: row => date(row.lastSeenAt, true) },
    ];
    case 'invoices': return [
      { label: 'Factura', render: row => <><div className="table-primary">{text(row.number)}</div><div className="table-secondary">Periodo {text(row.period)}</div></> },
      { label: 'Cliente', render: row => text(relation(row, 'client').name, text(row.clientId)) },
      { label: 'Total / saldo', render: row => <><strong>{money(row.amountCents, row.currency)}</strong><div className="table-secondary">Saldo {money(Number(row.amountCents) - Number(row.paidCents), row.currency)}</div></> },
      { label: 'Vencimiento', render: row => <><div>{date(row.dueAt)}</div><div className="table-secondary">Gracia hasta {date(row.graceUntil)}</div></> },
      { label: 'Estado', render: row => <Badge value={row.status} /> },
    ];
    case 'payments': return [
      { label: 'Pago', render: row => <><div className="table-primary">{text(row.externalReference)}</div><div className="table-secondary">{text(row.provider)}</div></> },
      { label: 'Factura', render: row => text(relation(row, 'invoice').number, text(row.invoiceId)) },
      { label: 'Importe recibido', render: row => <strong>{money(row.amountCents, relation(row, 'invoice').currency)}</strong> },
      { label: 'Fecha', render: row => date(row.receivedAt, true) },
    ];
    case 'tickets': return [
      { label: 'Solicitud', render: row => <><div className="table-primary">{text(row.subject)}</div><div className="table-secondary">{text(relation(row, 'client').name)}</div></> },
      { label: 'Prioridad', render: row => <Badge value={row.priority} /> },
      { label: 'Estado', render: row => <Badge value={row.status} /> },
      { label: 'Técnico', render: row => text(relation(row, 'assignee').name, 'Sin asignar') },
      { label: 'Actualización', render: row => date(row.updatedAt, true) },
    ];
    case 'tasks': return [
      { label: 'Operación', render: row => <><div className="table-primary">{labels[String(row.kind)] || text(row.kind)}</div><div className="table-secondary mono">{text(row.id).slice(-12)}</div></> },
      { label: 'Estado', render: row => <Badge value={row.status} /> },
      { label: 'Intentos', render: row => text(row.attempts, '0') },
      { label: 'Creación', render: row => date(row.createdAt, true) },
      { label: 'Finalización', render: row => date(row.completedAt, true) },
    ];
    case 'users': return [
      { label: 'Miembro del equipo', render: row => <><div className="table-primary">{text(row.name)}</div><div className="table-secondary">{text(row.email)}</div></> },
      { label: 'Permisos', render: row => <Badge value={row.role} /> },
      { label: 'Cuenta', render: row => <Badge value={row.active ? 'ACTIVE' : 'RETIRED'}>{row.active ? 'Habilitada' : 'Deshabilitada'}</Badge> },
      { label: 'Alta', render: row => date(row.createdAt) },
    ];
    case 'keys': return [
      { label: 'Integración', render: row => <div className="table-primary">{text(row.label)}</div> },
      { label: 'Identificador', render: row => <span className="mono">{text(row.prefix)}…</span> },
      { label: 'Estado', render: row => <Badge value={row.revokedAt ? 'RETIRED' : row.expiresAt && new Date(String(row.expiresAt)) < new Date() ? 'SUSPENDED' : 'ACTIVE'}>{row.revokedAt ? 'Revocada' : row.expiresAt && new Date(String(row.expiresAt)) < new Date() ? 'Vencida' : 'Activa'}</Badge> },
      { label: 'Último uso', render: row => date(row.lastUsedAt, true) },
      { label: 'Vencimiento', render: row => date(row.expiresAt, true) },
    ];
    case 'audit': return [
      { label: 'Acción', render: row => <div className="table-primary">{text(row.action)}</div> },
      { label: 'Recurso', render: row => <><div>{text(row.entityType)}</div><div className="table-secondary mono">{text(row.entityId)}</div></> },
      { label: 'Usuario', render: row => text(relation(row, 'user').name, 'Sistema') },
      { label: 'Fecha', render: row => date(row.createdAt, true) },
    ];
    default: return [];
  }
}

export function DashboardPage({ refresh, actions, networkReadOnly = false }: { refresh: number; actions: PageActions; networkReadOnly?: boolean }) {
  const [data, setData] = useState<Dashboard | null>(null);
  const [error, setError] = useState('');
  useEffect(() => {
    let active = true;
    const load = () => api<Dashboard>('/dashboard').then(result => { if (active) { setData(result); setError(''); } }).catch(err => { if (active) setError(errorMessage(err)); });
    void load();
    const timer = window.setInterval(() => void load(), 15000);
    return () => { active = false; window.clearInterval(timer); };
  }, [refresh]);
  if (error && !data) return <div className="alert error" role="alert">{error}</div>;
  if (!data) return <Loading />;
  const stats = [
    { label: 'Clientes activos', value: data.counts.activeClients, hint: `${countFormat(data.counts.clients)} clientes en total`, icon: Users },
    { label: 'Servicios de Internet', value: data.counts.services, hint: `${countFormat(data.counts.suspendedClients)} clientes suspendidos`, icon: Wifi },
    { label: 'Routers en línea', value: data.counts.onlineRouters, hint: `${countFormat(data.counts.routers)} routers registrados`, icon: RouterIcon },
    { label: 'Tickets abiertos', value: data.counts.openTickets, hint: `${countFormat(data.counts.pendingTasks)} operaciones pendientes`, icon: LifeBuoy },
  ];
  return <>{error && <div className="alert warning" role="alert">No se pudo actualizar el resumen: {error}</div>}<div className="stats-grid">{stats.map(stat => <article className="stat-card" key={stat.label}><div className="stat-icon"><stat.icon size={21} /></div><div className="stat-label">{stat.label}</div><div className="stat-value">{countFormat(stat.value)}</div><div className="stat-hint">{stat.hint}</div></article>)}</div><div className="split-grid"><section className="panel"><header className="panel-heading"><div><h2 className="panel-title">Balance de facturación</h2><p className="subtle">Importes acumulados, separados por moneda.</p></div><CircleDollarSign size={22} /></header><div className="panel-body">{data.billing.length ? data.billing.map(group => <div className="metric-strip" key={group.currency}><div><span className="subtle">Facturado · {group.currency}</span><strong>{money(group.invoicedCents, group.currency)}</strong></div><div><span className="subtle">Cobrado</span><strong>{money(group.paidCents, group.currency)}</strong></div><div><span className="subtle">Por cobrar</span><strong>{money(group.outstandingCents, group.currency)}</strong></div></div>) : <EmptyState icon={<CircleDollarSign size={25} />} title="Tu facturación, en orden" description="El resumen aparecerá al generar las primeras facturas." />}</div></section><section className="panel"><header className="panel-heading"><div><h2 className="panel-title">Estado operativo</h2><p className="subtle">Conectividad y solicitudes pendientes.</p></div><Network size={22} /></header><div className="panel-body"><div className="details-list"><div><span>Clientes suspendidos</span><strong>{countFormat(data.counts.suspendedClients)}</strong></div><div><span>Tareas en cola / proceso</span><strong>{countFormat(data.counts.pendingTasks)}</strong></div><div><span>Routers sin conexión confirmada</span><strong>{countFormat(Math.max(0, data.counts.routers - data.counts.onlineRouters))}</strong></div></div><div className="alert info">{networkReadOnly ? 'Modo de red solo lectura: las consultas no cambian la configuración del MikroTik y la automatización de red permanece bloqueada.' : 'Los cambios de servicio se aplican en segundo plano. Comprueba el estado de sincronización después de cada operación.'}</div></div></section></div><div className="split-grid"><section className="panel"><header className="panel-heading"><h2 className="panel-title">Últimas facturas</h2><FileText size={20} /></header>{data.recentInvoices.length ? <div className="table-wrap"><table className="data-table"><thead><tr><th>Factura / cliente</th><th>Total</th><th>Estado</th></tr></thead><tbody>{data.recentInvoices.map(invoice => <tr key={invoice.id}><td><button className="table-primary text-link" onClick={() => actions.details('invoices', invoice as unknown as Row)}>{invoice.number}</button><div className="table-secondary">{invoice.client?.name}</div></td><td>{money(invoice.amountCents, invoice.currency)}</td><td><Badge value={invoice.status} /></td></tr>)}</tbody></table></div> : <EmptyState title="Todavía no hay facturas" description="La facturación automática utilizará el calendario de cada servicio." />}</section><section className="panel"><header className="panel-heading"><h2 className="panel-title">Actividad reciente</h2><Activity size={20} /></header>{data.recentTasks.length ? <div className="table-wrap"><table className="data-table"><thead><tr><th>Operación</th><th>Creada</th><th>Estado</th></tr></thead><tbody>{data.recentTasks.map(task => <tr key={task.id}><td><button className="table-primary text-link" onClick={() => actions.details('tasks', task as unknown as Row)}>{labels[task.kind] || task.kind}</button></td><td>{date(task.createdAt, true)}</td><td><Badge value={task.status} /></td></tr>)}</tbody></table></div> : <EmptyState icon={<Activity size={25} />} title="Sin operaciones recientes" description="Las sincronizaciones, diagnósticos y cortes se registrarán aquí." />}</section></div></>;
}

export function ResourcePage({ page, user, refresh, actions, extensions = false, capabilities = { simulatedRouters: false } }: { page: PageName; user: User; refresh: number; actions: PageActions; extensions?: boolean; capabilities?: Capabilities }) {
  const [data, setData] = useState<PageResult<Row>>({ results: [], count: 0, page: 1, pageSize: 15 });
  const [search, setSearch] = useState(''), [query, setQuery] = useState(''), [status, setStatus] = useState('');
  const [pageNumber, setPageNumber] = useState(1), [loading, setLoading] = useState(true), [error, setError] = useState('');
  const [tick, setTick] = useState(0), [selection, setSelection] = useState<string[]>([]);
  useEffect(() => { const timer = window.setTimeout(() => { setQuery(search); setPageNumber(1); }, 300); return () => window.clearTimeout(timer); }, [search]);
  useEffect(() => { setPageNumber(1); setSelection([]); }, [status]);
  useEffect(() => {
    let active = true;
    setLoading(true);
    const params = new URLSearchParams({ page: String(pageNumber), pageSize: '15', search: query, q: query, ...(status ? { status } : {}) });
    api<PageResult<Row>>(`/${page}?${params}`).then(result => { if (active) { setData(result); if (!result.results.length && result.count > 0 && pageNumber > 1) setPageNumber(Math.ceil(result.count / 15)); setError(''); setSelection(old => old.filter(id => result.results.some(row => row.id === id))); } }).catch(err => { if (active) setError(errorMessage(err)); }).finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [page, pageNumber, query, status, refresh, tick]);
  useEffect(() => {
    if (!['tasks', 'services', 'routers'].includes(page)) return;
    const timer = window.setInterval(() => setTick(value => value + 1), page === 'tasks' ? 5000 : 15000);
    return () => window.clearInterval(timer);
  }, [page]);
  const meta = pageMeta[page], Icon = meta.icon;
  const readOnly = capabilities.networkReadOnly === true;
  const canCreate = canWrite(page, user.role) && !(readOnly && page === 'services'), canNetwork = ['ADMIN', 'TECHNICIAN'].includes(user.role), canBilling = ['ADMIN', 'BILLING'].includes(user.role);
  const canChangeNetwork = canNetwork && !readOnly;
  const tableColumns = columns(page, capabilities.secretImport === true, capabilities.clientIpAccess === true, canNetwork);
  const filters: Record<string, string[]> = { clients: ['ACTIVE', 'SUSPENDED', 'RETIRED'], services: ['ACTIVE', 'SUSPENDED', 'RETIRED'], invoices: ['OPEN', 'PAID', 'VOID'], tickets: ['OPEN', 'IN_PROGRESS', 'RESOLVED', 'CLOSED'], tasks: ['QUEUED', 'RUNNING', 'SUCCEEDED', 'FAILED'] };
  return <><div className="page-actions" style={{ justifyContent: 'flex-end', marginBottom: 20 }}>{page === 'invoices' && canBilling && extensions && <button className="button" onClick={() => actions.form('prorate')}><FileText size={16} />Primera factura prorrateada</button>}{page === 'invoices' && canBilling && !readOnly && <button className="button" onClick={() => actions.action('billing')}><RefreshCw size={16} />Facturación mensual</button>}{page === 'services' && canBilling && !readOnly && <button className="button" onClick={() => actions.action('autocut')}><ShieldCheck size={16} />Revisar autocorte</button>}{page === 'plans' && capabilities.profileImport === true && canNetwork && <button className="button" onClick={() => actions.form('profile-import')}><Download size={17} />Importar perfiles de MikroTik</button>}{page === 'clients' && capabilities.secretImport === true && canNetwork && <button className="button" onClick={() => actions.form('secret-import')}><Download size={17} />Importar secrets de MikroTik</button>}{canCreate && <button className="button primary" onClick={() => actions.form(page === 'invoices' ? 'invoice' : page === 'payments' ? 'payment' : page)}><Plus size={17} />{page === 'keys' ? 'Crear clave' : page === 'payments' ? 'Registrar pago' : `Nuevo ${meta.singular}`}</button>}</div><section className="panel"><header className="table-toolbar"><div className="inline-gap"><h2 className="panel-title">{meta.title}</h2><span className="count-pill">{data.count}</span></div><div className="inline-gap"><SearchBox value={search} onChange={setSearch} label={`Buscar ${meta.title.toLowerCase()}`} />{filters[page] && <select aria-label="Filtrar por estado" value={status} onChange={event => setStatus(event.target.value)}><option value="">Todos los estados</option>{filters[page]?.map(value => <option key={value} value={value}>{value === 'ACTIVE' ? 'Activo' : value === 'SUSPENDED' ? 'Suspendido' : value === 'RETIRED' ? 'Retirado' : value === 'OPEN' ? 'Abierto' : value === 'PAID' ? 'Pagada' : value === 'VOID' ? 'Anulada' : value === 'QUEUED' ? 'En cola' : value === 'RUNNING' ? 'En proceso' : value === 'SUCCEEDED' ? 'Completada' : value === 'FAILED' ? 'Falló' : value === 'IN_PROGRESS' ? 'En atención' : value === 'RESOLVED' ? 'Resuelto' : 'Cerrado'}</option>)}</select>}<button className="icon-button" aria-label="Actualizar listado" onClick={() => setTick(value => value + 1)}><RefreshCw size={17} className={loading ? 'spinner' : ''} /></button></div></header>{selection.length > 0 && !readOnly && <div className="panel-body inline-gap"><strong>{selection.length} seleccionados</strong>{extensions && <button className="button small" onClick={() => actions.action('bulk:diagnostics', undefined, selection)}>Diagnóstico masivo</button>}<button className="button small" onClick={() => actions.action('bulk:sync', undefined, selection)}>Sincronizar</button><button className="button small danger" onClick={() => actions.action('bulk:suspend', undefined, selection)}>Suspender</button><button className="button small" onClick={() => actions.action('bulk:reactivate', undefined, selection)}>Reactivar</button></div>}{error && <div className="alert error" role="alert">{error}<button className="button small ghost" onClick={() => setTick(value => value + 1)}>Reintentar</button></div>}{loading && data.results.length === 0 ? <Loading /> : data.results.length ? <><div className="table-wrap"><table className="data-table"><thead><tr>{page === 'services' && canChangeNetwork && <th className="check-cell"><input aria-label="Seleccionar todos los servicios de esta página" type="checkbox" checked={data.results.length > 0 && data.results.every(row => selection.includes(row.id))} onChange={event => setSelection(event.target.checked ? data.results.map(row => row.id) : [])} /></th>}{tableColumns.map(column => <th key={column.label}>{column.label}</th>)}<th className="right">Acciones</th></tr></thead><tbody>{data.results.map(row => <tr key={row.id}>{page === 'services' && canChangeNetwork && <td className="check-cell"><input aria-label={`Seleccionar ${text(row.ipAddress)}`} type="checkbox" checked={selection.includes(row.id)} onChange={event => setSelection(old => event.target.checked ? [...old, row.id] : old.filter(id => id !== row.id))} /></td>}{tableColumns.map(column => <td key={column.label} className={column.className}>{column.render(row)}</td>)}<td><div className="table-actions"><button className="icon-button" title="Ver detalle" aria-label="Ver detalle" onClick={() => actions.details(page, row)}><MoreHorizontal size={18} /></button>{canCreate && !['invoices', 'payments', 'keys'].includes(page) && <button className="icon-button" title="Editar" aria-label="Editar" onClick={() => actions.form(page, row)}><Pencil size={16} /></button>}{page === 'services' && canNetwork && row.desiredState !== 'RETIRED' && <><button className="icon-button" title="Diagnóstico en tiempo real" aria-label="Diagnóstico en tiempo real" onClick={() => actions.action('diagnostics', row)}><Activity size={17} /></button>{!readOnly && <><button className="icon-button" title="Sincronizar servicio" aria-label="Sincronizar servicio" onClick={() => actions.action('sync', row)}><RefreshCw size={16} /></button><button className={`button small ${row.desiredState === 'SUSPENDED' ? '' : 'danger'}`} onClick={() => actions.action(row.desiredState === 'SUSPENDED' ? 'reactivate' : 'suspend', row)}>{row.desiredState === 'SUSPENDED' ? 'Reactivar' : 'Suspender'}</button></>}</>}{page === 'routers' && canNetwork && <button className="button small" onClick={() => actions.action('router-test', row)}>Probar</button>}{page === 'invoices' && canBilling && row.status === 'OPEN' && <button className="button small" onClick={() => actions.form('payment', { id: '', invoiceId: row.id, amount: ((Number(row.amountCents) - Number(row.paidCents)) / 100).toFixed(2), currency: row.currency })}>Cobrar</button>}{page === 'keys' && !row.revokedAt && <button className="icon-button" title="Revocar clave" aria-label="Revocar clave" onClick={() => actions.action('revoke-key', row)}><Trash2 size={16} /></button>}{page === 'tasks' && canRetry(user.role, row.kind) && (!readOnly || ['DIAGNOSTIC', 'ROUTER_TEST'].includes(String(row.kind))) && row.status === 'FAILED' && <button className="button small" onClick={() => actions.action('retry-task', row)}>Reintentar</button>}</div></td></tr>)}</tbody></table></div><Pagination page={pageNumber} pageSize={15} count={data.count} change={setPageNumber} /></> : !error && <EmptyState icon={<Icon size={26} />} title={query || status ? 'No encontramos coincidencias' : `Aún no hay ${meta.title.toLowerCase()}`} description={query || status ? 'Prueba con otro término o cambia los filtros.' : 'Los registros que agregues aparecerán aquí.'} action={canCreate ? <button className="button" onClick={() => actions.form(page === 'invoices' ? 'invoice' : page === 'payments' ? 'payment' : page)}><Plus size={16} />Crear el primero</button> : undefined} />}</section>{page === 'keys' && <div className="alert info"><KeyRound size={18} /><span>Las claves se muestran una sola vez. Usa <code>Authorization: Api-Key &lt;TOKEN&gt;</code> en tu integración y revoca las que ya no necesites.</span></div>}{page === 'routers' && <div className="alert info"><Server size={18} /><span>Prueba la conexión antes de provisionar servicios. Cada router debe permitir acceso desde el backend mediante una red privada o VPN y credenciales con los permisos adecuados.</span></div>}{page === 'plans' && capabilities.profileImport === true && <RouterProfiles refresh={refresh + tick} canEdit={user.role === 'ADMIN'} editPlan={row => actions.form('plans', row)} />}</>;
}
