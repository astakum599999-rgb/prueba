# API propia de NexoISP para XAMPP v2

Base local: `http://localhost/nexoisp/api/v1`. Los cuerpos son JSON. Los importes se expresan como enteros en centavos y cada moneda usa tres letras mayúsculas. Las fechas de calendario usan `YYYY-MM-DD`; los instantes recibidos requieren zona horaria (`Z` o desplazamiento). La persistencia y los informes usan UTC.

El administrador crea claves personales desde **Claves de API**. Una integración envía `Authorization: Api-Key <TOKEN>`; hereda el rol de su propietario y puede revocarse. El inicio web utiliza cookies HttpOnly; las escrituras con sesión requieren que `Origin` coincida con el configurado durante la instalación. El portal de clientes tiene su propia sesión y sus rutas no aceptan una clave administrativa como identidad de cliente.

Los listados usan `page`, `pageSize` (máximo 100) y, donde corresponde, `search`. Responden `{results, count, page, pageSize}`. Los errores contienen `{error:{code,message}}`. Es un contrato propio; no ofrece compatibilidad completa con las rutas ni los JSON de WispHub.

## Recursos administrativos

| Ruta | Operaciones y propósito |
| --- | --- |
| `/auth/login`, `/auth/me`, `/auth/logout` | Entrar con correo y contraseña, consultar sesión y salir. |
| `/clients`, `/plans`, `/routers`, `/services` | Listar, crear y consultar recursos; `PATCH /:id` para edición permitida. El retiro y las operaciones de red mantienen el historial. |
| `/routers/:id/test` | Encolar prueba de conexión. No devuelve contraseñas guardadas. |
| `/services/:id/diagnostics` | Diagnóstico desde el router mediante tarea. |
| `/services/:id/traffic` | Leer muestras reales guardadas y sus fechas. La ausencia de muestras no se rellena con tráfico simulado. |
| `/network/bulk-diagnostics` | `POST {ids:[serviceId,...]}`: diagnóstico por servicio, hasta 100 identificadores únicos. |
| `/tasks`, `/tasks/:id` | Consultar cola y resultados; las operaciones continúan en el worker. |
| `/invoices`, `/payments`, `/tickets` | Facturación, registro validado de pagos y soporte. El pago genera reconciliación de la red cuando corresponde. |
| `/users`, `/keys`, `/audit` | Personal y roles, claves revocables y auditoría, según permisos. |

Las acciones de red son asíncronas. Un trabajo aceptado no demuestra que el router ya lo aplicó: debe comprobarse el resultado final en **Operaciones de red**. El worker reintenta fallos y conserva su diagnóstico. Una factura pagada no cancela una suspensión manual.

## Ampliaciones de facturación

Administración y facturación pueden escribir estos recursos; los usuarios técnicos y de lectura conservan únicamente los permisos de consulta definidos por cada módulo.

| Ruta | Cuerpo de creación o comportamiento |
| --- | --- |
| `/service-charges` | `{serviceId,name,quantity,unitCents,recurrence}`; frecuencia `MONTHLY` o `ONE_TIME`. Los cargos únicos se consumen junto con su factura en una transacción. |
| `/service-discounts` | `{serviceId,name,kind,value,startOn,endOn}`. `FIXED` usa centavos; `PERCENT` usa puntos básicos (1000 = 10 %). Un descuento activo por servicio; no vuelve negativa la base del plan. |
| `/payment-promises` | `{invoiceId,amountCents,currency,promisedUntil}`. La fecha es inclusiva en UTC y el importe debe cubrir el saldo de esa factura. Las demás facturas vencidas siguen contando para el corte. |
| `/payment-promises/:id/cancel` | Cancelar un compromiso activo y solicitar una nueva revisión de autocorte. |
| `/billing/prorate-preview` | `{serviceId,period,startOn,endOn}`; obtener líneas y total de la primera factura proporcional sin emitirla. |
| `/billing/prorate` | Mismo cuerpo; emitir únicamente si el servicio no tiene una factura anterior. Días inclusivos del mes real, cargos adicionales completos, descuento sobre la base proporcional. |

Las líneas de facturas emitidas son instantáneas: editar un plan, un cargo o un descuento no recalcula una factura existente. Las facturas antiguas reciben una línea `LEGACY` con su importe original al actualizar.

## Clientes, contratos y pagos informados

| Ruta del personal | Comportamiento |
| --- | --- |
| `/portal-accounts` | Administración/facturación crea `{clientId,username,password}`; contraseña propia de al menos 12 caracteres. `PATCH /:id` permite cambiar usuario, contraseña o activación. |
| `/contracts` | Crear `{serviceId,title,terms}`. Guardar condiciones y datos del servicio; las condiciones de un contrato aceptado no se editan. |
| `/payment-reports` | Consultar pagos pendientes de revisión. `POST /:id/approve` registra el pago una sola vez; `POST /:id/reject {reason}` conserva el motivo. |

Portal web: `http://localhost/nexoisp/portal/`. Sus rutas son `/portal/auth/login` con `{username,password}`, `/portal/auth/me`, `/portal/auth/logout`, `/portal/summary`, `/portal/invoices`, `/portal/payments`, `/portal/tickets`, `/portal/contracts` y `/portal/payment-reports`. Todas las consultas filtran por el cliente autenticado.

El cliente puede crear tickets, comentar los suyos, informar un pago con `{invoiceId,amountCents,currency,reference,note}` y aceptar un contrato mediante `POST /portal/contracts/:id/accept {name}`. Informar un pago no lo acredita: requiere aprobación del personal. La aceptación con nombre escrito registra una constancia, sin firma certificada.

Impresión: `/nexoisp/portal/documento.php?type=invoice|receipt|contract&id=...`, con la sesión correspondiente y control de propiedad. El navegador permite imprimir o guardar PDF. Las facturas y recibos son documentos administrativos, sin timbrado fiscal ni conexión bancaria.

## Caja, inventario, agenda e informes

| Ruta | Contrato principal |
| --- | --- |
| `/company-settings` | Perfil comercial del ISP; solo ADMIN lo modifica. |
| `/cash-accounts` | `{name,currency,openingCents}`; moneda y saldo inicial no se reescriben. |
| `/cash-movements` | `{accountId,type,amountCents,category,description,occurredAt?,paymentId?}`; `INCOME` o `EXPENSE`. Vincular un pago requiere importe y moneda exactos. |
| `/cash-movements/:id/reverse` | `POST {reason}`: contrapartida inmutable; no borra ni altera el movimiento inicial. |
| `/cash-transfers` | `{fromAccountId,toAccountId,amountCents,description,externalReference}`; dos asientos atómicos de igual moneda y referencia idempotente. |
| `/inventory-assets` | `{name,category,serialNumber?,macAddress?,brand?,model?,location?,costCents,currency}`; equipos individuales con historial de estados. |
| `/inventory-assets/:id/assign` | `{clientId,note?}`; acciones `/return`, `/repair`, `/retire` conservan movimientos y validan transiciones. |
| `/inventory-movements` | Historial de entrega, devolución y estados del equipo. |
| `/installations` | Cliente o prospecto, dirección, zona/GPS, técnico, fecha, plan/router previsto, estimado y notas. Estados `REQUESTED`, `SCHEDULED`, `IN_PROGRESS`, `COMPLETED`, `CANCELLED`. Una visita completada no provisiona automáticamente un servicio. |
| `/reports?from=...&to=...` | Facturación y cobros del intervalo, agrupados por moneda; cartera pendiente y vencida actual, cuentas y zonas. No reconstruye saldos históricos. |
| `/exports/clients.csv`, `/services.csv`, `/invoices.csv`, `/payments.csv`, `/tickets.csv`, `/cash.csv`, `/inventory.csv` | Prefijo común `/exports/` en cada nombre; columnas autorizadas, hasta 50 000 filas, sin contraseñas y con protección de fórmulas de hoja de cálculo. |

Los roles ADMIN/BILLING operan caja; VIEWER puede consultarla y TECHNICIAN no accede a sus recursos financieros. Inventario e instalaciones admiten trabajo de técnicos. El control se verifica en el servidor, independientemente de los botones visibles.

El código completo de cada contrato está en `app/api.php`, `portal.php`, `billing.php`, `finance.php` y `operations.php`. No se incluyen adaptadores ficticios para proveedores externos. El alcance comparado y las fuentes consultadas están en `MATRIZ-WISPHUB.md` y `REFERENCIAS-WISPHUB.md`.
