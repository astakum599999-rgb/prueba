# Alcance de NexoISP 2 respecto a WispHub

NexoISP es una implementación propia para PHP/XAMPP. La revisión del manual y la API públicos se recoge en [REFERENCIAS-WISPHUB.md](REFERENCIAS-WISPHUB.md). Esta matriz describe el código entregado; no afirma identidad del producto, sus pantallas ni compatibilidad completa con su API privada.

| Área | Funcionalidad entregada | Límites concretos |
| --- | --- | --- |
| Acceso del personal | Sesiones, claves `Authorization: Api-Key`, cuatro roles y auditoría. | No reproduce todos los permisos ni endpoints de WispHub; una empresa por despliegue. |
| Clientes y servicios | Documento RFC/DNI, contacto, GPS, zona, estados, planes, IP/MAC y router. | No incluye un CRM completo, multiempresa o importación automática de bases de terceros. |
| MikroTik | API Socket v6/v7, REST v7, PPPoE, Simple Queue, Queue Tree, DHCP e IP Bindings Hotspot. | Protocolos probados con servidores controlados; requiere validar firmware, perfiles, FastTrack y reglas del router real. |
| Cola y cortes | Tareas persistentes MySQL, worker PHP, reintentos, estados deseado/aplicado, autocorte y reconexión. | El equipo y el worker deben permanecer activos; no usa Redis ni registra un servicio de Windows automáticamente. |
| Portal del cliente | Acceso independiente a servicios, facturas, pagos, soporte y contratos propios. | Cuentas creadas por el personal; no hay registro público ni acceso a datos de otros clientes. |
| Pagos informados | Reporte del cliente, aprobación/rechazo y pago idempotente al aprobar. | Un reporte no acredita dinero ni reconecta por sí solo; no hay banco o pasarela preconfigurada. |
| Contratos | Condiciones, copia de datos del servicio, aceptación con nombre/fecha y documento imprimible. | No es firma electrónica certificada ni validación legal automática. |
| Facturación | Periodos, vencimiento, gracia, pagos parciales y desglose persistente por conceptos. | Documentos internos; sin CFDI, SUNAT, DIAN ni contabilidad fiscal certificada. |
| Cargos y descuentos | Conceptos únicos/mensuales, cantidades y descuento fijo o porcentual con vigencia. | Un descuento activo por servicio; no se recalculan facturas emitidas al modificar el catálogo. |
| Prorrateo | Vista previa y primera factura mensual proporcional por días. | No reproduce todas las variantes de prepago, postpago o cambio de calendario de la referencia. |
| Promesas de pago | Compromiso por factura, monto, vigencia, cancelación y revisión de autocorte. | Debe cubrir la deuda aplicable; no equivale a un pago ni elimina otras facturas vencidas. |
| Caja y gastos | Cuentas por moneda, ingresos, egresos, transferencias y contrapartidas con historial. | Registro interno manual; transferencias en la misma moneda y vinculación de pago a caja explícita, una vez por pago. |
| Inventario | Equipos por serie/MAC, asignación, devolución, reparación y retiro. | Sin compras, proveedores, stock fungible masivo ni ERP de almacenes. |
| Instalaciones | Agenda de clientes/prospectos, ubicación, técnico, plan, router, estados y notas. | Completar una visita no provisiona el servicio ni factura una instalación automáticamente. |
| Soporte | Tickets, prioridades, asignación y comentarios del personal o cliente autorizado. | Sin conectores de correo, chat, WhatsApp ni SLA automatizado de terceros. |
| Tráfico y diagnóstico | Ping desde RouterOS y muestras conservadas durante 30 días. | No es colector continuo NetFlow/SNMP ni genera tráfico ficticio para llenar gráficas. |
| Reportes y documentos | Cartera, facturación/recaudación por fechas, monedas, CSV y documentos imprimibles. | CSV de hasta 50 000 filas; PDF mediante impresión del navegador, sin certificación fiscal. |
| Empresa | Nombre, contacto, documento y notas para documentos del ISP. | Un perfil de empresa por instalación; sin integración tributaria. |
| Actualización | Migraciones SHA-256, bloqueo MySQL y conservación de configuración/claves. | Requiere respaldo; MariaDB confirma DDL por sentencia y no hay rollback global de esta actualización. |

No se incluyen integraciones con OLT, TR-069, RADIUS, fichas Hotspot de venta masiva, televisión, bancos, procesadores de tarjetas o mensajería. Requieren implementaciones, contratos y credenciales específicos; un webhook genérico o registro manual no constituye una conexión verificada con ellos.

La redirección de corte se limita a HTTP. No intercepta HTTPS ni configura por sí sola el servidor donde se publica `/nexoisp/portal/`.

Las pruebas y sus límites se describen en [PRUEBAS.txt](PRUEBAS.txt). No se entregan código privado, identidad gráfica ni datos de clientes de WispHub.
