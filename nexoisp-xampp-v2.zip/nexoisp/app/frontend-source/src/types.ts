export type Role = 'ADMIN' | 'BILLING' | 'TECHNICIAN' | 'VIEWER';
export interface User { id: string; name: string; email: string; role: Role; active?: boolean; createdAt?: string }
export interface Capabilities { simulatedRouters: boolean; browserWorker?: boolean; extensions?: boolean }
export interface Client { id: string; code: string; name: string; email?: string | null; phone?: string | null; document?: string | null; address?: string | null; latitude?: number | null; longitude?: number | null; zone?: string | null; status: string; createdAt: string; services?: Service[]; invoices?: Invoice[] }
export interface Plan { id: string; name: string; downloadKbps: number; uploadKbps: number; queueParent: string; priority: number; pppoeProfile: string; priceCents: number; currency: string; active: boolean }
export interface Router { id: string; name: string; host: string; port: number; transport: 'SOCKET' | 'REST' | 'SIMULATED'; username: string; useTls: boolean; verifyTls: boolean; cutAddressList: string; cutProfile: string; paymentPortalIp?: string | null; paymentPortalPort: number; dhcpServer: string; hotspotServer: string; online: boolean | null; lastSeenAt?: string | null; lastError?: string | null }
export interface Service { id: string; clientId: string; planId: string; routerId: string; type: string; ipAddress: string; macAddress?: string | null; username?: string | null; desiredState: string; appliedState?: string | null; syncStatus: string; revision: number; lastSyncAt?: string | null; lastError?: string | null; billingDay: number; dueDays: number; graceDays: number; client?: Client; plan?: Plan; router?: Router }
export interface Invoice { id: string; number: string; clientId: string; serviceId: string; period: string; amountCents: number; paidCents: number; currency: string; status: string; issuedAt: string; dueAt: string; graceUntil: string; client?: Client; service?: Service; payments?: Payment[]; lines?: InvoiceLine[] }
export interface Payment { id: string; invoiceId: string; amountCents: number; provider: string; externalReference: string; receivedAt: string; invoice?: Invoice }
export interface TicketComment { id: string; authorName: string; body: string; createdAt: string }
export interface Ticket { id: string; clientId: string; assigneeId?: string | null; subject: string; body: string; status: string; priority: string; createdAt: string; updatedAt: string; client?: Client; assignee?: User | null; comments?: TicketComment[] }
export interface Task { id: string; kind: string; status: string; payload: Record<string, unknown>; result?: unknown; error?: string | null; attempts: number; createdAt: string; updatedAt: string; completedAt?: string | null }
export interface ApiKey { id: string; label: string; prefix: string; expiresAt?: string | null; revokedAt?: string | null; lastUsedAt?: string | null; createdAt: string }
export interface Audit { id: string; action: string; entityType: string; entityId?: string | null; user?: User | null; createdAt: string; details?: unknown }
export interface PageResult<T> { results: T[]; count: number; page: number; pageSize: number }
export interface Dashboard { counts: { clients: number; activeClients: number; suspendedClients: number; services: number; routers: number; onlineRouters: number; openTickets: number; pendingTasks: number }; billing: { currency: string; invoicedCents: number; paidCents: number; outstandingCents: number }[]; recentInvoices: Invoice[]; recentTasks: Task[] }
export interface TrafficPoint { at: number; rx: number; tx: number; simulated?: boolean }
export type BasePageName = 'dashboard' | 'clients' | 'services' | 'plans' | 'routers' | 'invoices' | 'payments' | 'tickets' | 'tasks' | 'users' | 'keys' | 'audit';

export type ExtensionPageName = 'portal-accounts' | 'payment-reports' | 'contracts' | 'payment-promises' | 'service-charges' | 'service-discounts' | 'inventory-assets' | 'inventory-movements' | 'installations' | 'cash-accounts' | 'cash-movements' | 'reports' | 'company-settings';
export type PageName = BasePageName | ExtensionPageName;
export interface InvoiceLine { id?: string; description?: string; name?: string; quantity: number; unitCents: number; amountCents?: number; totalCents?: number; currency?: string; type?: string; kind?: string }
