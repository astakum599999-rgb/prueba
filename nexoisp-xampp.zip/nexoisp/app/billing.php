<?php
declare(strict_types=1);

namespace Nexo;

use DateTimeImmutable;
use DateTimeZone;
use PDO;

/** All financial arithmetic uses integer minor currency units. */
function paymentBalance(int $amountCents, int $paidCents, int $paymentCents): array
{
    if ($amountCents < 0 || $paidCents < 0 || $paymentCents <= 0) {
        throw new HttpError(400, 'Los importes deben ser enteros positivos en centavos.');
    }
    if ($paidCents > $amountCents || $paymentCents > $amountCents - $paidCents) {
        throw new HttpError(409, 'El pago supera el saldo pendiente.');
    }
    $total = $paidCents + $paymentCents;
    return ['paidCents' => $total, 'status' => $total === $amountCents ? 'PAID' : 'OPEN'];
}

function billingNow(): DateTimeImmutable
{
    return new DateTimeImmutable('now', new DateTimeZone('UTC'));
}

function billingDate(string $value): DateTimeImmutable
{
    return new DateTimeImmutable($value, new DateTimeZone('UTC'));
}

function invoiceDates(string $period, int $billingDay, int $dueDays, int $graceDays, DateTimeImmutable $createdAt, ?DateTimeImmutable $at = null): ?array
{
    $at ??= billingNow();
    if (!preg_match('/^\d{4}-(0[1-9]|1[0-2])$/D', $period)) {
        throw new HttpError(400, 'Periodo inválido; use YYYY-MM.');
    }
    if ($billingDay < 1 || $billingDay > 28 || $dueDays < 0 || $dueDays > 365 || $graceDays < 0 || $graceDays > 365) {
        throw new HttpError(400, 'Calendario de facturación inválido.');
    }
    $start = billingDate($period . '-01 00:00:00');
    $end = $start->modify('+1 month');
    if ($createdAt >= $end || $start > $at) {
        return null;
    }
    $scheduled = billingDate($period . '-' . str_pad((string) $billingDay, 2, '0', STR_PAD_LEFT) . ' 00:00:00');
    $issuedAt = $createdAt > $scheduled ? $createdAt : $scheduled;
    if ($issuedAt > $at) {
        return null;
    }
    $dueAt = $issuedAt->modify('+' . $dueDays . ' days');
    return [
        'issuedAt' => $issuedAt->format('Y-m-d H:i:s.v'),
        'dueAt' => $dueAt->format('Y-m-d H:i:s.v'),
        'graceUntil' => $dueAt->modify('+' . $graceDays . ' days')->format('Y-m-d H:i:s.v'),
    ];
}

function billingPeriods(DateTimeImmutable $createdAt, ?DateTimeImmutable $at = null): array
{
    $at ??= billingNow();
    $cursor = billingDate($createdAt->format('Y-m') . '-01 00:00:00');
    $last = billingDate($at->format('Y-m') . '-01 00:00:00');
    $periods = [];
    while ($cursor <= $last) {
        $periods[] = $cursor->format('Y-m');
        $cursor = $cursor->modify('+1 month');
    }
    return $periods;
}

function verifyWebhookSignature(string $secret, ?string $timestamp, ?string $signature, string $rawBody, ?int $at = null): bool
{
    if ($secret === '' || $timestamp === null || $signature === null ||
        !preg_match('/^\d{10}$/D', $timestamp) || !preg_match('/^[a-fA-F0-9]{64}$/D', $signature)) {
        return false;
    }
    if (abs(($at ?? time()) - (int) $timestamp) > 300) {
        return false;
    }
    return hash_equals(hash_hmac('sha256', $timestamp . '.' . $rawBody, $secret), strtolower($signature));
}

function billingWithLocks(array $keys, callable $callback): mixed
{
    $acquired = [];
    try {
        foreach (array_values(array_unique($keys)) as $key) {
            if (!lock($key, 10)) {
                throw new HttpError(503, 'La operación está ocupada. Inténtelo de nuevo.');
            }
            $acquired[] = $key;
        }
        return $callback();
    } finally {
        foreach (array_reverse($acquired) as $key) {
            unlock($key);
        }
    }
}

function billingService(string $serviceId): ?array
{
    $service = fetchOne('SELECT * FROM `Service` WHERE id = ?', [$serviceId]);
    if ($service === null) {
        return null;
    }
    $service['plan'] = fetchOne('SELECT * FROM `Plan` WHERE id = ?', [$service['planId']]);
    $service['client'] = fetchOne('SELECT * FROM `Client` WHERE id = ?', [$service['clientId']]);
    return $service;
}

/** Called within a transaction holding the client's named lock. */
function requestReconnection(string $serviceId, ?DateTimeImmutable $at = null): array
{
    $at ??= billingNow();
    $service = billingService($serviceId);
    if ($service === null || $service['client']['status'] === 'RETIRED' ||
        $service['desiredState'] !== 'SUSPENDED' || $service['suspensionReason'] !== 'BILLING') {
        return [];
    }
    $overdue = fetchOne("SELECT COUNT(*) AS n FROM `Invoice` WHERE serviceId = ? AND status = 'OPEN' AND graceUntil <= ?", [$serviceId, $at->format('Y-m-d H:i:s.v')]);
    if ((int) $overdue['n'] > 0) {
        return [];
    }
    $statement = db()->prepare("UPDATE `Service` SET desiredState = 'ACTIVE', suspensionReason = NULL, syncStatus = 'PENDING', revision = revision + 1, lastError = NULL, updatedAt = ? WHERE id = ?");
    $statement->execute([now(), $serviceId]);
    $task = enqueue('SERVICE_SYNC', ['serviceId' => $serviceId, 'source' => 'payment']);
    // Client status is reconciled only after the router confirms connectivity.
    return [$task['id']];
}

function makeInvoice(array $service, string $period, DateTimeImmutable $at, ?string $actorId = null): ?array
{
    $dates = invoiceDates($period, (int) $service['billingDay'], (int) $service['dueDays'], (int) $service['graceDays'], billingDate($service['createdAt']), $at);
    if ($dates === null) {
        return null;
    }
    $existing = fetchOne('SELECT * FROM `Invoice` WHERE serviceId = ? AND period = ?', [$service['id'], $period]);
    if ($existing !== null) {
        return ['invoice' => $existing, 'created' => false];
    }
    $invoiceId = id();
    $amount = (int) $service['plan']['priceCents'];
    $statement = db()->prepare('INSERT INTO `Invoice` (id, number, clientId, serviceId, period, amountCents, paidCents, currency, status, issuedAt, dueAt, graceUntil, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?, ?, 0, ?, ?, ?, ?, ?, ?, ?)');
    $statement->execute([
        $invoiceId, 'NX-' . str_replace('-', '', $period) . '-' . strtoupper($service['id']),
        $service['clientId'], $service['id'], $period, $amount, $service['plan']['currency'],
        $amount === 0 ? 'PAID' : 'OPEN', $dates['issuedAt'], $dates['dueAt'], $dates['graceUntil'], now(), now(),
    ]);
    audit('invoice.create', 'Invoice', $invoiceId, $actorId);
    return ['invoice' => fetchOne('SELECT * FROM `Invoice` WHERE id = ?', [$invoiceId]), 'created' => true];
}

/** Missing monthly periods are backfilled; issued invoices retain their snapshots. */
function generateInvoices(?DateTimeImmutable $at = null): array
{
    $at ??= billingNow();
    $cursor = '';
    $created = 0;
    $examinedServices = 0;
    while (true) {
        $services = fetchAll("SELECT s.id, s.clientId FROM `Service` s JOIN `Client` c ON c.id = s.clientId WHERE s.id > ? AND s.desiredState <> 'RETIRED' AND c.status <> 'RETIRED' ORDER BY s.id LIMIT 100", [$cursor]);
        if ($services === []) {
            break;
        }
        foreach ($services as $entry) {
            if (function_exists(__NAMESPACE__ . '\\workerTouchLease')) {
                workerTouchLease();
            }
            $created += billingWithLocks(['billing:' . $entry['id'], 'client:' . $entry['clientId']], function () use ($entry, $at): int {
                return tx(function (PDO $pdo) use ($entry, $at): int {
                    $service = billingService($entry['id']);
                    if ($service === null || $service['desiredState'] === 'RETIRED' || $service['client']['status'] === 'RETIRED') {
                        return 0;
                    }
                    $existing = array_fill_keys(array_column(fetchAll('SELECT period FROM `Invoice` WHERE serviceId = ?', [$service['id']]), 'period'), true);
                    $added = 0;
                    foreach (billingPeriods(billingDate($service['createdAt']), $at) as $period) {
                        if (!isset($existing[$period])) {
                            $result = makeInvoice($service, $period, $at);
                            if ($result !== null && $result['created']) {
                                $added++;
                            }
                        }
                    }
                    return $added;
                });
            });
            $examinedServices++;
        }
        $cursor = $services[array_key_last($services)]['id'];
    }
    return ['created' => $created, 'examinedServices' => $examinedServices];
}

function runAutocut(?DateTimeImmutable $at = null): array
{
    $at ??= billingNow();
    $cursor = '';
    $taskIds = [];
    $suspended = 0;
    while (true) {
        $candidates = fetchAll("SELECT i.id, i.serviceId, i.clientId FROM `Invoice` i JOIN `Service` s ON s.id = i.serviceId JOIN `Client` c ON c.id = s.clientId WHERE i.id > ? AND i.status = 'OPEN' AND i.graceUntil <= ? AND s.desiredState = 'ACTIVE' AND c.status <> 'RETIRED' ORDER BY i.id LIMIT 200", [$cursor, $at->format('Y-m-d H:i:s.v')]);
        if ($candidates === []) {
            break;
        }
        foreach ($candidates as $candidate) {
            if (function_exists(__NAMESPACE__ . '\\workerTouchLease')) {
                workerTouchLease();
            }
            $taskId = billingWithLocks(['client:' . $candidate['clientId']], function () use ($candidate, $at): ?string {
                return tx(function (PDO $pdo) use ($candidate, $at): ?string {
                    $service = billingService($candidate['serviceId']);
                    if ($service === null || $service['desiredState'] !== 'ACTIVE' || $service['client']['status'] === 'RETIRED') {
                        return null;
                    }
                    $outstanding = fetchOne("SELECT COUNT(*) AS n FROM `Invoice` WHERE serviceId = ? AND status = 'OPEN' AND graceUntil <= ?", [$service['id'], $at->format('Y-m-d H:i:s.v')]);
                    if ((int) $outstanding['n'] === 0) {
                        return null;
                    }
                    $statement = db()->prepare("UPDATE `Service` SET desiredState = 'SUSPENDED', suspensionReason = 'BILLING', syncStatus = 'PENDING', revision = revision + 1, lastError = NULL, updatedAt = ? WHERE id = ?");
                    $statement->execute([now(), $service['id']]);
                    $task = enqueue('SERVICE_SYNC', ['serviceId' => $service['id'], 'source' => 'autocut']);
                    audit('billing.autocut', 'Service', $service['id']);
                    return $task['id'];
                });
            });
            if ($taskId !== null) {
                $suspended++;
                if (count($taskIds) < 1000) {
                    $taskIds[] = $taskId;
                }
            }
        }
        $cursor = $candidates[array_key_last($candidates)]['id'];
    }
    return ['suspensionTaskIds' => $taskIds, 'suspended' => $suspended, 'truncated' => $suspended > count($taskIds)];
}

/** Transaction and client/reference locks are owned by registerPayment. */
function applyPayment(array $input, ?string $actorId = null): array
{
    $invoice = fetchOne('SELECT * FROM `Invoice` WHERE id = ? FOR UPDATE', [$input['invoiceId']]);
    if ($invoice === null) {
        throw new HttpError(404, 'Factura no encontrada.');
    }
    if ($invoice['currency'] !== $input['currency']) {
        throw new HttpError(409, 'La moneda del pago no coincide con la factura.');
    }
    $existing = fetchOne('SELECT * FROM `Payment` WHERE provider = ? AND externalReference = ?', [$input['provider'], $input['externalReference']]);
    if ($existing !== null) {
        if ($existing['invoiceId'] !== $input['invoiceId'] || (int) $existing['amountCents'] !== $input['amountCents']) {
            throw new HttpError(409, 'La referencia ya corresponde a un pago diferente.');
        }
        return ['payment' => $existing, 'invoice' => $invoice, 'replayed' => true, 'reconnectionTaskIds' => []];
    }
    if ($invoice['status'] === 'VOID') {
        throw new HttpError(409, 'No se pueden pagar facturas anuladas.');
    }
    if ($invoice['status'] === 'PAID') {
        throw new HttpError(409, 'La factura ya está pagada.');
    }
    $balance = paymentBalance((int) $invoice['amountCents'], (int) $invoice['paidCents'], $input['amountCents']);
    $paymentId = id();
    $statement = db()->prepare('INSERT INTO `Payment` (id, invoiceId, amountCents, provider, externalReference, receivedAt) VALUES (?, ?, ?, ?, ?, ?)');
    $statement->execute([$paymentId, $invoice['id'], $input['amountCents'], $input['provider'], $input['externalReference'], now()]);
    $statement = db()->prepare('UPDATE `Invoice` SET paidCents = ?, status = ?, updatedAt = ? WHERE id = ?');
    $statement->execute([$balance['paidCents'], $balance['status'], now(), $invoice['id']]);
    $taskIds = requestReconnection($invoice['serviceId']);
    audit('payment.register', 'Payment', $paymentId, $actorId);
    return [
        'payment' => fetchOne('SELECT * FROM `Payment` WHERE id = ?', [$paymentId]),
        'invoice' => fetchOne('SELECT * FROM `Invoice` WHERE id = ?', [$invoice['id']]),
        'replayed' => false, 'reconnectionTaskIds' => $taskIds,
    ];
}

function registerPayment(array $input, ?string $actorId = null, ?array $event = null): array
{
    $initial = fetchOne('SELECT clientId FROM `Invoice` WHERE id = ?', [$input['invoiceId']]);
    if ($initial === null) {
        throw new HttpError(404, 'Factura no encontrada.');
    }
    $keys = [];
    if ($event !== null) {
        $keys[] = 'webhook:' . $input['provider'] . ':' . $event['eventId'];
    }
    $keys[] = 'payment:' . $input['provider'] . ':' . $input['externalReference'];
    $keys[] = 'client:' . $initial['clientId'];
    return billingWithLocks($keys, function () use ($input, $actorId, $event): array {
        return tx(function (PDO $pdo) use ($input, $actorId, $event): array {
            $prior = null;
            if ($event !== null) {
                $prior = fetchOne('SELECT * FROM `WebhookEvent` WHERE provider = ? AND eventId = ?', [$input['provider'], $event['eventId']]);
                if ($prior !== null && !hash_equals($prior['bodyHash'], $event['bodyHash'])) {
                    throw new HttpError(409, 'El evento ya corresponde a un contenido diferente.');
                }
            }
            $result = applyPayment($input, $actorId);
            if ($event !== null && $prior === null) {
                $eventId = id();
                $statement = db()->prepare('INSERT INTO `WebhookEvent` (id, provider, eventId, bodyHash, createdAt) VALUES (?, ?, ?, ?, ?)');
                $statement->execute([$eventId, $input['provider'], $event['eventId'], $event['bodyHash'], now()]);
                audit('webhook.accept', 'WebhookEvent', $eventId);
            }
            return $result;
        });
    });
}

function billingInput(array $input, array $required, array $allowed): void
{
    foreach ($required as $field) {
        if (!array_key_exists($field, $input)) {
            throw new HttpError(400, 'Falta el campo ' . $field . '.');
        }
    }
    foreach (array_keys($input) as $field) {
        if (!in_array($field, $allowed, true)) {
            throw new HttpError(400, 'Campo no permitido: ' . $field . '.');
        }
    }
}

function billingId(mixed $value): string
{
    if (!is_string($value) || !preg_match('/^[A-Za-z0-9_-]{1,128}$/D', $value)) {
        throw new HttpError(400, 'Identificador inválido.');
    }
    return $value;
}

function paymentInput(array $input, bool $webhook = false): array
{
    $fields = ['invoiceId', 'amountCents', 'currency', 'provider', 'externalReference'];
    if ($webhook) {
        $fields[] = 'eventId';
    }
    billingInput($input, $fields, $fields);
    $input['invoiceId'] = billingId($input['invoiceId']);
    if ((!is_int($input['amountCents']) && !is_float($input['amountCents'])) ||
        !is_finite((float) $input['amountCents']) || floor((float) $input['amountCents']) !== (float) $input['amountCents'] ||
        $input['amountCents'] < 1 || $input['amountCents'] > 2147483647) {
        throw new HttpError(400, 'amountCents debe ser un entero positivo en centavos.');
    }
    $input['amountCents'] = (int) $input['amountCents'];
    if (!is_string($input['currency']) || !preg_match('/^[A-Z]{3}$/D', $input['currency'])) {
        throw new HttpError(400, 'Moneda inválida; use tres letras mayúsculas.');
    }
    if (!is_string($input['provider']) || !preg_match('/^[A-Za-z0-9_-]{1,80}$/D', $input['provider'])) {
        throw new HttpError(400, 'Proveedor de pago inválido.');
    }
    foreach ($webhook ? ['externalReference', 'eventId'] : ['externalReference'] as $field) {
        if (!is_string($input[$field]) || trim($input[$field]) === '' || strlen($input[$field]) > 180) {
            throw new HttpError(400, 'Referencia de pago o evento inválida.');
        }
        $input[$field] = trim($input[$field]);
    }
    return $input;
}

function billingPaging(): array
{
    $values = [];
    foreach (['page' => [1, 100000], 'pageSize' => [20, 100]] as $field => [$default, $maximum]) {
        $value = $_GET[$field] ?? (string) $default;
        if (!is_scalar($value) || !preg_match('/^[0-9]{1,6}$/D', (string) $value) || (int) $value < 1 || (int) $value > $maximum) {
            throw new HttpError(400, 'Paginación inválida.');
        }
        $values[$field] = (int) $value;
    }
    return [$values['page'], $values['pageSize'], ($values['page'] - 1) * $values['pageSize']];
}

function billingQuery(string $field, int $max = 128): ?string
{
    if (!isset($_GET[$field]) || $_GET[$field] === '') {
        return null;
    }
    if (!is_string($_GET[$field]) || strlen($_GET[$field]) > $max) {
        throw new HttpError(400, 'Filtro inválido: ' . $field . '.');
    }
    return $_GET[$field];
}

function invoicePublic(array $invoice): array
{
    $client = fetchOne('SELECT id, code, name, document FROM `Client` WHERE id = ?', [$invoice['clientId']]);
    $service = fetchOne('SELECT id, type, ipAddress, planId FROM `Service` WHERE id = ?', [$invoice['serviceId']]);
    if ($service !== null) {
        $service['plan'] = fetchOne('SELECT id, name FROM `Plan` WHERE id = ?', [$service['planId']]);
        unset($service['planId']);
    }
    $invoice['client'] = $client;
    $invoice['service'] = $service;
    return $invoice;
}

/** Return false only for routes owned by another module; json() terminates. */
function billingDispatch(string $method, string $route): bool
{
    if ($method === 'POST' && $route === '/webhooks/payments') {
        $input = body();
        $raw = $GLOBALS['nexo_raw_body'] ?? '';
        $secret = (string) config('payment_webhook_secret', '');
        if ($secret === '') {
            throw new HttpError(503, 'El webhook de pagos no está configurado.');
        }
        if (!is_string($raw) || !verifyWebhookSignature($secret, $_SERVER['HTTP_X_WEBHOOK_TIMESTAMP'] ?? null, $_SERVER['HTTP_X_WEBHOOK_SIGNATURE'] ?? null, $raw)) {
            throw new HttpError(401, 'Firma de webhook inválida o expirada.');
        }
        $input = paymentInput($input, true);
        $event = ['eventId' => $input['eventId'], 'bodyHash' => hash('sha256', $raw)];
        unset($input['eventId']);
        $result = registerPayment($input, null, $event);
        json($result, $result['replayed'] ? 200 : 201);
    }
    if ($route === '/invoices' && $method === 'GET') {
        requireAuth();
        [$page, $pageSize, $offset] = billingPaging();
        $conditions = [];
        $params = [];
        if (($status = billingQuery('status')) !== null) {
            if (!in_array($status, ['OPEN', 'PAID', 'VOID'], true)) {
                throw new HttpError(400, 'Estado de factura inválido.');
            }
            $conditions[] = 'i.status = ?';
            $params[] = $status;
        }
        foreach (['clientId', 'serviceId'] as $field) {
            if (($value = billingQuery($field)) !== null) {
                $conditions[] = 'i.' . $field . ' = ?';
                $params[] = billingId($value);
            }
        }
        if (($q = billingQuery('q', 120)) !== null) {
            $conditions[] = '(i.number LIKE ? OR c.name LIKE ?)';
            $params[] = '%' . $q . '%';
            $params[] = '%' . $q . '%';
        }
        $where = $conditions === [] ? '' : ' WHERE ' . implode(' AND ', $conditions);
        $from = ' FROM `Invoice` i JOIN `Client` c ON c.id = i.clientId';
        $count = (int) fetchOne('SELECT COUNT(*) AS n' . $from . $where, $params)['n'];
        $results = fetchAll('SELECT i.*' . $from . $where . ' ORDER BY i.issuedAt DESC, i.id DESC LIMIT ' . $pageSize . ' OFFSET ' . $offset, $params);
        json(['results' => array_map(__NAMESPACE__ . '\\invoicePublic', $results), 'count' => $count, 'page' => $page, 'pageSize' => $pageSize]);
    }
    if ($route === '/invoices' && $method === 'POST') {
        $user = permit('ADMIN', 'BILLING');
        $input = body();
        billingInput($input, ['serviceId'], ['serviceId', 'period']);
        $serviceId = billingId($input['serviceId']);
        $period = $input['period'] ?? billingNow()->format('Y-m');
        if (!is_string($period) || !preg_match('/^\d{4}-(0[1-9]|1[0-2])$/D', $period)) {
            throw new HttpError(400, 'Periodo inválido; use YYYY-MM.');
        }
        $initial = fetchOne('SELECT clientId FROM `Service` WHERE id = ?', [$serviceId]);
        if ($initial === null) {
            throw new HttpError(404, 'Servicio no encontrado.');
        }
        $result = billingWithLocks(['billing:' . $serviceId, 'client:' . $initial['clientId']], function () use ($serviceId, $period, $user): array {
            return tx(function (PDO $pdo) use ($serviceId, $period, $user): array {
                $service = billingService($serviceId);
                if ($service === null || $service['desiredState'] === 'RETIRED' || $service['client']['status'] === 'RETIRED') {
                    throw new HttpError(409, 'El servicio está retirado.');
                }
                $result = makeInvoice($service, $period, billingNow(), $user['id']);
                if ($result === null) {
                    throw new HttpError(409, 'El periodo todavía no vence para facturar o es anterior al alta del servicio.');
                }
                return $result;
            });
        });
        json(invoicePublic($result['invoice']), $result['created'] ? 201 : 200);
    }
    if (preg_match('#^/invoices/([A-Za-z0-9_-]+)/void$#D', $route, $matches) && $method === 'POST') {
        $user = permit('ADMIN', 'BILLING');
        $invoiceId = billingId($matches[1]);
        $initial = fetchOne('SELECT clientId FROM `Invoice` WHERE id = ?', [$invoiceId]);
        if ($initial === null) {
            throw new HttpError(404, 'Factura no encontrada.');
        }
        $result = billingWithLocks(['client:' . $initial['clientId']], function () use ($invoiceId, $user): array {
            return tx(function (PDO $pdo) use ($invoiceId, $user): array {
                $invoice = fetchOne('SELECT * FROM `Invoice` WHERE id = ? FOR UPDATE', [$invoiceId]);
                if ($invoice === null) {
                    throw new HttpError(404, 'Factura no encontrada.');
                }
                if ((int) $invoice['paidCents'] > 0) {
                    throw new HttpError(409, 'Una factura con pagos no se puede anular.');
                }
                db()->prepare("UPDATE `Invoice` SET status = 'VOID', updatedAt = ? WHERE id = ?")->execute([now(), $invoiceId]);
                $taskIds = requestReconnection($invoice['serviceId']);
                audit('invoice.void', 'Invoice', $invoiceId, $user['id']);
                return ['invoice' => fetchOne('SELECT * FROM `Invoice` WHERE id = ?', [$invoiceId]), 'reconnectionTaskIds' => $taskIds];
            });
        });
        json($result);
    }
    if (preg_match('#^/invoices/([A-Za-z0-9_-]+)$#D', $route, $matches) && $method === 'GET') {
        requireAuth();
        $invoice = fetchOne('SELECT * FROM `Invoice` WHERE id = ?', [billingId($matches[1])]);
        if ($invoice === null) {
            throw new HttpError(404, 'Factura no encontrada.');
        }
        $invoice = invoicePublic($invoice);
        $invoice['payments'] = fetchAll('SELECT * FROM `Payment` WHERE invoiceId = ? ORDER BY receivedAt DESC, id DESC', [$invoice['id']]);
        json($invoice);
    }
    if ($route === '/payments' && $method === 'GET') {
        requireAuth();
        [$page, $pageSize, $offset] = billingPaging();
        $conditions = [];
        $params = [];
        if (($invoiceId = billingQuery('invoiceId')) !== null) {
            $conditions[] = 'p.invoiceId = ?';
            $params[] = billingId($invoiceId);
        }
        if (($q = billingQuery('q', 120)) !== null) {
            $conditions[] = '(p.externalReference LIKE ? OR c.name LIKE ?)';
            $params[] = '%' . $q . '%';
            $params[] = '%' . $q . '%';
        }
        $where = $conditions === [] ? '' : ' WHERE ' . implode(' AND ', $conditions);
        $from = ' FROM `Payment` p JOIN `Invoice` i ON i.id = p.invoiceId JOIN `Client` c ON c.id = i.clientId';
        $count = (int) fetchOne('SELECT COUNT(*) AS n' . $from . $where, $params)['n'];
        $results = fetchAll('SELECT p.*, i.number AS invoiceNumber, i.currency AS invoiceCurrency, i.clientId AS invoiceClientId, c.name AS clientName' . $from . $where . ' ORDER BY p.receivedAt DESC, p.id DESC LIMIT ' . $pageSize . ' OFFSET ' . $offset, $params);
        foreach ($results as &$payment) {
            $payment['invoice'] = ['id' => $payment['invoiceId'], 'number' => $payment['invoiceNumber'], 'currency' => $payment['invoiceCurrency'], 'client' => ['id' => $payment['invoiceClientId'], 'name' => $payment['clientName']]];
            unset($payment['invoiceNumber'], $payment['invoiceCurrency'], $payment['invoiceClientId'], $payment['clientName']);
        }
        unset($payment);
        json(['results' => $results, 'count' => $count, 'page' => $page, 'pageSize' => $pageSize]);
    }
    if ($route === '/payments' && $method === 'POST') {
        $user = permit('ADMIN', 'BILLING');
        $result = registerPayment(paymentInput(body()), $user['id']);
        json($result, $result['replayed'] ? 200 : 201);
    }
    if ($method === 'POST' && in_array($route, ['/billing/run', '/billing/autocut'], true)) {
        $user = permit('ADMIN', 'BILLING');
        $task = enqueue($route === '/billing/run' ? 'BILLING_RUN' : 'AUTOCUT_RUN', ['requestedBy' => $user['id']]);
        json($task, 202);
    }
    return false;
}
