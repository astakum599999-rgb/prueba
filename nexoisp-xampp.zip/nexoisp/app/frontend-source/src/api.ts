import type { PageResult } from './types';

export class ApiError extends Error {
  constructor(public status: number, message: string, public code?: string) { super(message); }
}

function resolveApiBase(): string {
  const configured = document.querySelector<HTMLMetaElement>('meta[name="nexoisp-api-base"]')?.content.trim();
  if (!configured) return '/api/v1';
  const resolved = new URL(configured, window.location.origin);
  if (resolved.origin !== window.location.origin || resolved.search || resolved.hash) throw new Error('La ruta de API debe pertenecer al mismo sitio y no contener parámetros.');
  return resolved.pathname.replace(/\/+$/, '');
}

export const apiBase = resolveApiBase();

export async function api<T>(path: string, options: RequestInit = {}): Promise<T> {
  const response = await fetch(`${apiBase}${path}`, {
    ...options,
    credentials: 'same-origin',
    headers: { ...(options.body ? { 'Content-Type': 'application/json' } : {}), ...options.headers },
  });
  const value = response.status === 204 ? undefined : await response.json().catch(() => undefined);
  if (!response.ok) {
    const message = typeof value?.error === 'string' ? value.error : value?.error?.message || value?.message || `La solicitud falló (${response.status}).`;
    if (response.status === 401) window.dispatchEvent(new Event('nexoisp:unauthorized'));
    throw new ApiError(response.status, message, value?.error?.code || value?.code);
  }
  return value as T;
}

export const post = <T>(path: string, data: unknown = {}) => api<T>(path, { method: 'POST', body: JSON.stringify(data) });
export const patch = <T>(path: string, data: unknown) => api<T>(path, { method: 'PATCH', body: JSON.stringify(data) });
export const remove = <T>(path: string) => api<T>(path, { method: 'DELETE' });

export async function choices<T>(path: string): Promise<T[]> {
  const result: T[] = [];
  let page = 1;
  while (true) {
    const response = await api<PageResult<T>>(`${path}?page=${page}&pageSize=100`);
    result.push(...response.results);
    if (result.length >= response.count || response.results.length === 0) return result;
    page += 1;
  }
}
