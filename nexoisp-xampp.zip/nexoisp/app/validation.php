<?php
declare(strict_types=1);
namespace Nexo;

function validationSchemas(): array
{
    $text = ['type' => 'string', 'min' => 1, 'max' => 200, 'trim' => true];
    $nullableText = ['type' => 'string', 'max' => 500, 'nullable' => true, 'trim' => true];
    $identifier = ['type' => 'string', 'min' => 1, 'max' => 128];
    $integer = ['type' => 'integer', 'min' => 0, 'max' => 100000000];
    return [
        'login' => [
            'email' => ['type' => 'email', 'required' => true, 'lowercase' => true, 'max' => 254],
            'password' => ['type' => 'string', 'required' => true, 'min' => 1, 'max' => 128],
        ],
        'client' => [
            'code' => array_merge($text, ['required' => true, 'max' => 40]),
            'name' => $text + ['required' => true],
            'email' => ['type' => 'email', 'max' => 254, 'nullable' => true],
            'phone' => $nullableText, 'document' => $nullableText, 'address' => $nullableText,
            'latitude' => ['type' => 'number', 'min' => -90, 'max' => 90, 'nullable' => true],
            'longitude' => ['type' => 'number', 'min' => -180, 'max' => 180, 'nullable' => true],
            'zone' => $nullableText,
        ],
        'plan' => [
            'name' => $text + ['required' => true],
            'downloadKbps' => array_merge($integer, ['required' => true, 'min' => 1, 'max' => 10000000]),
            'uploadKbps' => array_merge($integer, ['required' => true, 'min' => 1, 'max' => 10000000]),
            'queueParent' => $text + ['default' => 'global'],
            'priority' => ['type' => 'integer', 'min' => 1, 'max' => 8, 'default' => 8],
            'pppoeProfile' => $text + ['default' => 'default'],
            'priceCents' => $integer + ['required' => true],
            'currency' => ['type' => 'string', 'pattern' => '/^[A-Z]{3}$/D', 'default' => 'USD'],
            'active' => ['type' => 'boolean', 'default' => true],
        ],
        'router' => [
            'name' => $text + ['required' => true],
            'host' => ['type' => 'host', 'required' => true, 'max' => 253],
            'port' => ['type' => 'integer', 'min' => 1, 'max' => 65535],
            'transport' => ['type' => 'enum', 'values' => ['SOCKET', 'REST', 'SIMULATED'], 'default' => 'REST'],
            'username' => $text + ['required' => true],
            'password' => ['type' => 'string', 'required' => true, 'min' => 1, 'max' => 200],
            'useTls' => ['type' => 'boolean', 'default' => true],
            'verifyTls' => ['type' => 'boolean', 'only' => true, 'default' => true],
            'cutAddressList' => ['type' => 'string', 'pattern' => '/^[A-Za-z0-9_.-]{1,63}$/D', 'default' => 'CORTE_WISPHUB'],
            'cutProfile' => $text + ['default' => 'Perfil_Corte'],
            'paymentPortalIp' => ['type' => 'ipv4', 'nullable' => true],
            'paymentPortalPort' => ['type' => 'integer', 'min' => 1, 'max' => 65535, 'default' => 80],
            'dhcpServer' => $text + ['default' => 'all'], 'hotspotServer' => $text + ['default' => 'all'],
        ],
        'service' => [
            'clientId' => $identifier + ['required' => true], 'planId' => $identifier + ['required' => true], 'routerId' => $identifier + ['required' => true],
            'type' => ['type' => 'enum', 'values' => ['PPPOE', 'SIMPLE_QUEUE', 'QUEUE_TREE', 'IP_MAC', 'HOTSPOT', 'DHCP'], 'required' => true],
            'ipAddress' => ['type' => 'ipv4', 'required' => true],
            'macAddress' => ['type' => 'string', 'pattern' => '/^(?:[a-fA-F0-9]{2}:){5}[a-fA-F0-9]{2}$/D', 'uppercase' => true, 'nullable' => true],
            'username' => ['type' => 'string', 'min' => 1, 'max' => 100, 'trim' => true, 'nullable' => true],
            'password' => ['type' => 'string', 'min' => 1, 'max' => 200],
            'billingDay' => ['type' => 'integer', 'min' => 1, 'max' => 28, 'default' => 1],
            'dueDays' => ['type' => 'integer', 'min' => 0, 'max' => 90, 'default' => 10],
            'graceDays' => ['type' => 'integer', 'min' => 0, 'max' => 90, 'default' => 3],
        ],
        'ticket' => [
            'clientId' => $identifier + ['required' => true], 'assigneeId' => $identifier + ['nullable' => true],
            'subject' => $text + ['required' => true], 'body' => ['type' => 'string', 'min' => 1, 'max' => 20000, 'trim' => true, 'required' => true],
            'priority' => ['type' => 'enum', 'values' => ['LOW', 'NORMAL', 'HIGH', 'URGENT'], 'default' => 'NORMAL'],
            'status' => ['type' => 'enum', 'values' => ['OPEN', 'IN_PROGRESS', 'RESOLVED', 'CLOSED'], 'default' => 'OPEN'],
        ],
        'user' => [
            'name' => $text + ['required' => true],
            'email' => ['type' => 'email', 'required' => true, 'lowercase' => true, 'max' => 254],
            'password' => ['type' => 'string', 'required' => true, 'min' => 12, 'max' => 128],
            'role' => ['type' => 'enum', 'values' => ['ADMIN', 'BILLING', 'TECHNICIAN', 'VIEWER'], 'default' => 'VIEWER'],
            'active' => ['type' => 'boolean', 'default' => true],
        ],
        'key' => [
            'label' => ['type' => 'string', 'min' => 1, 'max' => 100, 'trim' => true, 'required' => true],
            'expiresAt' => ['type' => 'datetime'],
        ],
        'comment' => ['body' => ['type' => 'string', 'min' => 1, 'max' => 20000, 'trim' => true, 'required' => true]],
    ];
}

function validate(string $entity, array $input, bool $patch = false): array
{
    $schema = validationSchemas()[$entity] ?? throw new \LogicException('Esquema no definido');
    foreach (array_keys($input) as $field) {
        if (!is_string($field) || !array_key_exists($field, $schema)) throw new HttpError(422, 'Campo no permitido: ' . (is_string($field) ? $field : 'índice'), 'VALIDATION_ERROR');
    }
    $output = [];
    foreach ($schema as $field => $rule) {
        if (!array_key_exists($field, $input)) {
            if (!$patch && array_key_exists('default', $rule)) $output[$field] = $rule['default'];
            elseif (!$patch && ($rule['required'] ?? false)) throw new HttpError(422, 'Campo obligatorio: ' . $field, 'VALIDATION_ERROR');
            continue;
        }
        $value = $input[$field];
        if ($value === null && ($rule['nullable'] ?? false)) { $output[$field] = null; continue; }
        $valid = match ($rule['type']) {
            'integer' => is_int($value) || is_float($value) && is_finite($value) && floor($value) === $value,
            'number' => is_int($value) || is_float($value),
            'boolean' => is_bool($value),
            default => is_string($value),
        };
        if (!$valid) throw new HttpError(422, 'Tipo inválido: ' . $field, 'VALIDATION_ERROR');
        if ($rule['type'] === 'integer') $value = (int)$value;
        if (is_string($value)) {
            if ($rule['trim'] ?? false) $value = trim($value);
            if ($rule['lowercase'] ?? false) $value = strtolower($value);
            if ($rule['uppercase'] ?? false) $value = strtoupper($value);
            $length = function_exists('mb_strlen') ? mb_strlen($value, 'UTF-8') : strlen($value);
            if (isset($rule['min']) && $length < $rule['min'] || isset($rule['max']) && $length > $rule['max']) throw new HttpError(422, 'Longitud inválida: ' . $field, 'VALIDATION_ERROR');
            if (isset($rule['pattern']) && preg_match($rule['pattern'], $value) !== 1) throw new HttpError(422, 'Formato inválido: ' . $field, 'VALIDATION_ERROR');
        }
        if ((is_int($value) || is_float($value)) && (isset($rule['min']) && $value < $rule['min'] || isset($rule['max']) && $value > $rule['max'] || !is_finite((float)$value))) throw new HttpError(422, 'Valor fuera de rango: ' . $field, 'VALIDATION_ERROR');
        if (isset($rule['values']) && !in_array($value, $rule['values'], true)) throw new HttpError(422, 'Valor inválido: ' . $field, 'VALIDATION_ERROR');
        if (array_key_exists('only', $rule) && $value !== $rule['only']) throw new HttpError(422, 'No se permite desactivar la verificación TLS', 'VALIDATION_ERROR');
        if ($rule['type'] === 'email' && !filter_var($value, FILTER_VALIDATE_EMAIL)) throw new HttpError(422, 'Email inválido', 'VALIDATION_ERROR');
        if ($rule['type'] === 'ipv4' && !filter_var($value, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) throw new HttpError(422, 'IPv4 inválida: ' . $field, 'VALIDATION_ERROR');
        if ($rule['type'] === 'host' && preg_match('/^(?=.{1,253}$)[A-Za-z0-9](?:[A-Za-z0-9.-]*[A-Za-z0-9])?$/D', $value) !== 1) throw new HttpError(422, 'Host inválido', 'VALIDATION_ERROR');
        if ($rule['type'] === 'datetime' && (preg_match('/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})$/D', $value) !== 1 || strtotime($value) === false)) throw new HttpError(422, 'Fecha ISO inválida', 'VALIDATION_ERROR');
        $output[$field] = $value;
    }
    return $output;
}

function pagination(): array
{
    $page = filter_var($_GET['page'] ?? '1', FILTER_VALIDATE_INT, ['options' => ['min_range' => 1, 'max_range' => 100000]]);
    $size = filter_var($_GET['pageSize'] ?? '20', FILTER_VALIDATE_INT, ['options' => ['min_range' => 1, 'max_range' => 100]]);
    $search = $_GET['search'] ?? $_GET['q'] ?? '';
    if ($page === false || $size === false || !is_string($search) || strlen($search) > 400) throw new HttpError(422, 'Paginación o búsqueda inválida', 'VALIDATION_ERROR');
    return ['page' => $page, 'pageSize' => $size, 'offset' => ($page - 1) * $size, 'search' => trim($search)];
}

function queryEnum(string $name, array $values): ?string
{
    if (!array_key_exists($name, $_GET)) return null;
    $value = $_GET[$name];
    if (!is_string($value) || !in_array($value, $values, true)) throw new HttpError(422, 'Filtro inválido: ' . $name, 'VALIDATION_ERROR');
    return $value;
}
