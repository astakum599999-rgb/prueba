<?php
declare(strict_types=1);

// This entry point only serves the compiled interface. Credentials stay in protected storage.
if (!is_file(__DIR__ . '/storage/config.php')) {
    header('Location: install.php', true, 302);
    exit;
}

$template = __DIR__ . '/app/index.html';
if (!is_file($template)) {
    http_response_code(503);
    header('Content-Type: text/plain; charset=utf-8');
    echo "Falta la interfaz compilada. Extrae de nuevo el paquete completo NexoISP para XAMPP.";
    exit;
}

$scriptName = str_replace('\\', '/', (string) ($_SERVER['SCRIPT_NAME'] ?? '/index.php'));
$basePath = rtrim(str_replace('\\', '/', dirname($scriptName)), '/.');
if ($basePath === '/' || $basePath === '.') {
    $basePath = '';
}
$apiBase = htmlspecialchars($basePath . '/api/v1', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
$html = file_get_contents($template);
if ($html === false) {
    http_response_code(503);
    header('Content-Type: text/plain; charset=utf-8');
    echo 'No se puede leer la interfaz compilada de NexoISP.';
    exit;
}

header('Content-Type: text/html; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: same-origin');
header('X-Frame-Options: DENY');
echo str_replace('</head>', '<meta name="nexoisp-api-base" content="' . $apiBase . '"></head>', $html);
